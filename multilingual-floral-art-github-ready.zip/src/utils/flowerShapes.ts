import { EXACT_ROSE_HEAD_ROWS, EXACT_STEM_AND_LEAVES } from "/src/data/roseExactData.ts";
import { EXACT_LILY_ROWS, LILY_STAMENS, LILY_FOLIAGE } from "/src/data/lilyExactData.ts";
import { LOVE_PHRASES } from "/src/data/languages.ts";
import { getPhraseForWord } from "/src/utils/exactRoseGenerator.ts";
export const AVAILABLE_FLOWERS = [
	{
		id: "pink_rose",
		name: "Pink Rose",
		emoji: "🌸",
		description: "Sweet admiration, gentle affection & blooming grace",
		scriptName: "pink_rose.py"
	},
	{
		id: "red_rose",
		name: "Red Rose",
		emoji: "🌹",
		description: "Immortal passion, romance & lifelong commitment",
		scriptName: "red_rose.py"
	},
	{
		id: "pink_lily",
		name: "Pink Lily",
		emoji: "🌺",
		description: "6-star Stargazer lily of purity, devotion & abundance",
		scriptName: "pink_lily.py"
	},
	{
		id: "golden_sunflower",
		name: "Sunflower",
		emoji: "🌻",
		description: "Radiant warmth, loyalty, happiness & solar adoration",
		scriptName: "sunflower.py"
	},
	{
		id: "royal_tulip",
		name: "Royal Tulip",
		emoji: "🌷",
		description: "Velvet cup petals of perfect, enduring royal love",
		scriptName: "royal_tulip.py"
	},
	{
		id: "white_rose",
		name: "White Rose",
		emoji: "🤍",
		description: "Moonlit ivory blossom of eternal soulmate devotion",
		scriptName: "white_rose.py"
	}
];
// Color palettes for each flower
const PALETTES = {
	pink_rose: {
		petals: [
			"#ff2d75",
			"#ff69b4",
			"#f43f5e",
			"#fda4af",
			"#fbcfe8",
			"#ff1493"
		],
		highlights: ["#ffffff", "#fbcfe8"],
		stem: [
			"#22c55e",
			"#4ade80",
			"#10b981",
			"#86efac",
			"#16a34a"
		]
	},
	red_rose: {
		petals: [
			"#ff1744",
			"#e11d48",
			"#f43f5e",
			"#be123c",
			"#fda4af"
		],
		highlights: ["#ffffff", "#fda4af"],
		stem: [
			"#22c55e",
			"#4ade80",
			"#10b981",
			"#86efac",
			"#16a34a"
		]
	},
	pink_lily: {
		petals: [
			"#ff2d75",
			"#ec4899",
			"#f472b6",
			"#db2777",
			"#fbcfe8",
			"#fda4af"
		],
		highlights: ["#ffffff", "#fef08a"],
		stem: [
			"#22c55e",
			"#4ade80",
			"#10b981",
			"#86efac",
			"#16a34a"
		]
	},
	golden_sunflower: {
		petals: [
			"#fbbf24",
			"#f59e0b",
			"#d97706",
			"#fef08a",
			"#fde68a",
			"#b45309"
		],
		highlights: ["#ffffff", "#fef3c7"],
		stem: [
			"#65a30d",
			"#84cc16",
			"#4d7c0f",
			"#a3e635",
			"#22c55e"
		]
	},
	royal_tulip: {
		petals: [
			"#c084fc",
			"#a855f7",
			"#9333ea",
			"#e879f9",
			"#f472b6",
			"#e9d5ff"
		],
		highlights: ["#ffffff", "#f5d0fe"],
		stem: [
			"#10b981",
			"#22c55e",
			"#34d399",
			"#4ade80",
			"#059669"
		]
	},
	white_rose: {
		petals: [
			"#ffffff",
			"#f8fafc",
			"#f1f5f9",
			"#e2e8f0",
			"#cbd5e1",
			"#e0e7ff"
		],
		highlights: ["#ffffff", "#f8fafc"],
		stem: [
			"#10b981",
			"#22c55e",
			"#34d399",
			"#4ade80",
			"#059669"
		]
	}
};
/**
* Universal High-Clarity Flower Generator
* Generates horizontal, non-overlapping, well-spaced text matrices for all flower types.
*/
export function generateUnifiedFlowerElements(flowerType, width, height, customDedication) {
	const elements = [];
	const cx = width / 2;
	const cy = height * .36;
	const scale = Math.min(width, height) / 520;
	const palette = PALETTES[flowerType] || PALETTES.pink_rose;
	let phraseIdx = 0;
	const getNextPhrase = () => {
		const p = LOVE_PHRASES[phraseIdx % LOVE_PHRASES.length];
		phraseIdx++;
		return p;
	};
	let idCounter = 0;
	// 1. FOR PINK ROSE & RED ROSE & WHITE ROSE:
	// Use the exact 31-row layout from image_8b5f9f0a.png with generous spacing!
	if (flowerType === "pink_rose" || flowerType === "red_rose" || flowerType === "white_rose") {
		const headTotalRows = EXACT_ROSE_HEAD_ROWS.length;
		const headRowHeight = Math.max(13, Math.round(15.5 * scale));
		const headStartY = cy - headTotalRows * headRowHeight * .52;
		EXACT_ROSE_HEAD_ROWS.forEach((row, rowIndex) => {
			const y = Math.round(headStartY + rowIndex * headRowHeight);
			const validWords = row.filter((w) => w.text.trim().length > 0);
			if (validWords.length === 0) return;
			const wordSpans = validWords.map((w) => {
				const isLarge = w.isBold || w.isBright;
				const fontSize = Math.max(9.5, Math.round((isLarge ? 12.5 : 10.5) * scale));
				const width = Math.round(w.text.length * fontSize * .62);
				return {
					...w,
					fontSize,
					width
				};
			});
			const gap = Math.max(7, Math.round(9.5 * scale));
			const totalRowWidth = wordSpans.reduce((acc, w) => acc + w.width, 0) + (wordSpans.length - 1) * gap;
			let curX = cx - totalRowWidth / 2;
			wordSpans.forEach((w) => {
				const wordCenterX = Math.round(curX + w.width / 2);
				const phrase = getPhraseForWord(w.text);
				let color;
				if (w.isBright) {
					color = "#ffffff";
				} else if (w.isBold) {
					color = palette.petals[0];
				} else {
					color = palette.petals[idCounter % palette.petals.length];
				}
				const isDedication = rowIndex === 11 && Math.abs(wordCenterX - cx) < 30 * scale && customDedication;
				const finalText = isDedication ? `♥ ${customDedication} ♥` : w.text;
				if (isDedication) color = "#ffffff";
				elements.push({
					id: `${flowerType}-${idCounter++}`,
					phrase,
					text: finalText,
					x: wordCenterX,
					y,
					width: w.width,
					height: w.fontSize + 4,
					angle: 0,
					fontSize: w.fontSize,
					fontWeight: w.isBold || w.isBright ? "800" : "700",
					color,
					part: "petal",
					order: .35 + rowIndex / headTotalRows * .65,
					isGreen: false
				});
				curX += w.width + gap;
			});
		});
		// Append Calyx & Foliage
		appendStemAndLeaves(elements, cx, headStartY + headTotalRows * headRowHeight + 4 * scale, scale, palette.stem, idCounter);
		return elements;
	}
	// 2. FOR PINK LILY (Exact Curated Stargazer Star Petals + Golden Stamens)
	if (flowerType === "pink_lily") {
		const lilyTotalRows = EXACT_LILY_ROWS.length;
		const rowHeight = Math.max(13, Math.round(15.5 * scale));
		const startY = cy - lilyTotalRows * rowHeight * .52;
		EXACT_LILY_ROWS.forEach((row, rowIndex) => {
			const y = Math.round(startY + rowIndex * rowHeight);
			const validWords = row.filter((w) => w.text.trim().length > 0);
			if (validWords.length === 0) return;
			const wordSpans = validWords.map((w) => {
				const isLarge = w.isBold || w.isBright;
				const fontSize = Math.max(9.5, Math.round((isLarge ? 12.5 : 10.5) * scale));
				const width = Math.round(w.text.length * fontSize * .62);
				return {
					...w,
					fontSize,
					width
				};
			});
			const gap = Math.max(7, Math.round(9.5 * scale));
			const totalRowWidth = wordSpans.reduce((acc, w) => acc + w.width, 0) + (wordSpans.length - 1) * gap;
			let curX = cx - totalRowWidth / 2;
			wordSpans.forEach((w) => {
				const wordCenterX = Math.round(curX + w.width / 2);
				const phrase = getPhraseForWord(w.text);
				let color;
				if (w.isBright) {
					color = "#ffffff";
				} else if (w.isBold) {
					color = palette.petals[0];
				} else {
					color = palette.petals[idCounter % palette.petals.length];
				}
				const isDedication = rowIndex === 10 && Math.abs(wordCenterX - cx) < 30 * scale && customDedication;
				const finalText = isDedication ? `♥ ${customDedication} ♥` : w.text;
				if (isDedication) color = "#ffffff";
				elements.push({
					id: `exact-lily-${idCounter++}`,
					phrase,
					text: finalText,
					x: wordCenterX,
					y,
					width: w.width,
					height: w.fontSize + 4,
					angle: 0,
					fontSize: w.fontSize,
					fontWeight: w.isBold || w.isBright ? "800" : "700",
					color,
					part: "petal",
					order: .35 + rowIndex / lilyTotalRows * .65,
					isGreen: false
				});
				curX += w.width + gap;
			});
		});
		// Golden Stamens Arching From the Throat
		const throatY = Math.round(startY + lilyTotalRows * rowHeight * .7);
		LILY_STAMENS.forEach((stamen, idx) => {
			const radius = 95 * scale * stamen.dist;
			const angle = -Math.PI / 2 + stamen.angleOffset;
			const sx = Math.round(cx + Math.cos(angle) * radius);
			const sy = Math.round(throatY + Math.sin(angle) * (radius * .82));
			const fontSize = Math.max(10, Math.round(11 * scale));
			const width = Math.round(stamen.text.length * fontSize * .62);
			elements.push({
				id: `exact-stamen-${idCounter++}`,
				phrase: getPhraseForWord(stamen.text.replace(/✦/g, "").trim()),
				text: stamen.text,
				x: sx,
				y: sy,
				width,
				height: fontSize + 4,
				angle: 0,
				fontSize,
				fontWeight: "800",
				color: "#f59e0b",
				part: "stamen",
				order: .88 + idx / LILY_STAMENS.length * .12,
				isGreen: false
			});
		});
		// Foliage & Stem for Pink Lily
		const calyxStartY = Math.round(startY + lilyTotalRows * rowHeight + 4 * scale);
		const calyxRowH = Math.max(13, Math.round(15 * scale));
		// Calyx
		LILY_FOLIAGE.calyx.forEach((row, rIdx) => {
			const y = Math.round(calyxStartY + rIdx * calyxRowH);
			const gap = Math.max(8, Math.round(10 * scale));
			const wordSpans = row.map((w) => {
				const fontSize = Math.max(9.5, Math.round(11 * scale));
				const width = Math.round(w.text.length * fontSize * .62);
				return {
					...w,
					fontSize,
					width
				};
			});
			const totalW = wordSpans.reduce((acc, w) => acc + w.width, 0) + (wordSpans.length - 1) * gap;
			let curX = cx - totalW / 2;
			wordSpans.forEach((w) => {
				elements.push({
					id: `lily-calyx-${idCounter++}`,
					phrase: getPhraseForWord(w.text),
					text: w.text,
					x: Math.round(curX + w.width / 2),
					y,
					width: w.width,
					height: w.fontSize + 4,
					angle: 0,
					fontSize: w.fontSize,
					fontWeight: "700",
					color: palette.stem[idCounter % palette.stem.length],
					part: "stem",
					order: .3 - rIdx / 10,
					isGreen: true
				});
				curX += w.width + gap;
			});
		});
		// Upper Lanceolate Leaves
		const leafStartY = calyxStartY + calyxRowH * 2;
		LILY_FOLIAGE.upperLeaves.left.forEach((row, rIdx) => {
			const y = Math.round(leafStartY + rIdx * calyxRowH);
			const gap = Math.max(6, Math.round(8 * scale));
			const wordSpans = row.map((w) => {
				const fontSize = Math.max(9, Math.round(10.5 * scale));
				const width = Math.round(w.text.length * fontSize * .62);
				return {
					...w,
					fontSize,
					width
				};
			});
			const totalW = wordSpans.reduce((acc, w) => acc + w.width, 0) + (wordSpans.length - 1) * gap;
			let curX = cx - 12 * scale - totalW;
			wordSpans.forEach((w) => {
				elements.push({
					id: `lily-left-leaf-${idCounter++}`,
					phrase: getPhraseForWord(w.text),
					text: w.text,
					x: Math.round(curX + w.width / 2),
					y,
					width: w.width,
					height: w.fontSize + 4,
					angle: 0,
					fontSize: w.fontSize,
					fontWeight: "700",
					color: palette.stem[(rIdx + idCounter) % palette.stem.length],
					part: "leaf",
					order: .15 + rIdx / 15,
					isGreen: true
				});
				curX += w.width + gap;
			});
		});
		LILY_FOLIAGE.upperLeaves.right.forEach((row, rIdx) => {
			const y = Math.round(leafStartY + (rIdx + 1) * calyxRowH);
			const gap = Math.max(6, Math.round(8 * scale));
			const wordSpans = row.map((w) => {
				const fontSize = Math.max(9, Math.round(10.5 * scale));
				const width = Math.round(w.text.length * fontSize * .62);
				return {
					...w,
					fontSize,
					width
				};
			});
			let curX = cx + 14 * scale;
			wordSpans.forEach((w) => {
				elements.push({
					id: `lily-right-leaf-${idCounter++}`,
					phrase: getPhraseForWord(w.text),
					text: w.text,
					x: Math.round(curX + w.width / 2),
					y,
					width: w.width,
					height: w.fontSize + 4,
					angle: 0,
					fontSize: w.fontSize,
					fontWeight: "700",
					color: palette.stem[(rIdx * 2 + idCounter) % palette.stem.length],
					part: "leaf",
					order: .18 + rIdx / 15,
					isGreen: true
				});
				curX += w.width + gap;
			});
		});
		// Lower Stem
		const lowerStemStartY = leafStartY + 4 * calyxRowH;
		LILY_FOLIAGE.lowerStem.forEach((row, rIdx) => {
			const y = Math.round(lowerStemStartY + rIdx * calyxRowH);
			const gap = Math.max(6, Math.round(8 * scale));
			const wordSpans = row.map((w) => {
				const fontSize = Math.max(9, Math.round(10.5 * scale));
				const width = Math.round(w.text.length * fontSize * .62);
				return {
					...w,
					fontSize,
					width
				};
			});
			const totalW = wordSpans.reduce((acc, w) => acc + w.width, 0) + (wordSpans.length - 1) * gap;
			let curX = cx - totalW / 2;
			wordSpans.forEach((w) => {
				elements.push({
					id: `lily-stem-${idCounter++}`,
					phrase: getPhraseForWord(w.text),
					text: w.text,
					x: Math.round(curX + w.width / 2),
					y,
					width: w.width,
					height: w.fontSize + 4,
					angle: 0,
					fontSize: w.fontSize,
					fontWeight: "700",
					color: palette.stem[(rIdx + idCounter) % palette.stem.length],
					part: "stem",
					order: .05 + rIdx / 30,
					isGreen: true
				});
				curX += w.width + gap;
			});
		});
		return elements;
	}
	// 3. FOR GOLDEN SUNFLOWER (Radiant Sunburst Petals around Amber Seed Disk)
	if (flowerType === "golden_sunflower") {
		const sfTotalRows = 25;
		const rowHeight = Math.max(13, Math.round(15.5 * scale));
		const startY = cy - sfTotalRows * rowHeight * .5;
		const isInsideSunflower = (dx, dy) => {
			const dist = Math.sqrt(dx * dx + dy * dy);
			if (dist <= 65 * scale) return true;
			// Radiating sunburst ray petals
			if (dist <= 170 * scale) {
				const ang = Math.atan2(dy, dx);
				const rays = Math.abs(Math.cos(ang * 8));
				return dist <= (100 + rays * 70) * scale;
			}
			return false;
		};
		packShapeRows(elements, isInsideSunflower, startY, sfTotalRows, rowHeight, cx, scale, palette.petals, "#fef08a", getNextPhrase, idCounter, customDedication);
		appendStemAndLeaves(elements, cx, startY + sfTotalRows * rowHeight + 6 * scale, scale, palette.stem, idCounter);
		return elements;
	}
	// 4. FOR ROYAL TULIP (Graceful 3-Petal Goblet Cup)
	if (flowerType === "royal_tulip") {
		const tulipTotalRows = 24;
		const rowHeight = Math.max(13, Math.round(15.5 * scale));
		const startY = cy - tulipTotalRows * rowHeight * .5;
		const isInsideTulip = (dx, dy) => {
			if (dy >= -160 * scale && dy <= 30 * scale) {
				const t = (dy + 160 * scale) / (190 * scale);
				let maxW;
				if (t < .28) {
					// Pointed tulip tips with deep center cleft
					const cleft = Math.abs(dx) < 25 * scale ? 25 * scale * (1 - Math.abs(dx) / (25 * scale)) : 0;
					if (dy < -160 * scale + cleft) return false;
					maxW = 125 * scale * Math.sin(t / .28 * Math.PI / 2) + 15 * scale;
				} else if (t < .75) {
					maxW = 138 * scale * Math.sin(t * Math.PI * .95);
				} else {
					maxW = 138 * scale * (1 - (t - .75) / .25 * .7);
				}
				return Math.abs(dx) <= maxW;
			}
			return false;
		};
		packShapeRows(elements, isInsideTulip, startY, tulipTotalRows, rowHeight, cx, scale, palette.petals, "#f5d0fe", getNextPhrase, idCounter, customDedication);
		appendStemAndLeaves(elements, cx, startY + tulipTotalRows * rowHeight + 6 * scale, scale, palette.stem, idCounter);
		return elements;
	}
	return elements;
}
// Helper to pack rows for parametric flowers
function packShapeRows(elements, insideTest, startY, totalRows, rowHeight, cx, scale, colors, highlightColor, getNextPhrase, idCounter, customDedication) {
	const shortPhrases = [
		"LOVE",
		"AMOR",
		"사랑해",
		"爱",
		"我爱你",
		"TE AMO",
		"TI AMO",
		"Amour",
		"LIEBE",
		"أحبك"
	];
	for (let r = 0; r < totalRows; r++) {
		const y = Math.round(startY + r * rowHeight);
		const dy = y - (startY + totalRows * rowHeight / 2);
		const intervals = [];
		let curStart = null;
		const scanStep = 4 * scale;
		for (let x = cx - 210 * scale; x <= cx + 210 * scale; x += scanStep) {
			const hit = insideTest(x - cx, dy);
			if (hit) {
				if (curStart === null) curStart = x;
			} else {
				if (curStart !== null) {
					intervals.push([curStart, x - scanStep]);
					curStart = null;
				}
			}
		}
		if (curStart !== null) intervals.push([curStart, cx + 210 * scale]);
		for (const [xStart, xEnd] of intervals) {
			const span = xEnd - xStart;
			if (span < 26 * scale) continue;
			let curX = xStart + 4 * scale;
			while (curX < xEnd - 10 * scale) {
				const remaining = xEnd - curX;
				let phrase = getNextPhrase();
				let text = phrase.phrase;
				if (remaining < 65 * scale && text.length > 7) {
					text = shortPhrases[idCounter % shortPhrases.length];
				}
				const isProminent = idCounter % 6 === 0 || text === "LOVE" || text === "TE AMO" || text === "AMOR";
				const fontSize = Math.max(9.5, Math.round((isProminent ? 12.5 : 10.5) * scale));
				const estimatedWidth = Math.round(text.length * fontSize * .62);
				if (curX + estimatedWidth <= xEnd + 4 * scale) {
					const wordCenterX = Math.round(curX + estimatedWidth / 2);
					const isCenter = Math.abs(wordCenterX - cx) < 28 * scale && Math.abs(dy) < 18 * scale && customDedication;
					const finalText = isCenter ? `♥ ${customDedication} ♥` : text;
					let color;
					if (isCenter) {
						color = "#ffffff";
					} else if (isProminent) {
						color = highlightColor;
					} else {
						color = colors[idCounter % colors.length];
					}
					elements.push({
						id: `flower-word-${idCounter++}`,
						phrase,
						text: finalText,
						x: wordCenterX,
						y,
						width: estimatedWidth,
						height: fontSize + 4,
						angle: 0,
						fontSize,
						fontWeight: isProminent || isCenter ? "800" : "700",
						color,
						part: "petal",
						order: .35 + r / totalRows * .65,
						isGreen: false
					});
					curX += estimatedWidth + Math.max(7, Math.round(9.5 * scale));
				} else {
					break;
				}
			}
		}
	}
}
// Helper to append exact green stem and leaves
function appendStemAndLeaves(elements, cx, startY, scale, stemColors, idCounter) {
	const rowH = Math.max(13, Math.round(15 * scale));
	// 1. Calyx
	EXACT_STEM_AND_LEAVES.calyx.forEach((row, rIdx) => {
		const y = Math.round(startY + rIdx * rowH);
		const gap = Math.max(8, Math.round(10 * scale));
		const wordSpans = row.map((w) => {
			const fontSize = Math.max(9.5, Math.round(11 * scale));
			const width = Math.round(w.text.length * fontSize * .62);
			return {
				...w,
				fontSize,
				width
			};
		});
		const totalW = wordSpans.reduce((acc, w) => acc + w.width, 0) + (wordSpans.length - 1) * gap;
		let curX = cx - totalW / 2;
		wordSpans.forEach((w) => {
			elements.push({
				id: `calyx-${idCounter++}`,
				phrase: getPhraseForWord(w.text),
				text: w.text,
				x: Math.round(curX + w.width / 2),
				y,
				width: w.width,
				height: w.fontSize + 4,
				angle: 0,
				fontSize: w.fontSize,
				fontWeight: "700",
				color: stemColors[idCounter % stemColors.length],
				part: "stem",
				order: .3 - rIdx / 10,
				isGreen: true
			});
			curX += w.width + gap;
		});
	});
	// 2. Left Leaf
	const leftLeafStartY = startY + rowH * 3;
	EXACT_STEM_AND_LEAVES.leftLeaf.forEach((row, rIdx) => {
		const y = Math.round(leftLeafStartY + rIdx * rowH);
		const gap = Math.max(6, Math.round(8 * scale));
		const wordSpans = row.map((w) => {
			const fontSize = Math.max(9, Math.round(10.5 * scale));
			const width = Math.round(w.text.length * fontSize * .62);
			return {
				...w,
				fontSize,
				width
			};
		});
		const totalW = wordSpans.reduce((acc, w) => acc + w.width, 0) + (wordSpans.length - 1) * gap;
		let curX = cx - 12 * scale - totalW;
		wordSpans.forEach((w) => {
			elements.push({
				id: `left-leaf-${idCounter++}`,
				phrase: getPhraseForWord(w.text),
				text: w.text,
				x: Math.round(curX + w.width / 2),
				y,
				width: w.width,
				height: w.fontSize + 4,
				angle: 0,
				fontSize: w.fontSize,
				fontWeight: "700",
				color: stemColors[(rIdx + idCounter) % stemColors.length],
				part: "leaf",
				order: .15 + rIdx / 15,
				isGreen: true
			});
			curX += w.width + gap;
		});
	});
	// 3. Right Leaf
	const rightLeafStartY = leftLeafStartY + rowH * 2;
	EXACT_STEM_AND_LEAVES.rightLeaf.forEach((row, rIdx) => {
		const y = Math.round(rightLeafStartY + rIdx * rowH);
		const gap = Math.max(6, Math.round(8 * scale));
		const wordSpans = row.map((w) => {
			const fontSize = Math.max(9, Math.round(10.5 * scale));
			const width = Math.round(w.text.length * fontSize * .62);
			return {
				...w,
				fontSize,
				width
			};
		});
		let curX = cx + 14 * scale;
		wordSpans.forEach((w) => {
			elements.push({
				id: `right-leaf-${idCounter++}`,
				phrase: getPhraseForWord(w.text),
				text: w.text,
				x: Math.round(curX + w.width / 2),
				y,
				width: w.width,
				height: w.fontSize + 4,
				angle: 0,
				fontSize: w.fontSize,
				fontWeight: "700",
				color: stemColors[(rIdx * 2 + idCounter) % stemColors.length],
				part: "leaf",
				order: .18 + rIdx / 15,
				isGreen: true
			});
			curX += w.width + gap;
		});
	});
	// 4. Lower Stem Column
	const lowerStemStartY = leftLeafStartY + EXACT_STEM_AND_LEAVES.leftLeaf.length * rowH;
	EXACT_STEM_AND_LEAVES.lowerStem.forEach((row, rIdx) => {
		const y = Math.round(lowerStemStartY + rIdx * rowH);
		const gap = Math.max(6, Math.round(8 * scale));
		const wordSpans = row.map((w) => {
			const fontSize = Math.max(9, Math.round(10.5 * scale));
			const width = Math.round(w.text.length * fontSize * .62);
			return {
				...w,
				fontSize,
				width
			};
		});
		const totalW = wordSpans.reduce((acc, w) => acc + w.width, 0) + (wordSpans.length - 1) * gap;
		let curX = cx - totalW / 2;
		wordSpans.forEach((w) => {
			elements.push({
				id: `lower-stem-${idCounter++}`,
				phrase: getPhraseForWord(w.text),
				text: w.text,
				x: Math.round(curX + w.width / 2),
				y,
				width: w.width,
				height: w.fontSize + 4,
				angle: 0,
				fontSize: w.fontSize,
				fontWeight: "700",
				color: stemColors[(rIdx + idCounter) % stemColors.length],
				part: "stem",
				order: .05 + rIdx / 30,
				isGreen: true
			});
			curX += w.width + gap;
		});
	});
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxzQkFBc0IsNkJBQTZCO0FBQzVELFNBQVMsaUJBQWlCLGNBQWMsb0JBQW9CO0FBQzVELFNBQVMsb0JBQWdDO0FBRXpDLFNBQVMsd0JBQXdCO0FBWWpDLE9BQU8sTUFBTSxvQkFBc0M7Q0FDakQ7RUFDRSxJQUFJO0VBQ0osTUFBTTtFQUNOLE9BQU87RUFDUCxhQUFhO0VBQ2IsWUFBWTtDQUNkO0NBQ0E7RUFDRSxJQUFJO0VBQ0osTUFBTTtFQUNOLE9BQU87RUFDUCxhQUFhO0VBQ2IsWUFBWTtDQUNkO0NBQ0E7RUFDRSxJQUFJO0VBQ0osTUFBTTtFQUNOLE9BQU87RUFDUCxhQUFhO0VBQ2IsWUFBWTtDQUNkO0NBQ0E7RUFDRSxJQUFJO0VBQ0osTUFBTTtFQUNOLE9BQU87RUFDUCxhQUFhO0VBQ2IsWUFBWTtDQUNkO0NBQ0E7RUFDRSxJQUFJO0VBQ0osTUFBTTtFQUNOLE9BQU87RUFDUCxhQUFhO0VBQ2IsWUFBWTtDQUNkO0NBQ0E7RUFDRSxJQUFJO0VBQ0osTUFBTTtFQUNOLE9BQU87RUFDUCxhQUFhO0VBQ2IsWUFBWTtDQUNkO0FBQ0Y7O0FBR0EsTUFBTSxXQUEyRjtDQUMvRixXQUFXO0VBQ1QsUUFBUTtHQUFDO0dBQVc7R0FBVztHQUFXO0dBQVc7R0FBVztFQUFTO0VBQ3pFLFlBQVksQ0FBQyxXQUFXLFNBQVM7RUFDakMsTUFBTTtHQUFDO0dBQVc7R0FBVztHQUFXO0dBQVc7RUFBUztDQUM5RDtDQUNBLFVBQVU7RUFDUixRQUFRO0dBQUM7R0FBVztHQUFXO0dBQVc7R0FBVztFQUFTO0VBQzlELFlBQVksQ0FBQyxXQUFXLFNBQVM7RUFDakMsTUFBTTtHQUFDO0dBQVc7R0FBVztHQUFXO0dBQVc7RUFBUztDQUM5RDtDQUNBLFdBQVc7RUFDVCxRQUFRO0dBQUM7R0FBVztHQUFXO0dBQVc7R0FBVztHQUFXO0VBQVM7RUFDekUsWUFBWSxDQUFDLFdBQVcsU0FBUztFQUNqQyxNQUFNO0dBQUM7R0FBVztHQUFXO0dBQVc7R0FBVztFQUFTO0NBQzlEO0NBQ0Esa0JBQWtCO0VBQ2hCLFFBQVE7R0FBQztHQUFXO0dBQVc7R0FBVztHQUFXO0dBQVc7RUFBUztFQUN6RSxZQUFZLENBQUMsV0FBVyxTQUFTO0VBQ2pDLE1BQU07R0FBQztHQUFXO0dBQVc7R0FBVztHQUFXO0VBQVM7Q0FDOUQ7Q0FDQSxhQUFhO0VBQ1gsUUFBUTtHQUFDO0dBQVc7R0FBVztHQUFXO0dBQVc7R0FBVztFQUFTO0VBQ3pFLFlBQVksQ0FBQyxXQUFXLFNBQVM7RUFDakMsTUFBTTtHQUFDO0dBQVc7R0FBVztHQUFXO0dBQVc7RUFBUztDQUM5RDtDQUNBLFlBQVk7RUFDVixRQUFRO0dBQUM7R0FBVztHQUFXO0dBQVc7R0FBVztHQUFXO0VBQVM7RUFDekUsWUFBWSxDQUFDLFdBQVcsU0FBUztFQUNqQyxNQUFNO0dBQUM7R0FBVztHQUFXO0dBQVc7R0FBVztFQUFTO0NBQzlEO0FBQ0Y7Ozs7O0FBTUEsT0FBTyxTQUFTLDhCQUNkLFlBQ0EsT0FDQSxRQUNBLGtCQUNxQjtDQUNyQixNQUFNLFdBQWdDLENBQUM7Q0FDdkMsTUFBTSxLQUFLLFFBQVE7Q0FDbkIsTUFBTSxLQUFLLFNBQVM7Q0FDcEIsTUFBTSxRQUFRLEtBQUssSUFBSSxPQUFPLE1BQU0sSUFBSTtDQUN4QyxNQUFNLFVBQVUsU0FBUyxlQUFlLFNBQVM7Q0FFakQsSUFBSSxZQUFZO0NBQ2hCLE1BQU0sc0JBQWtDO0VBQ3RDLE1BQU0sSUFBSSxhQUFhLFlBQVksYUFBYTtFQUNoRDtFQUNBLE9BQU87Q0FDVDtDQUVBLElBQUksWUFBWTs7O0NBSWhCLElBQUksZUFBZSxlQUFlLGVBQWUsY0FBYyxlQUFlLGNBQWM7RUFDMUYsTUFBTSxnQkFBZ0IscUJBQXFCO0VBQzNDLE1BQU0sZ0JBQWdCLEtBQUssSUFBSSxJQUFJLEtBQUssTUFBTSxPQUFPLEtBQUssQ0FBQztFQUMzRCxNQUFNLGFBQWEsS0FBTSxnQkFBZ0IsZ0JBQWdCO0VBRXpELHFCQUFxQixTQUFTLEtBQUssYUFBYTtHQUM5QyxNQUFNLElBQUksS0FBSyxNQUFNLGFBQWEsV0FBVyxhQUFhO0dBQzFELE1BQU0sYUFBYSxJQUFJLFFBQVEsTUFBTSxFQUFFLEtBQUssS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDO0dBQzdELElBQUksV0FBVyxXQUFXLEdBQUc7R0FFN0IsTUFBTSxZQUFZLFdBQVcsS0FBSyxNQUFNO0lBQ3RDLE1BQU0sVUFBVSxFQUFFLFVBQVUsRUFBRTtJQUM5QixNQUFNLFdBQVcsS0FBSyxJQUFJLEtBQUssS0FBSyxPQUFPLFVBQVUsT0FBTyxRQUFRLEtBQUssQ0FBQztJQUMxRSxNQUFNLFFBQVEsS0FBSyxNQUFNLEVBQUUsS0FBSyxTQUFTLFdBQVcsR0FBSTtJQUN4RCxPQUFPO0tBQUUsR0FBRztLQUFHO0tBQVU7SUFBTTtHQUNqQyxDQUFDO0dBRUQsTUFBTSxNQUFNLEtBQUssSUFBSSxHQUFHLEtBQUssTUFBTSxNQUFNLEtBQUssQ0FBQztHQUMvQyxNQUFNLGdCQUFnQixVQUFVLFFBQVEsS0FBSyxNQUFNLE1BQU0sRUFBRSxPQUFPLENBQUMsS0FBSyxVQUFVLFNBQVMsS0FBSztHQUNoRyxJQUFJLE9BQU8sS0FBTSxnQkFBZ0I7R0FFakMsVUFBVSxTQUFTLE1BQU07SUFDdkIsTUFBTSxjQUFjLEtBQUssTUFBTSxPQUFPLEVBQUUsUUFBUSxDQUFDO0lBQ2pELE1BQU0sU0FBUyxpQkFBaUIsRUFBRSxJQUFJO0lBRXRDLElBQUk7SUFDSixJQUFJLEVBQUUsVUFBVTtLQUNkLFFBQVE7SUFDVixPQUFPLElBQUksRUFBRSxRQUFRO0tBQ25CLFFBQVEsUUFBUSxPQUFPO0lBQ3pCLE9BQU87S0FDTCxRQUFRLFFBQVEsT0FBTyxZQUFZLFFBQVEsT0FBTztJQUNwRDtJQUVBLE1BQU0sZUFBZSxhQUFhLE1BQU0sS0FBSyxJQUFJLGNBQWMsRUFBRSxJQUFJLEtBQUssU0FBUztJQUNuRixNQUFNLFlBQVksZUFBZSxLQUFLLGlCQUFpQixNQUFNLEVBQUU7SUFDL0QsSUFBSSxjQUFjLFFBQVE7SUFFMUIsU0FBUyxLQUFLO0tBQ1osSUFBSSxHQUFHLFdBQVcsR0FBRztLQUNyQjtLQUNBLE1BQU07S0FDTixHQUFHO0tBQ0g7S0FDQSxPQUFPLEVBQUU7S0FDVCxRQUFRLEVBQUUsV0FBVztLQUNyQixPQUFPO0tBQ1AsVUFBVSxFQUFFO0tBQ1osWUFBWSxFQUFFLFVBQVUsRUFBRSxXQUFXLFFBQVE7S0FDN0M7S0FDQSxNQUFNO0tBQ04sT0FBTyxNQUFRLFdBQVcsZ0JBQWlCO0tBQzNDLFNBQVM7SUFDWCxDQUFDO0lBRUQsUUFBUSxFQUFFLFFBQVE7R0FDcEIsQ0FBQztFQUNILENBQUM7O0VBR0Qsb0JBQW9CLFVBQVUsSUFBSSxhQUFhLGdCQUFnQixnQkFBaUIsSUFBSSxPQUFRLE9BQU8sUUFBUSxNQUFNLFNBQVM7RUFDMUgsT0FBTztDQUNUOztDQUdBLElBQUksZUFBZSxhQUFhO0VBQzlCLE1BQU0sZ0JBQWdCLGdCQUFnQjtFQUN0QyxNQUFNLFlBQVksS0FBSyxJQUFJLElBQUksS0FBSyxNQUFNLE9BQU8sS0FBSyxDQUFDO0VBQ3ZELE1BQU0sU0FBUyxLQUFNLGdCQUFnQixZQUFZO0VBRWpELGdCQUFnQixTQUFTLEtBQUssYUFBYTtHQUN6QyxNQUFNLElBQUksS0FBSyxNQUFNLFNBQVMsV0FBVyxTQUFTO0dBQ2xELE1BQU0sYUFBYSxJQUFJLFFBQVEsTUFBTSxFQUFFLEtBQUssS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDO0dBQzdELElBQUksV0FBVyxXQUFXLEdBQUc7R0FFN0IsTUFBTSxZQUFZLFdBQVcsS0FBSyxNQUFNO0lBQ3RDLE1BQU0sVUFBVSxFQUFFLFVBQVUsRUFBRTtJQUM5QixNQUFNLFdBQVcsS0FBSyxJQUFJLEtBQUssS0FBSyxPQUFPLFVBQVUsT0FBTyxRQUFRLEtBQUssQ0FBQztJQUMxRSxNQUFNLFFBQVEsS0FBSyxNQUFNLEVBQUUsS0FBSyxTQUFTLFdBQVcsR0FBSTtJQUN4RCxPQUFPO0tBQUUsR0FBRztLQUFHO0tBQVU7SUFBTTtHQUNqQyxDQUFDO0dBRUQsTUFBTSxNQUFNLEtBQUssSUFBSSxHQUFHLEtBQUssTUFBTSxNQUFNLEtBQUssQ0FBQztHQUMvQyxNQUFNLGdCQUFnQixVQUFVLFFBQVEsS0FBSyxNQUFNLE1BQU0sRUFBRSxPQUFPLENBQUMsS0FBSyxVQUFVLFNBQVMsS0FBSztHQUNoRyxJQUFJLE9BQU8sS0FBTSxnQkFBZ0I7R0FFakMsVUFBVSxTQUFTLE1BQU07SUFDdkIsTUFBTSxjQUFjLEtBQUssTUFBTSxPQUFPLEVBQUUsUUFBUSxDQUFDO0lBQ2pELE1BQU0sU0FBUyxpQkFBaUIsRUFBRSxJQUFJO0lBRXRDLElBQUk7SUFDSixJQUFJLEVBQUUsVUFBVTtLQUNkLFFBQVE7SUFDVixPQUFPLElBQUksRUFBRSxRQUFRO0tBQ25CLFFBQVEsUUFBUSxPQUFPO0lBQ3pCLE9BQU87S0FDTCxRQUFRLFFBQVEsT0FBTyxZQUFZLFFBQVEsT0FBTztJQUNwRDtJQUVBLE1BQU0sZUFBZSxhQUFhLE1BQU0sS0FBSyxJQUFJLGNBQWMsRUFBRSxJQUFJLEtBQUssU0FBUztJQUNuRixNQUFNLFlBQVksZUFBZSxLQUFLLGlCQUFpQixNQUFNLEVBQUU7SUFDL0QsSUFBSSxjQUFjLFFBQVE7SUFFMUIsU0FBUyxLQUFLO0tBQ1osSUFBSSxjQUFjO0tBQ2xCO0tBQ0EsTUFBTTtLQUNOLEdBQUc7S0FDSDtLQUNBLE9BQU8sRUFBRTtLQUNULFFBQVEsRUFBRSxXQUFXO0tBQ3JCLE9BQU87S0FDUCxVQUFVLEVBQUU7S0FDWixZQUFZLEVBQUUsVUFBVSxFQUFFLFdBQVcsUUFBUTtLQUM3QztLQUNBLE1BQU07S0FDTixPQUFPLE1BQVEsV0FBVyxnQkFBaUI7S0FDM0MsU0FBUztJQUNYLENBQUM7SUFFRCxRQUFRLEVBQUUsUUFBUTtHQUNwQixDQUFDO0VBQ0gsQ0FBQzs7RUFHRCxNQUFNLFVBQVUsS0FBSyxNQUFNLFNBQVMsZ0JBQWdCLFlBQVksRUFBSTtFQUNwRSxhQUFhLFNBQVMsUUFBUSxRQUFRO0dBQ3BDLE1BQU0sU0FBUyxLQUFLLFFBQVEsT0FBTztHQUNuQyxNQUFNLFFBQVEsQ0FBQyxLQUFLLEtBQUssSUFBSSxPQUFPO0dBQ3BDLE1BQU0sS0FBSyxLQUFLLE1BQU0sS0FBSyxLQUFLLElBQUksS0FBSyxJQUFJLE1BQU07R0FDbkQsTUFBTSxLQUFLLEtBQUssTUFBTSxVQUFVLEtBQUssSUFBSSxLQUFLLEtBQUssU0FBUyxJQUFLO0dBRWpFLE1BQU0sV0FBVyxLQUFLLElBQUksSUFBSSxLQUFLLE1BQU0sS0FBSyxLQUFLLENBQUM7R0FDcEQsTUFBTSxRQUFRLEtBQUssTUFBTSxPQUFPLEtBQUssU0FBUyxXQUFXLEdBQUk7R0FFN0QsU0FBUyxLQUFLO0lBQ1osSUFBSSxnQkFBZ0I7SUFDcEIsUUFBUSxpQkFBaUIsT0FBTyxLQUFLLFFBQVEsTUFBTSxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUM7SUFDN0QsTUFBTSxPQUFPO0lBQ2IsR0FBRztJQUNILEdBQUc7SUFDSDtJQUNBLFFBQVEsV0FBVztJQUNuQixPQUFPO0lBQ1A7SUFDQSxZQUFZO0lBQ1osT0FBTztJQUNQLE1BQU07SUFDTixPQUFPLE1BQVEsTUFBTSxhQUFhLFNBQVU7SUFDNUMsU0FBUztHQUNYLENBQUM7RUFDSCxDQUFDOztFQUdELE1BQU0sY0FBYyxLQUFLLE1BQU0sU0FBUyxnQkFBZ0IsWUFBYSxJQUFJLEtBQU07RUFDL0UsTUFBTSxZQUFZLEtBQUssSUFBSSxJQUFJLEtBQUssTUFBTSxLQUFLLEtBQUssQ0FBQzs7RUFHckQsYUFBYSxNQUFNLFNBQVMsS0FBSyxTQUFTO0dBQ3hDLE1BQU0sSUFBSSxLQUFLLE1BQU0sY0FBYyxPQUFPLFNBQVM7R0FDbkQsTUFBTSxNQUFNLEtBQUssSUFBSSxHQUFHLEtBQUssTUFBTSxLQUFLLEtBQUssQ0FBQztHQUM5QyxNQUFNLFlBQVksSUFBSSxLQUFLLE1BQU07SUFDL0IsTUFBTSxXQUFXLEtBQUssSUFBSSxLQUFLLEtBQUssTUFBTSxLQUFLLEtBQUssQ0FBQztJQUNyRCxNQUFNLFFBQVEsS0FBSyxNQUFNLEVBQUUsS0FBSyxTQUFTLFdBQVcsR0FBSTtJQUN4RCxPQUFPO0tBQUUsR0FBRztLQUFHO0tBQVU7SUFBTTtHQUNqQyxDQUFDO0dBQ0QsTUFBTSxTQUFTLFVBQVUsUUFBUSxLQUFLLE1BQU0sTUFBTSxFQUFFLE9BQU8sQ0FBQyxLQUFLLFVBQVUsU0FBUyxLQUFLO0dBQ3pGLElBQUksT0FBTyxLQUFLLFNBQVM7R0FFekIsVUFBVSxTQUFTLE1BQU07SUFDdkIsU0FBUyxLQUFLO0tBQ1osSUFBSSxjQUFjO0tBQ2xCLFFBQVEsaUJBQWlCLEVBQUUsSUFBSTtLQUMvQixNQUFNLEVBQUU7S0FDUixHQUFHLEtBQUssTUFBTSxPQUFPLEVBQUUsUUFBUSxDQUFDO0tBQ2hDO0tBQ0EsT0FBTyxFQUFFO0tBQ1QsUUFBUSxFQUFFLFdBQVc7S0FDckIsT0FBTztLQUNQLFVBQVUsRUFBRTtLQUNaLFlBQVk7S0FDWixPQUFPLFFBQVEsS0FBSyxZQUFZLFFBQVEsS0FBSztLQUM3QyxNQUFNO0tBQ04sT0FBTyxLQUFPLE9BQU87S0FDckIsU0FBUztJQUNYLENBQUM7SUFDRCxRQUFRLEVBQUUsUUFBUTtHQUNwQixDQUFDO0VBQ0gsQ0FBQzs7RUFHRCxNQUFNLGFBQWEsY0FBYyxZQUFZO0VBQzdDLGFBQWEsWUFBWSxLQUFLLFNBQVMsS0FBSyxTQUFTO0dBQ25ELE1BQU0sSUFBSSxLQUFLLE1BQU0sYUFBYSxPQUFPLFNBQVM7R0FDbEQsTUFBTSxNQUFNLEtBQUssSUFBSSxHQUFHLEtBQUssTUFBTSxJQUFJLEtBQUssQ0FBQztHQUM3QyxNQUFNLFlBQVksSUFBSSxLQUFLLE1BQU07SUFDL0IsTUFBTSxXQUFXLEtBQUssSUFBSSxHQUFHLEtBQUssTUFBTSxPQUFPLEtBQUssQ0FBQztJQUNyRCxNQUFNLFFBQVEsS0FBSyxNQUFNLEVBQUUsS0FBSyxTQUFTLFdBQVcsR0FBSTtJQUN4RCxPQUFPO0tBQUUsR0FBRztLQUFHO0tBQVU7SUFBTTtHQUNqQyxDQUFDO0dBQ0QsTUFBTSxTQUFTLFVBQVUsUUFBUSxLQUFLLE1BQU0sTUFBTSxFQUFFLE9BQU8sQ0FBQyxLQUFLLFVBQVUsU0FBUyxLQUFLO0dBQ3pGLElBQUksT0FBTyxLQUFLLEtBQUssUUFBUTtHQUU3QixVQUFVLFNBQVMsTUFBTTtJQUN2QixTQUFTLEtBQUs7S0FDWixJQUFJLGtCQUFrQjtLQUN0QixRQUFRLGlCQUFpQixFQUFFLElBQUk7S0FDL0IsTUFBTSxFQUFFO0tBQ1IsR0FBRyxLQUFLLE1BQU0sT0FBTyxFQUFFLFFBQVEsQ0FBQztLQUNoQztLQUNBLE9BQU8sRUFBRTtLQUNULFFBQVEsRUFBRSxXQUFXO0tBQ3JCLE9BQU87S0FDUCxVQUFVLEVBQUU7S0FDWixZQUFZO0tBQ1osT0FBTyxRQUFRLE1BQU0sT0FBTyxhQUFhLFFBQVEsS0FBSztLQUN0RCxNQUFNO0tBQ04sT0FBTyxNQUFPLE9BQU87S0FDckIsU0FBUztJQUNYLENBQUM7SUFDRCxRQUFRLEVBQUUsUUFBUTtHQUNwQixDQUFDO0VBQ0gsQ0FBQztFQUVELGFBQWEsWUFBWSxNQUFNLFNBQVMsS0FBSyxTQUFTO0dBQ3BELE1BQU0sSUFBSSxLQUFLLE1BQU0sY0FBYyxPQUFPLEtBQUssU0FBUztHQUN4RCxNQUFNLE1BQU0sS0FBSyxJQUFJLEdBQUcsS0FBSyxNQUFNLElBQUksS0FBSyxDQUFDO0dBQzdDLE1BQU0sWUFBWSxJQUFJLEtBQUssTUFBTTtJQUMvQixNQUFNLFdBQVcsS0FBSyxJQUFJLEdBQUcsS0FBSyxNQUFNLE9BQU8sS0FBSyxDQUFDO0lBQ3JELE1BQU0sUUFBUSxLQUFLLE1BQU0sRUFBRSxLQUFLLFNBQVMsV0FBVyxHQUFJO0lBQ3hELE9BQU87S0FBRSxHQUFHO0tBQUc7S0FBVTtJQUFNO0dBQ2pDLENBQUM7R0FDRCxJQUFJLE9BQU8sS0FBSyxLQUFLO0dBRXJCLFVBQVUsU0FBUyxNQUFNO0lBQ3ZCLFNBQVMsS0FBSztLQUNaLElBQUksbUJBQW1CO0tBQ3ZCLFFBQVEsaUJBQWlCLEVBQUUsSUFBSTtLQUMvQixNQUFNLEVBQUU7S0FDUixHQUFHLEtBQUssTUFBTSxPQUFPLEVBQUUsUUFBUSxDQUFDO0tBQ2hDO0tBQ0EsT0FBTyxFQUFFO0tBQ1QsUUFBUSxFQUFFLFdBQVc7S0FDckIsT0FBTztLQUNQLFVBQVUsRUFBRTtLQUNaLFlBQVk7S0FDWixPQUFPLFFBQVEsTUFBTSxPQUFPLElBQUksYUFBYSxRQUFRLEtBQUs7S0FDMUQsTUFBTTtLQUNOLE9BQU8sTUFBTyxPQUFPO0tBQ3JCLFNBQVM7SUFDWCxDQUFDO0lBQ0QsUUFBUSxFQUFFLFFBQVE7R0FDcEIsQ0FBQztFQUNILENBQUM7O0VBR0QsTUFBTSxrQkFBa0IsYUFBYSxJQUFJO0VBQ3pDLGFBQWEsVUFBVSxTQUFTLEtBQUssU0FBUztHQUM1QyxNQUFNLElBQUksS0FBSyxNQUFNLGtCQUFrQixPQUFPLFNBQVM7R0FDdkQsTUFBTSxNQUFNLEtBQUssSUFBSSxHQUFHLEtBQUssTUFBTSxJQUFJLEtBQUssQ0FBQztHQUM3QyxNQUFNLFlBQVksSUFBSSxLQUFLLE1BQU07SUFDL0IsTUFBTSxXQUFXLEtBQUssSUFBSSxHQUFHLEtBQUssTUFBTSxPQUFPLEtBQUssQ0FBQztJQUNyRCxNQUFNLFFBQVEsS0FBSyxNQUFNLEVBQUUsS0FBSyxTQUFTLFdBQVcsR0FBSTtJQUN4RCxPQUFPO0tBQUUsR0FBRztLQUFHO0tBQVU7SUFBTTtHQUNqQyxDQUFDO0dBQ0QsTUFBTSxTQUFTLFVBQVUsUUFBUSxLQUFLLE1BQU0sTUFBTSxFQUFFLE9BQU8sQ0FBQyxLQUFLLFVBQVUsU0FBUyxLQUFLO0dBQ3pGLElBQUksT0FBTyxLQUFLLFNBQVM7R0FFekIsVUFBVSxTQUFTLE1BQU07SUFDdkIsU0FBUyxLQUFLO0tBQ1osSUFBSSxhQUFhO0tBQ2pCLFFBQVEsaUJBQWlCLEVBQUUsSUFBSTtLQUMvQixNQUFNLEVBQUU7S0FDUixHQUFHLEtBQUssTUFBTSxPQUFPLEVBQUUsUUFBUSxDQUFDO0tBQ2hDO0tBQ0EsT0FBTyxFQUFFO0tBQ1QsUUFBUSxFQUFFLFdBQVc7S0FDckIsT0FBTztLQUNQLFVBQVUsRUFBRTtLQUNaLFlBQVk7S0FDWixPQUFPLFFBQVEsTUFBTSxPQUFPLGFBQWEsUUFBUSxLQUFLO0tBQ3RELE1BQU07S0FDTixPQUFPLE1BQU8sT0FBTztLQUNyQixTQUFTO0lBQ1gsQ0FBQztJQUNELFFBQVEsRUFBRSxRQUFRO0dBQ3BCLENBQUM7RUFDSCxDQUFDO0VBRUQsT0FBTztDQUNUOztDQUdBLElBQUksZUFBZSxvQkFBb0I7RUFDckMsTUFBTSxjQUFjO0VBQ3BCLE1BQU0sWUFBWSxLQUFLLElBQUksSUFBSSxLQUFLLE1BQU0sT0FBTyxLQUFLLENBQUM7RUFDdkQsTUFBTSxTQUFTLEtBQU0sY0FBYyxZQUFZO0VBRS9DLE1BQU0scUJBQXFCLElBQVksT0FBZTtHQUNwRCxNQUFNLE9BQU8sS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEVBQUU7R0FDeEMsSUFBSSxRQUFRLEtBQUssT0FBTyxPQUFPOztHQUUvQixJQUFJLFFBQVEsTUFBTSxPQUFPO0lBQ3ZCLE1BQU0sTUFBTSxLQUFLLE1BQU0sSUFBSSxFQUFFO0lBQzdCLE1BQU0sT0FBTyxLQUFLLElBQUksS0FBSyxJQUFJLE1BQU0sQ0FBQyxDQUFDO0lBQ3ZDLE9BQU8sU0FBUyxNQUFNLE9BQU8sTUFBTTtHQUNyQztHQUNBLE9BQU87RUFDVDtFQUVBLGNBQWMsVUFBVSxtQkFBbUIsUUFBUSxhQUFhLFdBQVcsSUFBSSxPQUFPLFFBQVEsUUFBUSxXQUFXLGVBQWUsV0FBVyxnQkFBZ0I7RUFDM0osb0JBQW9CLFVBQVUsSUFBSSxTQUFTLGNBQWMsWUFBYSxJQUFJLE9BQVEsT0FBTyxRQUFRLE1BQU0sU0FBUztFQUNoSCxPQUFPO0NBQ1Q7O0NBR0EsSUFBSSxlQUFlLGVBQWU7RUFDaEMsTUFBTSxpQkFBaUI7RUFDdkIsTUFBTSxZQUFZLEtBQUssSUFBSSxJQUFJLEtBQUssTUFBTSxPQUFPLEtBQUssQ0FBQztFQUN2RCxNQUFNLFNBQVMsS0FBTSxpQkFBaUIsWUFBWTtFQUVsRCxNQUFNLGlCQUFpQixJQUFZLE9BQWU7R0FDaEQsSUFBSSxNQUFNLENBQUMsTUFBTSxTQUFTLE1BQU0sS0FBSyxPQUFPO0lBQzFDLE1BQU0sS0FBSyxLQUFLLE1BQU0sVUFBVSxNQUFNO0lBQ3RDLElBQUk7SUFDSixJQUFJLElBQUksS0FBTTs7S0FFWixNQUFNLFFBQVEsS0FBSyxJQUFJLEVBQUUsSUFBSSxLQUFLLFFBQVEsS0FBSyxTQUFTLElBQUksS0FBSyxJQUFJLEVBQUUsS0FBSyxLQUFLLFVBQVU7S0FDM0YsSUFBSSxLQUFLLENBQUMsTUFBTSxRQUFRLE9BQU8sT0FBTztLQUN0QyxPQUFPLE1BQU0sUUFBUSxLQUFLLElBQUssSUFBSSxNQUFRLEtBQUssS0FBSyxDQUFDLElBQUssS0FBSztJQUNsRSxPQUFPLElBQUksSUFBSSxLQUFNO0tBQ25CLE9BQU8sTUFBTSxRQUFRLEtBQUssSUFBSSxJQUFJLEtBQUssS0FBSyxHQUFJO0lBQ2xELE9BQU87S0FDTCxPQUFPLE1BQU0sU0FBUyxLQUFNLElBQUksT0FBUSxNQUFRO0lBQ2xEO0lBQ0EsT0FBTyxLQUFLLElBQUksRUFBRSxLQUFLO0dBQ3pCO0dBQ0EsT0FBTztFQUNUO0VBRUEsY0FBYyxVQUFVLGVBQWUsUUFBUSxnQkFBZ0IsV0FBVyxJQUFJLE9BQU8sUUFBUSxRQUFRLFdBQVcsZUFBZSxXQUFXLGdCQUFnQjtFQUMxSixvQkFBb0IsVUFBVSxJQUFJLFNBQVMsaUJBQWlCLFlBQWEsSUFBSSxPQUFRLE9BQU8sUUFBUSxNQUFNLFNBQVM7RUFDbkgsT0FBTztDQUNUO0NBRUEsT0FBTztBQUNUOztBQUdBLFNBQVMsY0FDUCxVQUNBLFlBQ0EsUUFDQSxXQUNBLFdBQ0EsSUFDQSxPQUNBLFFBQ0EsZ0JBQ0EsZUFDQSxXQUNBLGtCQUNBO0NBQ0EsTUFBTSxlQUFlO0VBQUM7RUFBUTtFQUFRO0VBQU87RUFBSztFQUFPO0VBQVU7RUFBVTtFQUFTO0VBQVM7Q0FBTTtDQUVyRyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksV0FBVyxLQUFLO0VBQ2xDLE1BQU0sSUFBSSxLQUFLLE1BQU0sU0FBUyxJQUFJLFNBQVM7RUFDM0MsTUFBTSxLQUFLLEtBQUssU0FBVSxZQUFZLFlBQWE7RUFFbkQsTUFBTSxZQUFnQyxDQUFDO0VBQ3ZDLElBQUksV0FBMEI7RUFDOUIsTUFBTSxXQUFXLElBQUk7RUFFckIsS0FBSyxJQUFJLElBQUksS0FBSyxNQUFNLE9BQU8sS0FBSyxLQUFLLE1BQU0sT0FBTyxLQUFLLFVBQVU7R0FDbkUsTUFBTSxNQUFNLFdBQVcsSUFBSSxJQUFJLEVBQUU7R0FDakMsSUFBSSxLQUFLO0lBQ1AsSUFBSSxhQUFhLE1BQU0sV0FBVztHQUNwQyxPQUFPO0lBQ0wsSUFBSSxhQUFhLE1BQU07S0FDckIsVUFBVSxLQUFLLENBQUMsVUFBVSxJQUFJLFFBQVEsQ0FBQztLQUN2QyxXQUFXO0lBQ2I7R0FDRjtFQUNGO0VBQ0EsSUFBSSxhQUFhLE1BQU0sVUFBVSxLQUFLLENBQUMsVUFBVSxLQUFLLE1BQU0sS0FBSyxDQUFDO0VBRWxFLEtBQUssTUFBTSxDQUFDLFFBQVEsU0FBUyxXQUFXO0dBQ3RDLE1BQU0sT0FBTyxPQUFPO0dBQ3BCLElBQUksT0FBTyxLQUFLLE9BQU87R0FFdkIsSUFBSSxPQUFPLFNBQVMsSUFBSTtHQUN4QixPQUFPLE9BQU8sT0FBTyxLQUFLLE9BQU87SUFDL0IsTUFBTSxZQUFZLE9BQU87SUFDekIsSUFBSSxTQUFTLGNBQWM7SUFDM0IsSUFBSSxPQUFPLE9BQU87SUFFbEIsSUFBSSxZQUFZLEtBQUssU0FBUyxLQUFLLFNBQVMsR0FBRztLQUM3QyxPQUFPLGFBQWEsWUFBWSxhQUFhO0lBQy9DO0lBRUEsTUFBTSxjQUFjLFlBQVksTUFBTSxLQUFLLFNBQVMsVUFBVSxTQUFTLFlBQVksU0FBUztJQUM1RixNQUFNLFdBQVcsS0FBSyxJQUFJLEtBQUssS0FBSyxPQUFPLGNBQWMsT0FBTyxRQUFRLEtBQUssQ0FBQztJQUM5RSxNQUFNLGlCQUFpQixLQUFLLE1BQU0sS0FBSyxTQUFTLFdBQVcsR0FBSTtJQUUvRCxJQUFJLE9BQU8sa0JBQWtCLE9BQU8sSUFBSSxPQUFPO0tBQzdDLE1BQU0sY0FBYyxLQUFLLE1BQU0sT0FBTyxpQkFBaUIsQ0FBQztLQUN4RCxNQUFNLFdBQVcsS0FBSyxJQUFJLGNBQWMsRUFBRSxJQUFJLEtBQUssU0FBUyxLQUFLLElBQUksRUFBRSxJQUFJLEtBQUssU0FBUztLQUN6RixNQUFNLFlBQVksV0FBVyxLQUFLLGlCQUFpQixNQUFNO0tBRXpELElBQUk7S0FDSixJQUFJLFVBQVU7TUFDWixRQUFRO0tBQ1YsT0FBTyxJQUFJLGFBQWE7TUFDdEIsUUFBUTtLQUNWLE9BQU87TUFDTCxRQUFRLE9BQU8sWUFBWSxPQUFPO0tBQ3BDO0tBRUEsU0FBUyxLQUFLO01BQ1osSUFBSSxlQUFlO01BQ25CO01BQ0EsTUFBTTtNQUNOLEdBQUc7TUFDSDtNQUNBLE9BQU87TUFDUCxRQUFRLFdBQVc7TUFDbkIsT0FBTztNQUNQO01BQ0EsWUFBWSxlQUFlLFdBQVcsUUFBUTtNQUM5QztNQUNBLE1BQU07TUFDTixPQUFPLE1BQVEsSUFBSSxZQUFhO01BQ2hDLFNBQVM7S0FDWCxDQUFDO0tBRUQsUUFBUSxpQkFBaUIsS0FBSyxJQUFJLEdBQUcsS0FBSyxNQUFNLE1BQU0sS0FBSyxDQUFDO0lBQzlELE9BQU87S0FDTDtJQUNGO0dBQ0Y7RUFDRjtDQUNGO0FBQ0Y7O0FBR0EsU0FBUyxvQkFDUCxVQUNBLElBQ0EsUUFDQSxPQUNBLFlBQ0EsV0FDQTtDQUNBLE1BQU0sT0FBTyxLQUFLLElBQUksSUFBSSxLQUFLLE1BQU0sS0FBSyxLQUFLLENBQUM7O0NBR2hELHNCQUFzQixNQUFNLFNBQVMsS0FBSyxTQUFTO0VBQ2pELE1BQU0sSUFBSSxLQUFLLE1BQU0sU0FBUyxPQUFPLElBQUk7RUFDekMsTUFBTSxNQUFNLEtBQUssSUFBSSxHQUFHLEtBQUssTUFBTSxLQUFLLEtBQUssQ0FBQztFQUM5QyxNQUFNLFlBQVksSUFBSSxLQUFLLE1BQU07R0FDL0IsTUFBTSxXQUFXLEtBQUssSUFBSSxLQUFLLEtBQUssTUFBTSxLQUFLLEtBQUssQ0FBQztHQUNyRCxNQUFNLFFBQVEsS0FBSyxNQUFNLEVBQUUsS0FBSyxTQUFTLFdBQVcsR0FBSTtHQUN4RCxPQUFPO0lBQUUsR0FBRztJQUFHO0lBQVU7R0FBTTtFQUNqQyxDQUFDO0VBQ0QsTUFBTSxTQUFTLFVBQVUsUUFBUSxLQUFLLE1BQU0sTUFBTSxFQUFFLE9BQU8sQ0FBQyxLQUFLLFVBQVUsU0FBUyxLQUFLO0VBQ3pGLElBQUksT0FBTyxLQUFLLFNBQVM7RUFFekIsVUFBVSxTQUFTLE1BQU07R0FDdkIsU0FBUyxLQUFLO0lBQ1osSUFBSSxTQUFTO0lBQ2IsUUFBUSxpQkFBaUIsRUFBRSxJQUFJO0lBQy9CLE1BQU0sRUFBRTtJQUNSLEdBQUcsS0FBSyxNQUFNLE9BQU8sRUFBRSxRQUFRLENBQUM7SUFDaEM7SUFDQSxPQUFPLEVBQUU7SUFDVCxRQUFRLEVBQUUsV0FBVztJQUNyQixPQUFPO0lBQ1AsVUFBVSxFQUFFO0lBQ1osWUFBWTtJQUNaLE9BQU8sV0FBVyxZQUFZLFdBQVc7SUFDekMsTUFBTTtJQUNOLE9BQU8sS0FBTyxPQUFPO0lBQ3JCLFNBQVM7R0FDWCxDQUFDO0dBQ0QsUUFBUSxFQUFFLFFBQVE7RUFDcEIsQ0FBQztDQUNILENBQUM7O0NBR0QsTUFBTSxpQkFBaUIsU0FBUyxPQUFPO0NBQ3ZDLHNCQUFzQixTQUFTLFNBQVMsS0FBSyxTQUFTO0VBQ3BELE1BQU0sSUFBSSxLQUFLLE1BQU0saUJBQWlCLE9BQU8sSUFBSTtFQUNqRCxNQUFNLE1BQU0sS0FBSyxJQUFJLEdBQUcsS0FBSyxNQUFNLElBQUksS0FBSyxDQUFDO0VBQzdDLE1BQU0sWUFBWSxJQUFJLEtBQUssTUFBTTtHQUMvQixNQUFNLFdBQVcsS0FBSyxJQUFJLEdBQUcsS0FBSyxNQUFNLE9BQU8sS0FBSyxDQUFDO0dBQ3JELE1BQU0sUUFBUSxLQUFLLE1BQU0sRUFBRSxLQUFLLFNBQVMsV0FBVyxHQUFJO0dBQ3hELE9BQU87SUFBRSxHQUFHO0lBQUc7SUFBVTtHQUFNO0VBQ2pDLENBQUM7RUFDRCxNQUFNLFNBQVMsVUFBVSxRQUFRLEtBQUssTUFBTSxNQUFNLEVBQUUsT0FBTyxDQUFDLEtBQUssVUFBVSxTQUFTLEtBQUs7RUFDekYsSUFBSSxPQUFPLEtBQU0sS0FBSyxRQUFTO0VBRS9CLFVBQVUsU0FBUyxNQUFNO0dBQ3ZCLFNBQVMsS0FBSztJQUNaLElBQUksYUFBYTtJQUNqQixRQUFRLGlCQUFpQixFQUFFLElBQUk7SUFDL0IsTUFBTSxFQUFFO0lBQ1IsR0FBRyxLQUFLLE1BQU0sT0FBTyxFQUFFLFFBQVEsQ0FBQztJQUNoQztJQUNBLE9BQU8sRUFBRTtJQUNULFFBQVEsRUFBRSxXQUFXO0lBQ3JCLE9BQU87SUFDUCxVQUFVLEVBQUU7SUFDWixZQUFZO0lBQ1osT0FBTyxZQUFZLE9BQU8sYUFBYSxXQUFXO0lBQ2xELE1BQU07SUFDTixPQUFPLE1BQU8sT0FBTztJQUNyQixTQUFTO0dBQ1gsQ0FBQztHQUNELFFBQVEsRUFBRSxRQUFRO0VBQ3BCLENBQUM7Q0FDSCxDQUFDOztDQUdELE1BQU0sa0JBQWtCLGlCQUFpQixPQUFPO0NBQ2hELHNCQUFzQixVQUFVLFNBQVMsS0FBSyxTQUFTO0VBQ3JELE1BQU0sSUFBSSxLQUFLLE1BQU0sa0JBQWtCLE9BQU8sSUFBSTtFQUNsRCxNQUFNLE1BQU0sS0FBSyxJQUFJLEdBQUcsS0FBSyxNQUFNLElBQUksS0FBSyxDQUFDO0VBQzdDLE1BQU0sWUFBWSxJQUFJLEtBQUssTUFBTTtHQUMvQixNQUFNLFdBQVcsS0FBSyxJQUFJLEdBQUcsS0FBSyxNQUFNLE9BQU8sS0FBSyxDQUFDO0dBQ3JELE1BQU0sUUFBUSxLQUFLLE1BQU0sRUFBRSxLQUFLLFNBQVMsV0FBVyxHQUFJO0dBQ3hELE9BQU87SUFBRSxHQUFHO0lBQUc7SUFBVTtHQUFNO0VBQ2pDLENBQUM7RUFDRCxJQUFJLE9BQU8sS0FBSyxLQUFLO0VBRXJCLFVBQVUsU0FBUyxNQUFNO0dBQ3ZCLFNBQVMsS0FBSztJQUNaLElBQUksY0FBYztJQUNsQixRQUFRLGlCQUFpQixFQUFFLElBQUk7SUFDL0IsTUFBTSxFQUFFO0lBQ1IsR0FBRyxLQUFLLE1BQU0sT0FBTyxFQUFFLFFBQVEsQ0FBQztJQUNoQztJQUNBLE9BQU8sRUFBRTtJQUNULFFBQVEsRUFBRSxXQUFXO0lBQ3JCLE9BQU87SUFDUCxVQUFVLEVBQUU7SUFDWixZQUFZO0lBQ1osT0FBTyxZQUFZLE9BQU8sSUFBSSxhQUFhLFdBQVc7SUFDdEQsTUFBTTtJQUNOLE9BQU8sTUFBTyxPQUFPO0lBQ3JCLFNBQVM7R0FDWCxDQUFDO0dBQ0QsUUFBUSxFQUFFLFFBQVE7RUFDcEIsQ0FBQztDQUNILENBQUM7O0NBR0QsTUFBTSxrQkFBa0IsaUJBQWlCLHNCQUFzQixTQUFTLFNBQVM7Q0FDakYsc0JBQXNCLFVBQVUsU0FBUyxLQUFLLFNBQVM7RUFDckQsTUFBTSxJQUFJLEtBQUssTUFBTSxrQkFBa0IsT0FBTyxJQUFJO0VBQ2xELE1BQU0sTUFBTSxLQUFLLElBQUksR0FBRyxLQUFLLE1BQU0sSUFBSSxLQUFLLENBQUM7RUFDN0MsTUFBTSxZQUFZLElBQUksS0FBSyxNQUFNO0dBQy9CLE1BQU0sV0FBVyxLQUFLLElBQUksR0FBRyxLQUFLLE1BQU0sT0FBTyxLQUFLLENBQUM7R0FDckQsTUFBTSxRQUFRLEtBQUssTUFBTSxFQUFFLEtBQUssU0FBUyxXQUFXLEdBQUk7R0FDeEQsT0FBTztJQUFFLEdBQUc7SUFBRztJQUFVO0dBQU07RUFDakMsQ0FBQztFQUNELE1BQU0sU0FBUyxVQUFVLFFBQVEsS0FBSyxNQUFNLE1BQU0sRUFBRSxPQUFPLENBQUMsS0FBSyxVQUFVLFNBQVMsS0FBSztFQUN6RixJQUFJLE9BQU8sS0FBSyxTQUFTO0VBRXpCLFVBQVUsU0FBUyxNQUFNO0dBQ3ZCLFNBQVMsS0FBSztJQUNaLElBQUksY0FBYztJQUNsQixRQUFRLGlCQUFpQixFQUFFLElBQUk7SUFDL0IsTUFBTSxFQUFFO0lBQ1IsR0FBRyxLQUFLLE1BQU0sT0FBTyxFQUFFLFFBQVEsQ0FBQztJQUNoQztJQUNBLE9BQU8sRUFBRTtJQUNULFFBQVEsRUFBRSxXQUFXO0lBQ3JCLE9BQU87SUFDUCxVQUFVLEVBQUU7SUFDWixZQUFZO0lBQ1osT0FBTyxZQUFZLE9BQU8sYUFBYSxXQUFXO0lBQ2xELE1BQU07SUFDTixPQUFPLE1BQU8sT0FBTztJQUNyQixTQUFTO0dBQ1gsQ0FBQztHQUNELFFBQVEsRUFBRSxRQUFRO0VBQ3BCLENBQUM7Q0FDSCxDQUFDO0FBQ0giLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiZmxvd2VyU2hhcGVzLnRzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEVYQUNUX1JPU0VfSEVBRF9ST1dTLCBFWEFDVF9TVEVNX0FORF9MRUFWRVMgfSBmcm9tICcuLi9kYXRhL3Jvc2VFeGFjdERhdGEnO1xuaW1wb3J0IHsgRVhBQ1RfTElMWV9ST1dTLCBMSUxZX1NUQU1FTlMsIExJTFlfRk9MSUFHRSB9IGZyb20gJy4uL2RhdGEvbGlseUV4YWN0RGF0YSc7XG5pbXBvcnQgeyBMT1ZFX1BIUkFTRVMsIExvdmVQaHJhc2UgfSBmcm9tICcuLi9kYXRhL2xhbmd1YWdlcyc7XG5pbXBvcnQgeyBGbG93ZXJUZXh0RWxlbWVudCB9IGZyb20gJy4vbGlseUdlbmVyYXRvcic7XG5pbXBvcnQgeyBnZXRQaHJhc2VGb3JXb3JkIH0gZnJvbSAnLi9leGFjdFJvc2VHZW5lcmF0b3InO1xuXG5leHBvcnQgdHlwZSBGbG93ZXJUeXBlID0gJ3Bpbmtfcm9zZScgfCAncmVkX3Jvc2UnIHwgJ3BpbmtfbGlseScgfCAnZ29sZGVuX3N1bmZsb3dlcicgfCAncm95YWxfdHVsaXAnIHwgJ3doaXRlX3Jvc2UnO1xuXG5leHBvcnQgaW50ZXJmYWNlIEZsb3dlck1ldGFkYXRhIHtcbiAgaWQ6IEZsb3dlclR5cGU7XG4gIG5hbWU6IHN0cmluZztcbiAgZW1vamk6IHN0cmluZztcbiAgZGVzY3JpcHRpb246IHN0cmluZztcbiAgc2NyaXB0TmFtZTogc3RyaW5nO1xufVxuXG5leHBvcnQgY29uc3QgQVZBSUxBQkxFX0ZMT1dFUlM6IEZsb3dlck1ldGFkYXRhW10gPSBbXG4gIHtcbiAgICBpZDogJ3Bpbmtfcm9zZScsXG4gICAgbmFtZTogJ1BpbmsgUm9zZScsXG4gICAgZW1vamk6ICfwn4y4JyxcbiAgICBkZXNjcmlwdGlvbjogJ1N3ZWV0IGFkbWlyYXRpb24sIGdlbnRsZSBhZmZlY3Rpb24gJiBibG9vbWluZyBncmFjZScsXG4gICAgc2NyaXB0TmFtZTogJ3Bpbmtfcm9zZS5weSdcbiAgfSxcbiAge1xuICAgIGlkOiAncmVkX3Jvc2UnLFxuICAgIG5hbWU6ICdSZWQgUm9zZScsXG4gICAgZW1vamk6ICfwn4y5JyxcbiAgICBkZXNjcmlwdGlvbjogJ0ltbW9ydGFsIHBhc3Npb24sIHJvbWFuY2UgJiBsaWZlbG9uZyBjb21taXRtZW50JyxcbiAgICBzY3JpcHROYW1lOiAncmVkX3Jvc2UucHknXG4gIH0sXG4gIHtcbiAgICBpZDogJ3BpbmtfbGlseScsXG4gICAgbmFtZTogJ1BpbmsgTGlseScsXG4gICAgZW1vamk6ICfwn4y6JyxcbiAgICBkZXNjcmlwdGlvbjogJzYtc3RhciBTdGFyZ2F6ZXIgbGlseSBvZiBwdXJpdHksIGRldm90aW9uICYgYWJ1bmRhbmNlJyxcbiAgICBzY3JpcHROYW1lOiAncGlua19saWx5LnB5J1xuICB9LFxuICB7XG4gICAgaWQ6ICdnb2xkZW5fc3VuZmxvd2VyJyxcbiAgICBuYW1lOiAnU3VuZmxvd2VyJyxcbiAgICBlbW9qaTogJ/CfjLsnLFxuICAgIGRlc2NyaXB0aW9uOiAnUmFkaWFudCB3YXJtdGgsIGxveWFsdHksIGhhcHBpbmVzcyAmIHNvbGFyIGFkb3JhdGlvbicsXG4gICAgc2NyaXB0TmFtZTogJ3N1bmZsb3dlci5weSdcbiAgfSxcbiAge1xuICAgIGlkOiAncm95YWxfdHVsaXAnLFxuICAgIG5hbWU6ICdSb3lhbCBUdWxpcCcsXG4gICAgZW1vamk6ICfwn4y3JyxcbiAgICBkZXNjcmlwdGlvbjogJ1ZlbHZldCBjdXAgcGV0YWxzIG9mIHBlcmZlY3QsIGVuZHVyaW5nIHJveWFsIGxvdmUnLFxuICAgIHNjcmlwdE5hbWU6ICdyb3lhbF90dWxpcC5weSdcbiAgfSxcbiAge1xuICAgIGlkOiAnd2hpdGVfcm9zZScsXG4gICAgbmFtZTogJ1doaXRlIFJvc2UnLFxuICAgIGVtb2ppOiAn8J+kjScsXG4gICAgZGVzY3JpcHRpb246ICdNb29ubGl0IGl2b3J5IGJsb3Nzb20gb2YgZXRlcm5hbCBzb3VsbWF0ZSBkZXZvdGlvbicsXG4gICAgc2NyaXB0TmFtZTogJ3doaXRlX3Jvc2UucHknXG4gIH1cbl07XG5cbi8vIENvbG9yIHBhbGV0dGVzIGZvciBlYWNoIGZsb3dlclxuY29uc3QgUEFMRVRURVM6IFJlY29yZDxGbG93ZXJUeXBlLCB7IHBldGFsczogc3RyaW5nW107IGhpZ2hsaWdodHM6IHN0cmluZ1tdOyBzdGVtOiBzdHJpbmdbXSB9PiA9IHtcbiAgcGlua19yb3NlOiB7XG4gICAgcGV0YWxzOiBbJyNmZjJkNzUnLCAnI2ZmNjliNCcsICcjZjQzZjVlJywgJyNmZGE0YWYnLCAnI2ZiY2ZlOCcsICcjZmYxNDkzJ10sXG4gICAgaGlnaGxpZ2h0czogWycjZmZmZmZmJywgJyNmYmNmZTgnXSxcbiAgICBzdGVtOiBbJyMyMmM1NWUnLCAnIzRhZGU4MCcsICcjMTBiOTgxJywgJyM4NmVmYWMnLCAnIzE2YTM0YSddXG4gIH0sXG4gIHJlZF9yb3NlOiB7XG4gICAgcGV0YWxzOiBbJyNmZjE3NDQnLCAnI2UxMWQ0OCcsICcjZjQzZjVlJywgJyNiZTEyM2MnLCAnI2ZkYTRhZiddLFxuICAgIGhpZ2hsaWdodHM6IFsnI2ZmZmZmZicsICcjZmRhNGFmJ10sXG4gICAgc3RlbTogWycjMjJjNTVlJywgJyM0YWRlODAnLCAnIzEwYjk4MScsICcjODZlZmFjJywgJyMxNmEzNGEnXVxuICB9LFxuICBwaW5rX2xpbHk6IHtcbiAgICBwZXRhbHM6IFsnI2ZmMmQ3NScsICcjZWM0ODk5JywgJyNmNDcyYjYnLCAnI2RiMjc3NycsICcjZmJjZmU4JywgJyNmZGE0YWYnXSxcbiAgICBoaWdobGlnaHRzOiBbJyNmZmZmZmYnLCAnI2ZlZjA4YSddLFxuICAgIHN0ZW06IFsnIzIyYzU1ZScsICcjNGFkZTgwJywgJyMxMGI5ODEnLCAnIzg2ZWZhYycsICcjMTZhMzRhJ11cbiAgfSxcbiAgZ29sZGVuX3N1bmZsb3dlcjoge1xuICAgIHBldGFsczogWycjZmJiZjI0JywgJyNmNTllMGInLCAnI2Q5NzcwNicsICcjZmVmMDhhJywgJyNmZGU2OGEnLCAnI2I0NTMwOSddLFxuICAgIGhpZ2hsaWdodHM6IFsnI2ZmZmZmZicsICcjZmVmM2M3J10sXG4gICAgc3RlbTogWycjNjVhMzBkJywgJyM4NGNjMTYnLCAnIzRkN2MwZicsICcjYTNlNjM1JywgJyMyMmM1NWUnXVxuICB9LFxuICByb3lhbF90dWxpcDoge1xuICAgIHBldGFsczogWycjYzA4NGZjJywgJyNhODU1ZjcnLCAnIzkzMzNlYScsICcjZTg3OWY5JywgJyNmNDcyYjYnLCAnI2U5ZDVmZiddLFxuICAgIGhpZ2hsaWdodHM6IFsnI2ZmZmZmZicsICcjZjVkMGZlJ10sXG4gICAgc3RlbTogWycjMTBiOTgxJywgJyMyMmM1NWUnLCAnIzM0ZDM5OScsICcjNGFkZTgwJywgJyMwNTk2NjknXVxuICB9LFxuICB3aGl0ZV9yb3NlOiB7XG4gICAgcGV0YWxzOiBbJyNmZmZmZmYnLCAnI2Y4ZmFmYycsICcjZjFmNWY5JywgJyNlMmU4ZjAnLCAnI2NiZDVlMScsICcjZTBlN2ZmJ10sXG4gICAgaGlnaGxpZ2h0czogWycjZmZmZmZmJywgJyNmOGZhZmMnXSxcbiAgICBzdGVtOiBbJyMxMGI5ODEnLCAnIzIyYzU1ZScsICcjMzRkMzk5JywgJyM0YWRlODAnLCAnIzA1OTY2OSddXG4gIH1cbn07XG5cbi8qKlxuICogVW5pdmVyc2FsIEhpZ2gtQ2xhcml0eSBGbG93ZXIgR2VuZXJhdG9yXG4gKiBHZW5lcmF0ZXMgaG9yaXpvbnRhbCwgbm9uLW92ZXJsYXBwaW5nLCB3ZWxsLXNwYWNlZCB0ZXh0IG1hdHJpY2VzIGZvciBhbGwgZmxvd2VyIHR5cGVzLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2VuZXJhdGVVbmlmaWVkRmxvd2VyRWxlbWVudHMoXG4gIGZsb3dlclR5cGU6IEZsb3dlclR5cGUsXG4gIHdpZHRoOiBudW1iZXIsXG4gIGhlaWdodDogbnVtYmVyLFxuICBjdXN0b21EZWRpY2F0aW9uPzogc3RyaW5nXG4pOiBGbG93ZXJUZXh0RWxlbWVudFtdIHtcbiAgY29uc3QgZWxlbWVudHM6IEZsb3dlclRleHRFbGVtZW50W10gPSBbXTtcbiAgY29uc3QgY3ggPSB3aWR0aCAvIDI7XG4gIGNvbnN0IGN5ID0gaGVpZ2h0ICogMC4zNjtcbiAgY29uc3Qgc2NhbGUgPSBNYXRoLm1pbih3aWR0aCwgaGVpZ2h0KSAvIDUyMDtcbiAgY29uc3QgcGFsZXR0ZSA9IFBBTEVUVEVTW2Zsb3dlclR5cGVdIHx8IFBBTEVUVEVTLnBpbmtfcm9zZTtcblxuICBsZXQgcGhyYXNlSWR4ID0gMDtcbiAgY29uc3QgZ2V0TmV4dFBocmFzZSA9ICgpOiBMb3ZlUGhyYXNlID0+IHtcbiAgICBjb25zdCBwID0gTE9WRV9QSFJBU0VTW3BocmFzZUlkeCAlIExPVkVfUEhSQVNFUy5sZW5ndGhdO1xuICAgIHBocmFzZUlkeCsrO1xuICAgIHJldHVybiBwO1xuICB9O1xuXG4gIGxldCBpZENvdW50ZXIgPSAwO1xuXG4gIC8vIDEuIEZPUiBQSU5LIFJPU0UgJiBSRUQgUk9TRSAmIFdISVRFIFJPU0U6XG4gIC8vIFVzZSB0aGUgZXhhY3QgMzEtcm93IGxheW91dCBmcm9tIGltYWdlXzhiNWY5ZjBhLnBuZyB3aXRoIGdlbmVyb3VzIHNwYWNpbmchXG4gIGlmIChmbG93ZXJUeXBlID09PSAncGlua19yb3NlJyB8fCBmbG93ZXJUeXBlID09PSAncmVkX3Jvc2UnIHx8IGZsb3dlclR5cGUgPT09ICd3aGl0ZV9yb3NlJykge1xuICAgIGNvbnN0IGhlYWRUb3RhbFJvd3MgPSBFWEFDVF9ST1NFX0hFQURfUk9XUy5sZW5ndGg7XG4gICAgY29uc3QgaGVhZFJvd0hlaWdodCA9IE1hdGgubWF4KDEzLCBNYXRoLnJvdW5kKDE1LjUgKiBzY2FsZSkpO1xuICAgIGNvbnN0IGhlYWRTdGFydFkgPSBjeSAtIChoZWFkVG90YWxSb3dzICogaGVhZFJvd0hlaWdodCAqIDAuNTIpO1xuXG4gICAgRVhBQ1RfUk9TRV9IRUFEX1JPV1MuZm9yRWFjaCgocm93LCByb3dJbmRleCkgPT4ge1xuICAgICAgY29uc3QgeSA9IE1hdGgucm91bmQoaGVhZFN0YXJ0WSArIHJvd0luZGV4ICogaGVhZFJvd0hlaWdodCk7XG4gICAgICBjb25zdCB2YWxpZFdvcmRzID0gcm93LmZpbHRlcigodykgPT4gdy50ZXh0LnRyaW0oKS5sZW5ndGggPiAwKTtcbiAgICAgIGlmICh2YWxpZFdvcmRzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuXG4gICAgICBjb25zdCB3b3JkU3BhbnMgPSB2YWxpZFdvcmRzLm1hcCgodykgPT4ge1xuICAgICAgICBjb25zdCBpc0xhcmdlID0gdy5pc0JvbGQgfHwgdy5pc0JyaWdodDtcbiAgICAgICAgY29uc3QgZm9udFNpemUgPSBNYXRoLm1heCg5LjUsIE1hdGgucm91bmQoKGlzTGFyZ2UgPyAxMi41IDogMTAuNSkgKiBzY2FsZSkpO1xuICAgICAgICBjb25zdCB3aWR0aCA9IE1hdGgucm91bmQody50ZXh0Lmxlbmd0aCAqIGZvbnRTaXplICogMC42Mik7XG4gICAgICAgIHJldHVybiB7IC4uLncsIGZvbnRTaXplLCB3aWR0aCB9O1xuICAgICAgfSk7XG5cbiAgICAgIGNvbnN0IGdhcCA9IE1hdGgubWF4KDcsIE1hdGgucm91bmQoOS41ICogc2NhbGUpKTtcbiAgICAgIGNvbnN0IHRvdGFsUm93V2lkdGggPSB3b3JkU3BhbnMucmVkdWNlKChhY2MsIHcpID0+IGFjYyArIHcud2lkdGgsIDApICsgKHdvcmRTcGFucy5sZW5ndGggLSAxKSAqIGdhcDtcbiAgICAgIGxldCBjdXJYID0gY3ggLSAodG90YWxSb3dXaWR0aCAvIDIpO1xuXG4gICAgICB3b3JkU3BhbnMuZm9yRWFjaCgodykgPT4ge1xuICAgICAgICBjb25zdCB3b3JkQ2VudGVyWCA9IE1hdGgucm91bmQoY3VyWCArIHcud2lkdGggLyAyKTtcbiAgICAgICAgY29uc3QgcGhyYXNlID0gZ2V0UGhyYXNlRm9yV29yZCh3LnRleHQpO1xuXG4gICAgICAgIGxldCBjb2xvcjogc3RyaW5nO1xuICAgICAgICBpZiAody5pc0JyaWdodCkge1xuICAgICAgICAgIGNvbG9yID0gJyNmZmZmZmYnO1xuICAgICAgICB9IGVsc2UgaWYgKHcuaXNCb2xkKSB7XG4gICAgICAgICAgY29sb3IgPSBwYWxldHRlLnBldGFsc1swXTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjb2xvciA9IHBhbGV0dGUucGV0YWxzW2lkQ291bnRlciAlIHBhbGV0dGUucGV0YWxzLmxlbmd0aF07XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBpc0RlZGljYXRpb24gPSByb3dJbmRleCA9PT0gMTEgJiYgTWF0aC5hYnMod29yZENlbnRlclggLSBjeCkgPCAzMCAqIHNjYWxlICYmIGN1c3RvbURlZGljYXRpb247XG4gICAgICAgIGNvbnN0IGZpbmFsVGV4dCA9IGlzRGVkaWNhdGlvbiA/IGDimaUgJHtjdXN0b21EZWRpY2F0aW9ufSDimaVgIDogdy50ZXh0O1xuICAgICAgICBpZiAoaXNEZWRpY2F0aW9uKSBjb2xvciA9ICcjZmZmZmZmJztcblxuICAgICAgICBlbGVtZW50cy5wdXNoKHtcbiAgICAgICAgICBpZDogYCR7Zmxvd2VyVHlwZX0tJHtpZENvdW50ZXIrK31gLFxuICAgICAgICAgIHBocmFzZSxcbiAgICAgICAgICB0ZXh0OiBmaW5hbFRleHQsXG4gICAgICAgICAgeDogd29yZENlbnRlclgsXG4gICAgICAgICAgeSxcbiAgICAgICAgICB3aWR0aDogdy53aWR0aCxcbiAgICAgICAgICBoZWlnaHQ6IHcuZm9udFNpemUgKyA0LFxuICAgICAgICAgIGFuZ2xlOiAwLFxuICAgICAgICAgIGZvbnRTaXplOiB3LmZvbnRTaXplLFxuICAgICAgICAgIGZvbnRXZWlnaHQ6IHcuaXNCb2xkIHx8IHcuaXNCcmlnaHQgPyAnODAwJyA6ICc3MDAnLFxuICAgICAgICAgIGNvbG9yLFxuICAgICAgICAgIHBhcnQ6ICdwZXRhbCcsXG4gICAgICAgICAgb3JkZXI6IDAuMzUgKyAocm93SW5kZXggLyBoZWFkVG90YWxSb3dzKSAqIDAuNjUsXG4gICAgICAgICAgaXNHcmVlbjogZmFsc2UsXG4gICAgICAgIH0pO1xuXG4gICAgICAgIGN1clggKz0gdy53aWR0aCArIGdhcDtcbiAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgLy8gQXBwZW5kIENhbHl4ICYgRm9saWFnZVxuICAgIGFwcGVuZFN0ZW1BbmRMZWF2ZXMoZWxlbWVudHMsIGN4LCBoZWFkU3RhcnRZICsgaGVhZFRvdGFsUm93cyAqIGhlYWRSb3dIZWlnaHQgKyAoNCAqIHNjYWxlKSwgc2NhbGUsIHBhbGV0dGUuc3RlbSwgaWRDb3VudGVyKTtcbiAgICByZXR1cm4gZWxlbWVudHM7XG4gIH1cblxuICAvLyAyLiBGT1IgUElOSyBMSUxZIChFeGFjdCBDdXJhdGVkIFN0YXJnYXplciBTdGFyIFBldGFscyArIEdvbGRlbiBTdGFtZW5zKVxuICBpZiAoZmxvd2VyVHlwZSA9PT0gJ3BpbmtfbGlseScpIHtcbiAgICBjb25zdCBsaWx5VG90YWxSb3dzID0gRVhBQ1RfTElMWV9ST1dTLmxlbmd0aDtcbiAgICBjb25zdCByb3dIZWlnaHQgPSBNYXRoLm1heCgxMywgTWF0aC5yb3VuZCgxNS41ICogc2NhbGUpKTtcbiAgICBjb25zdCBzdGFydFkgPSBjeSAtIChsaWx5VG90YWxSb3dzICogcm93SGVpZ2h0ICogMC41Mik7XG5cbiAgICBFWEFDVF9MSUxZX1JPV1MuZm9yRWFjaCgocm93LCByb3dJbmRleCkgPT4ge1xuICAgICAgY29uc3QgeSA9IE1hdGgucm91bmQoc3RhcnRZICsgcm93SW5kZXggKiByb3dIZWlnaHQpO1xuICAgICAgY29uc3QgdmFsaWRXb3JkcyA9IHJvdy5maWx0ZXIoKHcpID0+IHcudGV4dC50cmltKCkubGVuZ3RoID4gMCk7XG4gICAgICBpZiAodmFsaWRXb3Jkcy5sZW5ndGggPT09IDApIHJldHVybjtcblxuICAgICAgY29uc3Qgd29yZFNwYW5zID0gdmFsaWRXb3Jkcy5tYXAoKHcpID0+IHtcbiAgICAgICAgY29uc3QgaXNMYXJnZSA9IHcuaXNCb2xkIHx8IHcuaXNCcmlnaHQ7XG4gICAgICAgIGNvbnN0IGZvbnRTaXplID0gTWF0aC5tYXgoOS41LCBNYXRoLnJvdW5kKChpc0xhcmdlID8gMTIuNSA6IDEwLjUpICogc2NhbGUpKTtcbiAgICAgICAgY29uc3Qgd2lkdGggPSBNYXRoLnJvdW5kKHcudGV4dC5sZW5ndGggKiBmb250U2l6ZSAqIDAuNjIpO1xuICAgICAgICByZXR1cm4geyAuLi53LCBmb250U2l6ZSwgd2lkdGggfTtcbiAgICAgIH0pO1xuXG4gICAgICBjb25zdCBnYXAgPSBNYXRoLm1heCg3LCBNYXRoLnJvdW5kKDkuNSAqIHNjYWxlKSk7XG4gICAgICBjb25zdCB0b3RhbFJvd1dpZHRoID0gd29yZFNwYW5zLnJlZHVjZSgoYWNjLCB3KSA9PiBhY2MgKyB3LndpZHRoLCAwKSArICh3b3JkU3BhbnMubGVuZ3RoIC0gMSkgKiBnYXA7XG4gICAgICBsZXQgY3VyWCA9IGN4IC0gKHRvdGFsUm93V2lkdGggLyAyKTtcblxuICAgICAgd29yZFNwYW5zLmZvckVhY2goKHcpID0+IHtcbiAgICAgICAgY29uc3Qgd29yZENlbnRlclggPSBNYXRoLnJvdW5kKGN1clggKyB3LndpZHRoIC8gMik7XG4gICAgICAgIGNvbnN0IHBocmFzZSA9IGdldFBocmFzZUZvcldvcmQody50ZXh0KTtcblxuICAgICAgICBsZXQgY29sb3I6IHN0cmluZztcbiAgICAgICAgaWYgKHcuaXNCcmlnaHQpIHtcbiAgICAgICAgICBjb2xvciA9ICcjZmZmZmZmJztcbiAgICAgICAgfSBlbHNlIGlmICh3LmlzQm9sZCkge1xuICAgICAgICAgIGNvbG9yID0gcGFsZXR0ZS5wZXRhbHNbMF07XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY29sb3IgPSBwYWxldHRlLnBldGFsc1tpZENvdW50ZXIgJSBwYWxldHRlLnBldGFscy5sZW5ndGhdO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgaXNEZWRpY2F0aW9uID0gcm93SW5kZXggPT09IDEwICYmIE1hdGguYWJzKHdvcmRDZW50ZXJYIC0gY3gpIDwgMzAgKiBzY2FsZSAmJiBjdXN0b21EZWRpY2F0aW9uO1xuICAgICAgICBjb25zdCBmaW5hbFRleHQgPSBpc0RlZGljYXRpb24gPyBg4pmlICR7Y3VzdG9tRGVkaWNhdGlvbn0g4pmlYCA6IHcudGV4dDtcbiAgICAgICAgaWYgKGlzRGVkaWNhdGlvbikgY29sb3IgPSAnI2ZmZmZmZic7XG5cbiAgICAgICAgZWxlbWVudHMucHVzaCh7XG4gICAgICAgICAgaWQ6IGBleGFjdC1saWx5LSR7aWRDb3VudGVyKyt9YCxcbiAgICAgICAgICBwaHJhc2UsXG4gICAgICAgICAgdGV4dDogZmluYWxUZXh0LFxuICAgICAgICAgIHg6IHdvcmRDZW50ZXJYLFxuICAgICAgICAgIHksXG4gICAgICAgICAgd2lkdGg6IHcud2lkdGgsXG4gICAgICAgICAgaGVpZ2h0OiB3LmZvbnRTaXplICsgNCxcbiAgICAgICAgICBhbmdsZTogMCxcbiAgICAgICAgICBmb250U2l6ZTogdy5mb250U2l6ZSxcbiAgICAgICAgICBmb250V2VpZ2h0OiB3LmlzQm9sZCB8fCB3LmlzQnJpZ2h0ID8gJzgwMCcgOiAnNzAwJyxcbiAgICAgICAgICBjb2xvcixcbiAgICAgICAgICBwYXJ0OiAncGV0YWwnLFxuICAgICAgICAgIG9yZGVyOiAwLjM1ICsgKHJvd0luZGV4IC8gbGlseVRvdGFsUm93cykgKiAwLjY1LFxuICAgICAgICAgIGlzR3JlZW46IGZhbHNlLFxuICAgICAgICB9KTtcblxuICAgICAgICBjdXJYICs9IHcud2lkdGggKyBnYXA7XG4gICAgICB9KTtcbiAgICB9KTtcblxuICAgIC8vIEdvbGRlbiBTdGFtZW5zIEFyY2hpbmcgRnJvbSB0aGUgVGhyb2F0XG4gICAgY29uc3QgdGhyb2F0WSA9IE1hdGgucm91bmQoc3RhcnRZICsgbGlseVRvdGFsUm93cyAqIHJvd0hlaWdodCAqIDAuNzApO1xuICAgIExJTFlfU1RBTUVOUy5mb3JFYWNoKChzdGFtZW4sIGlkeCkgPT4ge1xuICAgICAgY29uc3QgcmFkaXVzID0gOTUgKiBzY2FsZSAqIHN0YW1lbi5kaXN0O1xuICAgICAgY29uc3QgYW5nbGUgPSAtTWF0aC5QSSAvIDIgKyBzdGFtZW4uYW5nbGVPZmZzZXQ7XG4gICAgICBjb25zdCBzeCA9IE1hdGgucm91bmQoY3ggKyBNYXRoLmNvcyhhbmdsZSkgKiByYWRpdXMpO1xuICAgICAgY29uc3Qgc3kgPSBNYXRoLnJvdW5kKHRocm9hdFkgKyBNYXRoLnNpbihhbmdsZSkgKiAocmFkaXVzICogMC44MikpO1xuXG4gICAgICBjb25zdCBmb250U2l6ZSA9IE1hdGgubWF4KDEwLCBNYXRoLnJvdW5kKDExICogc2NhbGUpKTtcbiAgICAgIGNvbnN0IHdpZHRoID0gTWF0aC5yb3VuZChzdGFtZW4udGV4dC5sZW5ndGggKiBmb250U2l6ZSAqIDAuNjIpO1xuXG4gICAgICBlbGVtZW50cy5wdXNoKHtcbiAgICAgICAgaWQ6IGBleGFjdC1zdGFtZW4tJHtpZENvdW50ZXIrK31gLFxuICAgICAgICBwaHJhc2U6IGdldFBocmFzZUZvcldvcmQoc3RhbWVuLnRleHQucmVwbGFjZSgv4pymL2csICcnKS50cmltKCkpLFxuICAgICAgICB0ZXh0OiBzdGFtZW4udGV4dCxcbiAgICAgICAgeDogc3gsXG4gICAgICAgIHk6IHN5LFxuICAgICAgICB3aWR0aCxcbiAgICAgICAgaGVpZ2h0OiBmb250U2l6ZSArIDQsXG4gICAgICAgIGFuZ2xlOiAwLFxuICAgICAgICBmb250U2l6ZSxcbiAgICAgICAgZm9udFdlaWdodDogJzgwMCcsXG4gICAgICAgIGNvbG9yOiAnI2Y1OWUwYicsIC8vIEdvbGRlbiBBbWJlciBwb2xsZW5cbiAgICAgICAgcGFydDogJ3N0YW1lbicsXG4gICAgICAgIG9yZGVyOiAwLjg4ICsgKGlkeCAvIExJTFlfU1RBTUVOUy5sZW5ndGgpICogMC4xMixcbiAgICAgICAgaXNHcmVlbjogZmFsc2UsXG4gICAgICB9KTtcbiAgICB9KTtcblxuICAgIC8vIEZvbGlhZ2UgJiBTdGVtIGZvciBQaW5rIExpbHlcbiAgICBjb25zdCBjYWx5eFN0YXJ0WSA9IE1hdGgucm91bmQoc3RhcnRZICsgbGlseVRvdGFsUm93cyAqIHJvd0hlaWdodCArICg0ICogc2NhbGUpKTtcbiAgICBjb25zdCBjYWx5eFJvd0ggPSBNYXRoLm1heCgxMywgTWF0aC5yb3VuZCgxNSAqIHNjYWxlKSk7XG5cbiAgICAvLyBDYWx5eFxuICAgIExJTFlfRk9MSUFHRS5jYWx5eC5mb3JFYWNoKChyb3csIHJJZHgpID0+IHtcbiAgICAgIGNvbnN0IHkgPSBNYXRoLnJvdW5kKGNhbHl4U3RhcnRZICsgcklkeCAqIGNhbHl4Um93SCk7XG4gICAgICBjb25zdCBnYXAgPSBNYXRoLm1heCg4LCBNYXRoLnJvdW5kKDEwICogc2NhbGUpKTtcbiAgICAgIGNvbnN0IHdvcmRTcGFucyA9IHJvdy5tYXAoKHcpID0+IHtcbiAgICAgICAgY29uc3QgZm9udFNpemUgPSBNYXRoLm1heCg5LjUsIE1hdGgucm91bmQoMTEgKiBzY2FsZSkpO1xuICAgICAgICBjb25zdCB3aWR0aCA9IE1hdGgucm91bmQody50ZXh0Lmxlbmd0aCAqIGZvbnRTaXplICogMC42Mik7XG4gICAgICAgIHJldHVybiB7IC4uLncsIGZvbnRTaXplLCB3aWR0aCB9O1xuICAgICAgfSk7XG4gICAgICBjb25zdCB0b3RhbFcgPSB3b3JkU3BhbnMucmVkdWNlKChhY2MsIHcpID0+IGFjYyArIHcud2lkdGgsIDApICsgKHdvcmRTcGFucy5sZW5ndGggLSAxKSAqIGdhcDtcbiAgICAgIGxldCBjdXJYID0gY3ggLSB0b3RhbFcgLyAyO1xuXG4gICAgICB3b3JkU3BhbnMuZm9yRWFjaCgodykgPT4ge1xuICAgICAgICBlbGVtZW50cy5wdXNoKHtcbiAgICAgICAgICBpZDogYGxpbHktY2FseXgtJHtpZENvdW50ZXIrK31gLFxuICAgICAgICAgIHBocmFzZTogZ2V0UGhyYXNlRm9yV29yZCh3LnRleHQpLFxuICAgICAgICAgIHRleHQ6IHcudGV4dCxcbiAgICAgICAgICB4OiBNYXRoLnJvdW5kKGN1clggKyB3LndpZHRoIC8gMiksXG4gICAgICAgICAgeSxcbiAgICAgICAgICB3aWR0aDogdy53aWR0aCxcbiAgICAgICAgICBoZWlnaHQ6IHcuZm9udFNpemUgKyA0LFxuICAgICAgICAgIGFuZ2xlOiAwLFxuICAgICAgICAgIGZvbnRTaXplOiB3LmZvbnRTaXplLFxuICAgICAgICAgIGZvbnRXZWlnaHQ6ICc3MDAnLFxuICAgICAgICAgIGNvbG9yOiBwYWxldHRlLnN0ZW1baWRDb3VudGVyICUgcGFsZXR0ZS5zdGVtLmxlbmd0aF0sXG4gICAgICAgICAgcGFydDogJ3N0ZW0nLFxuICAgICAgICAgIG9yZGVyOiAwLjMwIC0gcklkeCAvIDEwLFxuICAgICAgICAgIGlzR3JlZW46IHRydWUsXG4gICAgICAgIH0pO1xuICAgICAgICBjdXJYICs9IHcud2lkdGggKyBnYXA7XG4gICAgICB9KTtcbiAgICB9KTtcblxuICAgIC8vIFVwcGVyIExhbmNlb2xhdGUgTGVhdmVzXG4gICAgY29uc3QgbGVhZlN0YXJ0WSA9IGNhbHl4U3RhcnRZICsgY2FseXhSb3dIICogMjtcbiAgICBMSUxZX0ZPTElBR0UudXBwZXJMZWF2ZXMubGVmdC5mb3JFYWNoKChyb3csIHJJZHgpID0+IHtcbiAgICAgIGNvbnN0IHkgPSBNYXRoLnJvdW5kKGxlYWZTdGFydFkgKyBySWR4ICogY2FseXhSb3dIKTtcbiAgICAgIGNvbnN0IGdhcCA9IE1hdGgubWF4KDYsIE1hdGgucm91bmQoOCAqIHNjYWxlKSk7XG4gICAgICBjb25zdCB3b3JkU3BhbnMgPSByb3cubWFwKCh3KSA9PiB7XG4gICAgICAgIGNvbnN0IGZvbnRTaXplID0gTWF0aC5tYXgoOSwgTWF0aC5yb3VuZCgxMC41ICogc2NhbGUpKTtcbiAgICAgICAgY29uc3Qgd2lkdGggPSBNYXRoLnJvdW5kKHcudGV4dC5sZW5ndGggKiBmb250U2l6ZSAqIDAuNjIpO1xuICAgICAgICByZXR1cm4geyAuLi53LCBmb250U2l6ZSwgd2lkdGggfTtcbiAgICAgIH0pO1xuICAgICAgY29uc3QgdG90YWxXID0gd29yZFNwYW5zLnJlZHVjZSgoYWNjLCB3KSA9PiBhY2MgKyB3LndpZHRoLCAwKSArICh3b3JkU3BhbnMubGVuZ3RoIC0gMSkgKiBnYXA7XG4gICAgICBsZXQgY3VyWCA9IGN4IC0gMTIgKiBzY2FsZSAtIHRvdGFsVztcblxuICAgICAgd29yZFNwYW5zLmZvckVhY2goKHcpID0+IHtcbiAgICAgICAgZWxlbWVudHMucHVzaCh7XG4gICAgICAgICAgaWQ6IGBsaWx5LWxlZnQtbGVhZi0ke2lkQ291bnRlcisrfWAsXG4gICAgICAgICAgcGhyYXNlOiBnZXRQaHJhc2VGb3JXb3JkKHcudGV4dCksXG4gICAgICAgICAgdGV4dDogdy50ZXh0LFxuICAgICAgICAgIHg6IE1hdGgucm91bmQoY3VyWCArIHcud2lkdGggLyAyKSxcbiAgICAgICAgICB5LFxuICAgICAgICAgIHdpZHRoOiB3LndpZHRoLFxuICAgICAgICAgIGhlaWdodDogdy5mb250U2l6ZSArIDQsXG4gICAgICAgICAgYW5nbGU6IDAsXG4gICAgICAgICAgZm9udFNpemU6IHcuZm9udFNpemUsXG4gICAgICAgICAgZm9udFdlaWdodDogJzcwMCcsXG4gICAgICAgICAgY29sb3I6IHBhbGV0dGUuc3RlbVsocklkeCArIGlkQ291bnRlcikgJSBwYWxldHRlLnN0ZW0ubGVuZ3RoXSxcbiAgICAgICAgICBwYXJ0OiAnbGVhZicsXG4gICAgICAgICAgb3JkZXI6IDAuMTUgKyBySWR4IC8gMTUsXG4gICAgICAgICAgaXNHcmVlbjogdHJ1ZSxcbiAgICAgICAgfSk7XG4gICAgICAgIGN1clggKz0gdy53aWR0aCArIGdhcDtcbiAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgTElMWV9GT0xJQUdFLnVwcGVyTGVhdmVzLnJpZ2h0LmZvckVhY2goKHJvdywgcklkeCkgPT4ge1xuICAgICAgY29uc3QgeSA9IE1hdGgucm91bmQobGVhZlN0YXJ0WSArIChySWR4ICsgMSkgKiBjYWx5eFJvd0gpO1xuICAgICAgY29uc3QgZ2FwID0gTWF0aC5tYXgoNiwgTWF0aC5yb3VuZCg4ICogc2NhbGUpKTtcbiAgICAgIGNvbnN0IHdvcmRTcGFucyA9IHJvdy5tYXAoKHcpID0+IHtcbiAgICAgICAgY29uc3QgZm9udFNpemUgPSBNYXRoLm1heCg5LCBNYXRoLnJvdW5kKDEwLjUgKiBzY2FsZSkpO1xuICAgICAgICBjb25zdCB3aWR0aCA9IE1hdGgucm91bmQody50ZXh0Lmxlbmd0aCAqIGZvbnRTaXplICogMC42Mik7XG4gICAgICAgIHJldHVybiB7IC4uLncsIGZvbnRTaXplLCB3aWR0aCB9O1xuICAgICAgfSk7XG4gICAgICBsZXQgY3VyWCA9IGN4ICsgMTQgKiBzY2FsZTtcblxuICAgICAgd29yZFNwYW5zLmZvckVhY2goKHcpID0+IHtcbiAgICAgICAgZWxlbWVudHMucHVzaCh7XG4gICAgICAgICAgaWQ6IGBsaWx5LXJpZ2h0LWxlYWYtJHtpZENvdW50ZXIrK31gLFxuICAgICAgICAgIHBocmFzZTogZ2V0UGhyYXNlRm9yV29yZCh3LnRleHQpLFxuICAgICAgICAgIHRleHQ6IHcudGV4dCxcbiAgICAgICAgICB4OiBNYXRoLnJvdW5kKGN1clggKyB3LndpZHRoIC8gMiksXG4gICAgICAgICAgeSxcbiAgICAgICAgICB3aWR0aDogdy53aWR0aCxcbiAgICAgICAgICBoZWlnaHQ6IHcuZm9udFNpemUgKyA0LFxuICAgICAgICAgIGFuZ2xlOiAwLFxuICAgICAgICAgIGZvbnRTaXplOiB3LmZvbnRTaXplLFxuICAgICAgICAgIGZvbnRXZWlnaHQ6ICc3MDAnLFxuICAgICAgICAgIGNvbG9yOiBwYWxldHRlLnN0ZW1bKHJJZHggKiAyICsgaWRDb3VudGVyKSAlIHBhbGV0dGUuc3RlbS5sZW5ndGhdLFxuICAgICAgICAgIHBhcnQ6ICdsZWFmJyxcbiAgICAgICAgICBvcmRlcjogMC4xOCArIHJJZHggLyAxNSxcbiAgICAgICAgICBpc0dyZWVuOiB0cnVlLFxuICAgICAgICB9KTtcbiAgICAgICAgY3VyWCArPSB3LndpZHRoICsgZ2FwO1xuICAgICAgfSk7XG4gICAgfSk7XG5cbiAgICAvLyBMb3dlciBTdGVtXG4gICAgY29uc3QgbG93ZXJTdGVtU3RhcnRZID0gbGVhZlN0YXJ0WSArIDQgKiBjYWx5eFJvd0g7XG4gICAgTElMWV9GT0xJQUdFLmxvd2VyU3RlbS5mb3JFYWNoKChyb3csIHJJZHgpID0+IHtcbiAgICAgIGNvbnN0IHkgPSBNYXRoLnJvdW5kKGxvd2VyU3RlbVN0YXJ0WSArIHJJZHggKiBjYWx5eFJvd0gpO1xuICAgICAgY29uc3QgZ2FwID0gTWF0aC5tYXgoNiwgTWF0aC5yb3VuZCg4ICogc2NhbGUpKTtcbiAgICAgIGNvbnN0IHdvcmRTcGFucyA9IHJvdy5tYXAoKHcpID0+IHtcbiAgICAgICAgY29uc3QgZm9udFNpemUgPSBNYXRoLm1heCg5LCBNYXRoLnJvdW5kKDEwLjUgKiBzY2FsZSkpO1xuICAgICAgICBjb25zdCB3aWR0aCA9IE1hdGgucm91bmQody50ZXh0Lmxlbmd0aCAqIGZvbnRTaXplICogMC42Mik7XG4gICAgICAgIHJldHVybiB7IC4uLncsIGZvbnRTaXplLCB3aWR0aCB9O1xuICAgICAgfSk7XG4gICAgICBjb25zdCB0b3RhbFcgPSB3b3JkU3BhbnMucmVkdWNlKChhY2MsIHcpID0+IGFjYyArIHcud2lkdGgsIDApICsgKHdvcmRTcGFucy5sZW5ndGggLSAxKSAqIGdhcDtcbiAgICAgIGxldCBjdXJYID0gY3ggLSB0b3RhbFcgLyAyO1xuXG4gICAgICB3b3JkU3BhbnMuZm9yRWFjaCgodykgPT4ge1xuICAgICAgICBlbGVtZW50cy5wdXNoKHtcbiAgICAgICAgICBpZDogYGxpbHktc3RlbS0ke2lkQ291bnRlcisrfWAsXG4gICAgICAgICAgcGhyYXNlOiBnZXRQaHJhc2VGb3JXb3JkKHcudGV4dCksXG4gICAgICAgICAgdGV4dDogdy50ZXh0LFxuICAgICAgICAgIHg6IE1hdGgucm91bmQoY3VyWCArIHcud2lkdGggLyAyKSxcbiAgICAgICAgICB5LFxuICAgICAgICAgIHdpZHRoOiB3LndpZHRoLFxuICAgICAgICAgIGhlaWdodDogdy5mb250U2l6ZSArIDQsXG4gICAgICAgICAgYW5nbGU6IDAsXG4gICAgICAgICAgZm9udFNpemU6IHcuZm9udFNpemUsXG4gICAgICAgICAgZm9udFdlaWdodDogJzcwMCcsXG4gICAgICAgICAgY29sb3I6IHBhbGV0dGUuc3RlbVsocklkeCArIGlkQ291bnRlcikgJSBwYWxldHRlLnN0ZW0ubGVuZ3RoXSxcbiAgICAgICAgICBwYXJ0OiAnc3RlbScsXG4gICAgICAgICAgb3JkZXI6IDAuMDUgKyBySWR4IC8gMzAsXG4gICAgICAgICAgaXNHcmVlbjogdHJ1ZSxcbiAgICAgICAgfSk7XG4gICAgICAgIGN1clggKz0gdy53aWR0aCArIGdhcDtcbiAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgcmV0dXJuIGVsZW1lbnRzO1xuICB9XG5cbiAgLy8gMy4gRk9SIEdPTERFTiBTVU5GTE9XRVIgKFJhZGlhbnQgU3VuYnVyc3QgUGV0YWxzIGFyb3VuZCBBbWJlciBTZWVkIERpc2spXG4gIGlmIChmbG93ZXJUeXBlID09PSAnZ29sZGVuX3N1bmZsb3dlcicpIHtcbiAgICBjb25zdCBzZlRvdGFsUm93cyA9IDI1O1xuICAgIGNvbnN0IHJvd0hlaWdodCA9IE1hdGgubWF4KDEzLCBNYXRoLnJvdW5kKDE1LjUgKiBzY2FsZSkpO1xuICAgIGNvbnN0IHN0YXJ0WSA9IGN5IC0gKHNmVG90YWxSb3dzICogcm93SGVpZ2h0ICogMC41MCk7XG5cbiAgICBjb25zdCBpc0luc2lkZVN1bmZsb3dlciA9IChkeDogbnVtYmVyLCBkeTogbnVtYmVyKSA9PiB7XG4gICAgICBjb25zdCBkaXN0ID0gTWF0aC5zcXJ0KGR4ICogZHggKyBkeSAqIGR5KTtcbiAgICAgIGlmIChkaXN0IDw9IDY1ICogc2NhbGUpIHJldHVybiB0cnVlOyAvLyBDZW50ZXIgc2VlZCBkaXNrXG4gICAgICAvLyBSYWRpYXRpbmcgc3VuYnVyc3QgcmF5IHBldGFsc1xuICAgICAgaWYgKGRpc3QgPD0gMTcwICogc2NhbGUpIHtcbiAgICAgICAgY29uc3QgYW5nID0gTWF0aC5hdGFuMihkeSwgZHgpO1xuICAgICAgICBjb25zdCByYXlzID0gTWF0aC5hYnMoTWF0aC5jb3MoYW5nICogOCkpOyAvLyAxNiBwZXRhbHMgYXJvdW5kIHBlcmltZXRlclxuICAgICAgICByZXR1cm4gZGlzdCA8PSAoMTAwICsgcmF5cyAqIDcwKSAqIHNjYWxlO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH07XG5cbiAgICBwYWNrU2hhcGVSb3dzKGVsZW1lbnRzLCBpc0luc2lkZVN1bmZsb3dlciwgc3RhcnRZLCBzZlRvdGFsUm93cywgcm93SGVpZ2h0LCBjeCwgc2NhbGUsIHBhbGV0dGUucGV0YWxzLCAnI2ZlZjA4YScsIGdldE5leHRQaHJhc2UsIGlkQ291bnRlciwgY3VzdG9tRGVkaWNhdGlvbik7XG4gICAgYXBwZW5kU3RlbUFuZExlYXZlcyhlbGVtZW50cywgY3gsIHN0YXJ0WSArIHNmVG90YWxSb3dzICogcm93SGVpZ2h0ICsgKDYgKiBzY2FsZSksIHNjYWxlLCBwYWxldHRlLnN0ZW0sIGlkQ291bnRlcik7XG4gICAgcmV0dXJuIGVsZW1lbnRzO1xuICB9XG5cbiAgLy8gNC4gRk9SIFJPWUFMIFRVTElQIChHcmFjZWZ1bCAzLVBldGFsIEdvYmxldCBDdXApXG4gIGlmIChmbG93ZXJUeXBlID09PSAncm95YWxfdHVsaXAnKSB7XG4gICAgY29uc3QgdHVsaXBUb3RhbFJvd3MgPSAyNDtcbiAgICBjb25zdCByb3dIZWlnaHQgPSBNYXRoLm1heCgxMywgTWF0aC5yb3VuZCgxNS41ICogc2NhbGUpKTtcbiAgICBjb25zdCBzdGFydFkgPSBjeSAtICh0dWxpcFRvdGFsUm93cyAqIHJvd0hlaWdodCAqIDAuNTApO1xuXG4gICAgY29uc3QgaXNJbnNpZGVUdWxpcCA9IChkeDogbnVtYmVyLCBkeTogbnVtYmVyKSA9PiB7XG4gICAgICBpZiAoZHkgPj0gLTE2MCAqIHNjYWxlICYmIGR5IDw9IDMwICogc2NhbGUpIHtcbiAgICAgICAgY29uc3QgdCA9IChkeSArIDE2MCAqIHNjYWxlKSAvICgxOTAgKiBzY2FsZSk7IC8vIDAgYXQgdG9wLCAxIGF0IGJhc2VcbiAgICAgICAgbGV0IG1heFc7XG4gICAgICAgIGlmICh0IDwgMC4yOCkge1xuICAgICAgICAgIC8vIFBvaW50ZWQgdHVsaXAgdGlwcyB3aXRoIGRlZXAgY2VudGVyIGNsZWZ0XG4gICAgICAgICAgY29uc3QgY2xlZnQgPSBNYXRoLmFicyhkeCkgPCAyNSAqIHNjYWxlID8gMjUgKiBzY2FsZSAqICgxIC0gTWF0aC5hYnMoZHgpIC8gKDI1ICogc2NhbGUpKSA6IDA7XG4gICAgICAgICAgaWYgKGR5IDwgLTE2MCAqIHNjYWxlICsgY2xlZnQpIHJldHVybiBmYWxzZTtcbiAgICAgICAgICBtYXhXID0gMTI1ICogc2NhbGUgKiBNYXRoLnNpbigodCAvIDAuMjgpICogTWF0aC5QSSAvIDIpICsgKDE1ICogc2NhbGUpO1xuICAgICAgICB9IGVsc2UgaWYgKHQgPCAwLjc1KSB7XG4gICAgICAgICAgbWF4VyA9IDEzOCAqIHNjYWxlICogTWF0aC5zaW4odCAqIE1hdGguUEkgKiAwLjk1KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBtYXhXID0gMTM4ICogc2NhbGUgKiAoMSAtICgodCAtIDAuNzUpIC8gMC4yNSkgKiAwLjcwKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gTWF0aC5hYnMoZHgpIDw9IG1heFc7XG4gICAgICB9XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfTtcblxuICAgIHBhY2tTaGFwZVJvd3MoZWxlbWVudHMsIGlzSW5zaWRlVHVsaXAsIHN0YXJ0WSwgdHVsaXBUb3RhbFJvd3MsIHJvd0hlaWdodCwgY3gsIHNjYWxlLCBwYWxldHRlLnBldGFscywgJyNmNWQwZmUnLCBnZXROZXh0UGhyYXNlLCBpZENvdW50ZXIsIGN1c3RvbURlZGljYXRpb24pO1xuICAgIGFwcGVuZFN0ZW1BbmRMZWF2ZXMoZWxlbWVudHMsIGN4LCBzdGFydFkgKyB0dWxpcFRvdGFsUm93cyAqIHJvd0hlaWdodCArICg2ICogc2NhbGUpLCBzY2FsZSwgcGFsZXR0ZS5zdGVtLCBpZENvdW50ZXIpO1xuICAgIHJldHVybiBlbGVtZW50cztcbiAgfVxuXG4gIHJldHVybiBlbGVtZW50cztcbn1cblxuLy8gSGVscGVyIHRvIHBhY2sgcm93cyBmb3IgcGFyYW1ldHJpYyBmbG93ZXJzXG5mdW5jdGlvbiBwYWNrU2hhcGVSb3dzKFxuICBlbGVtZW50czogRmxvd2VyVGV4dEVsZW1lbnRbXSxcbiAgaW5zaWRlVGVzdDogKGR4OiBudW1iZXIsIGR5OiBudW1iZXIpID0+IGJvb2xlYW4sXG4gIHN0YXJ0WTogbnVtYmVyLFxuICB0b3RhbFJvd3M6IG51bWJlcixcbiAgcm93SGVpZ2h0OiBudW1iZXIsXG4gIGN4OiBudW1iZXIsXG4gIHNjYWxlOiBudW1iZXIsXG4gIGNvbG9yczogc3RyaW5nW10sXG4gIGhpZ2hsaWdodENvbG9yOiBzdHJpbmcsXG4gIGdldE5leHRQaHJhc2U6ICgpID0+IExvdmVQaHJhc2UsXG4gIGlkQ291bnRlcjogbnVtYmVyLFxuICBjdXN0b21EZWRpY2F0aW9uPzogc3RyaW5nXG4pIHtcbiAgY29uc3Qgc2hvcnRQaHJhc2VzID0gWydMT1ZFJywgJ0FNT1InLCAn7IKs656R7ZW0JywgJ+eIsScsICfmiJHniLHkvaAnLCAnVEUgQU1PJywgJ1RJIEFNTycsICdBbW91cicsICdMSUVCRScsICfYo9it2KjZgyddO1xuXG4gIGZvciAobGV0IHIgPSAwOyByIDwgdG90YWxSb3dzOyByKyspIHtcbiAgICBjb25zdCB5ID0gTWF0aC5yb3VuZChzdGFydFkgKyByICogcm93SGVpZ2h0KTtcbiAgICBjb25zdCBkeSA9IHkgLSAoc3RhcnRZICsgKHRvdGFsUm93cyAqIHJvd0hlaWdodCkgLyAyKTtcblxuICAgIGNvbnN0IGludGVydmFsczogW251bWJlciwgbnVtYmVyXVtdID0gW107XG4gICAgbGV0IGN1clN0YXJ0OiBudW1iZXIgfCBudWxsID0gbnVsbDtcbiAgICBjb25zdCBzY2FuU3RlcCA9IDQgKiBzY2FsZTtcblxuICAgIGZvciAobGV0IHggPSBjeCAtIDIxMCAqIHNjYWxlOyB4IDw9IGN4ICsgMjEwICogc2NhbGU7IHggKz0gc2NhblN0ZXApIHtcbiAgICAgIGNvbnN0IGhpdCA9IGluc2lkZVRlc3QoeCAtIGN4LCBkeSk7XG4gICAgICBpZiAoaGl0KSB7XG4gICAgICAgIGlmIChjdXJTdGFydCA9PT0gbnVsbCkgY3VyU3RhcnQgPSB4O1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgaWYgKGN1clN0YXJ0ICE9PSBudWxsKSB7XG4gICAgICAgICAgaW50ZXJ2YWxzLnB1c2goW2N1clN0YXJ0LCB4IC0gc2NhblN0ZXBdKTtcbiAgICAgICAgICBjdXJTdGFydCA9IG51bGw7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKGN1clN0YXJ0ICE9PSBudWxsKSBpbnRlcnZhbHMucHVzaChbY3VyU3RhcnQsIGN4ICsgMjEwICogc2NhbGVdKTtcblxuICAgIGZvciAoY29uc3QgW3hTdGFydCwgeEVuZF0gb2YgaW50ZXJ2YWxzKSB7XG4gICAgICBjb25zdCBzcGFuID0geEVuZCAtIHhTdGFydDtcbiAgICAgIGlmIChzcGFuIDwgMjYgKiBzY2FsZSkgY29udGludWU7XG5cbiAgICAgIGxldCBjdXJYID0geFN0YXJ0ICsgNCAqIHNjYWxlO1xuICAgICAgd2hpbGUgKGN1clggPCB4RW5kIC0gMTAgKiBzY2FsZSkge1xuICAgICAgICBjb25zdCByZW1haW5pbmcgPSB4RW5kIC0gY3VyWDtcbiAgICAgICAgbGV0IHBocmFzZSA9IGdldE5leHRQaHJhc2UoKTtcbiAgICAgICAgbGV0IHRleHQgPSBwaHJhc2UucGhyYXNlO1xuXG4gICAgICAgIGlmIChyZW1haW5pbmcgPCA2NSAqIHNjYWxlICYmIHRleHQubGVuZ3RoID4gNykge1xuICAgICAgICAgIHRleHQgPSBzaG9ydFBocmFzZXNbaWRDb3VudGVyICUgc2hvcnRQaHJhc2VzLmxlbmd0aF07XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBpc1Byb21pbmVudCA9IGlkQ291bnRlciAlIDYgPT09IDAgfHwgdGV4dCA9PT0gJ0xPVkUnIHx8IHRleHQgPT09ICdURSBBTU8nIHx8IHRleHQgPT09ICdBTU9SJztcbiAgICAgICAgY29uc3QgZm9udFNpemUgPSBNYXRoLm1heCg5LjUsIE1hdGgucm91bmQoKGlzUHJvbWluZW50ID8gMTIuNSA6IDEwLjUpICogc2NhbGUpKTtcbiAgICAgICAgY29uc3QgZXN0aW1hdGVkV2lkdGggPSBNYXRoLnJvdW5kKHRleHQubGVuZ3RoICogZm9udFNpemUgKiAwLjYyKTtcblxuICAgICAgICBpZiAoY3VyWCArIGVzdGltYXRlZFdpZHRoIDw9IHhFbmQgKyA0ICogc2NhbGUpIHtcbiAgICAgICAgICBjb25zdCB3b3JkQ2VudGVyWCA9IE1hdGgucm91bmQoY3VyWCArIGVzdGltYXRlZFdpZHRoIC8gMik7XG4gICAgICAgICAgY29uc3QgaXNDZW50ZXIgPSBNYXRoLmFicyh3b3JkQ2VudGVyWCAtIGN4KSA8IDI4ICogc2NhbGUgJiYgTWF0aC5hYnMoZHkpIDwgMTggKiBzY2FsZSAmJiBjdXN0b21EZWRpY2F0aW9uO1xuICAgICAgICAgIGNvbnN0IGZpbmFsVGV4dCA9IGlzQ2VudGVyID8gYOKZpSAke2N1c3RvbURlZGljYXRpb259IOKZpWAgOiB0ZXh0O1xuXG4gICAgICAgICAgbGV0IGNvbG9yOiBzdHJpbmc7XG4gICAgICAgICAgaWYgKGlzQ2VudGVyKSB7XG4gICAgICAgICAgICBjb2xvciA9ICcjZmZmZmZmJztcbiAgICAgICAgICB9IGVsc2UgaWYgKGlzUHJvbWluZW50KSB7XG4gICAgICAgICAgICBjb2xvciA9IGhpZ2hsaWdodENvbG9yO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjb2xvciA9IGNvbG9yc1tpZENvdW50ZXIgJSBjb2xvcnMubGVuZ3RoXTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBlbGVtZW50cy5wdXNoKHtcbiAgICAgICAgICAgIGlkOiBgZmxvd2VyLXdvcmQtJHtpZENvdW50ZXIrK31gLFxuICAgICAgICAgICAgcGhyYXNlLFxuICAgICAgICAgICAgdGV4dDogZmluYWxUZXh0LFxuICAgICAgICAgICAgeDogd29yZENlbnRlclgsXG4gICAgICAgICAgICB5LFxuICAgICAgICAgICAgd2lkdGg6IGVzdGltYXRlZFdpZHRoLFxuICAgICAgICAgICAgaGVpZ2h0OiBmb250U2l6ZSArIDQsXG4gICAgICAgICAgICBhbmdsZTogMCxcbiAgICAgICAgICAgIGZvbnRTaXplLFxuICAgICAgICAgICAgZm9udFdlaWdodDogaXNQcm9taW5lbnQgfHwgaXNDZW50ZXIgPyAnODAwJyA6ICc3MDAnLFxuICAgICAgICAgICAgY29sb3IsXG4gICAgICAgICAgICBwYXJ0OiAncGV0YWwnLFxuICAgICAgICAgICAgb3JkZXI6IDAuMzUgKyAociAvIHRvdGFsUm93cykgKiAwLjY1LFxuICAgICAgICAgICAgaXNHcmVlbjogZmFsc2UsXG4gICAgICAgICAgfSk7XG5cbiAgICAgICAgICBjdXJYICs9IGVzdGltYXRlZFdpZHRoICsgTWF0aC5tYXgoNywgTWF0aC5yb3VuZCg5LjUgKiBzY2FsZSkpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG59XG5cbi8vIEhlbHBlciB0byBhcHBlbmQgZXhhY3QgZ3JlZW4gc3RlbSBhbmQgbGVhdmVzXG5mdW5jdGlvbiBhcHBlbmRTdGVtQW5kTGVhdmVzKFxuICBlbGVtZW50czogRmxvd2VyVGV4dEVsZW1lbnRbXSxcbiAgY3g6IG51bWJlcixcbiAgc3RhcnRZOiBudW1iZXIsXG4gIHNjYWxlOiBudW1iZXIsXG4gIHN0ZW1Db2xvcnM6IHN0cmluZ1tdLFxuICBpZENvdW50ZXI6IG51bWJlclxuKSB7XG4gIGNvbnN0IHJvd0ggPSBNYXRoLm1heCgxMywgTWF0aC5yb3VuZCgxNSAqIHNjYWxlKSk7XG5cbiAgLy8gMS4gQ2FseXhcbiAgRVhBQ1RfU1RFTV9BTkRfTEVBVkVTLmNhbHl4LmZvckVhY2goKHJvdywgcklkeCkgPT4ge1xuICAgIGNvbnN0IHkgPSBNYXRoLnJvdW5kKHN0YXJ0WSArIHJJZHggKiByb3dIKTtcbiAgICBjb25zdCBnYXAgPSBNYXRoLm1heCg4LCBNYXRoLnJvdW5kKDEwICogc2NhbGUpKTtcbiAgICBjb25zdCB3b3JkU3BhbnMgPSByb3cubWFwKCh3KSA9PiB7XG4gICAgICBjb25zdCBmb250U2l6ZSA9IE1hdGgubWF4KDkuNSwgTWF0aC5yb3VuZCgxMSAqIHNjYWxlKSk7XG4gICAgICBjb25zdCB3aWR0aCA9IE1hdGgucm91bmQody50ZXh0Lmxlbmd0aCAqIGZvbnRTaXplICogMC42Mik7XG4gICAgICByZXR1cm4geyAuLi53LCBmb250U2l6ZSwgd2lkdGggfTtcbiAgICB9KTtcbiAgICBjb25zdCB0b3RhbFcgPSB3b3JkU3BhbnMucmVkdWNlKChhY2MsIHcpID0+IGFjYyArIHcud2lkdGgsIDApICsgKHdvcmRTcGFucy5sZW5ndGggLSAxKSAqIGdhcDtcbiAgICBsZXQgY3VyWCA9IGN4IC0gdG90YWxXIC8gMjtcblxuICAgIHdvcmRTcGFucy5mb3JFYWNoKCh3KSA9PiB7XG4gICAgICBlbGVtZW50cy5wdXNoKHtcbiAgICAgICAgaWQ6IGBjYWx5eC0ke2lkQ291bnRlcisrfWAsXG4gICAgICAgIHBocmFzZTogZ2V0UGhyYXNlRm9yV29yZCh3LnRleHQpLFxuICAgICAgICB0ZXh0OiB3LnRleHQsXG4gICAgICAgIHg6IE1hdGgucm91bmQoY3VyWCArIHcud2lkdGggLyAyKSxcbiAgICAgICAgeSxcbiAgICAgICAgd2lkdGg6IHcud2lkdGgsXG4gICAgICAgIGhlaWdodDogdy5mb250U2l6ZSArIDQsXG4gICAgICAgIGFuZ2xlOiAwLFxuICAgICAgICBmb250U2l6ZTogdy5mb250U2l6ZSxcbiAgICAgICAgZm9udFdlaWdodDogJzcwMCcsXG4gICAgICAgIGNvbG9yOiBzdGVtQ29sb3JzW2lkQ291bnRlciAlIHN0ZW1Db2xvcnMubGVuZ3RoXSxcbiAgICAgICAgcGFydDogJ3N0ZW0nLFxuICAgICAgICBvcmRlcjogMC4zMCAtIHJJZHggLyAxMCxcbiAgICAgICAgaXNHcmVlbjogdHJ1ZSxcbiAgICAgIH0pO1xuICAgICAgY3VyWCArPSB3LndpZHRoICsgZ2FwO1xuICAgIH0pO1xuICB9KTtcblxuICAvLyAyLiBMZWZ0IExlYWZcbiAgY29uc3QgbGVmdExlYWZTdGFydFkgPSBzdGFydFkgKyByb3dIICogMztcbiAgRVhBQ1RfU1RFTV9BTkRfTEVBVkVTLmxlZnRMZWFmLmZvckVhY2goKHJvdywgcklkeCkgPT4ge1xuICAgIGNvbnN0IHkgPSBNYXRoLnJvdW5kKGxlZnRMZWFmU3RhcnRZICsgcklkeCAqIHJvd0gpO1xuICAgIGNvbnN0IGdhcCA9IE1hdGgubWF4KDYsIE1hdGgucm91bmQoOCAqIHNjYWxlKSk7XG4gICAgY29uc3Qgd29yZFNwYW5zID0gcm93Lm1hcCgodykgPT4ge1xuICAgICAgY29uc3QgZm9udFNpemUgPSBNYXRoLm1heCg5LCBNYXRoLnJvdW5kKDEwLjUgKiBzY2FsZSkpO1xuICAgICAgY29uc3Qgd2lkdGggPSBNYXRoLnJvdW5kKHcudGV4dC5sZW5ndGggKiBmb250U2l6ZSAqIDAuNjIpO1xuICAgICAgcmV0dXJuIHsgLi4udywgZm9udFNpemUsIHdpZHRoIH07XG4gICAgfSk7XG4gICAgY29uc3QgdG90YWxXID0gd29yZFNwYW5zLnJlZHVjZSgoYWNjLCB3KSA9PiBhY2MgKyB3LndpZHRoLCAwKSArICh3b3JkU3BhbnMubGVuZ3RoIC0gMSkgKiBnYXA7XG4gICAgbGV0IGN1clggPSBjeCAtICgxMiAqIHNjYWxlKSAtIHRvdGFsVztcblxuICAgIHdvcmRTcGFucy5mb3JFYWNoKCh3KSA9PiB7XG4gICAgICBlbGVtZW50cy5wdXNoKHtcbiAgICAgICAgaWQ6IGBsZWZ0LWxlYWYtJHtpZENvdW50ZXIrK31gLFxuICAgICAgICBwaHJhc2U6IGdldFBocmFzZUZvcldvcmQody50ZXh0KSxcbiAgICAgICAgdGV4dDogdy50ZXh0LFxuICAgICAgICB4OiBNYXRoLnJvdW5kKGN1clggKyB3LndpZHRoIC8gMiksXG4gICAgICAgIHksXG4gICAgICAgIHdpZHRoOiB3LndpZHRoLFxuICAgICAgICBoZWlnaHQ6IHcuZm9udFNpemUgKyA0LFxuICAgICAgICBhbmdsZTogMCxcbiAgICAgICAgZm9udFNpemU6IHcuZm9udFNpemUsXG4gICAgICAgIGZvbnRXZWlnaHQ6ICc3MDAnLFxuICAgICAgICBjb2xvcjogc3RlbUNvbG9yc1socklkeCArIGlkQ291bnRlcikgJSBzdGVtQ29sb3JzLmxlbmd0aF0sXG4gICAgICAgIHBhcnQ6ICdsZWFmJyxcbiAgICAgICAgb3JkZXI6IDAuMTUgKyBySWR4IC8gMTUsXG4gICAgICAgIGlzR3JlZW46IHRydWUsXG4gICAgICB9KTtcbiAgICAgIGN1clggKz0gdy53aWR0aCArIGdhcDtcbiAgICB9KTtcbiAgfSk7XG5cbiAgLy8gMy4gUmlnaHQgTGVhZlxuICBjb25zdCByaWdodExlYWZTdGFydFkgPSBsZWZ0TGVhZlN0YXJ0WSArIHJvd0ggKiAyO1xuICBFWEFDVF9TVEVNX0FORF9MRUFWRVMucmlnaHRMZWFmLmZvckVhY2goKHJvdywgcklkeCkgPT4ge1xuICAgIGNvbnN0IHkgPSBNYXRoLnJvdW5kKHJpZ2h0TGVhZlN0YXJ0WSArIHJJZHggKiByb3dIKTtcbiAgICBjb25zdCBnYXAgPSBNYXRoLm1heCg2LCBNYXRoLnJvdW5kKDggKiBzY2FsZSkpO1xuICAgIGNvbnN0IHdvcmRTcGFucyA9IHJvdy5tYXAoKHcpID0+IHtcbiAgICAgIGNvbnN0IGZvbnRTaXplID0gTWF0aC5tYXgoOSwgTWF0aC5yb3VuZCgxMC41ICogc2NhbGUpKTtcbiAgICAgIGNvbnN0IHdpZHRoID0gTWF0aC5yb3VuZCh3LnRleHQubGVuZ3RoICogZm9udFNpemUgKiAwLjYyKTtcbiAgICAgIHJldHVybiB7IC4uLncsIGZvbnRTaXplLCB3aWR0aCB9O1xuICAgIH0pO1xuICAgIGxldCBjdXJYID0gY3ggKyAxNCAqIHNjYWxlO1xuXG4gICAgd29yZFNwYW5zLmZvckVhY2goKHcpID0+IHtcbiAgICAgIGVsZW1lbnRzLnB1c2goe1xuICAgICAgICBpZDogYHJpZ2h0LWxlYWYtJHtpZENvdW50ZXIrK31gLFxuICAgICAgICBwaHJhc2U6IGdldFBocmFzZUZvcldvcmQody50ZXh0KSxcbiAgICAgICAgdGV4dDogdy50ZXh0LFxuICAgICAgICB4OiBNYXRoLnJvdW5kKGN1clggKyB3LndpZHRoIC8gMiksXG4gICAgICAgIHksXG4gICAgICAgIHdpZHRoOiB3LndpZHRoLFxuICAgICAgICBoZWlnaHQ6IHcuZm9udFNpemUgKyA0LFxuICAgICAgICBhbmdsZTogMCxcbiAgICAgICAgZm9udFNpemU6IHcuZm9udFNpemUsXG4gICAgICAgIGZvbnRXZWlnaHQ6ICc3MDAnLFxuICAgICAgICBjb2xvcjogc3RlbUNvbG9yc1socklkeCAqIDIgKyBpZENvdW50ZXIpICUgc3RlbUNvbG9ycy5sZW5ndGhdLFxuICAgICAgICBwYXJ0OiAnbGVhZicsXG4gICAgICAgIG9yZGVyOiAwLjE4ICsgcklkeCAvIDE1LFxuICAgICAgICBpc0dyZWVuOiB0cnVlLFxuICAgICAgfSk7XG4gICAgICBjdXJYICs9IHcud2lkdGggKyBnYXA7XG4gICAgfSk7XG4gIH0pO1xuXG4gIC8vIDQuIExvd2VyIFN0ZW0gQ29sdW1uXG4gIGNvbnN0IGxvd2VyU3RlbVN0YXJ0WSA9IGxlZnRMZWFmU3RhcnRZICsgRVhBQ1RfU1RFTV9BTkRfTEVBVkVTLmxlZnRMZWFmLmxlbmd0aCAqIHJvd0g7XG4gIEVYQUNUX1NURU1fQU5EX0xFQVZFUy5sb3dlclN0ZW0uZm9yRWFjaCgocm93LCBySWR4KSA9PiB7XG4gICAgY29uc3QgeSA9IE1hdGgucm91bmQobG93ZXJTdGVtU3RhcnRZICsgcklkeCAqIHJvd0gpO1xuICAgIGNvbnN0IGdhcCA9IE1hdGgubWF4KDYsIE1hdGgucm91bmQoOCAqIHNjYWxlKSk7XG4gICAgY29uc3Qgd29yZFNwYW5zID0gcm93Lm1hcCgodykgPT4ge1xuICAgICAgY29uc3QgZm9udFNpemUgPSBNYXRoLm1heCg5LCBNYXRoLnJvdW5kKDEwLjUgKiBzY2FsZSkpO1xuICAgICAgY29uc3Qgd2lkdGggPSBNYXRoLnJvdW5kKHcudGV4dC5sZW5ndGggKiBmb250U2l6ZSAqIDAuNjIpO1xuICAgICAgcmV0dXJuIHsgLi4udywgZm9udFNpemUsIHdpZHRoIH07XG4gICAgfSk7XG4gICAgY29uc3QgdG90YWxXID0gd29yZFNwYW5zLnJlZHVjZSgoYWNjLCB3KSA9PiBhY2MgKyB3LndpZHRoLCAwKSArICh3b3JkU3BhbnMubGVuZ3RoIC0gMSkgKiBnYXA7XG4gICAgbGV0IGN1clggPSBjeCAtIHRvdGFsVyAvIDI7XG5cbiAgICB3b3JkU3BhbnMuZm9yRWFjaCgodykgPT4ge1xuICAgICAgZWxlbWVudHMucHVzaCh7XG4gICAgICAgIGlkOiBgbG93ZXItc3RlbS0ke2lkQ291bnRlcisrfWAsXG4gICAgICAgIHBocmFzZTogZ2V0UGhyYXNlRm9yV29yZCh3LnRleHQpLFxuICAgICAgICB0ZXh0OiB3LnRleHQsXG4gICAgICAgIHg6IE1hdGgucm91bmQoY3VyWCArIHcud2lkdGggLyAyKSxcbiAgICAgICAgeSxcbiAgICAgICAgd2lkdGg6IHcud2lkdGgsXG4gICAgICAgIGhlaWdodDogdy5mb250U2l6ZSArIDQsXG4gICAgICAgIGFuZ2xlOiAwLFxuICAgICAgICBmb250U2l6ZTogdy5mb250U2l6ZSxcbiAgICAgICAgZm9udFdlaWdodDogJzcwMCcsXG4gICAgICAgIGNvbG9yOiBzdGVtQ29sb3JzWyhySWR4ICsgaWRDb3VudGVyKSAlIHN0ZW1Db2xvcnMubGVuZ3RoXSxcbiAgICAgICAgcGFydDogJ3N0ZW0nLFxuICAgICAgICBvcmRlcjogMC4wNSArIHJJZHggLyAzMCxcbiAgICAgICAgaXNHcmVlbjogdHJ1ZSxcbiAgICAgIH0pO1xuICAgICAgY3VyWCArPSB3LndpZHRoICsgZ2FwO1xuICAgIH0pO1xuICB9KTtcbn1cbiJdfQ==