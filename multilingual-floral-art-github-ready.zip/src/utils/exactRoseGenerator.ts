import { EXACT_ROSE_HEAD_ROWS, EXACT_STEM_AND_LEAVES } from "/src/data/roseExactData.ts";
import { LOVE_PHRASES } from "/src/data/languages.ts";
// Map word text to phrase object for translation card & audio pronunciation
const phraseLookup = new Map();
// Prepopulate lookup table
LOVE_PHRASES.forEach((p) => {
	phraseLookup.set(p.phrase.toLowerCase(), p);
	phraseLookup.set(p.language.toLowerCase(), p);
});
// Specific mappings for all languages appearing in the image
const customPhraseMap = {
	"nakupenda": {
		id: "sw",
		phrase: "Nakupenda",
		language: "Swahili",
		native: "Kiswahili",
		pronunciation: "nah-koo-PEN-dah",
		region: "Africa",
		flag: "🇰🇪",
		funFact: "A single complete Swahili verb meaning 'I love you warmly'."
	},
	"liebe": {
		id: "de",
		phrase: "Liebe (Ich liebe dich)",
		language: "German",
		native: "Deutsch",
		pronunciation: "LEE-buh",
		region: "Europe",
		flag: "🇩🇪",
		funFact: "German poetic root for pure heartfelt romantic love."
	},
	"amor": {
		id: "es",
		phrase: "Amor (Te amo)",
		language: "Spanish / Portuguese",
		native: "Español / Português",
		pronunciation: "ah-MOR",
		region: "Americas",
		flag: "🇪🇸",
		funFact: "The universal Romance declaration of eternal devotion."
	},
	"amour": {
		id: "fr",
		phrase: "Amour (Je t’aime)",
		language: "French",
		native: "Français",
		pronunciation: "ah-MOOR",
		region: "Europe",
		flag: "🇫🇷",
		funFact: "The city of light's eternal poetic word for profound love."
	},
	"รักคุณ": {
		id: "th",
		phrase: "รักคุณ (Rak khun)",
		language: "Thai",
		native: "ไทย",
		pronunciation: "rak khoon",
		region: "Asia",
		flag: "🇹🇭",
		funFact: "Courtly Thai expression denoting reverent romantic love."
	},
	"szeretlek": {
		id: "hu",
		phrase: "Szeretlek",
		language: "Hungarian",
		native: "Magyar",
		pronunciation: "SEH-ret-lek",
		region: "Europe",
		flag: "🇭🇺",
		funFact: "Compresses subject and object into one intimate verb: 'I love YOU'."
	},
	"kocham cię": {
		id: "pl",
		phrase: "Kocham cię",
		language: "Polish",
		native: "Polski",
		pronunciation: "KOH-khahm chyeh",
		region: "Europe",
		flag: "🇵🇱",
		funFact: "Polish expression of deep tenderness and cherished protection."
	},
	"אני אוהבת אותך": {
		id: "he",
		phrase: "אני אוהבת אותך",
		language: "Hebrew",
		native: "עברית",
		pronunciation: "ani ohevet otcha",
		region: "Middle East",
		flag: "🇮🇱",
		funFact: "Song of Solomon: 'I am my beloved’s, and my beloved is mine'."
	},
	"నిన్ను ప్రేమిస్తున్నాను": {
		id: "te",
		phrase: "నిన్ను ప్రేమిస్తున్నాను (Ninnu premistunnanu)",
		language: "Telugu",
		native: "తెలుగు",
		pronunciation: "nin-noo preh-mis-toon-nah-noo",
		region: "Asia",
		flag: "🇮🇳",
		funFact: "Celebrated in classical South Indian lyrical poetry."
	},
	"ভালোবাসি": {
		id: "bn",
		phrase: "আমি তোমাকে ভালোবাসি",
		language: "Bengali",
		native: "বাংলা",
		pronunciation: "bhalobashi",
		region: "Asia",
		flag: "🇧🇩",
		funFact: "Language of Nobel laureate Rabindranath Tagore: 'making a home of goodness'."
	},
	"jag älskar dig": {
		id: "sv",
		phrase: "Jag älskar dig",
		language: "Swedish",
		native: "Svenska",
		pronunciation: "yahg EL-skar dey",
		region: "Europe",
		flag: "🇸🇪",
		funFact: "From Old Norse 'elska'—caring tenderly through Arctic winters."
	},
	"jeg elsker dig": {
		id: "da",
		phrase: "Jeg elsker dig",
		language: "Danish",
		native: "Dansk",
		pronunciation: "yai el-sker dai",
		region: "Europe",
		flag: "🇩🇰",
		funFact: "Deeply connected to the Danish warmth of hygge."
	},
	"anh yêu em": {
		id: "vi",
		phrase: "Anh yêu em",
		language: "Vietnamese",
		native: "Tiếng Việt",
		pronunciation: "ahn eeyew em",
		region: "Asia",
		flag: "🇻🇳",
		funFact: "Tender relation of protective care for one's beloved flower."
	},
	"te quiero": {
		id: "es-q",
		phrase: "Te quiero",
		language: "Spanish",
		native: "Español",
		pronunciation: "teh kee-EH-roh",
		region: "Americas",
		flag: "🇲🇽",
		funFact: "Expresses everyday intimate affection and fond longing."
	},
	"rakastan sinua": {
		id: "fi",
		phrase: "Rakastan sinua",
		language: "Finnish",
		native: "Suomi",
		pronunciation: "RAH-kas-tahn SEE-noo-ah",
		region: "Europe",
		flag: "🇫🇮",
		funFact: "A solemn, lifelong vow of sincerity in Finland."
	},
	"ljubim te": {
		id: "sl",
		phrase: "Ljubim te",
		language: "Slovenian / Croatian",
		native: "Slovenščina",
		pronunciation: "LYOO-beem teh",
		region: "Europe",
		flag: "🇸🇮",
		funFact: "Lyrical Slavic expression of passionate devotion."
	},
	"te iubesc": {
		id: "ro",
		phrase: "Te iubesc",
		language: "Romanian",
		native: "Română",
		pronunciation: "teh yoo-BESK",
		region: "Europe",
		flag: "🇷🇴",
		funFact: "Latin grammar combined with Slavic sweetness of the soul."
	},
	"volim te": {
		id: "hr",
		phrase: "Volim te",
		language: "Croatian / Serbian",
		native: "Hrvatski",
		pronunciation: "VOH-leem teh",
		region: "Europe",
		flag: "🇭🇷",
		funFact: "'I choose you with all my free will and love'."
	}
};
export function getPhraseForWord(wordText) {
	const clean = wordText.trim().toLowerCase();
	if (customPhraseMap[clean]) return customPhraseMap[clean];
	for (const [k, v] of phraseLookup.entries()) {
		if (k.includes(clean) || clean.includes(k)) return v;
	}
	// Fallback generic phrase
	return {
		id: "universal",
		phrase: wordText,
		language: "Universal Love",
		native: wordText,
		pronunciation: wordText,
		region: "Europe",
		flag: "💖",
		funFact: "A sacred word of affection spoken from the depths of the human heart."
	};
}
/**
* Generates the EXACT "same-to-same" Rose layout from image_8b5f9f0a.png
* with generous, crystal-clear spacing and a vibrant Pink Rose palette!
*/
export function generateExactSameRoseElements(width, height, isPinkRose = true, customDedication) {
	const elements = [];
	const cx = width / 2;
	const cy = height * .36;
	const scale = Math.min(width, height) / 520;
	// Luminous Pink Rose palette (when isPinkRose = true)
	const pinkPalette = [
		"#ff2d75",
		"#ff69b4",
		"#f43f5e",
		"#fda4af",
		"#fbcfe8",
		"#ff1493"
	];
	// Classic Red Rose palette (matches original image_8b5f9f0a.png exactly)
	const redPalette = [
		"#e11d48",
		"#ff1744",
		"#f43f5e",
		"#be123c",
		"#fda4af"
	];
	const flowerColors = isPinkRose ? pinkPalette : redPalette;
	// Green stem & leaves palette
	const greenPalette = [
		"#22c55e",
		"#4ade80",
		"#10b981",
		"#86efac",
		"#16a34a"
	];
	let idCounter = 0;
	// 1. GENERATE THE ROSE HEAD (Exact rows 1 to 31)
	const headTotalRows = EXACT_ROSE_HEAD_ROWS.length;
	const headRowHeight = Math.max(13, Math.round(15.5 * scale));
	const headStartY = cy - headTotalRows * headRowHeight * .52;
	EXACT_ROSE_HEAD_ROWS.forEach((row, rowIndex) => {
		const y = Math.round(headStartY + rowIndex * headRowHeight);
		const validWords = row.filter((w) => w.text.trim().length > 0);
		if (validWords.length === 0) return;
		// Calculate total row width based on character count and generous spacing
		const wordSpans = validWords.map((w) => {
			const isLarge = w.isBold || w.isBright;
			const fontSize = Math.max(9.5, Math.round((isLarge ? 12.5 : 10.5) * scale));
			const charW = fontSize * .62;
			const width = Math.round(w.text.length * charW);
			return {
				...w,
				fontSize,
				width
			};
		});
		// Generous clean spacing between words (8px to 14px)
		const gap = Math.max(7, Math.round(9.5 * scale));
		const totalRowWidth = wordSpans.reduce((acc, w) => acc + w.width, 0) + (wordSpans.length - 1) * gap;
		// Center the row horizontally
		let curX = cx - totalRowWidth / 2;
		wordSpans.forEach((w) => {
			const wordCenterX = Math.round(curX + w.width / 2);
			const phrase = getPhraseForWord(w.text);
			// Color selection
			let color;
			if (w.isBright) {
				color = "#ffffff";
			} else if (w.isBold) {
				color = isPinkRose ? "#ff69b4" : "#ff1744";
			} else {
				color = flowerColors[idCounter % flowerColors.length];
			}
			// Check center dedication
			const isDedicationPos = rowIndex === 11 && Math.abs(wordCenterX - cx) < 30 * scale && customDedication;
			const finalText = isDedicationPos ? `♥ ${customDedication} ♥` : w.text;
			if (isDedicationPos) {
				color = "#ffffff";
			}
			elements.push({
				id: `exact-rose-${idCounter++}`,
				phrase,
				text: finalText,
				x: wordCenterX,
				y,
				width: w.width,
				height: w.fontSize + 4,
				angle: 0,
				fontSize: w.fontSize,
				fontWeight: w.isBold || w.isBright ? "800" : "700",
				color,
				part: "petal",
				order: .35 + rowIndex / headTotalRows * .65,
				isGreen: false
			});
			curX += w.width + gap;
		});
	});
	// 2. GENERATE STEM CALYX (Top of stem junction right below rose head)
	const calyxStartY = Math.round(headStartY + headTotalRows * headRowHeight + 4 * scale);
	const calyxRowHeight = Math.max(13, Math.round(15 * scale));
	EXACT_STEM_AND_LEAVES.calyx.forEach((row, rIdx) => {
		const y = Math.round(calyxStartY + rIdx * calyxRowHeight);
		const gap = Math.max(8, Math.round(10 * scale));
		const wordSpans = row.map((w) => {
			const fontSize = Math.max(9.5, Math.round(11 * scale));
			const width = Math.round(w.text.length * fontSize * .62);
			return {
				...w,
				fontSize,
				width
			};
		});
		const totalW = wordSpans.reduce((acc, w) => acc + w.width, 0) + (wordSpans.length - 1) * gap;
		let curX = cx - totalW / 2;
		wordSpans.forEach((w) => {
			const wordCenterX = Math.round(curX + w.width / 2);
			elements.push({
				id: `calyx-${idCounter++}`,
				phrase: getPhraseForWord(w.text),
				text: w.text,
				x: wordCenterX,
				y,
				width: w.width,
				height: w.fontSize + 4,
				angle: 0,
				fontSize: w.fontSize,
				fontWeight: "700",
				color: greenPalette[idCounter % greenPalette.length],
				part: "stem",
				order: .3 - rIdx / 10,
				isGreen: true
			});
			curX += w.width + gap;
		});
	});
	// 3. GENERATE LEFT LEAF CLUSTER
	const leftLeafStartY = calyxStartY + calyxRowHeight * 3;
	EXACT_STEM_AND_LEAVES.leftLeaf.forEach((row, rIdx) => {
		const y = Math.round(leftLeafStartY + rIdx * calyxRowHeight);
		const gap = Math.max(6, Math.round(8 * scale));
		const wordSpans = row.map((w) => {
			const fontSize = Math.max(9, Math.round(10.5 * scale));
			const width = Math.round(w.text.length * fontSize * .62);
			return {
				...w,
				fontSize,
				width
			};
		});
		const totalW = wordSpans.reduce((acc, w) => acc + w.width, 0) + (wordSpans.length - 1) * gap;
		// Position to the left of the center stem
		const rightEdge = cx - 12 * scale;
		let curX = rightEdge - totalW;
		wordSpans.forEach((w) => {
			const wordCenterX = Math.round(curX + w.width / 2);
			elements.push({
				id: `left-leaf-${idCounter++}`,
				phrase: getPhraseForWord(w.text),
				text: w.text,
				x: wordCenterX,
				y,
				width: w.width,
				height: w.fontSize + 4,
				angle: 0,
				fontSize: w.fontSize,
				fontWeight: "700",
				color: greenPalette[(rIdx + idCounter) % greenPalette.length],
				part: "leaf",
				order: .15 + rIdx / 15,
				isGreen: true
			});
			curX += w.width + gap;
		});
	});
	// 4. GENERATE RIGHT LEAF CLUSTER
	const rightLeafStartY = leftLeafStartY + calyxRowHeight * 2;
	EXACT_STEM_AND_LEAVES.rightLeaf.forEach((row, rIdx) => {
		const y = Math.round(rightLeafStartY + rIdx * calyxRowHeight);
		const gap = Math.max(6, Math.round(8 * scale));
		const wordSpans = row.map((w) => {
			const fontSize = Math.max(9, Math.round(10.5 * scale));
			const width = Math.round(w.text.length * fontSize * .62);
			return {
				...w,
				fontSize,
				width
			};
		});
		const leftEdge = cx + 14 * scale;
		let curX = leftEdge;
		wordSpans.forEach((w) => {
			const wordCenterX = Math.round(curX + w.width / 2);
			elements.push({
				id: `right-leaf-${idCounter++}`,
				phrase: getPhraseForWord(w.text),
				text: w.text,
				x: wordCenterX,
				y,
				width: w.width,
				height: w.fontSize + 4,
				angle: 0,
				fontSize: w.fontSize,
				fontWeight: "700",
				color: greenPalette[(rIdx * 2 + idCounter) % greenPalette.length],
				part: "leaf",
				order: .18 + rIdx / 15,
				isGreen: true
			});
			curX += w.width + gap;
		});
	});
	// 5. GENERATE LOWER STEM COLUMN
	const lowerStemStartY = leftLeafStartY + EXACT_STEM_AND_LEAVES.leftLeaf.length * calyxRowHeight;
	EXACT_STEM_AND_LEAVES.lowerStem.forEach((row, rIdx) => {
		const y = Math.round(lowerStemStartY + rIdx * calyxRowHeight);
		const gap = Math.max(6, Math.round(8 * scale));
		const wordSpans = row.map((w) => {
			const fontSize = Math.max(9, Math.round(10.5 * scale));
			const width = Math.round(w.text.length * fontSize * .62);
			return {
				...w,
				fontSize,
				width
			};
		});
		const totalW = wordSpans.reduce((acc, w) => acc + w.width, 0) + (wordSpans.length - 1) * gap;
		let curX = cx - totalW / 2;
		wordSpans.forEach((w) => {
			const wordCenterX = Math.round(curX + w.width / 2);
			elements.push({
				id: `lower-stem-${idCounter++}`,
				phrase: getPhraseForWord(w.text),
				text: w.text,
				x: wordCenterX,
				y,
				width: w.width,
				height: w.fontSize + 4,
				angle: 0,
				fontSize: w.fontSize,
				fontWeight: "700",
				color: greenPalette[(rIdx + idCounter) % greenPalette.length],
				part: "stem",
				order: .05 + rIdx / 30,
				isGreen: true
			});
			curX += w.width + gap;
		});
	});
	return elements;
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxzQkFBc0IsNkJBQTZCO0FBQzVELFNBQVMsb0JBQWdDOztBQUl6QyxNQUFNLGVBQWUsSUFBSSxJQUF3Qjs7QUFHakQsYUFBYSxTQUFTLE1BQU07Q0FDMUIsYUFBYSxJQUFJLEVBQUUsT0FBTyxZQUFZLEdBQUcsQ0FBQztDQUMxQyxhQUFhLElBQUksRUFBRSxTQUFTLFlBQVksR0FBRyxDQUFDO0FBQzlDLENBQUM7O0FBR0QsTUFBTSxrQkFBOEM7Q0FDbEQsYUFBYTtFQUNYLElBQUk7RUFDSixRQUFRO0VBQ1IsVUFBVTtFQUNWLFFBQVE7RUFDUixlQUFlO0VBQ2YsUUFBUTtFQUNSLE1BQU07RUFDTixTQUFTO0NBQ1g7Q0FDQSxTQUFTO0VBQ1AsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBLFFBQVE7RUFDTixJQUFJO0VBQ0osUUFBUTtFQUNSLFVBQVU7RUFDVixRQUFRO0VBQ1IsZUFBZTtFQUNmLFFBQVE7RUFDUixNQUFNO0VBQ04sU0FBUztDQUNYO0NBQ0EsU0FBUztFQUNQLElBQUk7RUFDSixRQUFRO0VBQ1IsVUFBVTtFQUNWLFFBQVE7RUFDUixlQUFlO0VBQ2YsUUFBUTtFQUNSLE1BQU07RUFDTixTQUFTO0NBQ1g7Q0FDQSxVQUFVO0VBQ1IsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBLGFBQWE7RUFDWCxJQUFJO0VBQ0osUUFBUTtFQUNSLFVBQVU7RUFDVixRQUFRO0VBQ1IsZUFBZTtFQUNmLFFBQVE7RUFDUixNQUFNO0VBQ04sU0FBUztDQUNYO0NBQ0EsY0FBYztFQUNaLElBQUk7RUFDSixRQUFRO0VBQ1IsVUFBVTtFQUNWLFFBQVE7RUFDUixlQUFlO0VBQ2YsUUFBUTtFQUNSLE1BQU07RUFDTixTQUFTO0NBQ1g7Q0FDQSxrQkFBa0I7RUFDaEIsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBLDJCQUEyQjtFQUN6QixJQUFJO0VBQ0osUUFBUTtFQUNSLFVBQVU7RUFDVixRQUFRO0VBQ1IsZUFBZTtFQUNmLFFBQVE7RUFDUixNQUFNO0VBQ04sU0FBUztDQUNYO0NBQ0EsWUFBWTtFQUNWLElBQUk7RUFDSixRQUFRO0VBQ1IsVUFBVTtFQUNWLFFBQVE7RUFDUixlQUFlO0VBQ2YsUUFBUTtFQUNSLE1BQU07RUFDTixTQUFTO0NBQ1g7Q0FDQSxrQkFBa0I7RUFDaEIsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBLGtCQUFrQjtFQUNoQixJQUFJO0VBQ0osUUFBUTtFQUNSLFVBQVU7RUFDVixRQUFRO0VBQ1IsZUFBZTtFQUNmLFFBQVE7RUFDUixNQUFNO0VBQ04sU0FBUztDQUNYO0NBQ0EsY0FBYztFQUNaLElBQUk7RUFDSixRQUFRO0VBQ1IsVUFBVTtFQUNWLFFBQVE7RUFDUixlQUFlO0VBQ2YsUUFBUTtFQUNSLE1BQU07RUFDTixTQUFTO0NBQ1g7Q0FDQSxhQUFhO0VBQ1gsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBLGtCQUFrQjtFQUNoQixJQUFJO0VBQ0osUUFBUTtFQUNSLFVBQVU7RUFDVixRQUFRO0VBQ1IsZUFBZTtFQUNmLFFBQVE7RUFDUixNQUFNO0VBQ04sU0FBUztDQUNYO0NBQ0EsYUFBYTtFQUNYLElBQUk7RUFDSixRQUFRO0VBQ1IsVUFBVTtFQUNWLFFBQVE7RUFDUixlQUFlO0VBQ2YsUUFBUTtFQUNSLE1BQU07RUFDTixTQUFTO0NBQ1g7Q0FDQSxhQUFhO0VBQ1gsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBLFlBQVk7RUFDVixJQUFJO0VBQ0osUUFBUTtFQUNSLFVBQVU7RUFDVixRQUFRO0VBQ1IsZUFBZTtFQUNmLFFBQVE7RUFDUixNQUFNO0VBQ04sU0FBUztDQUNYO0FBQ0Y7QUFFQSxPQUFPLFNBQVMsaUJBQWlCLFVBQThCO0NBQzdELE1BQU0sUUFBUSxTQUFTLEtBQUssQ0FBQyxDQUFDLFlBQVk7Q0FDMUMsSUFBSSxnQkFBZ0IsUUFBUSxPQUFPLGdCQUFnQjtDQUVuRCxLQUFLLE1BQU0sQ0FBQyxHQUFHLE1BQU0sYUFBYSxRQUFRLEdBQUc7RUFDM0MsSUFBSSxFQUFFLFNBQVMsS0FBSyxLQUFLLE1BQU0sU0FBUyxDQUFDLEdBQUcsT0FBTztDQUNyRDs7Q0FHQSxPQUFPO0VBQ0wsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtBQUNGOzs7OztBQU1BLE9BQU8sU0FBUyw4QkFDZCxPQUNBLFFBQ0EsYUFBc0IsTUFDdEIsa0JBQ3FCO0NBQ3JCLE1BQU0sV0FBZ0MsQ0FBQztDQUN2QyxNQUFNLEtBQUssUUFBUTtDQUNuQixNQUFNLEtBQUssU0FBUztDQUNwQixNQUFNLFFBQVEsS0FBSyxJQUFJLE9BQU8sTUFBTSxJQUFJOztDQUd4QyxNQUFNLGNBQWM7RUFDbEI7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0Y7O0NBR0EsTUFBTSxhQUFhO0VBQ2pCO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRjtDQUVBLE1BQU0sZUFBZSxhQUFhLGNBQWM7O0NBR2hELE1BQU0sZUFBZTtFQUNuQjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0Y7Q0FFQSxJQUFJLFlBQVk7O0NBR2hCLE1BQU0sZ0JBQWdCLHFCQUFxQjtDQUMzQyxNQUFNLGdCQUFnQixLQUFLLElBQUksSUFBSSxLQUFLLE1BQU0sT0FBTyxLQUFLLENBQUM7Q0FDM0QsTUFBTSxhQUFhLEtBQU0sZ0JBQWdCLGdCQUFnQjtDQUV6RCxxQkFBcUIsU0FBUyxLQUFLLGFBQWE7RUFDOUMsTUFBTSxJQUFJLEtBQUssTUFBTSxhQUFhLFdBQVcsYUFBYTtFQUMxRCxNQUFNLGFBQWEsSUFBSSxRQUFRLE1BQU0sRUFBRSxLQUFLLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQztFQUM3RCxJQUFJLFdBQVcsV0FBVyxHQUFHOztFQUc3QixNQUFNLFlBQVksV0FBVyxLQUFLLE1BQU07R0FDdEMsTUFBTSxVQUFVLEVBQUUsVUFBVSxFQUFFO0dBQzlCLE1BQU0sV0FBVyxLQUFLLElBQUksS0FBSyxLQUFLLE9BQU8sVUFBVSxPQUFPLFFBQVEsS0FBSyxDQUFDO0dBQzFFLE1BQU0sUUFBUSxXQUFXO0dBQ3pCLE1BQU0sUUFBUSxLQUFLLE1BQU0sRUFBRSxLQUFLLFNBQVMsS0FBSztHQUM5QyxPQUFPO0lBQUUsR0FBRztJQUFHO0lBQVU7R0FBTTtFQUNqQyxDQUFDOztFQUdELE1BQU0sTUFBTSxLQUFLLElBQUksR0FBRyxLQUFLLE1BQU0sTUFBTSxLQUFLLENBQUM7RUFDL0MsTUFBTSxnQkFBZ0IsVUFBVSxRQUFRLEtBQUssTUFBTSxNQUFNLEVBQUUsT0FBTyxDQUFDLEtBQUssVUFBVSxTQUFTLEtBQUs7O0VBR2hHLElBQUksT0FBTyxLQUFNLGdCQUFnQjtFQUVqQyxVQUFVLFNBQVMsTUFBTTtHQUN2QixNQUFNLGNBQWMsS0FBSyxNQUFNLE9BQU8sRUFBRSxRQUFRLENBQUM7R0FDakQsTUFBTSxTQUFTLGlCQUFpQixFQUFFLElBQUk7O0dBR3RDLElBQUk7R0FDSixJQUFJLEVBQUUsVUFBVTtJQUNkLFFBQVE7R0FDVixPQUFPLElBQUksRUFBRSxRQUFRO0lBQ25CLFFBQVEsYUFBYSxZQUFZO0dBQ25DLE9BQU87SUFDTCxRQUFRLGFBQWEsWUFBWSxhQUFhO0dBQ2hEOztHQUdBLE1BQU0sa0JBQWtCLGFBQWEsTUFBTSxLQUFLLElBQUksY0FBYyxFQUFFLElBQUksS0FBSyxTQUFTO0dBQ3RGLE1BQU0sWUFBWSxrQkFBa0IsS0FBSyxpQkFBaUIsTUFBTSxFQUFFO0dBQ2xFLElBQUksaUJBQWlCO0lBQ25CLFFBQVE7R0FDVjtHQUVBLFNBQVMsS0FBSztJQUNaLElBQUksY0FBYztJQUNsQjtJQUNBLE1BQU07SUFDTixHQUFHO0lBQ0g7SUFDQSxPQUFPLEVBQUU7SUFDVCxRQUFRLEVBQUUsV0FBVztJQUNyQixPQUFPO0lBQ1AsVUFBVSxFQUFFO0lBQ1osWUFBWSxFQUFFLFVBQVUsRUFBRSxXQUFXLFFBQVE7SUFDN0M7SUFDQSxNQUFNO0lBQ04sT0FBTyxNQUFRLFdBQVcsZ0JBQWlCO0lBQzNDLFNBQVM7R0FDWCxDQUFDO0dBRUQsUUFBUSxFQUFFLFFBQVE7RUFDcEIsQ0FBQztDQUNILENBQUM7O0NBR0QsTUFBTSxjQUFjLEtBQUssTUFBTSxhQUFhLGdCQUFnQixnQkFBaUIsSUFBSSxLQUFNO0NBQ3ZGLE1BQU0saUJBQWlCLEtBQUssSUFBSSxJQUFJLEtBQUssTUFBTSxLQUFLLEtBQUssQ0FBQztDQUUxRCxzQkFBc0IsTUFBTSxTQUFTLEtBQUssU0FBUztFQUNqRCxNQUFNLElBQUksS0FBSyxNQUFNLGNBQWMsT0FBTyxjQUFjO0VBQ3hELE1BQU0sTUFBTSxLQUFLLElBQUksR0FBRyxLQUFLLE1BQU0sS0FBSyxLQUFLLENBQUM7RUFDOUMsTUFBTSxZQUFZLElBQUksS0FBSyxNQUFNO0dBQy9CLE1BQU0sV0FBVyxLQUFLLElBQUksS0FBSyxLQUFLLE1BQU0sS0FBSyxLQUFLLENBQUM7R0FDckQsTUFBTSxRQUFRLEtBQUssTUFBTSxFQUFFLEtBQUssU0FBUyxXQUFXLEdBQUk7R0FDeEQsT0FBTztJQUFFLEdBQUc7SUFBRztJQUFVO0dBQU07RUFDakMsQ0FBQztFQUNELE1BQU0sU0FBUyxVQUFVLFFBQVEsS0FBSyxNQUFNLE1BQU0sRUFBRSxPQUFPLENBQUMsS0FBSyxVQUFVLFNBQVMsS0FBSztFQUN6RixJQUFJLE9BQU8sS0FBSyxTQUFTO0VBRXpCLFVBQVUsU0FBUyxNQUFNO0dBQ3ZCLE1BQU0sY0FBYyxLQUFLLE1BQU0sT0FBTyxFQUFFLFFBQVEsQ0FBQztHQUNqRCxTQUFTLEtBQUs7SUFDWixJQUFJLFNBQVM7SUFDYixRQUFRLGlCQUFpQixFQUFFLElBQUk7SUFDL0IsTUFBTSxFQUFFO0lBQ1IsR0FBRztJQUNIO0lBQ0EsT0FBTyxFQUFFO0lBQ1QsUUFBUSxFQUFFLFdBQVc7SUFDckIsT0FBTztJQUNQLFVBQVUsRUFBRTtJQUNaLFlBQVk7SUFDWixPQUFPLGFBQWEsWUFBWSxhQUFhO0lBQzdDLE1BQU07SUFDTixPQUFPLEtBQVEsT0FBTztJQUN0QixTQUFTO0dBQ1gsQ0FBQztHQUNELFFBQVEsRUFBRSxRQUFRO0VBQ3BCLENBQUM7Q0FDSCxDQUFDOztDQUdELE1BQU0saUJBQWlCLGNBQWUsaUJBQWlCO0NBQ3ZELHNCQUFzQixTQUFTLFNBQVMsS0FBSyxTQUFTO0VBQ3BELE1BQU0sSUFBSSxLQUFLLE1BQU0saUJBQWlCLE9BQU8sY0FBYztFQUMzRCxNQUFNLE1BQU0sS0FBSyxJQUFJLEdBQUcsS0FBSyxNQUFNLElBQUksS0FBSyxDQUFDO0VBQzdDLE1BQU0sWUFBWSxJQUFJLEtBQUssTUFBTTtHQUMvQixNQUFNLFdBQVcsS0FBSyxJQUFJLEdBQUcsS0FBSyxNQUFNLE9BQU8sS0FBSyxDQUFDO0dBQ3JELE1BQU0sUUFBUSxLQUFLLE1BQU0sRUFBRSxLQUFLLFNBQVMsV0FBVyxHQUFJO0dBQ3hELE9BQU87SUFBRSxHQUFHO0lBQUc7SUFBVTtHQUFNO0VBQ2pDLENBQUM7RUFDRCxNQUFNLFNBQVMsVUFBVSxRQUFRLEtBQUssTUFBTSxNQUFNLEVBQUUsT0FBTyxDQUFDLEtBQUssVUFBVSxTQUFTLEtBQUs7O0VBRXpGLE1BQU0sWUFBWSxLQUFNLEtBQUs7RUFDN0IsSUFBSSxPQUFPLFlBQVk7RUFFdkIsVUFBVSxTQUFTLE1BQU07R0FDdkIsTUFBTSxjQUFjLEtBQUssTUFBTSxPQUFPLEVBQUUsUUFBUSxDQUFDO0dBQ2pELFNBQVMsS0FBSztJQUNaLElBQUksYUFBYTtJQUNqQixRQUFRLGlCQUFpQixFQUFFLElBQUk7SUFDL0IsTUFBTSxFQUFFO0lBQ1IsR0FBRztJQUNIO0lBQ0EsT0FBTyxFQUFFO0lBQ1QsUUFBUSxFQUFFLFdBQVc7SUFDckIsT0FBTztJQUNQLFVBQVUsRUFBRTtJQUNaLFlBQVk7SUFDWixPQUFPLGNBQWMsT0FBTyxhQUFhLGFBQWE7SUFDdEQsTUFBTTtJQUNOLE9BQU8sTUFBUSxPQUFPO0lBQ3RCLFNBQVM7R0FDWCxDQUFDO0dBQ0QsUUFBUSxFQUFFLFFBQVE7RUFDcEIsQ0FBQztDQUNILENBQUM7O0NBR0QsTUFBTSxrQkFBa0IsaUJBQWtCLGlCQUFpQjtDQUMzRCxzQkFBc0IsVUFBVSxTQUFTLEtBQUssU0FBUztFQUNyRCxNQUFNLElBQUksS0FBSyxNQUFNLGtCQUFrQixPQUFPLGNBQWM7RUFDNUQsTUFBTSxNQUFNLEtBQUssSUFBSSxHQUFHLEtBQUssTUFBTSxJQUFJLEtBQUssQ0FBQztFQUM3QyxNQUFNLFlBQVksSUFBSSxLQUFLLE1BQU07R0FDL0IsTUFBTSxXQUFXLEtBQUssSUFBSSxHQUFHLEtBQUssTUFBTSxPQUFPLEtBQUssQ0FBQztHQUNyRCxNQUFNLFFBQVEsS0FBSyxNQUFNLEVBQUUsS0FBSyxTQUFTLFdBQVcsR0FBSTtHQUN4RCxPQUFPO0lBQUUsR0FBRztJQUFHO0lBQVU7R0FBTTtFQUNqQyxDQUFDO0VBQ0QsTUFBTSxXQUFXLEtBQU0sS0FBSztFQUM1QixJQUFJLE9BQU87RUFFWCxVQUFVLFNBQVMsTUFBTTtHQUN2QixNQUFNLGNBQWMsS0FBSyxNQUFNLE9BQU8sRUFBRSxRQUFRLENBQUM7R0FDakQsU0FBUyxLQUFLO0lBQ1osSUFBSSxjQUFjO0lBQ2xCLFFBQVEsaUJBQWlCLEVBQUUsSUFBSTtJQUMvQixNQUFNLEVBQUU7SUFDUixHQUFHO0lBQ0g7SUFDQSxPQUFPLEVBQUU7SUFDVCxRQUFRLEVBQUUsV0FBVztJQUNyQixPQUFPO0lBQ1AsVUFBVSxFQUFFO0lBQ1osWUFBWTtJQUNaLE9BQU8sY0FBYyxPQUFPLElBQUksYUFBYSxhQUFhO0lBQzFELE1BQU07SUFDTixPQUFPLE1BQVEsT0FBTztJQUN0QixTQUFTO0dBQ1gsQ0FBQztHQUNELFFBQVEsRUFBRSxRQUFRO0VBQ3BCLENBQUM7Q0FDSCxDQUFDOztDQUdELE1BQU0sa0JBQWtCLGlCQUFrQixzQkFBc0IsU0FBUyxTQUFTO0NBQ2xGLHNCQUFzQixVQUFVLFNBQVMsS0FBSyxTQUFTO0VBQ3JELE1BQU0sSUFBSSxLQUFLLE1BQU0sa0JBQWtCLE9BQU8sY0FBYztFQUM1RCxNQUFNLE1BQU0sS0FBSyxJQUFJLEdBQUcsS0FBSyxNQUFNLElBQUksS0FBSyxDQUFDO0VBQzdDLE1BQU0sWUFBWSxJQUFJLEtBQUssTUFBTTtHQUMvQixNQUFNLFdBQVcsS0FBSyxJQUFJLEdBQUcsS0FBSyxNQUFNLE9BQU8sS0FBSyxDQUFDO0dBQ3JELE1BQU0sUUFBUSxLQUFLLE1BQU0sRUFBRSxLQUFLLFNBQVMsV0FBVyxHQUFJO0dBQ3hELE9BQU87SUFBRSxHQUFHO0lBQUc7SUFBVTtHQUFNO0VBQ2pDLENBQUM7RUFDRCxNQUFNLFNBQVMsVUFBVSxRQUFRLEtBQUssTUFBTSxNQUFNLEVBQUUsT0FBTyxDQUFDLEtBQUssVUFBVSxTQUFTLEtBQUs7RUFDekYsSUFBSSxPQUFPLEtBQUssU0FBUztFQUV6QixVQUFVLFNBQVMsTUFBTTtHQUN2QixNQUFNLGNBQWMsS0FBSyxNQUFNLE9BQU8sRUFBRSxRQUFRLENBQUM7R0FDakQsU0FBUyxLQUFLO0lBQ1osSUFBSSxjQUFjO0lBQ2xCLFFBQVEsaUJBQWlCLEVBQUUsSUFBSTtJQUMvQixNQUFNLEVBQUU7SUFDUixHQUFHO0lBQ0g7SUFDQSxPQUFPLEVBQUU7SUFDVCxRQUFRLEVBQUUsV0FBVztJQUNyQixPQUFPO0lBQ1AsVUFBVSxFQUFFO0lBQ1osWUFBWTtJQUNaLE9BQU8sY0FBYyxPQUFPLGFBQWEsYUFBYTtJQUN0RCxNQUFNO0lBQ04sT0FBTyxNQUFRLE9BQU87SUFDdEIsU0FBUztHQUNYLENBQUM7R0FDRCxRQUFRLEVBQUUsUUFBUTtFQUNwQixDQUFDO0NBQ0gsQ0FBQztDQUVELE9BQU87QUFDVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJleGFjdFJvc2VHZW5lcmF0b3IudHMiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRVhBQ1RfUk9TRV9IRUFEX1JPV1MsIEVYQUNUX1NURU1fQU5EX0xFQVZFUyB9IGZyb20gJy4uL2RhdGEvcm9zZUV4YWN0RGF0YSc7XG5pbXBvcnQgeyBMT1ZFX1BIUkFTRVMsIExvdmVQaHJhc2UgfSBmcm9tICcuLi9kYXRhL2xhbmd1YWdlcyc7XG5pbXBvcnQgeyBGbG93ZXJUZXh0RWxlbWVudCB9IGZyb20gJy4vbGlseUdlbmVyYXRvcic7XG5cbi8vIE1hcCB3b3JkIHRleHQgdG8gcGhyYXNlIG9iamVjdCBmb3IgdHJhbnNsYXRpb24gY2FyZCAmIGF1ZGlvIHByb251bmNpYXRpb25cbmNvbnN0IHBocmFzZUxvb2t1cCA9IG5ldyBNYXA8c3RyaW5nLCBMb3ZlUGhyYXNlPigpO1xuXG4vLyBQcmVwb3B1bGF0ZSBsb29rdXAgdGFibGVcbkxPVkVfUEhSQVNFUy5mb3JFYWNoKChwKSA9PiB7XG4gIHBocmFzZUxvb2t1cC5zZXQocC5waHJhc2UudG9Mb3dlckNhc2UoKSwgcCk7XG4gIHBocmFzZUxvb2t1cC5zZXQocC5sYW5ndWFnZS50b0xvd2VyQ2FzZSgpLCBwKTtcbn0pO1xuXG4vLyBTcGVjaWZpYyBtYXBwaW5ncyBmb3IgYWxsIGxhbmd1YWdlcyBhcHBlYXJpbmcgaW4gdGhlIGltYWdlXG5jb25zdCBjdXN0b21QaHJhc2VNYXA6IFJlY29yZDxzdHJpbmcsIExvdmVQaHJhc2U+ID0ge1xuICAnbmFrdXBlbmRhJzoge1xuICAgIGlkOiAnc3cnLFxuICAgIHBocmFzZTogJ05ha3VwZW5kYScsXG4gICAgbGFuZ3VhZ2U6ICdTd2FoaWxpJyxcbiAgICBuYXRpdmU6ICdLaXN3YWhpbGknLFxuICAgIHByb251bmNpYXRpb246ICduYWgta29vLVBFTi1kYWgnLFxuICAgIHJlZ2lvbjogJ0FmcmljYScsXG4gICAgZmxhZzogJ/Cfh7Dwn4eqJyxcbiAgICBmdW5GYWN0OiBcIkEgc2luZ2xlIGNvbXBsZXRlIFN3YWhpbGkgdmVyYiBtZWFuaW5nICdJIGxvdmUgeW91IHdhcm1seScuXCJcbiAgfSxcbiAgJ2xpZWJlJzoge1xuICAgIGlkOiAnZGUnLFxuICAgIHBocmFzZTogJ0xpZWJlIChJY2ggbGllYmUgZGljaCknLFxuICAgIGxhbmd1YWdlOiAnR2VybWFuJyxcbiAgICBuYXRpdmU6ICdEZXV0c2NoJyxcbiAgICBwcm9udW5jaWF0aW9uOiAnTEVFLWJ1aCcsXG4gICAgcmVnaW9uOiAnRXVyb3BlJyxcbiAgICBmbGFnOiAn8J+HqfCfh6onLFxuICAgIGZ1bkZhY3Q6IFwiR2VybWFuIHBvZXRpYyByb290IGZvciBwdXJlIGhlYXJ0ZmVsdCByb21hbnRpYyBsb3ZlLlwiXG4gIH0sXG4gICdhbW9yJzoge1xuICAgIGlkOiAnZXMnLFxuICAgIHBocmFzZTogJ0Ftb3IgKFRlIGFtbyknLFxuICAgIGxhbmd1YWdlOiAnU3BhbmlzaCAvIFBvcnR1Z3Vlc2UnLFxuICAgIG5hdGl2ZTogJ0VzcGHDsW9sIC8gUG9ydHVndcOqcycsXG4gICAgcHJvbnVuY2lhdGlvbjogJ2FoLU1PUicsXG4gICAgcmVnaW9uOiAnQW1lcmljYXMnLFxuICAgIGZsYWc6ICfwn4eq8J+HuCcsXG4gICAgZnVuRmFjdDogXCJUaGUgdW5pdmVyc2FsIFJvbWFuY2UgZGVjbGFyYXRpb24gb2YgZXRlcm5hbCBkZXZvdGlvbi5cIlxuICB9LFxuICAnYW1vdXInOiB7XG4gICAgaWQ6ICdmcicsXG4gICAgcGhyYXNlOiAnQW1vdXIgKEplIHTigJlhaW1lKScsXG4gICAgbGFuZ3VhZ2U6ICdGcmVuY2gnLFxuICAgIG5hdGl2ZTogJ0ZyYW7Dp2FpcycsXG4gICAgcHJvbnVuY2lhdGlvbjogJ2FoLU1PT1InLFxuICAgIHJlZ2lvbjogJ0V1cm9wZScsXG4gICAgZmxhZzogJ/Cfh6vwn4e3JyxcbiAgICBmdW5GYWN0OiBcIlRoZSBjaXR5IG9mIGxpZ2h0J3MgZXRlcm5hbCBwb2V0aWMgd29yZCBmb3IgcHJvZm91bmQgbG92ZS5cIlxuICB9LFxuICAn4Lij4Lix4LiB4LiE4Li44LiTJzoge1xuICAgIGlkOiAndGgnLFxuICAgIHBocmFzZTogJ+C4o+C4seC4geC4hOC4uOC4kyAoUmFrIGtodW4pJyxcbiAgICBsYW5ndWFnZTogJ1RoYWknLFxuICAgIG5hdGl2ZTogJ+C5hOC4l+C4oicsXG4gICAgcHJvbnVuY2lhdGlvbjogJ3JhayBraG9vbicsXG4gICAgcmVnaW9uOiAnQXNpYScsXG4gICAgZmxhZzogJ/Cfh7nwn4etJyxcbiAgICBmdW5GYWN0OiBcIkNvdXJ0bHkgVGhhaSBleHByZXNzaW9uIGRlbm90aW5nIHJldmVyZW50IHJvbWFudGljIGxvdmUuXCJcbiAgfSxcbiAgJ3N6ZXJldGxlayc6IHtcbiAgICBpZDogJ2h1JyxcbiAgICBwaHJhc2U6ICdTemVyZXRsZWsnLFxuICAgIGxhbmd1YWdlOiAnSHVuZ2FyaWFuJyxcbiAgICBuYXRpdmU6ICdNYWd5YXInLFxuICAgIHByb251bmNpYXRpb246ICdTRUgtcmV0LWxlaycsXG4gICAgcmVnaW9uOiAnRXVyb3BlJyxcbiAgICBmbGFnOiAn8J+HrfCfh7onLFxuICAgIGZ1bkZhY3Q6IFwiQ29tcHJlc3NlcyBzdWJqZWN0IGFuZCBvYmplY3QgaW50byBvbmUgaW50aW1hdGUgdmVyYjogJ0kgbG92ZSBZT1UnLlwiXG4gIH0sXG4gICdrb2NoYW0gY2nEmSc6IHtcbiAgICBpZDogJ3BsJyxcbiAgICBwaHJhc2U6ICdLb2NoYW0gY2nEmScsXG4gICAgbGFuZ3VhZ2U6ICdQb2xpc2gnLFxuICAgIG5hdGl2ZTogJ1BvbHNraScsXG4gICAgcHJvbnVuY2lhdGlvbjogJ0tPSC1raGFobSBjaHllaCcsXG4gICAgcmVnaW9uOiAnRXVyb3BlJyxcbiAgICBmbGFnOiAn8J+HtfCfh7EnLFxuICAgIGZ1bkZhY3Q6IFwiUG9saXNoIGV4cHJlc3Npb24gb2YgZGVlcCB0ZW5kZXJuZXNzIGFuZCBjaGVyaXNoZWQgcHJvdGVjdGlvbi5cIlxuICB9LFxuICAn15DXoNeZINeQ15XXlNeR16og15DXldeq15onOiB7XG4gICAgaWQ6ICdoZScsXG4gICAgcGhyYXNlOiAn15DXoNeZINeQ15XXlNeR16og15DXldeq15onLFxuICAgIGxhbmd1YWdlOiAnSGVicmV3JyxcbiAgICBuYXRpdmU6ICfXoteR16jXmdeqJyxcbiAgICBwcm9udW5jaWF0aW9uOiAnYW5pIG9oZXZldCBvdGNoYScsXG4gICAgcmVnaW9uOiAnTWlkZGxlIEVhc3QnLFxuICAgIGZsYWc6ICfwn4eu8J+HsScsXG4gICAgZnVuRmFjdDogXCJTb25nIG9mIFNvbG9tb246ICdJIGFtIG15IGJlbG92ZWTigJlzLCBhbmQgbXkgYmVsb3ZlZCBpcyBtaW5lJy5cIlxuICB9LFxuICAn4LCo4LC/4LCo4LGN4LCo4LGBIOCwquCxjeCwsOCxh+CwruCwv+CwuOCxjeCwpOCxgeCwqOCxjeCwqOCwvuCwqOCxgSc6IHtcbiAgICBpZDogJ3RlJyxcbiAgICBwaHJhc2U6ICfgsKjgsL/gsKjgsY3gsKjgsYEg4LCq4LGN4LCw4LGH4LCu4LC/4LC44LGN4LCk4LGB4LCo4LGN4LCo4LC+4LCo4LGBIChOaW5udSBwcmVtaXN0dW5uYW51KScsXG4gICAgbGFuZ3VhZ2U6ICdUZWx1Z3UnLFxuICAgIG5hdGl2ZTogJ+CwpOCxhuCwsuCxgeCwl+CxgScsXG4gICAgcHJvbnVuY2lhdGlvbjogJ25pbi1ub28gcHJlaC1taXMtdG9vbi1uYWgtbm9vJyxcbiAgICByZWdpb246ICdBc2lhJyxcbiAgICBmbGFnOiAn8J+HrvCfh7MnLFxuICAgIGZ1bkZhY3Q6IFwiQ2VsZWJyYXRlZCBpbiBjbGFzc2ljYWwgU291dGggSW5kaWFuIGx5cmljYWwgcG9ldHJ5LlwiXG4gIH0sXG4gICfgpq3gpr7gprLgp4vgpqzgpr7gprjgpr8nOiB7XG4gICAgaWQ6ICdibicsXG4gICAgcGhyYXNlOiAn4KaG4Kau4Ka/IOCmpOCni+CmruCmvuCmleCnhyDgpq3gpr7gprLgp4vgpqzgpr7gprjgpr8nLFxuICAgIGxhbmd1YWdlOiAnQmVuZ2FsaScsXG4gICAgbmF0aXZlOiAn4Kas4Ka+4KaC4Kay4Ka+JyxcbiAgICBwcm9udW5jaWF0aW9uOiAnYmhhbG9iYXNoaScsXG4gICAgcmVnaW9uOiAnQXNpYScsXG4gICAgZmxhZzogJ/Cfh6fwn4epJyxcbiAgICBmdW5GYWN0OiBcIkxhbmd1YWdlIG9mIE5vYmVsIGxhdXJlYXRlIFJhYmluZHJhbmF0aCBUYWdvcmU6ICdtYWtpbmcgYSBob21lIG9mIGdvb2RuZXNzJy5cIlxuICB9LFxuICAnamFnIMOkbHNrYXIgZGlnJzoge1xuICAgIGlkOiAnc3YnLFxuICAgIHBocmFzZTogJ0phZyDDpGxza2FyIGRpZycsXG4gICAgbGFuZ3VhZ2U6ICdTd2VkaXNoJyxcbiAgICBuYXRpdmU6ICdTdmVuc2thJyxcbiAgICBwcm9udW5jaWF0aW9uOiAneWFoZyBFTC1za2FyIGRleScsXG4gICAgcmVnaW9uOiAnRXVyb3BlJyxcbiAgICBmbGFnOiAn8J+HuPCfh6onLFxuICAgIGZ1bkZhY3Q6IFwiRnJvbSBPbGQgTm9yc2UgJ2Vsc2thJ+KAlGNhcmluZyB0ZW5kZXJseSB0aHJvdWdoIEFyY3RpYyB3aW50ZXJzLlwiXG4gIH0sXG4gICdqZWcgZWxza2VyIGRpZyc6IHtcbiAgICBpZDogJ2RhJyxcbiAgICBwaHJhc2U6ICdKZWcgZWxza2VyIGRpZycsXG4gICAgbGFuZ3VhZ2U6ICdEYW5pc2gnLFxuICAgIG5hdGl2ZTogJ0RhbnNrJyxcbiAgICBwcm9udW5jaWF0aW9uOiAneWFpIGVsLXNrZXIgZGFpJyxcbiAgICByZWdpb246ICdFdXJvcGUnLFxuICAgIGZsYWc6ICfwn4ep8J+HsCcsXG4gICAgZnVuRmFjdDogXCJEZWVwbHkgY29ubmVjdGVkIHRvIHRoZSBEYW5pc2ggd2FybXRoIG9mIGh5Z2dlLlwiXG4gIH0sXG4gICdhbmggecOqdSBlbSc6IHtcbiAgICBpZDogJ3ZpJyxcbiAgICBwaHJhc2U6ICdBbmggecOqdSBlbScsXG4gICAgbGFuZ3VhZ2U6ICdWaWV0bmFtZXNlJyxcbiAgICBuYXRpdmU6ICdUaeG6v25nIFZp4buHdCcsXG4gICAgcHJvbnVuY2lhdGlvbjogJ2FobiBlZXlldyBlbScsXG4gICAgcmVnaW9uOiAnQXNpYScsXG4gICAgZmxhZzogJ/Cfh7vwn4ezJyxcbiAgICBmdW5GYWN0OiBcIlRlbmRlciByZWxhdGlvbiBvZiBwcm90ZWN0aXZlIGNhcmUgZm9yIG9uZSdzIGJlbG92ZWQgZmxvd2VyLlwiXG4gIH0sXG4gICd0ZSBxdWllcm8nOiB7XG4gICAgaWQ6ICdlcy1xJyxcbiAgICBwaHJhc2U6ICdUZSBxdWllcm8nLFxuICAgIGxhbmd1YWdlOiAnU3BhbmlzaCcsXG4gICAgbmF0aXZlOiAnRXNwYcOxb2wnLFxuICAgIHByb251bmNpYXRpb246ICd0ZWgga2VlLUVILXJvaCcsXG4gICAgcmVnaW9uOiAnQW1lcmljYXMnLFxuICAgIGZsYWc6ICfwn4ey8J+HvScsXG4gICAgZnVuRmFjdDogXCJFeHByZXNzZXMgZXZlcnlkYXkgaW50aW1hdGUgYWZmZWN0aW9uIGFuZCBmb25kIGxvbmdpbmcuXCJcbiAgfSxcbiAgJ3Jha2FzdGFuIHNpbnVhJzoge1xuICAgIGlkOiAnZmknLFxuICAgIHBocmFzZTogJ1Jha2FzdGFuIHNpbnVhJyxcbiAgICBsYW5ndWFnZTogJ0Zpbm5pc2gnLFxuICAgIG5hdGl2ZTogJ1N1b21pJyxcbiAgICBwcm9udW5jaWF0aW9uOiAnUkFILWthcy10YWhuIFNFRS1ub28tYWgnLFxuICAgIHJlZ2lvbjogJ0V1cm9wZScsXG4gICAgZmxhZzogJ/Cfh6vwn4euJyxcbiAgICBmdW5GYWN0OiBcIkEgc29sZW1uLCBsaWZlbG9uZyB2b3cgb2Ygc2luY2VyaXR5IGluIEZpbmxhbmQuXCJcbiAgfSxcbiAgJ2xqdWJpbSB0ZSc6IHtcbiAgICBpZDogJ3NsJyxcbiAgICBwaHJhc2U6ICdManViaW0gdGUnLFxuICAgIGxhbmd1YWdlOiAnU2xvdmVuaWFuIC8gQ3JvYXRpYW4nLFxuICAgIG5hdGl2ZTogJ1Nsb3ZlbsWhxI1pbmEnLFxuICAgIHByb251bmNpYXRpb246ICdMWU9PLWJlZW0gdGVoJyxcbiAgICByZWdpb246ICdFdXJvcGUnLFxuICAgIGZsYWc6ICfwn4e48J+HricsXG4gICAgZnVuRmFjdDogXCJMeXJpY2FsIFNsYXZpYyBleHByZXNzaW9uIG9mIHBhc3Npb25hdGUgZGV2b3Rpb24uXCJcbiAgfSxcbiAgJ3RlIGl1YmVzYyc6IHtcbiAgICBpZDogJ3JvJyxcbiAgICBwaHJhc2U6ICdUZSBpdWJlc2MnLFxuICAgIGxhbmd1YWdlOiAnUm9tYW5pYW4nLFxuICAgIG5hdGl2ZTogJ1JvbcOibsSDJyxcbiAgICBwcm9udW5jaWF0aW9uOiAndGVoIHlvby1CRVNLJyxcbiAgICByZWdpb246ICdFdXJvcGUnLFxuICAgIGZsYWc6ICfwn4e38J+HtCcsXG4gICAgZnVuRmFjdDogXCJMYXRpbiBncmFtbWFyIGNvbWJpbmVkIHdpdGggU2xhdmljIHN3ZWV0bmVzcyBvZiB0aGUgc291bC5cIlxuICB9LFxuICAndm9saW0gdGUnOiB7XG4gICAgaWQ6ICdocicsXG4gICAgcGhyYXNlOiAnVm9saW0gdGUnLFxuICAgIGxhbmd1YWdlOiAnQ3JvYXRpYW4gLyBTZXJiaWFuJyxcbiAgICBuYXRpdmU6ICdIcnZhdHNraScsXG4gICAgcHJvbnVuY2lhdGlvbjogJ1ZPSC1sZWVtIHRlaCcsXG4gICAgcmVnaW9uOiAnRXVyb3BlJyxcbiAgICBmbGFnOiAn8J+HrfCfh7cnLFxuICAgIGZ1bkZhY3Q6IFwiJ0kgY2hvb3NlIHlvdSB3aXRoIGFsbCBteSBmcmVlIHdpbGwgYW5kIGxvdmUnLlwiXG4gIH1cbn07XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRQaHJhc2VGb3JXb3JkKHdvcmRUZXh0OiBzdHJpbmcpOiBMb3ZlUGhyYXNlIHtcbiAgY29uc3QgY2xlYW4gPSB3b3JkVGV4dC50cmltKCkudG9Mb3dlckNhc2UoKTtcbiAgaWYgKGN1c3RvbVBocmFzZU1hcFtjbGVhbl0pIHJldHVybiBjdXN0b21QaHJhc2VNYXBbY2xlYW5dO1xuXG4gIGZvciAoY29uc3QgW2ssIHZdIG9mIHBocmFzZUxvb2t1cC5lbnRyaWVzKCkpIHtcbiAgICBpZiAoay5pbmNsdWRlcyhjbGVhbikgfHwgY2xlYW4uaW5jbHVkZXMoaykpIHJldHVybiB2O1xuICB9XG5cbiAgLy8gRmFsbGJhY2sgZ2VuZXJpYyBwaHJhc2VcbiAgcmV0dXJuIHtcbiAgICBpZDogJ3VuaXZlcnNhbCcsXG4gICAgcGhyYXNlOiB3b3JkVGV4dCxcbiAgICBsYW5ndWFnZTogJ1VuaXZlcnNhbCBMb3ZlJyxcbiAgICBuYXRpdmU6IHdvcmRUZXh0LFxuICAgIHByb251bmNpYXRpb246IHdvcmRUZXh0LFxuICAgIHJlZ2lvbjogJ0V1cm9wZScsXG4gICAgZmxhZzogJ/CfkpYnLFxuICAgIGZ1bkZhY3Q6ICdBIHNhY3JlZCB3b3JkIG9mIGFmZmVjdGlvbiBzcG9rZW4gZnJvbSB0aGUgZGVwdGhzIG9mIHRoZSBodW1hbiBoZWFydC4nXG4gIH07XG59XG5cbi8qKlxuICogR2VuZXJhdGVzIHRoZSBFWEFDVCBcInNhbWUtdG8tc2FtZVwiIFJvc2UgbGF5b3V0IGZyb20gaW1hZ2VfOGI1ZjlmMGEucG5nXG4gKiB3aXRoIGdlbmVyb3VzLCBjcnlzdGFsLWNsZWFyIHNwYWNpbmcgYW5kIGEgdmlicmFudCBQaW5rIFJvc2UgcGFsZXR0ZSFcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdlbmVyYXRlRXhhY3RTYW1lUm9zZUVsZW1lbnRzKFxuICB3aWR0aDogbnVtYmVyLFxuICBoZWlnaHQ6IG51bWJlcixcbiAgaXNQaW5rUm9zZTogYm9vbGVhbiA9IHRydWUsXG4gIGN1c3RvbURlZGljYXRpb24/OiBzdHJpbmdcbik6IEZsb3dlclRleHRFbGVtZW50W10ge1xuICBjb25zdCBlbGVtZW50czogRmxvd2VyVGV4dEVsZW1lbnRbXSA9IFtdO1xuICBjb25zdCBjeCA9IHdpZHRoIC8gMjtcbiAgY29uc3QgY3kgPSBoZWlnaHQgKiAwLjM2OyAvLyBDZW50ZXIgb2YgZmxvd2VyIGhlYWRcbiAgY29uc3Qgc2NhbGUgPSBNYXRoLm1pbih3aWR0aCwgaGVpZ2h0KSAvIDUyMDtcblxuICAvLyBMdW1pbm91cyBQaW5rIFJvc2UgcGFsZXR0ZSAod2hlbiBpc1BpbmtSb3NlID0gdHJ1ZSlcbiAgY29uc3QgcGlua1BhbGV0dGUgPSBbXG4gICAgJyNmZjJkNzUnLCAvLyBIb3QgcmFkaWFudCBwaW5rXG4gICAgJyNmZjY5YjQnLCAvLyBOZW9uIHJvc2UgcGlua1xuICAgICcjZjQzZjVlJywgLy8gRGVlcCByb3NlIGZ1Y2hzaWFcbiAgICAnI2ZkYTRhZicsIC8vIFNvZnQgYmx1c2ggcGlua1xuICAgICcjZmJjZmU4JywgLy8gUGV0YWwgcmltIHBhc3RlbCBwaW5rXG4gICAgJyNmZjE0OTMnLCAvLyBSaWNoIG1hZ2VudGFcbiAgXTtcblxuICAvLyBDbGFzc2ljIFJlZCBSb3NlIHBhbGV0dGUgKG1hdGNoZXMgb3JpZ2luYWwgaW1hZ2VfOGI1ZjlmMGEucG5nIGV4YWN0bHkpXG4gIGNvbnN0IHJlZFBhbGV0dGUgPSBbXG4gICAgJyNlMTFkNDgnLCAvLyBDbGFzc2ljIHZlbHZldCByZWRcbiAgICAnI2ZmMTc0NCcsIC8vIEJyaWdodCBydWJ5IHJlZFxuICAgICcjZjQzZjVlJywgLy8gUm9zZSByZWRcbiAgICAnI2JlMTIzYycsIC8vIFdpbmUgcmVkXG4gICAgJyNmZGE0YWYnLCAvLyBIaWdobGlnaHQgcGlua1xuICBdO1xuXG4gIGNvbnN0IGZsb3dlckNvbG9ycyA9IGlzUGlua1Jvc2UgPyBwaW5rUGFsZXR0ZSA6IHJlZFBhbGV0dGU7XG5cbiAgLy8gR3JlZW4gc3RlbSAmIGxlYXZlcyBwYWxldHRlXG4gIGNvbnN0IGdyZWVuUGFsZXR0ZSA9IFtcbiAgICAnIzIyYzU1ZScsIC8vIEJyaWdodCBsZWFmIGdyZWVuXG4gICAgJyM0YWRlODAnLCAvLyBMaW1lIGdyZWVuIGhpZ2hsaWdodFxuICAgICcjMTBiOTgxJywgLy8gRW1lcmFsZCBncmVlblxuICAgICcjODZlZmFjJywgLy8gUGFsZSBtaW50XG4gICAgJyMxNmEzNGEnLCAvLyBGb3Jlc3QgZ3JlZW5cbiAgXTtcblxuICBsZXQgaWRDb3VudGVyID0gMDtcblxuICAvLyAxLiBHRU5FUkFURSBUSEUgUk9TRSBIRUFEIChFeGFjdCByb3dzIDEgdG8gMzEpXG4gIGNvbnN0IGhlYWRUb3RhbFJvd3MgPSBFWEFDVF9ST1NFX0hFQURfUk9XUy5sZW5ndGg7XG4gIGNvbnN0IGhlYWRSb3dIZWlnaHQgPSBNYXRoLm1heCgxMywgTWF0aC5yb3VuZCgxNS41ICogc2NhbGUpKTtcbiAgY29uc3QgaGVhZFN0YXJ0WSA9IGN5IC0gKGhlYWRUb3RhbFJvd3MgKiBoZWFkUm93SGVpZ2h0ICogMC41Mik7XG5cbiAgRVhBQ1RfUk9TRV9IRUFEX1JPV1MuZm9yRWFjaCgocm93LCByb3dJbmRleCkgPT4ge1xuICAgIGNvbnN0IHkgPSBNYXRoLnJvdW5kKGhlYWRTdGFydFkgKyByb3dJbmRleCAqIGhlYWRSb3dIZWlnaHQpO1xuICAgIGNvbnN0IHZhbGlkV29yZHMgPSByb3cuZmlsdGVyKCh3KSA9PiB3LnRleHQudHJpbSgpLmxlbmd0aCA+IDApO1xuICAgIGlmICh2YWxpZFdvcmRzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuXG4gICAgLy8gQ2FsY3VsYXRlIHRvdGFsIHJvdyB3aWR0aCBiYXNlZCBvbiBjaGFyYWN0ZXIgY291bnQgYW5kIGdlbmVyb3VzIHNwYWNpbmdcbiAgICBjb25zdCB3b3JkU3BhbnMgPSB2YWxpZFdvcmRzLm1hcCgodykgPT4ge1xuICAgICAgY29uc3QgaXNMYXJnZSA9IHcuaXNCb2xkIHx8IHcuaXNCcmlnaHQ7XG4gICAgICBjb25zdCBmb250U2l6ZSA9IE1hdGgubWF4KDkuNSwgTWF0aC5yb3VuZCgoaXNMYXJnZSA/IDEyLjUgOiAxMC41KSAqIHNjYWxlKSk7XG4gICAgICBjb25zdCBjaGFyVyA9IGZvbnRTaXplICogMC42MjtcbiAgICAgIGNvbnN0IHdpZHRoID0gTWF0aC5yb3VuZCh3LnRleHQubGVuZ3RoICogY2hhclcpO1xuICAgICAgcmV0dXJuIHsgLi4udywgZm9udFNpemUsIHdpZHRoIH07XG4gICAgfSk7XG5cbiAgICAvLyBHZW5lcm91cyBjbGVhbiBzcGFjaW5nIGJldHdlZW4gd29yZHMgKDhweCB0byAxNHB4KVxuICAgIGNvbnN0IGdhcCA9IE1hdGgubWF4KDcsIE1hdGgucm91bmQoOS41ICogc2NhbGUpKTtcbiAgICBjb25zdCB0b3RhbFJvd1dpZHRoID0gd29yZFNwYW5zLnJlZHVjZSgoYWNjLCB3KSA9PiBhY2MgKyB3LndpZHRoLCAwKSArICh3b3JkU3BhbnMubGVuZ3RoIC0gMSkgKiBnYXA7XG5cbiAgICAvLyBDZW50ZXIgdGhlIHJvdyBob3Jpem9udGFsbHlcbiAgICBsZXQgY3VyWCA9IGN4IC0gKHRvdGFsUm93V2lkdGggLyAyKTtcblxuICAgIHdvcmRTcGFucy5mb3JFYWNoKCh3KSA9PiB7XG4gICAgICBjb25zdCB3b3JkQ2VudGVyWCA9IE1hdGgucm91bmQoY3VyWCArIHcud2lkdGggLyAyKTtcbiAgICAgIGNvbnN0IHBocmFzZSA9IGdldFBocmFzZUZvcldvcmQody50ZXh0KTtcblxuICAgICAgLy8gQ29sb3Igc2VsZWN0aW9uXG4gICAgICBsZXQgY29sb3I6IHN0cmluZztcbiAgICAgIGlmICh3LmlzQnJpZ2h0KSB7XG4gICAgICAgIGNvbG9yID0gJyNmZmZmZmYnOyAvLyBDcmlzcCB3aGl0ZSBoaWdobGlnaHQgbGlrZSBpbiByZWZlcmVuY2UgaW1hZ2VcbiAgICAgIH0gZWxzZSBpZiAody5pc0JvbGQpIHtcbiAgICAgICAgY29sb3IgPSBpc1BpbmtSb3NlID8gJyNmZjY5YjQnIDogJyNmZjE3NDQnO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29sb3IgPSBmbG93ZXJDb2xvcnNbaWRDb3VudGVyICUgZmxvd2VyQ29sb3JzLmxlbmd0aF07XG4gICAgICB9XG5cbiAgICAgIC8vIENoZWNrIGNlbnRlciBkZWRpY2F0aW9uXG4gICAgICBjb25zdCBpc0RlZGljYXRpb25Qb3MgPSByb3dJbmRleCA9PT0gMTEgJiYgTWF0aC5hYnMod29yZENlbnRlclggLSBjeCkgPCAzMCAqIHNjYWxlICYmIGN1c3RvbURlZGljYXRpb247XG4gICAgICBjb25zdCBmaW5hbFRleHQgPSBpc0RlZGljYXRpb25Qb3MgPyBg4pmlICR7Y3VzdG9tRGVkaWNhdGlvbn0g4pmlYCA6IHcudGV4dDtcbiAgICAgIGlmIChpc0RlZGljYXRpb25Qb3MpIHtcbiAgICAgICAgY29sb3IgPSAnI2ZmZmZmZic7XG4gICAgICB9XG5cbiAgICAgIGVsZW1lbnRzLnB1c2goe1xuICAgICAgICBpZDogYGV4YWN0LXJvc2UtJHtpZENvdW50ZXIrK31gLFxuICAgICAgICBwaHJhc2UsXG4gICAgICAgIHRleHQ6IGZpbmFsVGV4dCxcbiAgICAgICAgeDogd29yZENlbnRlclgsXG4gICAgICAgIHksXG4gICAgICAgIHdpZHRoOiB3LndpZHRoLFxuICAgICAgICBoZWlnaHQ6IHcuZm9udFNpemUgKyA0LFxuICAgICAgICBhbmdsZTogMCwgLy8gMTAwJSBIb3Jpem9udGFsIGZvciBjcmlzcCByZWFkYWJpbGl0eVxuICAgICAgICBmb250U2l6ZTogdy5mb250U2l6ZSxcbiAgICAgICAgZm9udFdlaWdodDogdy5pc0JvbGQgfHwgdy5pc0JyaWdodCA/ICc4MDAnIDogJzcwMCcsXG4gICAgICAgIGNvbG9yLFxuICAgICAgICBwYXJ0OiAncGV0YWwnLFxuICAgICAgICBvcmRlcjogMC4zNSArIChyb3dJbmRleCAvIGhlYWRUb3RhbFJvd3MpICogMC42NSxcbiAgICAgICAgaXNHcmVlbjogZmFsc2UsXG4gICAgICB9KTtcblxuICAgICAgY3VyWCArPSB3LndpZHRoICsgZ2FwO1xuICAgIH0pO1xuICB9KTtcblxuICAvLyAyLiBHRU5FUkFURSBTVEVNIENBTFlYIChUb3Agb2Ygc3RlbSBqdW5jdGlvbiByaWdodCBiZWxvdyByb3NlIGhlYWQpXG4gIGNvbnN0IGNhbHl4U3RhcnRZID0gTWF0aC5yb3VuZChoZWFkU3RhcnRZICsgaGVhZFRvdGFsUm93cyAqIGhlYWRSb3dIZWlnaHQgKyAoNCAqIHNjYWxlKSk7XG4gIGNvbnN0IGNhbHl4Um93SGVpZ2h0ID0gTWF0aC5tYXgoMTMsIE1hdGgucm91bmQoMTUgKiBzY2FsZSkpO1xuXG4gIEVYQUNUX1NURU1fQU5EX0xFQVZFUy5jYWx5eC5mb3JFYWNoKChyb3csIHJJZHgpID0+IHtcbiAgICBjb25zdCB5ID0gTWF0aC5yb3VuZChjYWx5eFN0YXJ0WSArIHJJZHggKiBjYWx5eFJvd0hlaWdodCk7XG4gICAgY29uc3QgZ2FwID0gTWF0aC5tYXgoOCwgTWF0aC5yb3VuZCgxMCAqIHNjYWxlKSk7XG4gICAgY29uc3Qgd29yZFNwYW5zID0gcm93Lm1hcCgodykgPT4ge1xuICAgICAgY29uc3QgZm9udFNpemUgPSBNYXRoLm1heCg5LjUsIE1hdGgucm91bmQoMTEgKiBzY2FsZSkpO1xuICAgICAgY29uc3Qgd2lkdGggPSBNYXRoLnJvdW5kKHcudGV4dC5sZW5ndGggKiBmb250U2l6ZSAqIDAuNjIpO1xuICAgICAgcmV0dXJuIHsgLi4udywgZm9udFNpemUsIHdpZHRoIH07XG4gICAgfSk7XG4gICAgY29uc3QgdG90YWxXID0gd29yZFNwYW5zLnJlZHVjZSgoYWNjLCB3KSA9PiBhY2MgKyB3LndpZHRoLCAwKSArICh3b3JkU3BhbnMubGVuZ3RoIC0gMSkgKiBnYXA7XG4gICAgbGV0IGN1clggPSBjeCAtIHRvdGFsVyAvIDI7XG5cbiAgICB3b3JkU3BhbnMuZm9yRWFjaCgodykgPT4ge1xuICAgICAgY29uc3Qgd29yZENlbnRlclggPSBNYXRoLnJvdW5kKGN1clggKyB3LndpZHRoIC8gMik7XG4gICAgICBlbGVtZW50cy5wdXNoKHtcbiAgICAgICAgaWQ6IGBjYWx5eC0ke2lkQ291bnRlcisrfWAsXG4gICAgICAgIHBocmFzZTogZ2V0UGhyYXNlRm9yV29yZCh3LnRleHQpLFxuICAgICAgICB0ZXh0OiB3LnRleHQsXG4gICAgICAgIHg6IHdvcmRDZW50ZXJYLFxuICAgICAgICB5LFxuICAgICAgICB3aWR0aDogdy53aWR0aCxcbiAgICAgICAgaGVpZ2h0OiB3LmZvbnRTaXplICsgNCxcbiAgICAgICAgYW5nbGU6IDAsXG4gICAgICAgIGZvbnRTaXplOiB3LmZvbnRTaXplLFxuICAgICAgICBmb250V2VpZ2h0OiAnNzAwJyxcbiAgICAgICAgY29sb3I6IGdyZWVuUGFsZXR0ZVtpZENvdW50ZXIgJSBncmVlblBhbGV0dGUubGVuZ3RoXSxcbiAgICAgICAgcGFydDogJ3N0ZW0nLFxuICAgICAgICBvcmRlcjogMC4zMCAtIChySWR4IC8gMTApLFxuICAgICAgICBpc0dyZWVuOiB0cnVlLFxuICAgICAgfSk7XG4gICAgICBjdXJYICs9IHcud2lkdGggKyBnYXA7XG4gICAgfSk7XG4gIH0pO1xuXG4gIC8vIDMuIEdFTkVSQVRFIExFRlQgTEVBRiBDTFVTVEVSXG4gIGNvbnN0IGxlZnRMZWFmU3RhcnRZID0gY2FseXhTdGFydFkgKyAoY2FseXhSb3dIZWlnaHQgKiAzKTtcbiAgRVhBQ1RfU1RFTV9BTkRfTEVBVkVTLmxlZnRMZWFmLmZvckVhY2goKHJvdywgcklkeCkgPT4ge1xuICAgIGNvbnN0IHkgPSBNYXRoLnJvdW5kKGxlZnRMZWFmU3RhcnRZICsgcklkeCAqIGNhbHl4Um93SGVpZ2h0KTtcbiAgICBjb25zdCBnYXAgPSBNYXRoLm1heCg2LCBNYXRoLnJvdW5kKDggKiBzY2FsZSkpO1xuICAgIGNvbnN0IHdvcmRTcGFucyA9IHJvdy5tYXAoKHcpID0+IHtcbiAgICAgIGNvbnN0IGZvbnRTaXplID0gTWF0aC5tYXgoOSwgTWF0aC5yb3VuZCgxMC41ICogc2NhbGUpKTtcbiAgICAgIGNvbnN0IHdpZHRoID0gTWF0aC5yb3VuZCh3LnRleHQubGVuZ3RoICogZm9udFNpemUgKiAwLjYyKTtcbiAgICAgIHJldHVybiB7IC4uLncsIGZvbnRTaXplLCB3aWR0aCB9O1xuICAgIH0pO1xuICAgIGNvbnN0IHRvdGFsVyA9IHdvcmRTcGFucy5yZWR1Y2UoKGFjYywgdykgPT4gYWNjICsgdy53aWR0aCwgMCkgKyAod29yZFNwYW5zLmxlbmd0aCAtIDEpICogZ2FwO1xuICAgIC8vIFBvc2l0aW9uIHRvIHRoZSBsZWZ0IG9mIHRoZSBjZW50ZXIgc3RlbVxuICAgIGNvbnN0IHJpZ2h0RWRnZSA9IGN4IC0gKDEyICogc2NhbGUpO1xuICAgIGxldCBjdXJYID0gcmlnaHRFZGdlIC0gdG90YWxXO1xuXG4gICAgd29yZFNwYW5zLmZvckVhY2goKHcpID0+IHtcbiAgICAgIGNvbnN0IHdvcmRDZW50ZXJYID0gTWF0aC5yb3VuZChjdXJYICsgdy53aWR0aCAvIDIpO1xuICAgICAgZWxlbWVudHMucHVzaCh7XG4gICAgICAgIGlkOiBgbGVmdC1sZWFmLSR7aWRDb3VudGVyKyt9YCxcbiAgICAgICAgcGhyYXNlOiBnZXRQaHJhc2VGb3JXb3JkKHcudGV4dCksXG4gICAgICAgIHRleHQ6IHcudGV4dCxcbiAgICAgICAgeDogd29yZENlbnRlclgsXG4gICAgICAgIHksXG4gICAgICAgIHdpZHRoOiB3LndpZHRoLFxuICAgICAgICBoZWlnaHQ6IHcuZm9udFNpemUgKyA0LFxuICAgICAgICBhbmdsZTogMCxcbiAgICAgICAgZm9udFNpemU6IHcuZm9udFNpemUsXG4gICAgICAgIGZvbnRXZWlnaHQ6ICc3MDAnLFxuICAgICAgICBjb2xvcjogZ3JlZW5QYWxldHRlWyhySWR4ICsgaWRDb3VudGVyKSAlIGdyZWVuUGFsZXR0ZS5sZW5ndGhdLFxuICAgICAgICBwYXJ0OiAnbGVhZicsXG4gICAgICAgIG9yZGVyOiAwLjE1ICsgKHJJZHggLyAxNSksXG4gICAgICAgIGlzR3JlZW46IHRydWUsXG4gICAgICB9KTtcbiAgICAgIGN1clggKz0gdy53aWR0aCArIGdhcDtcbiAgICB9KTtcbiAgfSk7XG5cbiAgLy8gNC4gR0VORVJBVEUgUklHSFQgTEVBRiBDTFVTVEVSXG4gIGNvbnN0IHJpZ2h0TGVhZlN0YXJ0WSA9IGxlZnRMZWFmU3RhcnRZICsgKGNhbHl4Um93SGVpZ2h0ICogMik7XG4gIEVYQUNUX1NURU1fQU5EX0xFQVZFUy5yaWdodExlYWYuZm9yRWFjaCgocm93LCBySWR4KSA9PiB7XG4gICAgY29uc3QgeSA9IE1hdGgucm91bmQocmlnaHRMZWFmU3RhcnRZICsgcklkeCAqIGNhbHl4Um93SGVpZ2h0KTtcbiAgICBjb25zdCBnYXAgPSBNYXRoLm1heCg2LCBNYXRoLnJvdW5kKDggKiBzY2FsZSkpO1xuICAgIGNvbnN0IHdvcmRTcGFucyA9IHJvdy5tYXAoKHcpID0+IHtcbiAgICAgIGNvbnN0IGZvbnRTaXplID0gTWF0aC5tYXgoOSwgTWF0aC5yb3VuZCgxMC41ICogc2NhbGUpKTtcbiAgICAgIGNvbnN0IHdpZHRoID0gTWF0aC5yb3VuZCh3LnRleHQubGVuZ3RoICogZm9udFNpemUgKiAwLjYyKTtcbiAgICAgIHJldHVybiB7IC4uLncsIGZvbnRTaXplLCB3aWR0aCB9O1xuICAgIH0pO1xuICAgIGNvbnN0IGxlZnRFZGdlID0gY3ggKyAoMTQgKiBzY2FsZSk7XG4gICAgbGV0IGN1clggPSBsZWZ0RWRnZTtcblxuICAgIHdvcmRTcGFucy5mb3JFYWNoKCh3KSA9PiB7XG4gICAgICBjb25zdCB3b3JkQ2VudGVyWCA9IE1hdGgucm91bmQoY3VyWCArIHcud2lkdGggLyAyKTtcbiAgICAgIGVsZW1lbnRzLnB1c2goe1xuICAgICAgICBpZDogYHJpZ2h0LWxlYWYtJHtpZENvdW50ZXIrK31gLFxuICAgICAgICBwaHJhc2U6IGdldFBocmFzZUZvcldvcmQody50ZXh0KSxcbiAgICAgICAgdGV4dDogdy50ZXh0LFxuICAgICAgICB4OiB3b3JkQ2VudGVyWCxcbiAgICAgICAgeSxcbiAgICAgICAgd2lkdGg6IHcud2lkdGgsXG4gICAgICAgIGhlaWdodDogdy5mb250U2l6ZSArIDQsXG4gICAgICAgIGFuZ2xlOiAwLFxuICAgICAgICBmb250U2l6ZTogdy5mb250U2l6ZSxcbiAgICAgICAgZm9udFdlaWdodDogJzcwMCcsXG4gICAgICAgIGNvbG9yOiBncmVlblBhbGV0dGVbKHJJZHggKiAyICsgaWRDb3VudGVyKSAlIGdyZWVuUGFsZXR0ZS5sZW5ndGhdLFxuICAgICAgICBwYXJ0OiAnbGVhZicsXG4gICAgICAgIG9yZGVyOiAwLjE4ICsgKHJJZHggLyAxNSksXG4gICAgICAgIGlzR3JlZW46IHRydWUsXG4gICAgICB9KTtcbiAgICAgIGN1clggKz0gdy53aWR0aCArIGdhcDtcbiAgICB9KTtcbiAgfSk7XG5cbiAgLy8gNS4gR0VORVJBVEUgTE9XRVIgU1RFTSBDT0xVTU5cbiAgY29uc3QgbG93ZXJTdGVtU3RhcnRZID0gbGVmdExlYWZTdGFydFkgKyAoRVhBQ1RfU1RFTV9BTkRfTEVBVkVTLmxlZnRMZWFmLmxlbmd0aCAqIGNhbHl4Um93SGVpZ2h0KTtcbiAgRVhBQ1RfU1RFTV9BTkRfTEVBVkVTLmxvd2VyU3RlbS5mb3JFYWNoKChyb3csIHJJZHgpID0+IHtcbiAgICBjb25zdCB5ID0gTWF0aC5yb3VuZChsb3dlclN0ZW1TdGFydFkgKyBySWR4ICogY2FseXhSb3dIZWlnaHQpO1xuICAgIGNvbnN0IGdhcCA9IE1hdGgubWF4KDYsIE1hdGgucm91bmQoOCAqIHNjYWxlKSk7XG4gICAgY29uc3Qgd29yZFNwYW5zID0gcm93Lm1hcCgodykgPT4ge1xuICAgICAgY29uc3QgZm9udFNpemUgPSBNYXRoLm1heCg5LCBNYXRoLnJvdW5kKDEwLjUgKiBzY2FsZSkpO1xuICAgICAgY29uc3Qgd2lkdGggPSBNYXRoLnJvdW5kKHcudGV4dC5sZW5ndGggKiBmb250U2l6ZSAqIDAuNjIpO1xuICAgICAgcmV0dXJuIHsgLi4udywgZm9udFNpemUsIHdpZHRoIH07XG4gICAgfSk7XG4gICAgY29uc3QgdG90YWxXID0gd29yZFNwYW5zLnJlZHVjZSgoYWNjLCB3KSA9PiBhY2MgKyB3LndpZHRoLCAwKSArICh3b3JkU3BhbnMubGVuZ3RoIC0gMSkgKiBnYXA7XG4gICAgbGV0IGN1clggPSBjeCAtIHRvdGFsVyAvIDI7XG5cbiAgICB3b3JkU3BhbnMuZm9yRWFjaCgodykgPT4ge1xuICAgICAgY29uc3Qgd29yZENlbnRlclggPSBNYXRoLnJvdW5kKGN1clggKyB3LndpZHRoIC8gMik7XG4gICAgICBlbGVtZW50cy5wdXNoKHtcbiAgICAgICAgaWQ6IGBsb3dlci1zdGVtLSR7aWRDb3VudGVyKyt9YCxcbiAgICAgICAgcGhyYXNlOiBnZXRQaHJhc2VGb3JXb3JkKHcudGV4dCksXG4gICAgICAgIHRleHQ6IHcudGV4dCxcbiAgICAgICAgeDogd29yZENlbnRlclgsXG4gICAgICAgIHksXG4gICAgICAgIHdpZHRoOiB3LndpZHRoLFxuICAgICAgICBoZWlnaHQ6IHcuZm9udFNpemUgKyA0LFxuICAgICAgICBhbmdsZTogMCxcbiAgICAgICAgZm9udFNpemU6IHcuZm9udFNpemUsXG4gICAgICAgIGZvbnRXZWlnaHQ6ICc3MDAnLFxuICAgICAgICBjb2xvcjogZ3JlZW5QYWxldHRlWyhySWR4ICsgaWRDb3VudGVyKSAlIGdyZWVuUGFsZXR0ZS5sZW5ndGhdLFxuICAgICAgICBwYXJ0OiAnc3RlbScsXG4gICAgICAgIG9yZGVyOiAwLjA1ICsgKHJJZHggLyAzMCksXG4gICAgICAgIGlzR3JlZW46IHRydWUsXG4gICAgICB9KTtcbiAgICAgIGN1clggKz0gdy53aWR0aCArIGdhcDtcbiAgICB9KTtcbiAgfSk7XG5cbiAgcmV0dXJuIGVsZW1lbnRzO1xufVxuIl19