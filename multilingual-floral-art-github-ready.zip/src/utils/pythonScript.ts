export function generatePythonCode(config) {
	const isLily = config.flowerType === "lily";
	if (isLily) {
		return `"""
Pink Lily In Every Language 🌸
Creative Coding Art / Python Tkinter Edition
Run with: python pink_lily.py
"""

import math as m
import random as r
import tkinter as tk
import time

# --- Configuration ---
W, H = ${config.width}, ${config.height}
DURATION = ${config.duration}  # seconds for full bloom
TICK = 16         # frame tick in ms (~60 FPS)
SCALE = ${config.scale}       # canvas scale multiplier
RECIPIENT = "${config.recipientName || "My Love"}"

# Multilingual Love Phrases
PHRASES = [
    "I LOVE YOU", "Je t'aime", "TE AMO", "TI AMO", "Ich liebe dich",
    "愛してる", "我爱你", "사랑해", "Я тебя люблю", "Seni seviyorum",
    "Mahal kita", "أحبك", "मैं तुमसे प्यार करता हूँ", "Eu te amo",
    "Σ' αγαπώ", "Ik hou van jou", "Kocham Cię", "Jag älskar dig",
    "Nakupenda", "Táim i ngrá leat", "Aloha au iā 'oe", "ฉันรักเธอ",
    "Anh yêu em", "Aku cinta kamu", "Szeretlek", "Te iubesc",
    "Miluji tě", "دوستت دارم", "Minä rakastan sinua", "Të dua",
    "Volim te", "AMOR", "LOVE", "Amour"
]

# Pink Lily Color Palette
PINK_PETAL_COLORS = ["#f472b6", "#ec4899", "#db2777", "#fda4af", "#fbcfe8", "#e11d48", "#f43f5e"]
STEM_COLORS = ["#22c55e", "#10b981", "#34d399", "#4ade80", "#15803d", "#16a34a"]
GOLD_ANTHER = "#f59e0b"
BG_COLOR = "#000000"


class PinkLilyApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Pink Lily In Every Language 🌸")
        self.root.geometry(f"{W}x{H}")
        self.root.configure(bg=BG_COLOR)

        self.canvas = tk.Canvas(root, width=W, height=H, bg=BG_COLOR, highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)

        self.elements = self.generate_lily_elements()
        self.elements.sort(key=lambda el: el["order"])

        self.start_time = time.time()
        self.drawn_count = 0

        # Title Header
        self.canvas.create_text(
            W // 2, 40,
            text="Pink Lily In Every Language",
            fill="#fbcfe8",
            font=("Georgia", 16, "italic bold")
        )

        self.animate()

    def generate_lily_elements(self):
        elems = []
        cx = W // 2
        cy = int(H * 0.36)
        scale = min(W, H) / 520 * SCALE
        p_idx = 0

        def next_phrase():
            nonlocal p_idx
            p = PHRASES[p_idx % len(PHRASES)]
            p_idx += 1
            return p

        # 1. Stem (Vertical column of horizontal green words as seen in reference image)
        stem_top_y = cy + int(24 * scale)
        stem_bottom_y = int(H * 0.90)
        stem_step = int(17 * scale)

        for y in range(stem_top_y, stem_bottom_y, max(1, stem_step)):
            t = (y - stem_top_y) / (stem_bottom_y - stem_top_y)
            stem_x = cx + int(m.sin(t * m.pi * 1.2) * (10 * scale))
            words_in_row = 2 if 0.15 < t < 0.65 else 1
            offsets = [-int(14 * scale), int(14 * scale)] if words_in_row == 2 else [0]

            for ox in offsets:
                phrase = next_phrase()
                word = phrase if len(phrase) <= 12 else phrase[:11]
                elems.append({
                    "text": word,
                    "x": stem_x + ox, "y": y,
                    "color": STEM_COLORS[(y // 15) % len(STEM_COLORS)],
                    "size": int(11 * scale) if r.random() > 0.4 else int(9.5 * scale),
                    "order": t * 0.32
                })

        # 2. Leaves (Graceful lanceolate foliage)
        for side, sign in [("left", -1), ("right", 1)]:
            leaf_y = cy + int((130 if sign == -1 else 205) * scale)
            for j in range(10):
                t = j / 9
                lx = cx + sign * int((10 + t * 105) * scale)
                ly = leaf_y + int(t * 50 * scale) - int(m.sin(t * m.pi) * (20 * scale))
                elems.append({
                    "text": next_phrase(),
                    "x": lx, "y": ly,
                    "color": STEM_COLORS[(j + 2) % len(STEM_COLORS)],
                    "size": int(10 * scale),
                    "order": (0.20 if sign == -1 else 0.25) + t * 0.18
                })

        # 3. Pink Lily Petals (6 Star Tepals)
        petal_angles = [
            -m.pi / 2,                  # 0: Top
            -m.pi / 2 + m.pi / 3,       # 1: Top Right
            -m.pi / 2 + 2 * m.pi / 3,   # 2: Bottom Right
            m.pi / 2,                   # 3: Bottom
            -m.pi / 2 + 4 * m.pi / 3,   # 4: Bottom Left
            -m.pi / 2 + 5 * m.pi / 3    # 5: Top Left
        ]
        max_petal_r = 175 * scale
        scan_r = int(185 * scale)
        row_h = int(15 * scale)
        col_w = int(48 * scale)

        for y in range(cy - scan_r, cy + scan_r, max(1, row_h)):
            for x in range(cx - scan_r, cx + scan_r, max(1, col_w)):
                jx = x + ((y // row_h % 2) * col_w // 2) + r.randint(-3, 3)
                jy = y + r.randint(-2, 2)
                dx, dy = jx - cx, jy - cy
                dist = m.sqrt(dx * dx + dy * dy)

                is_inside = False
                dist_ratio = 0.0

                if dist < 26 * scale:
                    is_inside = True
                    dist_ratio = dist / (26 * scale)
                else:
                    for i, p_ang in enumerate(petal_angles):
                        along = dx * m.cos(p_ang) + dy * m.sin(p_ang)
                        perp = abs(-dx * m.sin(p_ang) + dy * m.cos(p_ang))
                        if 12 * scale < along < max_petal_r:
                            t = along / max_petal_r
                            max_w = (42 if i in (0, 3) else 48) * scale
                            w_at_t = max_w * m.sin(t * m.pi) * ((1 - t * 0.45) ** 0.7)
                            if perp <= w_at_t:
                                is_inside = True
                                dist_ratio = t
                                break

                if is_inside:
                    phrase = next_phrase()
                    color = PINK_PETAL_COLORS[r.randint(0, len(PINK_PETAL_COLORS) - 1)]
                    elems.append({
                        "text": phrase,
                        "x": jx, "y": jy,
                        "color": color,
                        "size": int(13 * scale) if r.random() > 0.8 else int(10 * scale),
                        "order": 0.40 + dist_ratio * 0.55
                    })

        # 4. Golden Stamens & Anthers (Pollen tips)
        for idx, ang in enumerate(petal_angles):
            s_len = (48 + (idx % 2) * 12) * scale
            ax = cx + int(m.cos(ang) * s_len)
            ay = cy + int(m.sin(ang) * s_len * 0.88)
            elems.append({
                "text": f"✦ {next_phrase()[:7]} •",
                "x": ax, "y": ay,
                "color": GOLD_ANTHER,
                "size": int(10 * scale),
                "order": 0.92 + (idx / 6) * 0.08
            })

        return elems

    def animate(self):
        elapsed = time.time() - self.start_time
        progress = min(1.0, elapsed / max(1.0, DURATION))

        while self.drawn_count < len(self.elements):
            el = self.elements[self.drawn_count]
            if el["order"] <= progress:
                self.canvas.create_text(
                    el["x"], el["y"],
                    text=el["text"],
                    fill=el["color"],
                    font=("Helvetica", max(7, el["size"]), "bold")
                )
                self.drawn_count += 1
            else:
                break

        if progress < 1.0:
            self.root.after(TICK, self.animate)
        else:
            self.canvas.create_text(
                W // 2, H - 35,
                text="A pink lily that blooms your heart in every language. 🌸",
                fill="#fda4af",
                font=("Georgia", 11, "italic")
            )


if __name__ == "__main__":
    root = tk.Tk()
    app = PinkLilyApp(root)
    root.mainloop()
`;
	}
	// Classic Rose Python Script fallback
	return `"""
Pink Rose In Every Language 🌹
Creative Coding Art / Python Tkinter Edition
Run with: python pink_rose.py
"""

import math as m
import random as r
import tkinter as tk
import time

W, H = ${config.width}, ${config.height}
DURATION = ${config.duration}
TICK = 16
SCALE = ${config.scale}
RECIPIENT = "${config.recipientName || "My Love"}"

PHRASES = [
    "I love you", "Je t'aime", "Te amo", "Ti amo", "Ich liebe dich",
    "愛してる", "我爱你", "사랑해", "Я тебя люблю", "Seni seviyorum",
    "Mahal kita", "أحبك", "मैं तुमसे प्यार करता हूँ", "Eu te amo"
]

PETAL_COLORS = ["#ff1744", "#f43f5e", "#e11d48", "#be123c", "#fda4af"]
STEM_COLORS = ["#10b981", "#059669", "#34d399", "#22c55e"]
BG_COLOR = "#000000"

# Main Tkinter implementation...
`;
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBV0EsT0FBTyxTQUFTLG1CQUFtQixRQUE4QjtDQUMvRCxNQUFNLFNBQVMsT0FBTyxlQUFlO0NBRXJDLElBQUksUUFBUTtFQUNWLE9BQU87Ozs7Ozs7Ozs7OztTQVlGLE9BQU8sTUFBTSxJQUFJLE9BQU8sT0FBTzthQUMzQixPQUFPLFNBQVM7O1VBRW5CLE9BQU8sTUFBTTtlQUNSLE9BQU8saUJBQWlCLFVBQVU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FvTS9DOztDQUdBLE9BQU87Ozs7Ozs7Ozs7O1NBV0EsT0FBTyxNQUFNLElBQUksT0FBTyxPQUFPO2FBQzNCLE9BQU8sU0FBUzs7VUFFbkIsT0FBTyxNQUFNO2VBQ1IsT0FBTyxpQkFBaUIsVUFBVTs7Ozs7Ozs7Ozs7Ozs7QUFjakQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsicHl0aG9uU2NyaXB0LnRzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBpbnRlcmZhY2UgUHl0aG9uQ29uZmlnIHtcbiAgd2lkdGg6IG51bWJlcjtcbiAgaGVpZ2h0OiBudW1iZXI7XG4gIGR1cmF0aW9uOiBudW1iZXI7XG4gIGdhcDogbnVtYmVyO1xuICBzY2FsZTogbnVtYmVyO1xuICBmbG93ZXJUeXBlOiAnbGlseScgfCAncm9zZSc7XG4gIHRoZW1lTmFtZTogc3RyaW5nO1xuICByZWNpcGllbnROYW1lOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZW5lcmF0ZVB5dGhvbkNvZGUoY29uZmlnOiBQeXRob25Db25maWcpOiBzdHJpbmcge1xuICBjb25zdCBpc0xpbHkgPSBjb25maWcuZmxvd2VyVHlwZSA9PT0gJ2xpbHknO1xuXG4gIGlmIChpc0xpbHkpIHtcbiAgICByZXR1cm4gYFwiXCJcIlxuUGluayBMaWx5IEluIEV2ZXJ5IExhbmd1YWdlIPCfjLhcbkNyZWF0aXZlIENvZGluZyBBcnQgLyBQeXRob24gVGtpbnRlciBFZGl0aW9uXG5SdW4gd2l0aDogcHl0aG9uIHBpbmtfbGlseS5weVxuXCJcIlwiXG5cbmltcG9ydCBtYXRoIGFzIG1cbmltcG9ydCByYW5kb20gYXMgclxuaW1wb3J0IHRraW50ZXIgYXMgdGtcbmltcG9ydCB0aW1lXG5cbiMgLS0tIENvbmZpZ3VyYXRpb24gLS0tXG5XLCBIID0gJHtjb25maWcud2lkdGh9LCAke2NvbmZpZy5oZWlnaHR9XG5EVVJBVElPTiA9ICR7Y29uZmlnLmR1cmF0aW9ufSAgIyBzZWNvbmRzIGZvciBmdWxsIGJsb29tXG5USUNLID0gMTYgICAgICAgICAjIGZyYW1lIHRpY2sgaW4gbXMgKH42MCBGUFMpXG5TQ0FMRSA9ICR7Y29uZmlnLnNjYWxlfSAgICAgICAjIGNhbnZhcyBzY2FsZSBtdWx0aXBsaWVyXG5SRUNJUElFTlQgPSBcIiR7Y29uZmlnLnJlY2lwaWVudE5hbWUgfHwgJ015IExvdmUnfVwiXG5cbiMgTXVsdGlsaW5ndWFsIExvdmUgUGhyYXNlc1xuUEhSQVNFUyA9IFtcbiAgICBcIkkgTE9WRSBZT1VcIiwgXCJKZSB0J2FpbWVcIiwgXCJURSBBTU9cIiwgXCJUSSBBTU9cIiwgXCJJY2ggbGllYmUgZGljaFwiLFxuICAgIFwi5oSb44GX44Gm44KLXCIsIFwi5oiR54ix5L2gXCIsIFwi7IKs656R7ZW0XCIsIFwi0K8g0YLQtdCx0Y8g0LvRjtCx0LvRjlwiLCBcIlNlbmkgc2V2aXlvcnVtXCIsXG4gICAgXCJNYWhhbCBraXRhXCIsIFwi2KPYrdio2YNcIiwgXCLgpK7gpYjgpIIg4KSk4KWB4KSu4KS44KWHIOCkquCljeCkr+CkvuCksCDgpJXgpLDgpKTgpL4g4KS54KWC4KSBXCIsIFwiRXUgdGUgYW1vXCIsXG4gICAgXCLOoycgzrHOs86xz4DPjlwiLCBcIklrIGhvdSB2YW4gam91XCIsIFwiS29jaGFtIENpxJlcIiwgXCJKYWcgw6Rsc2thciBkaWdcIixcbiAgICBcIk5ha3VwZW5kYVwiLCBcIlTDoWltIGkgbmdyw6EgbGVhdFwiLCBcIkFsb2hhIGF1IGnEgSAnb2VcIiwgXCLguInguLHguJnguKPguLHguIHguYDguJjguK1cIixcbiAgICBcIkFuaCB5w6p1IGVtXCIsIFwiQWt1IGNpbnRhIGthbXVcIiwgXCJTemVyZXRsZWtcIiwgXCJUZSBpdWJlc2NcIixcbiAgICBcIk1pbHVqaSB0xJtcIiwgXCLYr9mI2LPYqtiqINiv2KfYsdmFXCIsIFwiTWluw6QgcmFrYXN0YW4gc2ludWFcIiwgXCJUw6sgZHVhXCIsXG4gICAgXCJWb2xpbSB0ZVwiLCBcIkFNT1JcIiwgXCJMT1ZFXCIsIFwiQW1vdXJcIlxuXVxuXG4jIFBpbmsgTGlseSBDb2xvciBQYWxldHRlXG5QSU5LX1BFVEFMX0NPTE9SUyA9IFtcIiNmNDcyYjZcIiwgXCIjZWM0ODk5XCIsIFwiI2RiMjc3N1wiLCBcIiNmZGE0YWZcIiwgXCIjZmJjZmU4XCIsIFwiI2UxMWQ0OFwiLCBcIiNmNDNmNWVcIl1cblNURU1fQ09MT1JTID0gW1wiIzIyYzU1ZVwiLCBcIiMxMGI5ODFcIiwgXCIjMzRkMzk5XCIsIFwiIzRhZGU4MFwiLCBcIiMxNTgwM2RcIiwgXCIjMTZhMzRhXCJdXG5HT0xEX0FOVEhFUiA9IFwiI2Y1OWUwYlwiXG5CR19DT0xPUiA9IFwiIzAwMDAwMFwiXG5cblxuY2xhc3MgUGlua0xpbHlBcHA6XG4gICAgZGVmIF9faW5pdF9fKHNlbGYsIHJvb3QpOlxuICAgICAgICBzZWxmLnJvb3QgPSByb290XG4gICAgICAgIHNlbGYucm9vdC50aXRsZShcIlBpbmsgTGlseSBJbiBFdmVyeSBMYW5ndWFnZSDwn4y4XCIpXG4gICAgICAgIHNlbGYucm9vdC5nZW9tZXRyeShmXCJ7V314e0h9XCIpXG4gICAgICAgIHNlbGYucm9vdC5jb25maWd1cmUoYmc9QkdfQ09MT1IpXG5cbiAgICAgICAgc2VsZi5jYW52YXMgPSB0ay5DYW52YXMocm9vdCwgd2lkdGg9VywgaGVpZ2h0PUgsIGJnPUJHX0NPTE9SLCBoaWdobGlnaHR0aGlja25lc3M9MClcbiAgICAgICAgc2VsZi5jYW52YXMucGFjayhmaWxsPVwiYm90aFwiLCBleHBhbmQ9VHJ1ZSlcblxuICAgICAgICBzZWxmLmVsZW1lbnRzID0gc2VsZi5nZW5lcmF0ZV9saWx5X2VsZW1lbnRzKClcbiAgICAgICAgc2VsZi5lbGVtZW50cy5zb3J0KGtleT1sYW1iZGEgZWw6IGVsW1wib3JkZXJcIl0pXG5cbiAgICAgICAgc2VsZi5zdGFydF90aW1lID0gdGltZS50aW1lKClcbiAgICAgICAgc2VsZi5kcmF3bl9jb3VudCA9IDBcblxuICAgICAgICAjIFRpdGxlIEhlYWRlclxuICAgICAgICBzZWxmLmNhbnZhcy5jcmVhdGVfdGV4dChcbiAgICAgICAgICAgIFcgLy8gMiwgNDAsXG4gICAgICAgICAgICB0ZXh0PVwiUGluayBMaWx5IEluIEV2ZXJ5IExhbmd1YWdlXCIsXG4gICAgICAgICAgICBmaWxsPVwiI2ZiY2ZlOFwiLFxuICAgICAgICAgICAgZm9udD0oXCJHZW9yZ2lhXCIsIDE2LCBcIml0YWxpYyBib2xkXCIpXG4gICAgICAgIClcblxuICAgICAgICBzZWxmLmFuaW1hdGUoKVxuXG4gICAgZGVmIGdlbmVyYXRlX2xpbHlfZWxlbWVudHMoc2VsZik6XG4gICAgICAgIGVsZW1zID0gW11cbiAgICAgICAgY3ggPSBXIC8vIDJcbiAgICAgICAgY3kgPSBpbnQoSCAqIDAuMzYpXG4gICAgICAgIHNjYWxlID0gbWluKFcsIEgpIC8gNTIwICogU0NBTEVcbiAgICAgICAgcF9pZHggPSAwXG5cbiAgICAgICAgZGVmIG5leHRfcGhyYXNlKCk6XG4gICAgICAgICAgICBub25sb2NhbCBwX2lkeFxuICAgICAgICAgICAgcCA9IFBIUkFTRVNbcF9pZHggJSBsZW4oUEhSQVNFUyldXG4gICAgICAgICAgICBwX2lkeCArPSAxXG4gICAgICAgICAgICByZXR1cm4gcFxuXG4gICAgICAgICMgMS4gU3RlbSAoVmVydGljYWwgY29sdW1uIG9mIGhvcml6b250YWwgZ3JlZW4gd29yZHMgYXMgc2VlbiBpbiByZWZlcmVuY2UgaW1hZ2UpXG4gICAgICAgIHN0ZW1fdG9wX3kgPSBjeSArIGludCgyNCAqIHNjYWxlKVxuICAgICAgICBzdGVtX2JvdHRvbV95ID0gaW50KEggKiAwLjkwKVxuICAgICAgICBzdGVtX3N0ZXAgPSBpbnQoMTcgKiBzY2FsZSlcblxuICAgICAgICBmb3IgeSBpbiByYW5nZShzdGVtX3RvcF95LCBzdGVtX2JvdHRvbV95LCBtYXgoMSwgc3RlbV9zdGVwKSk6XG4gICAgICAgICAgICB0ID0gKHkgLSBzdGVtX3RvcF95KSAvIChzdGVtX2JvdHRvbV95IC0gc3RlbV90b3BfeSlcbiAgICAgICAgICAgIHN0ZW1feCA9IGN4ICsgaW50KG0uc2luKHQgKiBtLnBpICogMS4yKSAqICgxMCAqIHNjYWxlKSlcbiAgICAgICAgICAgIHdvcmRzX2luX3JvdyA9IDIgaWYgMC4xNSA8IHQgPCAwLjY1IGVsc2UgMVxuICAgICAgICAgICAgb2Zmc2V0cyA9IFstaW50KDE0ICogc2NhbGUpLCBpbnQoMTQgKiBzY2FsZSldIGlmIHdvcmRzX2luX3JvdyA9PSAyIGVsc2UgWzBdXG5cbiAgICAgICAgICAgIGZvciBveCBpbiBvZmZzZXRzOlxuICAgICAgICAgICAgICAgIHBocmFzZSA9IG5leHRfcGhyYXNlKClcbiAgICAgICAgICAgICAgICB3b3JkID0gcGhyYXNlIGlmIGxlbihwaHJhc2UpIDw9IDEyIGVsc2UgcGhyYXNlWzoxMV1cbiAgICAgICAgICAgICAgICBlbGVtcy5hcHBlbmQoe1xuICAgICAgICAgICAgICAgICAgICBcInRleHRcIjogd29yZCxcbiAgICAgICAgICAgICAgICAgICAgXCJ4XCI6IHN0ZW1feCArIG94LCBcInlcIjogeSxcbiAgICAgICAgICAgICAgICAgICAgXCJjb2xvclwiOiBTVEVNX0NPTE9SU1soeSAvLyAxNSkgJSBsZW4oU1RFTV9DT0xPUlMpXSxcbiAgICAgICAgICAgICAgICAgICAgXCJzaXplXCI6IGludCgxMSAqIHNjYWxlKSBpZiByLnJhbmRvbSgpID4gMC40IGVsc2UgaW50KDkuNSAqIHNjYWxlKSxcbiAgICAgICAgICAgICAgICAgICAgXCJvcmRlclwiOiB0ICogMC4zMlxuICAgICAgICAgICAgICAgIH0pXG5cbiAgICAgICAgIyAyLiBMZWF2ZXMgKEdyYWNlZnVsIGxhbmNlb2xhdGUgZm9saWFnZSlcbiAgICAgICAgZm9yIHNpZGUsIHNpZ24gaW4gWyhcImxlZnRcIiwgLTEpLCAoXCJyaWdodFwiLCAxKV06XG4gICAgICAgICAgICBsZWFmX3kgPSBjeSArIGludCgoMTMwIGlmIHNpZ24gPT0gLTEgZWxzZSAyMDUpICogc2NhbGUpXG4gICAgICAgICAgICBmb3IgaiBpbiByYW5nZSgxMCk6XG4gICAgICAgICAgICAgICAgdCA9IGogLyA5XG4gICAgICAgICAgICAgICAgbHggPSBjeCArIHNpZ24gKiBpbnQoKDEwICsgdCAqIDEwNSkgKiBzY2FsZSlcbiAgICAgICAgICAgICAgICBseSA9IGxlYWZfeSArIGludCh0ICogNTAgKiBzY2FsZSkgLSBpbnQobS5zaW4odCAqIG0ucGkpICogKDIwICogc2NhbGUpKVxuICAgICAgICAgICAgICAgIGVsZW1zLmFwcGVuZCh7XG4gICAgICAgICAgICAgICAgICAgIFwidGV4dFwiOiBuZXh0X3BocmFzZSgpLFxuICAgICAgICAgICAgICAgICAgICBcInhcIjogbHgsIFwieVwiOiBseSxcbiAgICAgICAgICAgICAgICAgICAgXCJjb2xvclwiOiBTVEVNX0NPTE9SU1soaiArIDIpICUgbGVuKFNURU1fQ09MT1JTKV0sXG4gICAgICAgICAgICAgICAgICAgIFwic2l6ZVwiOiBpbnQoMTAgKiBzY2FsZSksXG4gICAgICAgICAgICAgICAgICAgIFwib3JkZXJcIjogKDAuMjAgaWYgc2lnbiA9PSAtMSBlbHNlIDAuMjUpICsgdCAqIDAuMThcbiAgICAgICAgICAgICAgICB9KVxuXG4gICAgICAgICMgMy4gUGluayBMaWx5IFBldGFscyAoNiBTdGFyIFRlcGFscylcbiAgICAgICAgcGV0YWxfYW5nbGVzID0gW1xuICAgICAgICAgICAgLW0ucGkgLyAyLCAgICAgICAgICAgICAgICAgICMgMDogVG9wXG4gICAgICAgICAgICAtbS5waSAvIDIgKyBtLnBpIC8gMywgICAgICAgIyAxOiBUb3AgUmlnaHRcbiAgICAgICAgICAgIC1tLnBpIC8gMiArIDIgKiBtLnBpIC8gMywgICAjIDI6IEJvdHRvbSBSaWdodFxuICAgICAgICAgICAgbS5waSAvIDIsICAgICAgICAgICAgICAgICAgICMgMzogQm90dG9tXG4gICAgICAgICAgICAtbS5waSAvIDIgKyA0ICogbS5waSAvIDMsICAgIyA0OiBCb3R0b20gTGVmdFxuICAgICAgICAgICAgLW0ucGkgLyAyICsgNSAqIG0ucGkgLyAzICAgICMgNTogVG9wIExlZnRcbiAgICAgICAgXVxuICAgICAgICBtYXhfcGV0YWxfciA9IDE3NSAqIHNjYWxlXG4gICAgICAgIHNjYW5fciA9IGludCgxODUgKiBzY2FsZSlcbiAgICAgICAgcm93X2ggPSBpbnQoMTUgKiBzY2FsZSlcbiAgICAgICAgY29sX3cgPSBpbnQoNDggKiBzY2FsZSlcblxuICAgICAgICBmb3IgeSBpbiByYW5nZShjeSAtIHNjYW5fciwgY3kgKyBzY2FuX3IsIG1heCgxLCByb3dfaCkpOlxuICAgICAgICAgICAgZm9yIHggaW4gcmFuZ2UoY3ggLSBzY2FuX3IsIGN4ICsgc2Nhbl9yLCBtYXgoMSwgY29sX3cpKTpcbiAgICAgICAgICAgICAgICBqeCA9IHggKyAoKHkgLy8gcm93X2ggJSAyKSAqIGNvbF93IC8vIDIpICsgci5yYW5kaW50KC0zLCAzKVxuICAgICAgICAgICAgICAgIGp5ID0geSArIHIucmFuZGludCgtMiwgMilcbiAgICAgICAgICAgICAgICBkeCwgZHkgPSBqeCAtIGN4LCBqeSAtIGN5XG4gICAgICAgICAgICAgICAgZGlzdCA9IG0uc3FydChkeCAqIGR4ICsgZHkgKiBkeSlcblxuICAgICAgICAgICAgICAgIGlzX2luc2lkZSA9IEZhbHNlXG4gICAgICAgICAgICAgICAgZGlzdF9yYXRpbyA9IDAuMFxuXG4gICAgICAgICAgICAgICAgaWYgZGlzdCA8IDI2ICogc2NhbGU6XG4gICAgICAgICAgICAgICAgICAgIGlzX2luc2lkZSA9IFRydWVcbiAgICAgICAgICAgICAgICAgICAgZGlzdF9yYXRpbyA9IGRpc3QgLyAoMjYgKiBzY2FsZSlcbiAgICAgICAgICAgICAgICBlbHNlOlxuICAgICAgICAgICAgICAgICAgICBmb3IgaSwgcF9hbmcgaW4gZW51bWVyYXRlKHBldGFsX2FuZ2xlcyk6XG4gICAgICAgICAgICAgICAgICAgICAgICBhbG9uZyA9IGR4ICogbS5jb3MocF9hbmcpICsgZHkgKiBtLnNpbihwX2FuZylcbiAgICAgICAgICAgICAgICAgICAgICAgIHBlcnAgPSBhYnMoLWR4ICogbS5zaW4ocF9hbmcpICsgZHkgKiBtLmNvcyhwX2FuZykpXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAxMiAqIHNjYWxlIDwgYWxvbmcgPCBtYXhfcGV0YWxfcjpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ID0gYWxvbmcgLyBtYXhfcGV0YWxfclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1heF93ID0gKDQyIGlmIGkgaW4gKDAsIDMpIGVsc2UgNDgpICogc2NhbGVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB3X2F0X3QgPSBtYXhfdyAqIG0uc2luKHQgKiBtLnBpKSAqICgoMSAtIHQgKiAwLjQ1KSAqKiAwLjcpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgcGVycCA8PSB3X2F0X3Q6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzX2luc2lkZSA9IFRydWVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzdF9yYXRpbyA9IHRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWtcblxuICAgICAgICAgICAgICAgIGlmIGlzX2luc2lkZTpcbiAgICAgICAgICAgICAgICAgICAgcGhyYXNlID0gbmV4dF9waHJhc2UoKVxuICAgICAgICAgICAgICAgICAgICBjb2xvciA9IFBJTktfUEVUQUxfQ09MT1JTW3IucmFuZGludCgwLCBsZW4oUElOS19QRVRBTF9DT0xPUlMpIC0gMSldXG4gICAgICAgICAgICAgICAgICAgIGVsZW1zLmFwcGVuZCh7XG4gICAgICAgICAgICAgICAgICAgICAgICBcInRleHRcIjogcGhyYXNlLFxuICAgICAgICAgICAgICAgICAgICAgICAgXCJ4XCI6IGp4LCBcInlcIjoganksXG4gICAgICAgICAgICAgICAgICAgICAgICBcImNvbG9yXCI6IGNvbG9yLFxuICAgICAgICAgICAgICAgICAgICAgICAgXCJzaXplXCI6IGludCgxMyAqIHNjYWxlKSBpZiByLnJhbmRvbSgpID4gMC44IGVsc2UgaW50KDEwICogc2NhbGUpLFxuICAgICAgICAgICAgICAgICAgICAgICAgXCJvcmRlclwiOiAwLjQwICsgZGlzdF9yYXRpbyAqIDAuNTVcbiAgICAgICAgICAgICAgICAgICAgfSlcblxuICAgICAgICAjIDQuIEdvbGRlbiBTdGFtZW5zICYgQW50aGVycyAoUG9sbGVuIHRpcHMpXG4gICAgICAgIGZvciBpZHgsIGFuZyBpbiBlbnVtZXJhdGUocGV0YWxfYW5nbGVzKTpcbiAgICAgICAgICAgIHNfbGVuID0gKDQ4ICsgKGlkeCAlIDIpICogMTIpICogc2NhbGVcbiAgICAgICAgICAgIGF4ID0gY3ggKyBpbnQobS5jb3MoYW5nKSAqIHNfbGVuKVxuICAgICAgICAgICAgYXkgPSBjeSArIGludChtLnNpbihhbmcpICogc19sZW4gKiAwLjg4KVxuICAgICAgICAgICAgZWxlbXMuYXBwZW5kKHtcbiAgICAgICAgICAgICAgICBcInRleHRcIjogZlwi4pymIHtuZXh0X3BocmFzZSgpWzo3XX0g4oCiXCIsXG4gICAgICAgICAgICAgICAgXCJ4XCI6IGF4LCBcInlcIjogYXksXG4gICAgICAgICAgICAgICAgXCJjb2xvclwiOiBHT0xEX0FOVEhFUixcbiAgICAgICAgICAgICAgICBcInNpemVcIjogaW50KDEwICogc2NhbGUpLFxuICAgICAgICAgICAgICAgIFwib3JkZXJcIjogMC45MiArIChpZHggLyA2KSAqIDAuMDhcbiAgICAgICAgICAgIH0pXG5cbiAgICAgICAgcmV0dXJuIGVsZW1zXG5cbiAgICBkZWYgYW5pbWF0ZShzZWxmKTpcbiAgICAgICAgZWxhcHNlZCA9IHRpbWUudGltZSgpIC0gc2VsZi5zdGFydF90aW1lXG4gICAgICAgIHByb2dyZXNzID0gbWluKDEuMCwgZWxhcHNlZCAvIG1heCgxLjAsIERVUkFUSU9OKSlcblxuICAgICAgICB3aGlsZSBzZWxmLmRyYXduX2NvdW50IDwgbGVuKHNlbGYuZWxlbWVudHMpOlxuICAgICAgICAgICAgZWwgPSBzZWxmLmVsZW1lbnRzW3NlbGYuZHJhd25fY291bnRdXG4gICAgICAgICAgICBpZiBlbFtcIm9yZGVyXCJdIDw9IHByb2dyZXNzOlxuICAgICAgICAgICAgICAgIHNlbGYuY2FudmFzLmNyZWF0ZV90ZXh0KFxuICAgICAgICAgICAgICAgICAgICBlbFtcInhcIl0sIGVsW1wieVwiXSxcbiAgICAgICAgICAgICAgICAgICAgdGV4dD1lbFtcInRleHRcIl0sXG4gICAgICAgICAgICAgICAgICAgIGZpbGw9ZWxbXCJjb2xvclwiXSxcbiAgICAgICAgICAgICAgICAgICAgZm9udD0oXCJIZWx2ZXRpY2FcIiwgbWF4KDcsIGVsW1wic2l6ZVwiXSksIFwiYm9sZFwiKVxuICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICBzZWxmLmRyYXduX2NvdW50ICs9IDFcbiAgICAgICAgICAgIGVsc2U6XG4gICAgICAgICAgICAgICAgYnJlYWtcblxuICAgICAgICBpZiBwcm9ncmVzcyA8IDEuMDpcbiAgICAgICAgICAgIHNlbGYucm9vdC5hZnRlcihUSUNLLCBzZWxmLmFuaW1hdGUpXG4gICAgICAgIGVsc2U6XG4gICAgICAgICAgICBzZWxmLmNhbnZhcy5jcmVhdGVfdGV4dChcbiAgICAgICAgICAgICAgICBXIC8vIDIsIEggLSAzNSxcbiAgICAgICAgICAgICAgICB0ZXh0PVwiQSBwaW5rIGxpbHkgdGhhdCBibG9vbXMgeW91ciBoZWFydCBpbiBldmVyeSBsYW5ndWFnZS4g8J+MuFwiLFxuICAgICAgICAgICAgICAgIGZpbGw9XCIjZmRhNGFmXCIsXG4gICAgICAgICAgICAgICAgZm9udD0oXCJHZW9yZ2lhXCIsIDExLCBcIml0YWxpY1wiKVxuICAgICAgICAgICAgKVxuXG5cbmlmIF9fbmFtZV9fID09IFwiX19tYWluX19cIjpcbiAgICByb290ID0gdGsuVGsoKVxuICAgIGFwcCA9IFBpbmtMaWx5QXBwKHJvb3QpXG4gICAgcm9vdC5tYWlubG9vcCgpXG5gO1xuICB9XG5cbiAgLy8gQ2xhc3NpYyBSb3NlIFB5dGhvbiBTY3JpcHQgZmFsbGJhY2tcbiAgcmV0dXJuIGBcIlwiXCJcblBpbmsgUm9zZSBJbiBFdmVyeSBMYW5ndWFnZSDwn4y5XG5DcmVhdGl2ZSBDb2RpbmcgQXJ0IC8gUHl0aG9uIFRraW50ZXIgRWRpdGlvblxuUnVuIHdpdGg6IHB5dGhvbiBwaW5rX3Jvc2UucHlcblwiXCJcIlxuXG5pbXBvcnQgbWF0aCBhcyBtXG5pbXBvcnQgcmFuZG9tIGFzIHJcbmltcG9ydCB0a2ludGVyIGFzIHRrXG5pbXBvcnQgdGltZVxuXG5XLCBIID0gJHtjb25maWcud2lkdGh9LCAke2NvbmZpZy5oZWlnaHR9XG5EVVJBVElPTiA9ICR7Y29uZmlnLmR1cmF0aW9ufVxuVElDSyA9IDE2XG5TQ0FMRSA9ICR7Y29uZmlnLnNjYWxlfVxuUkVDSVBJRU5UID0gXCIke2NvbmZpZy5yZWNpcGllbnROYW1lIHx8ICdNeSBMb3ZlJ31cIlxuXG5QSFJBU0VTID0gW1xuICAgIFwiSSBsb3ZlIHlvdVwiLCBcIkplIHQnYWltZVwiLCBcIlRlIGFtb1wiLCBcIlRpIGFtb1wiLCBcIkljaCBsaWViZSBkaWNoXCIsXG4gICAgXCLmhJvjgZfjgabjgotcIiwgXCLmiJHniLHkvaBcIiwgXCLsgqzrnpHtlbRcIiwgXCLQryDRgtC10LHRjyDQu9GO0LHQu9GOXCIsIFwiU2VuaSBzZXZpeW9ydW1cIixcbiAgICBcIk1haGFsIGtpdGFcIiwgXCLYo9it2KjZg1wiLCBcIuCkruCliOCkgiDgpKTgpYHgpK7gpLjgpYcg4KSq4KWN4KSv4KS+4KSwIOCkleCksOCkpOCkviDgpLngpYLgpIFcIiwgXCJFdSB0ZSBhbW9cIlxuXVxuXG5QRVRBTF9DT0xPUlMgPSBbXCIjZmYxNzQ0XCIsIFwiI2Y0M2Y1ZVwiLCBcIiNlMTFkNDhcIiwgXCIjYmUxMjNjXCIsIFwiI2ZkYTRhZlwiXVxuU1RFTV9DT0xPUlMgPSBbXCIjMTBiOTgxXCIsIFwiIzA1OTY2OVwiLCBcIiMzNGQzOTlcIiwgXCIjMjJjNTVlXCJdXG5CR19DT0xPUiA9IFwiIzAwMDAwMFwiXG5cbiMgTWFpbiBUa2ludGVyIGltcGxlbWVudGF0aW9uLi4uXG5gO1xufVxuIl19