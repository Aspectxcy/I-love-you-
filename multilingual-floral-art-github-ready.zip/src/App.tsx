const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"];const _jsxDEV = __vite__cjsImport10_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=3ba6436c";
import { RoseCanvas } from "/src/components/RoseCanvas.tsx";
import { RoseControls } from "/src/components/RoseControls.tsx";
import { PhraseCard } from "/src/components/PhraseCard.tsx";
import { CodeViewer } from "/src/components/CodeViewer.tsx";
import { LanguageExplorer } from "/src/components/LanguageExplorer.tsx";
import { CardExportModal } from "/src/components/CardExportModal.tsx";
import { GitHubExportModal } from "/src/components/GitHubExportModal.tsx";
import { AVAILABLE_FLOWERS } from "/src/utils/flowerShapes.ts";
import { Heart, Code2, Globe, Github } from "/node_modules/.vite/deps/lucide-react.js?v=3ba6436c";
var _jsxFileName = "/app/applet/src/App.tsx";
import __vite__cjsImport10_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3ba6436c";
export default function App() {
	const [flowerType, setFlowerType] = useState("pink_rose");
	const [bloomProgress, setBloomProgress] = useState(1);
	const [isPlaying, setIsPlaying] = useState(false);
	const [themeId, setThemeId] = useState("crimson");
	const [recipientName, setRecipientName] = useState("");
	const [isCinematic, setIsCinematic] = useState(true);
	const [selectedPhrase, setSelectedPhrase] = useState(null);
	const [hoveredPhrase, setHoveredPhrase] = useState(null);
	const [isLanguagesOpen, setIsLanguagesOpen] = useState(false);
	const [isCardModalOpen, setIsCardModalOpen] = useState(false);
	const [isGitHubModalOpen, setIsGitHubModalOpen] = useState(false);
	const currentFlower = AVAILABLE_FLOWERS.find((f) => f.id === flowerType) || AVAILABLE_FLOWERS[0];
	// Python IDE configuration state
	const [pythonConfig, setPythonConfig] = useState({
		width: 600,
		height: 800,
		duration: 10,
		gap: 3,
		scale: 1,
		flowerType: "rose",
		themeName: currentFlower.name,
		recipientName: ""
	});
	// Keep python config flowerType in sync
	useEffect(() => {
		setPythonConfig((prev) => ({
			...prev,
			flowerType: flowerType === "pink_lily" ? "lily" : "rose",
			themeName: currentFlower.name
		}));
	}, [flowerType, currentFlower.name]);
	// Animation frame loop for bloom progress
	const animStartTimeRef = useRef(null);
	const animInitialProgressRef = useRef(0);
	useEffect(() => {
		let reqId;
		const tick = (now) => {
			if (!animStartTimeRef.current) {
				animStartTimeRef.current = now;
				animInitialProgressRef.current = bloomProgress;
			}
			const elapsed = (now - animStartTimeRef.current) / 1e3;
			const speed = 1 / (pythonConfig.duration || 10);
			const newProgress = Math.min(1, animInitialProgressRef.current + elapsed * speed);
			setBloomProgress(newProgress);
			if (newProgress >= 1) {
				setIsPlaying(false);
				animStartTimeRef.current = null;
			} else {
				reqId = requestAnimationFrame(tick);
			}
		};
		if (isPlaying) {
			animStartTimeRef.current = null;
			reqId = requestAnimationFrame(tick);
		}
		return () => {
			if (reqId) cancelAnimationFrame(reqId);
		};
	}, [isPlaying, pythonConfig.duration]);
	// Sync recipient name into python config
	useEffect(() => {
		setPythonConfig((prev) => ({
			...prev,
			recipientName
		}));
	}, [recipientName]);
	const handleTogglePlay = () => {
		if (bloomProgress >= 1) {
			setBloomProgress(0);
		}
		setIsPlaying((prev) => !prev);
	};
	const handleReset = () => {
		setIsPlaying(false);
		animStartTimeRef.current = null;
		setBloomProgress(0);
	};
	const handleRunCode = () => {
		setBloomProgress(0);
		setIsPlaying(true);
	};
	const activePhrase = hoveredPhrase || selectedPhrase;
	const flowerTitle = currentFlower.name;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "relative min-h-screen w-full bg-black text-rose-50 flex flex-col justify-between overflow-x-hidden selection:bg-pink-500 selection:text-white",
		children: [
			/* @__PURE__ */ _jsxDEV("div", { className: "fixed top-0 left-1/4 w-96 h-96 bg-pink-600/10 rounded-full blur-[140px] pointer-events-none" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 116,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", { className: "fixed top-1/3 right-10 w-80 h-80 bg-fuchsia-600/10 rounded-full blur-[120px] pointer-events-none" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 117,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", { className: "fixed bottom-10 left-10 w-96 h-96 bg-emerald-600/10 rounded-full blur-[150px] pointer-events-none" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 118,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("header", {
				className: "relative z-20 px-4 py-3 border-b border-zinc-900 bg-black/85 backdrop-blur-md flex items-center justify-between gap-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "w-9 h-9 rounded-xl bg-gradient-to-tr from-pink-600 to-rose-500 flex items-center justify-center text-lg shadow-lg shadow-pink-950 select-none",
						children: currentFlower.emoji
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 123,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", {
						className: "font-display text-base md:text-lg font-bold tracking-tight text-white flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV("span", { children: flowerTitle }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 128,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs px-2 py-0.5 rounded-full bg-pink-950 border border-pink-500/40 text-pink-300 font-sans font-medium hidden sm:inline-block",
							children: "In Every Language"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 129,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 127,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-[11px] text-zinc-400 font-sans",
						children: "\"What if a single flower could say 'I love you' in 60+ languages?\""
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 133,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 126,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 122,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setIsGitHubModalOpen(true),
							className: "flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700/80 text-xs font-semibold text-zinc-200 hover:text-white transition-all shadow-sm active:scale-95",
							title: "Export repository to GitHub",
							children: [/* @__PURE__ */ _jsxDEV(Github, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 147,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "hidden sm:inline",
								children: "Export to GitHub"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 148,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 142,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setIsCardModalOpen(true),
							className: "flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-pink-950/80 hover:bg-pink-900 border border-pink-500/40 text-xs font-medium text-pink-200 hover:text-white transition-all shadow-sm active:scale-95",
							title: "Create a personalized dedication card",
							children: [/* @__PURE__ */ _jsxDEV(Heart, { className: "w-3.5 h-3.5 fill-pink-500 text-pink-500" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 156,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "hidden sm:inline",
								children: "Dedicate"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 157,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 151,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setIsLanguagesOpen(!isLanguagesOpen),
							className: `flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-medium transition-all ${isLanguagesOpen ? "bg-pink-900/60 border-pink-500 text-white" : "bg-zinc-900/80 border-zinc-800 text-zinc-300 hover:text-white"}`,
							title: "Explore all languages",
							children: [/* @__PURE__ */ _jsxDEV(Globe, { className: "w-3.5 h-3.5 text-pink-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 169,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "hidden sm:inline",
								children: "Languages"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 170,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 160,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setIsCinematic(!isCinematic),
							className: `flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-medium transition-all ${!isCinematic ? "bg-pink-900/60 border-pink-500 text-white" : "bg-zinc-900/80 border-zinc-800 text-zinc-300 hover:text-white"}`,
							title: "Toggle between cinematic romance mode and Python IDE coding studio",
							children: [/* @__PURE__ */ _jsxDEV(Code2, { className: "w-3.5 h-3.5 text-pink-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 182,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "hidden md:inline",
								children: isCinematic ? "Python IDE" : "Cinematic"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 183,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 173,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 140,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 121,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("main", {
				className: "relative z-10 flex-1 flex flex-col p-2 md:p-4 gap-3 max-w-7xl mx-auto w-full overflow-hidden",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex-1 min-h-[440px] md:min-h-[560px] grid grid-cols-1 lg:grid-cols-12 gap-4 items-stretch",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: `relative transition-all duration-500 flex flex-col ${isCinematic ? "lg:col-span-12" : "lg:col-span-7"} min-h-[430px] md:min-h-[550px]`,
						children: [isCinematic && /* @__PURE__ */ _jsxDEV("div", {
							className: "absolute top-4 left-0 right-0 z-10 text-center pointer-events-none px-4",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "font-script text-3xl md:text-5xl text-pink-200 drop-shadow-[0_2px_15px_rgba(244,114,182,0.7)] animate-float-gentle inline-block",
									children: flowerTitle
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 203,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "font-mono text-xs text-pink-300/80 tracking-widest uppercase mt-0.5",
									children: "In Every Language"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 206,
									columnNumber: 17
								}, this),
								recipientName && /* @__PURE__ */ _jsxDEV("p", {
									className: "font-script text-2xl text-pink-300 mt-1 drop-shadow-md",
									children: [
										"Dedicated with endless affection to ",
										recipientName,
										" ♥"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 210,
									columnNumber: 19
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 202,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex-1 w-full h-full relative",
							children: [
								/* @__PURE__ */ _jsxDEV(RoseCanvas, {
									bloomProgress,
									themeId,
									recipientName,
									flowerType,
									isCinematic,
									onSelectPhrase: (phrase) => setSelectedPhrase(phrase),
									selectedPhraseId: selectedPhrase?.id,
									onHoverPhrase: (phrase) => setHoveredPhrase(phrase)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 219,
									columnNumber: 15
								}, this),
								activePhrase && /* @__PURE__ */ _jsxDEV("div", {
									className: "absolute bottom-4 right-4 z-20 max-w-xs w-full animate-fadeIn",
									children: /* @__PURE__ */ _jsxDEV(PhraseCard, {
										phrase: activePhrase,
										onClose: () => {
											setSelectedPhrase(null);
											setHoveredPhrase(null);
										},
										onDedicate: (p) => {
											setSelectedPhrase(p);
										}
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 233,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 232,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "absolute bottom-2 left-4 z-10 pointer-events-none text-[11px] text-zinc-400 font-mono bg-black/70 px-2.5 py-1 rounded-full border border-zinc-800/80 backdrop-blur-md",
									children: "✦ Hover or click any phrase to hear pronunciation & cultural lore"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 247,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 218,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 195,
						columnNumber: 11
					}, this), !isCinematic && /* @__PURE__ */ _jsxDEV("div", {
						className: "lg:col-span-5 flex flex-col min-h-[440px] md:min-h-[560px]",
						children: /* @__PURE__ */ _jsxDEV(CodeViewer, {
							config: pythonConfig,
							onConfigChange: (newCfg) => {
								setPythonConfig(newCfg);
								if (newCfg.recipientName !== recipientName) {
									setRecipientName(newCfg.recipientName);
								}
							},
							onRunCode: handleRunCode
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 256,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 255,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 193,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "relative z-20",
					children: /* @__PURE__ */ _jsxDEV(RoseControls, {
						bloomProgress,
						onProgressChange: (val) => {
							setIsPlaying(false);
							setBloomProgress(val);
						},
						isPlaying,
						onTogglePlay: handleTogglePlay,
						onReset: handleReset,
						flowerType,
						onFlowerTypeChange: (type) => {
							setFlowerType(type);
							setBloomProgress(1);
						},
						themeId,
						onThemeChange: setThemeId,
						isCinematic,
						onToggleCinematic: () => setIsCinematic(!isCinematic),
						onOpenDedication: () => setIsCardModalOpen(true),
						onToggleLanguages: () => setIsLanguagesOpen(!isLanguagesOpen),
						isLanguagesOpen,
						onOpenGitHubExport: () => setIsGitHubModalOpen(true),
						recipientName
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 273,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 272,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 191,
				columnNumber: 7
			}, this),
			isLanguagesOpen && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-y-0 right-0 z-40 w-full max-w-md bg-zinc-950/95 border-l border-pink-900/50 shadow-2xl p-4 flex flex-col animate-slideLeft backdrop-blur-2xl",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between pb-3 mb-2 border-b border-zinc-800",
					children: [/* @__PURE__ */ _jsxDEV("h3", {
						className: "font-display font-bold text-pink-200 text-base flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV(Globe, { className: "w-4 h-4 text-pink-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 305,
							columnNumber: 15
						}, this), "Multilingual Flower Directory"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 304,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setIsLanguagesOpen(false),
						className: "p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800",
						children: "✕"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 308,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 303,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex-1 overflow-hidden",
					children: /* @__PURE__ */ _jsxDEV(LanguageExplorer, {
						onSelectPhrase: (phrase) => {
							setSelectedPhrase(phrase);
							setHoveredPhrase(phrase);
						},
						selectedPhraseId: selectedPhrase?.id
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 316,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 315,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 302,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV(CardExportModal, {
				isOpen: isCardModalOpen,
				onClose: () => setIsCardModalOpen(false),
				recipientName,
				onUpdateRecipient: setRecipientName,
				themeId,
				flowerType: flowerType === "pink_lily" ? "lily" : "rose"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 328,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(GitHubExportModal, {
				isOpen: isGitHubModalOpen,
				onClose: () => setIsGitHubModalOpen(false),
				recipientName
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 338,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 114,
		columnNumber: 5
	}, this);
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsV0FBVyxjQUFjO0FBQ25ELFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsd0JBQXdCO0FBQ2pDLFNBQVMsdUJBQXVCO0FBQ2hDLFNBQVMseUJBQXlCO0FBQ2xDLFNBQVMseUJBQXFDO0FBRzlDLFNBQVMsT0FBTyxPQUFPLE9BQU8sY0FBYzs7O0FBRTVDLGVBQWUsU0FBUyxNQUFNO0NBQzVCLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFxQixXQUFXO0NBQ3BFLE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFTLENBQUc7Q0FDdEQsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsS0FBSztDQUNoRCxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsU0FBUztDQUNoRCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxFQUFFO0NBQ3JELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLElBQUk7Q0FDbkQsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBNEIsSUFBSTtDQUM1RSxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBNEIsSUFBSTtDQUMxRSxNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUFTLEtBQUs7Q0FDNUQsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBUyxLQUFLO0NBQzVELE1BQU0sQ0FBQyxtQkFBbUIsd0JBQXdCLFNBQVMsS0FBSztDQUVoRSxNQUFNLGdCQUFnQixrQkFBa0IsTUFBTSxNQUFNLEVBQUUsT0FBTyxVQUFVLEtBQUssa0JBQWtCOztDQUc5RixNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBdUI7RUFDN0QsT0FBTztFQUNQLFFBQVE7RUFDUixVQUFVO0VBQ1YsS0FBSztFQUNMLE9BQU87RUFDUCxZQUFZO0VBQ1osV0FBVyxjQUFjO0VBQ3pCLGVBQWU7Q0FDakIsQ0FBQzs7Q0FHRCxnQkFBZ0I7RUFDZCxpQkFBaUIsVUFBVTtHQUN6QixHQUFHO0dBQ0gsWUFBWSxlQUFlLGNBQWMsU0FBUztHQUNsRCxXQUFXLGNBQWM7RUFDM0IsRUFBRTtDQUNKLEdBQUcsQ0FBQyxZQUFZLGNBQWMsSUFBSSxDQUFDOztDQUduQyxNQUFNLG1CQUFtQixPQUFzQixJQUFJO0NBQ25ELE1BQU0seUJBQXlCLE9BQWUsQ0FBQztDQUUvQyxnQkFBZ0I7RUFDZCxJQUFJO0VBRUosTUFBTSxRQUFRLFFBQWdCO0dBQzVCLElBQUksQ0FBQyxpQkFBaUIsU0FBUztJQUM3QixpQkFBaUIsVUFBVTtJQUMzQix1QkFBdUIsVUFBVTtHQUNuQztHQUVBLE1BQU0sV0FBVyxNQUFNLGlCQUFpQixXQUFXO0dBQ25ELE1BQU0sUUFBUSxLQUFLLGFBQWEsWUFBWTtHQUM1QyxNQUFNLGNBQWMsS0FBSyxJQUFJLEdBQUssdUJBQXVCLFVBQVUsVUFBVSxLQUFLO0dBRWxGLGlCQUFpQixXQUFXO0dBRTVCLElBQUksZUFBZSxHQUFLO0lBQ3RCLGFBQWEsS0FBSztJQUNsQixpQkFBaUIsVUFBVTtHQUM3QixPQUFPO0lBQ0wsUUFBUSxzQkFBc0IsSUFBSTtHQUNwQztFQUNGO0VBRUEsSUFBSSxXQUFXO0dBQ2IsaUJBQWlCLFVBQVU7R0FDM0IsUUFBUSxzQkFBc0IsSUFBSTtFQUNwQztFQUVBLGFBQWE7R0FDWCxJQUFJLE9BQU8scUJBQXFCLEtBQUs7RUFDdkM7Q0FDRixHQUFHLENBQUMsV0FBVyxhQUFhLFFBQVEsQ0FBQzs7Q0FHckMsZ0JBQWdCO0VBQ2QsaUJBQWlCLFVBQVU7R0FBRSxHQUFHO0dBQU07RUFBYyxFQUFFO0NBQ3hELEdBQUcsQ0FBQyxhQUFhLENBQUM7Q0FFbEIsTUFBTSx5QkFBeUI7RUFDN0IsSUFBSSxpQkFBaUIsR0FBSztHQUN4QixpQkFBaUIsQ0FBQztFQUNwQjtFQUNBLGNBQWMsU0FBUyxDQUFDLElBQUk7Q0FDOUI7Q0FFQSxNQUFNLG9CQUFvQjtFQUN4QixhQUFhLEtBQUs7RUFDbEIsaUJBQWlCLFVBQVU7RUFDM0IsaUJBQWlCLENBQUM7Q0FDcEI7Q0FFQSxNQUFNLHNCQUFzQjtFQUMxQixpQkFBaUIsQ0FBQztFQUNsQixhQUFhLElBQUk7Q0FDbkI7Q0FFQSxNQUFNLGVBQWUsaUJBQWlCO0NBQ3RDLE1BQU0sY0FBYyxjQUFjO0NBRWxDLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUVFLHdCQUFDLE9BQUQsRUFBSyxXQUFVLDhGQUErRjs7Ozs7R0FDOUcsd0JBQUMsT0FBRCxFQUFLLFdBQVUsbUdBQW9HOzs7OztHQUNuSCx3QkFBQyxPQUFELEVBQUssV0FBVSxvR0FBcUc7Ozs7O0dBR3BILHdCQUFDLFVBQUQ7SUFBUSxXQUFVO2NBQWxCLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNaLGNBQWM7S0FDWjs7OztlQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBZCxDQUNFLHdCQUFDLFFBQUQsWUFBTyxZQUFrQjs7OztnQkFDekIsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQW9JO01BRTlJOzs7O2NBQ0o7Ozs7O2VBQ0osd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQXNDO0tBRWhEOzs7O2FBQ0E7Ozs7YUFDRjs7Ozs7Y0FHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BRUUsd0JBQUMsVUFBRDtPQUNFLGVBQWUscUJBQXFCLElBQUk7T0FDeEMsV0FBVTtPQUNWLE9BQU07aUJBSFIsQ0FLRSx3QkFBQyxRQUFELEVBQVEsV0FBVSxjQUFlOzs7O2lCQUNqQyx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBbUI7T0FBc0I7Ozs7ZUFDbkQ7Ozs7OztNQUVSLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLG1CQUFtQixJQUFJO09BQ3RDLFdBQVU7T0FDVixPQUFNO2lCQUhSLENBS0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUsMENBQTJDOzs7O2lCQUM1RCx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBbUI7T0FBYzs7OztlQUMzQzs7Ozs7O01BRVIsd0JBQUMsVUFBRDtPQUNFLGVBQWUsbUJBQW1CLENBQUMsZUFBZTtPQUNsRCxXQUFXLDhGQUNULGtCQUNJLDhDQUNBO09BRU4sT0FBTTtpQkFQUixDQVNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLDRCQUE2Qjs7OztpQkFDOUMsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQW1CO09BQWU7Ozs7ZUFDNUM7Ozs7OztNQUVSLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLGVBQWUsQ0FBQyxXQUFXO09BQzFDLFdBQVcsOEZBQ1QsQ0FBQyxjQUNHLDhDQUNBO09BRU4sT0FBTTtpQkFQUixDQVNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLDRCQUE2Qjs7OztpQkFDOUMsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQ2IsY0FBYyxlQUFlO09BQzFCOzs7O2VBQ0E7Ozs7OztLQUNMOzs7OztZQUNDOzs7Ozs7R0FHUix3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUFoQixDQUVFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FFRSx3QkFBQyxPQUFEO01BQ0UsV0FBVyxzREFDVCxjQUFjLG1CQUFtQixnQkFDbEM7Z0JBSEgsQ0FNRyxlQUNDLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQ2I7UUFDRzs7Ozs7UUFDTix3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBc0U7UUFFaEY7Ozs7O1FBQ0YsaUJBQ0Msd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQWI7VUFBc0U7VUFDL0I7VUFBYztTQUNsRDs7Ozs7O09BRUY7Ozs7O2dCQUlQLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsWUFBRDtTQUNpQjtTQUNOO1NBQ007U0FDSDtTQUNDO1NBQ2IsaUJBQWlCLFdBQVcsa0JBQWtCLE1BQU07U0FDcEQsa0JBQWtCLGdCQUFnQjtTQUNsQyxnQkFBZ0IsV0FBVyxpQkFBaUIsTUFBTTtRQUNuRDs7Ozs7UUFHQSxnQkFDQyx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDYix3QkFBQyxZQUFEO1VBQ0UsUUFBUTtVQUNSLGVBQWU7V0FDYixrQkFBa0IsSUFBSTtXQUN0QixpQkFBaUIsSUFBSTtVQUN2QjtVQUNBLGFBQWEsTUFBTTtXQUNqQixrQkFBa0IsQ0FBQztVQUNyQjtTQUNEOzs7OztRQUNFOzs7OztRQUlQLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUF3SztRQUVsTDs7Ozs7T0FDRjs7Ozs7Y0FDRjs7Ozs7ZUFHSixDQUFDLGVBQ0Esd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsWUFBRDtPQUNFLFFBQVE7T0FDUixpQkFBaUIsV0FBVztRQUMxQixnQkFBZ0IsTUFBTTtRQUN0QixJQUFJLE9BQU8sa0JBQWtCLGVBQWU7U0FDMUMsaUJBQWlCLE9BQU8sYUFBYTtRQUN2QztPQUNGO09BQ0EsV0FBVztNQUNaOzs7OztLQUNFOzs7O2FBRUo7Ozs7O2NBSUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDYix3QkFBQyxjQUFEO01BQ2lCO01BQ2YsbUJBQW1CLFFBQVE7T0FDekIsYUFBYSxLQUFLO09BQ2xCLGlCQUFpQixHQUFHO01BQ3RCO01BQ1c7TUFDWCxjQUFjO01BQ2QsU0FBUztNQUNHO01BQ1oscUJBQXFCLFNBQVM7T0FDNUIsY0FBYyxJQUFJO09BQ2xCLGlCQUFpQixDQUFHO01BQ3RCO01BQ1M7TUFDVCxlQUFlO01BQ0Y7TUFDYix5QkFBeUIsZUFBZSxDQUFDLFdBQVc7TUFDcEQsd0JBQXdCLG1CQUFtQixJQUFJO01BQy9DLHlCQUF5QixtQkFBbUIsQ0FBQyxlQUFlO01BQzNDO01BQ2pCLDBCQUEwQixxQkFBcUIsSUFBSTtNQUNwQztLQUNoQjs7Ozs7SUFDRTs7OztZQUNEOzs7Ozs7R0FHTCxtQkFDQyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFkLENBQ0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUsd0JBQXlCOzs7O2dCQUFDLCtCQUV6Qzs7Ozs7ZUFDSix3QkFBQyxVQUFEO01BQ0UsZUFBZSxtQkFBbUIsS0FBSztNQUN2QyxXQUFVO2dCQUNYO0tBRU87Ozs7YUFDTDs7Ozs7Y0FDTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLGtCQUFEO01BQ0UsaUJBQWlCLFdBQVc7T0FDMUIsa0JBQWtCLE1BQU07T0FDeEIsaUJBQWlCLE1BQU07TUFDekI7TUFDQSxrQkFBa0IsZ0JBQWdCO0tBQ25DOzs7OztJQUNFOzs7O1lBQ0Y7Ozs7OztHQUlQLHdCQUFDLGlCQUFEO0lBQ0UsUUFBUTtJQUNSLGVBQWUsbUJBQW1CLEtBQUs7SUFDeEI7SUFDZixtQkFBbUI7SUFDVjtJQUNULFlBQVksZUFBZSxjQUFjLFNBQVM7R0FDbkQ7Ozs7O0dBR0Qsd0JBQUMsbUJBQUQ7SUFDRSxRQUFRO0lBQ1IsZUFBZSxxQkFBcUIsS0FBSztJQUMxQjtHQUNoQjs7Ozs7RUFDRTs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXBwLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlUmVmIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgUm9zZUNhbnZhcyB9IGZyb20gJy4vY29tcG9uZW50cy9Sb3NlQ2FudmFzJztcbmltcG9ydCB7IFJvc2VDb250cm9scyB9IGZyb20gJy4vY29tcG9uZW50cy9Sb3NlQ29udHJvbHMnO1xuaW1wb3J0IHsgUGhyYXNlQ2FyZCB9IGZyb20gJy4vY29tcG9uZW50cy9QaHJhc2VDYXJkJztcbmltcG9ydCB7IENvZGVWaWV3ZXIgfSBmcm9tICcuL2NvbXBvbmVudHMvQ29kZVZpZXdlcic7XG5pbXBvcnQgeyBMYW5ndWFnZUV4cGxvcmVyIH0gZnJvbSAnLi9jb21wb25lbnRzL0xhbmd1YWdlRXhwbG9yZXInO1xuaW1wb3J0IHsgQ2FyZEV4cG9ydE1vZGFsIH0gZnJvbSAnLi9jb21wb25lbnRzL0NhcmRFeHBvcnRNb2RhbCc7XG5pbXBvcnQgeyBHaXRIdWJFeHBvcnRNb2RhbCB9IGZyb20gJy4vY29tcG9uZW50cy9HaXRIdWJFeHBvcnRNb2RhbCc7XG5pbXBvcnQgeyBBVkFJTEFCTEVfRkxPV0VSUywgRmxvd2VyVHlwZSB9IGZyb20gJy4vdXRpbHMvZmxvd2VyU2hhcGVzJztcbmltcG9ydCB7IExvdmVQaHJhc2UgfSBmcm9tICcuL2RhdGEvbGFuZ3VhZ2VzJztcbmltcG9ydCB7IFB5dGhvbkNvbmZpZyB9IGZyb20gJy4vdXRpbHMvcHl0aG9uU2NyaXB0JztcbmltcG9ydCB7IEhlYXJ0LCBDb2RlMiwgR2xvYmUsIEdpdGh1YiB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFwcCgpIHtcbiAgY29uc3QgW2Zsb3dlclR5cGUsIHNldEZsb3dlclR5cGVdID0gdXNlU3RhdGU8Rmxvd2VyVHlwZT4oJ3Bpbmtfcm9zZScpO1xuICBjb25zdCBbYmxvb21Qcm9ncmVzcywgc2V0Qmxvb21Qcm9ncmVzc10gPSB1c2VTdGF0ZSgxLjApOyAvLyBzdGFydCBmdWxseSBibG9vbWVkXG4gIGNvbnN0IFtpc1BsYXlpbmcsIHNldElzUGxheWluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFt0aGVtZUlkLCBzZXRUaGVtZUlkXSA9IHVzZVN0YXRlKCdjcmltc29uJyk7XG4gIGNvbnN0IFtyZWNpcGllbnROYW1lLCBzZXRSZWNpcGllbnROYW1lXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2lzQ2luZW1hdGljLCBzZXRJc0NpbmVtYXRpY10gPSB1c2VTdGF0ZSh0cnVlKTtcbiAgY29uc3QgW3NlbGVjdGVkUGhyYXNlLCBzZXRTZWxlY3RlZFBocmFzZV0gPSB1c2VTdGF0ZTxMb3ZlUGhyYXNlIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtob3ZlcmVkUGhyYXNlLCBzZXRIb3ZlcmVkUGhyYXNlXSA9IHVzZVN0YXRlPExvdmVQaHJhc2UgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2lzTGFuZ3VhZ2VzT3Blbiwgc2V0SXNMYW5ndWFnZXNPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2lzQ2FyZE1vZGFsT3Blbiwgc2V0SXNDYXJkTW9kYWxPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2lzR2l0SHViTW9kYWxPcGVuLCBzZXRJc0dpdEh1Yk1vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgY29uc3QgY3VycmVudEZsb3dlciA9IEFWQUlMQUJMRV9GTE9XRVJTLmZpbmQoKGYpID0+IGYuaWQgPT09IGZsb3dlclR5cGUpIHx8IEFWQUlMQUJMRV9GTE9XRVJTWzBdO1xuXG4gIC8vIFB5dGhvbiBJREUgY29uZmlndXJhdGlvbiBzdGF0ZVxuICBjb25zdCBbcHl0aG9uQ29uZmlnLCBzZXRQeXRob25Db25maWddID0gdXNlU3RhdGU8UHl0aG9uQ29uZmlnPih7XG4gICAgd2lkdGg6IDYwMCxcbiAgICBoZWlnaHQ6IDgwMCxcbiAgICBkdXJhdGlvbjogMTAsXG4gICAgZ2FwOiAzLFxuICAgIHNjYWxlOiAxLjAsXG4gICAgZmxvd2VyVHlwZTogJ3Jvc2UnLFxuICAgIHRoZW1lTmFtZTogY3VycmVudEZsb3dlci5uYW1lLFxuICAgIHJlY2lwaWVudE5hbWU6ICcnLFxuICB9KTtcblxuICAvLyBLZWVwIHB5dGhvbiBjb25maWcgZmxvd2VyVHlwZSBpbiBzeW5jXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgc2V0UHl0aG9uQ29uZmlnKChwcmV2KSA9PiAoe1xuICAgICAgLi4ucHJldixcbiAgICAgIGZsb3dlclR5cGU6IGZsb3dlclR5cGUgPT09ICdwaW5rX2xpbHknID8gJ2xpbHknIDogJ3Jvc2UnLFxuICAgICAgdGhlbWVOYW1lOiBjdXJyZW50Rmxvd2VyLm5hbWUsXG4gICAgfSkpO1xuICB9LCBbZmxvd2VyVHlwZSwgY3VycmVudEZsb3dlci5uYW1lXSk7XG5cbiAgLy8gQW5pbWF0aW9uIGZyYW1lIGxvb3AgZm9yIGJsb29tIHByb2dyZXNzXG4gIGNvbnN0IGFuaW1TdGFydFRpbWVSZWYgPSB1c2VSZWY8bnVtYmVyIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IGFuaW1Jbml0aWFsUHJvZ3Jlc3NSZWYgPSB1c2VSZWY8bnVtYmVyPigwKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGxldCByZXFJZDogbnVtYmVyO1xuXG4gICAgY29uc3QgdGljayA9IChub3c6IG51bWJlcikgPT4ge1xuICAgICAgaWYgKCFhbmltU3RhcnRUaW1lUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgYW5pbVN0YXJ0VGltZVJlZi5jdXJyZW50ID0gbm93O1xuICAgICAgICBhbmltSW5pdGlhbFByb2dyZXNzUmVmLmN1cnJlbnQgPSBibG9vbVByb2dyZXNzO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBlbGFwc2VkID0gKG5vdyAtIGFuaW1TdGFydFRpbWVSZWYuY3VycmVudCkgLyAxMDAwO1xuICAgICAgY29uc3Qgc3BlZWQgPSAxIC8gKHB5dGhvbkNvbmZpZy5kdXJhdGlvbiB8fCAxMCk7XG4gICAgICBjb25zdCBuZXdQcm9ncmVzcyA9IE1hdGgubWluKDEuMCwgYW5pbUluaXRpYWxQcm9ncmVzc1JlZi5jdXJyZW50ICsgZWxhcHNlZCAqIHNwZWVkKTtcblxuICAgICAgc2V0Qmxvb21Qcm9ncmVzcyhuZXdQcm9ncmVzcyk7XG5cbiAgICAgIGlmIChuZXdQcm9ncmVzcyA+PSAxLjApIHtcbiAgICAgICAgc2V0SXNQbGF5aW5nKGZhbHNlKTtcbiAgICAgICAgYW5pbVN0YXJ0VGltZVJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJlcUlkID0gcmVxdWVzdEFuaW1hdGlvbkZyYW1lKHRpY2spO1xuICAgICAgfVxuICAgIH07XG5cbiAgICBpZiAoaXNQbGF5aW5nKSB7XG4gICAgICBhbmltU3RhcnRUaW1lUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgcmVxSWQgPSByZXF1ZXN0QW5pbWF0aW9uRnJhbWUodGljayk7XG4gICAgfVxuXG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGlmIChyZXFJZCkgY2FuY2VsQW5pbWF0aW9uRnJhbWUocmVxSWQpO1xuICAgIH07XG4gIH0sIFtpc1BsYXlpbmcsIHB5dGhvbkNvbmZpZy5kdXJhdGlvbl0pO1xuXG4gIC8vIFN5bmMgcmVjaXBpZW50IG5hbWUgaW50byBweXRob24gY29uZmlnXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgc2V0UHl0aG9uQ29uZmlnKChwcmV2KSA9PiAoeyAuLi5wcmV2LCByZWNpcGllbnROYW1lIH0pKTtcbiAgfSwgW3JlY2lwaWVudE5hbWVdKTtcblxuICBjb25zdCBoYW5kbGVUb2dnbGVQbGF5ID0gKCkgPT4ge1xuICAgIGlmIChibG9vbVByb2dyZXNzID49IDEuMCkge1xuICAgICAgc2V0Qmxvb21Qcm9ncmVzcygwKTtcbiAgICB9XG4gICAgc2V0SXNQbGF5aW5nKChwcmV2KSA9PiAhcHJldik7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlUmVzZXQgPSAoKSA9PiB7XG4gICAgc2V0SXNQbGF5aW5nKGZhbHNlKTtcbiAgICBhbmltU3RhcnRUaW1lUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgIHNldEJsb29tUHJvZ3Jlc3MoMCk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlUnVuQ29kZSA9ICgpID0+IHtcbiAgICBzZXRCbG9vbVByb2dyZXNzKDApO1xuICAgIHNldElzUGxheWluZyh0cnVlKTtcbiAgfTtcblxuICBjb25zdCBhY3RpdmVQaHJhc2UgPSBob3ZlcmVkUGhyYXNlIHx8IHNlbGVjdGVkUGhyYXNlO1xuICBjb25zdCBmbG93ZXJUaXRsZSA9IGN1cnJlbnRGbG93ZXIubmFtZTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgbWluLWgtc2NyZWVuIHctZnVsbCBiZy1ibGFjayB0ZXh0LXJvc2UtNTAgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW4gb3ZlcmZsb3cteC1oaWRkZW4gc2VsZWN0aW9uOmJnLXBpbmstNTAwIHNlbGVjdGlvbjp0ZXh0LXdoaXRlXCI+XG4gICAgICB7LyogU3VidGxlIEFtYmllbnQgR2xvdyBPcmJzICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCB0b3AtMCBsZWZ0LTEvNCB3LTk2IGgtOTYgYmctcGluay02MDAvMTAgcm91bmRlZC1mdWxsIGJsdXItWzE0MHB4XSBwb2ludGVyLWV2ZW50cy1ub25lXCIgLz5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgdG9wLTEvMyByaWdodC0xMCB3LTgwIGgtODAgYmctZnVjaHNpYS02MDAvMTAgcm91bmRlZC1mdWxsIGJsdXItWzEyMHB4XSBwb2ludGVyLWV2ZW50cy1ub25lXCIgLz5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgYm90dG9tLTEwIGxlZnQtMTAgdy05NiBoLTk2IGJnLWVtZXJhbGQtNjAwLzEwIHJvdW5kZWQtZnVsbCBibHVyLVsxNTBweF0gcG9pbnRlci1ldmVudHMtbm9uZVwiIC8+XG5cbiAgICAgIHsvKiBUb3AgTmF2aWdhdGlvbiAmIFRpdGxlIEJhciAqL31cbiAgICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwicmVsYXRpdmUgei0yMCBweC00IHB5LTMgYm9yZGVyLWIgYm9yZGVyLXppbmMtOTAwIGJnLWJsYWNrLzg1IGJhY2tkcm9wLWJsdXItbWQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOSBoLTkgcm91bmRlZC14bCBiZy1ncmFkaWVudC10by10ciBmcm9tLXBpbmstNjAwIHRvLXJvc2UtNTAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtbGcgc2hhZG93LWxnIHNoYWRvdy1waW5rLTk1MCBzZWxlY3Qtbm9uZVwiPlxuICAgICAgICAgICAge2N1cnJlbnRGbG93ZXIuZW1vaml9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJmb250LWRpc3BsYXkgdGV4dC1iYXNlIG1kOnRleHQtbGcgZm9udC1ib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPHNwYW4+e2Zsb3dlclRpdGxlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgYmctcGluay05NTAgYm9yZGVyIGJvcmRlci1waW5rLTUwMC80MCB0ZXh0LXBpbmstMzAwIGZvbnQtc2FucyBmb250LW1lZGl1bSBoaWRkZW4gc206aW5saW5lLWJsb2NrXCI+XG4gICAgICAgICAgICAgICAgSW4gRXZlcnkgTGFuZ3VhZ2VcbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPC9oMT5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtemluYy00MDAgZm9udC1zYW5zXCI+XG4gICAgICAgICAgICAgIFwiV2hhdCBpZiBhIHNpbmdsZSBmbG93ZXIgY291bGQgc2F5ICdJIGxvdmUgeW91JyBpbiA2MCsgbGFuZ3VhZ2VzP1wiXG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBUb3AgUmlnaHQgUXVpY2sgQWN0aW9ucyAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgIHsvKiBHaXRIdWIgRXhwb3J0IEJ1dHRvbiAqL31cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc0dpdEh1Yk1vZGFsT3Blbih0cnVlKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0xLjUgcm91bmRlZC14bCBiZy16aW5jLTkwMCBob3ZlcjpiZy16aW5jLTgwMCBib3JkZXIgYm9yZGVyLXppbmMtNzAwLzgwIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXppbmMtMjAwIGhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1hbGwgc2hhZG93LXNtIGFjdGl2ZTpzY2FsZS05NVwiXG4gICAgICAgICAgICB0aXRsZT1cIkV4cG9ydCByZXBvc2l0b3J5IHRvIEdpdEh1YlwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPEdpdGh1YiBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gc206aW5saW5lXCI+RXhwb3J0IHRvIEdpdEh1Yjwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzQ2FyZE1vZGFsT3Blbih0cnVlKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0xLjUgcm91bmRlZC14bCBiZy1waW5rLTk1MC84MCBob3ZlcjpiZy1waW5rLTkwMCBib3JkZXIgYm9yZGVyLXBpbmstNTAwLzQwIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1waW5rLTIwMCBob3Zlcjp0ZXh0LXdoaXRlIHRyYW5zaXRpb24tYWxsIHNoYWRvdy1zbSBhY3RpdmU6c2NhbGUtOTVcIlxuICAgICAgICAgICAgdGl0bGU9XCJDcmVhdGUgYSBwZXJzb25hbGl6ZWQgZGVkaWNhdGlvbiBjYXJkXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8SGVhcnQgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgZmlsbC1waW5rLTUwMCB0ZXh0LXBpbmstNTAwXCIgLz5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhpZGRlbiBzbTppbmxpbmVcIj5EZWRpY2F0ZTwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzTGFuZ3VhZ2VzT3BlbighaXNMYW5ndWFnZXNPcGVuKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0xLjUgcm91bmRlZC14bCBib3JkZXIgdGV4dC14cyBmb250LW1lZGl1bSB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICBpc0xhbmd1YWdlc09wZW5cbiAgICAgICAgICAgICAgICA/ICdiZy1waW5rLTkwMC82MCBib3JkZXItcGluay01MDAgdGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgICA6ICdiZy16aW5jLTkwMC84MCBib3JkZXItemluYy04MDAgdGV4dC16aW5jLTMwMCBob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICB0aXRsZT1cIkV4cGxvcmUgYWxsIGxhbmd1YWdlc1wiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPEdsb2JlIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtcGluay00MDBcIiAvPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGlkZGVuIHNtOmlubGluZVwiPkxhbmd1YWdlczwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzQ2luZW1hdGljKCFpc0NpbmVtYXRpYyl9XG4gICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMS41IHJvdW5kZWQteGwgYm9yZGVyIHRleHQteHMgZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgIWlzQ2luZW1hdGljXG4gICAgICAgICAgICAgICAgPyAnYmctcGluay05MDAvNjAgYm9yZGVyLXBpbmstNTAwIHRleHQtd2hpdGUnXG4gICAgICAgICAgICAgICAgOiAnYmctemluYy05MDAvODAgYm9yZGVyLXppbmMtODAwIHRleHQtemluYy0zMDAgaG92ZXI6dGV4dC13aGl0ZSdcbiAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgdGl0bGU9XCJUb2dnbGUgYmV0d2VlbiBjaW5lbWF0aWMgcm9tYW5jZSBtb2RlIGFuZCBQeXRob24gSURFIGNvZGluZyBzdHVkaW9cIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxDb2RlMiBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXBpbmstNDAwXCIgLz5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhpZGRlbiBtZDppbmxpbmVcIj5cbiAgICAgICAgICAgICAge2lzQ2luZW1hdGljID8gJ1B5dGhvbiBJREUnIDogJ0NpbmVtYXRpYyd9XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9oZWFkZXI+XG5cbiAgICAgIHsvKiBNYWluIFdvcmtzcGFjZSBBcmVhICovfVxuICAgICAgPG1haW4gY2xhc3NOYW1lPVwicmVsYXRpdmUgei0xMCBmbGV4LTEgZmxleCBmbGV4LWNvbCBwLTIgbWQ6cC00IGdhcC0zIG1heC13LTd4bCBteC1hdXRvIHctZnVsbCBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgey8qIENpbmVtYXRpYyBWaWV3IHZzIENyZWF0aXZlIENvZGluZyBTcGxpdCBWaWV3ICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4taC1bNDQwcHhdIG1kOm1pbi1oLVs1NjBweF0gZ3JpZCBncmlkLWNvbHMtMSBsZzpncmlkLWNvbHMtMTIgZ2FwLTQgaXRlbXMtc3RyZXRjaFwiPlxuICAgICAgICAgIHsvKiBGbG93ZXIgQ2FudmFzIFZpc3VhbGl6ZXIgKi99XG4gICAgICAgICAgPGRpdlxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgcmVsYXRpdmUgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tNTAwIGZsZXggZmxleC1jb2wgJHtcbiAgICAgICAgICAgICAgaXNDaW5lbWF0aWMgPyAnbGc6Y29sLXNwYW4tMTInIDogJ2xnOmNvbC1zcGFuLTcnXG4gICAgICAgICAgICB9IG1pbi1oLVs0MzBweF0gbWQ6bWluLWgtWzU1MHB4XWB9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgey8qIEhlYWRpbmcgb24gQ2FudmFzIGluIENpbmVtYXRpYyBtb2RlICovfVxuICAgICAgICAgICAge2lzQ2luZW1hdGljICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtNCBsZWZ0LTAgcmlnaHQtMCB6LTEwIHRleHQtY2VudGVyIHBvaW50ZXItZXZlbnRzLW5vbmUgcHgtNFwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2NyaXB0IHRleHQtM3hsIG1kOnRleHQtNXhsIHRleHQtcGluay0yMDAgZHJvcC1zaGFkb3ctWzBfMnB4XzE1cHhfcmdiYSgyNDQsMTE0LDE4MiwwLjcpXSBhbmltYXRlLWZsb2F0LWdlbnRsZSBpbmxpbmUtYmxvY2tcIj5cbiAgICAgICAgICAgICAgICAgIHtmbG93ZXJUaXRsZX1cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQteHMgdGV4dC1waW5rLTMwMC84MCB0cmFja2luZy13aWRlc3QgdXBwZXJjYXNlIG10LTAuNVwiPlxuICAgICAgICAgICAgICAgICAgSW4gRXZlcnkgTGFuZ3VhZ2VcbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAge3JlY2lwaWVudE5hbWUgJiYgKFxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1zY3JpcHQgdGV4dC0yeGwgdGV4dC1waW5rLTMwMCBtdC0xIGRyb3Atc2hhZG93LW1kXCI+XG4gICAgICAgICAgICAgICAgICAgIERlZGljYXRlZCB3aXRoIGVuZGxlc3MgYWZmZWN0aW9uIHRvIHtyZWNpcGllbnROYW1lfSDimaVcbiAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHsvKiBUaGUgQW5pbWF0ZWQgQ2FudmFzICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgdy1mdWxsIGgtZnVsbCByZWxhdGl2ZVwiPlxuICAgICAgICAgICAgICA8Um9zZUNhbnZhc1xuICAgICAgICAgICAgICAgIGJsb29tUHJvZ3Jlc3M9e2Jsb29tUHJvZ3Jlc3N9XG4gICAgICAgICAgICAgICAgdGhlbWVJZD17dGhlbWVJZH1cbiAgICAgICAgICAgICAgICByZWNpcGllbnROYW1lPXtyZWNpcGllbnROYW1lfVxuICAgICAgICAgICAgICAgIGZsb3dlclR5cGU9e2Zsb3dlclR5cGV9XG4gICAgICAgICAgICAgICAgaXNDaW5lbWF0aWM9e2lzQ2luZW1hdGljfVxuICAgICAgICAgICAgICAgIG9uU2VsZWN0UGhyYXNlPXsocGhyYXNlKSA9PiBzZXRTZWxlY3RlZFBocmFzZShwaHJhc2UpfVxuICAgICAgICAgICAgICAgIHNlbGVjdGVkUGhyYXNlSWQ9e3NlbGVjdGVkUGhyYXNlPy5pZH1cbiAgICAgICAgICAgICAgICBvbkhvdmVyUGhyYXNlPXsocGhyYXNlKSA9PiBzZXRIb3ZlcmVkUGhyYXNlKHBocmFzZSl9XG4gICAgICAgICAgICAgIC8+XG5cbiAgICAgICAgICAgICAgey8qIEZsb2F0aW5nIFBocmFzZSBDYXJkIE92ZXJsYXkgd2hlbiBob3ZlcmluZyBvciBjbGlja2luZyBhIHBocmFzZSAqL31cbiAgICAgICAgICAgICAge2FjdGl2ZVBocmFzZSAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBib3R0b20tNCByaWdodC00IHotMjAgbWF4LXcteHMgdy1mdWxsIGFuaW1hdGUtZmFkZUluXCI+XG4gICAgICAgICAgICAgICAgICA8UGhyYXNlQ2FyZFxuICAgICAgICAgICAgICAgICAgICBwaHJhc2U9e2FjdGl2ZVBocmFzZX1cbiAgICAgICAgICAgICAgICAgICAgb25DbG9zZT17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkUGhyYXNlKG51bGwpO1xuICAgICAgICAgICAgICAgICAgICAgIHNldEhvdmVyZWRQaHJhc2UobnVsbCk7XG4gICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgIG9uRGVkaWNhdGU9eyhwKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRQaHJhc2UocCk7XG4gICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgIHsvKiBIZWxwZnVsIEhpbnQgYmFubmVyICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGJvdHRvbS0yIGxlZnQtNCB6LTEwIHBvaW50ZXItZXZlbnRzLW5vbmUgdGV4dC1bMTFweF0gdGV4dC16aW5jLTQwMCBmb250LW1vbm8gYmctYmxhY2svNzAgcHgtMi41IHB5LTEgcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItemluYy04MDAvODAgYmFja2Ryb3AtYmx1ci1tZFwiPlxuICAgICAgICAgICAgICAgIOKcpiBIb3ZlciBvciBjbGljayBhbnkgcGhyYXNlIHRvIGhlYXIgcHJvbnVuY2lhdGlvbiAmIGN1bHR1cmFsIGxvcmVcbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBQeXRob24gQ3JlYXRpdmUgQ29kZSBTdHVkaW8gKFNwbGl0IG1vZGUpICovfVxuICAgICAgICAgIHshaXNDaW5lbWF0aWMgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZzpjb2wtc3Bhbi01IGZsZXggZmxleC1jb2wgbWluLWgtWzQ0MHB4XSBtZDptaW4taC1bNTYwcHhdXCI+XG4gICAgICAgICAgICAgIDxDb2RlVmlld2VyXG4gICAgICAgICAgICAgICAgY29uZmlnPXtweXRob25Db25maWd9XG4gICAgICAgICAgICAgICAgb25Db25maWdDaGFuZ2U9eyhuZXdDZmcpID0+IHtcbiAgICAgICAgICAgICAgICAgIHNldFB5dGhvbkNvbmZpZyhuZXdDZmcpO1xuICAgICAgICAgICAgICAgICAgaWYgKG5ld0NmZy5yZWNpcGllbnROYW1lICE9PSByZWNpcGllbnROYW1lKSB7XG4gICAgICAgICAgICAgICAgICAgIHNldFJlY2lwaWVudE5hbWUobmV3Q2ZnLnJlY2lwaWVudE5hbWUpO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgb25SdW5Db2RlPXtoYW5kbGVSdW5Db2RlfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG5cblxuICAgICAgICB7LyogR2xvYmFsIENvbnRyb2xzIFRvb2xiYXIgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgei0yMFwiPlxuICAgICAgICAgIDxSb3NlQ29udHJvbHNcbiAgICAgICAgICAgIGJsb29tUHJvZ3Jlc3M9e2Jsb29tUHJvZ3Jlc3N9XG4gICAgICAgICAgICBvblByb2dyZXNzQ2hhbmdlPXsodmFsKSA9PiB7XG4gICAgICAgICAgICAgIHNldElzUGxheWluZyhmYWxzZSk7XG4gICAgICAgICAgICAgIHNldEJsb29tUHJvZ3Jlc3ModmFsKTtcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgICBpc1BsYXlpbmc9e2lzUGxheWluZ31cbiAgICAgICAgICAgIG9uVG9nZ2xlUGxheT17aGFuZGxlVG9nZ2xlUGxheX1cbiAgICAgICAgICAgIG9uUmVzZXQ9e2hhbmRsZVJlc2V0fVxuICAgICAgICAgICAgZmxvd2VyVHlwZT17Zmxvd2VyVHlwZX1cbiAgICAgICAgICAgIG9uRmxvd2VyVHlwZUNoYW5nZT17KHR5cGUpID0+IHtcbiAgICAgICAgICAgICAgc2V0Rmxvd2VyVHlwZSh0eXBlKTtcbiAgICAgICAgICAgICAgc2V0Qmxvb21Qcm9ncmVzcygxLjApO1xuICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIHRoZW1lSWQ9e3RoZW1lSWR9XG4gICAgICAgICAgICBvblRoZW1lQ2hhbmdlPXtzZXRUaGVtZUlkfVxuICAgICAgICAgICAgaXNDaW5lbWF0aWM9e2lzQ2luZW1hdGljfVxuICAgICAgICAgICAgb25Ub2dnbGVDaW5lbWF0aWM9eygpID0+IHNldElzQ2luZW1hdGljKCFpc0NpbmVtYXRpYyl9XG4gICAgICAgICAgICBvbk9wZW5EZWRpY2F0aW9uPXsoKSA9PiBzZXRJc0NhcmRNb2RhbE9wZW4odHJ1ZSl9XG4gICAgICAgICAgICBvblRvZ2dsZUxhbmd1YWdlcz17KCkgPT4gc2V0SXNMYW5ndWFnZXNPcGVuKCFpc0xhbmd1YWdlc09wZW4pfVxuICAgICAgICAgICAgaXNMYW5ndWFnZXNPcGVuPXtpc0xhbmd1YWdlc09wZW59XG4gICAgICAgICAgICBvbk9wZW5HaXRIdWJFeHBvcnQ9eygpID0+IHNldElzR2l0SHViTW9kYWxPcGVuKHRydWUpfVxuICAgICAgICAgICAgcmVjaXBpZW50TmFtZT17cmVjaXBpZW50TmFtZX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvbWFpbj5cblxuICAgICAgey8qIFNsaWRlLW91dCBMYW5ndWFnZXMgRXhwbG9yZXIgRHJhd2VyICovfVxuICAgICAge2lzTGFuZ3VhZ2VzT3BlbiAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQteS0wIHJpZ2h0LTAgei00MCB3LWZ1bGwgbWF4LXctbWQgYmctemluYy05NTAvOTUgYm9yZGVyLWwgYm9yZGVyLXBpbmstOTAwLzUwIHNoYWRvdy0yeGwgcC00IGZsZXggZmxleC1jb2wgYW5pbWF0ZS1zbGlkZUxlZnQgYmFja2Ryb3AtYmx1ci0yeGxcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwYi0zIG1iLTIgYm9yZGVyLWIgYm9yZGVyLXppbmMtODAwXCI+XG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1kaXNwbGF5IGZvbnQtYm9sZCB0ZXh0LXBpbmstMjAwIHRleHQtYmFzZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICA8R2xvYmUgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXBpbmstNDAwXCIgLz5cbiAgICAgICAgICAgICAgTXVsdGlsaW5ndWFsIEZsb3dlciBEaXJlY3RvcnlcbiAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzTGFuZ3VhZ2VzT3BlbihmYWxzZSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHJvdW5kZWQtbGcgdGV4dC16aW5jLTQwMCBob3Zlcjp0ZXh0LXdoaXRlIGhvdmVyOmJnLXppbmMtODAwXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAg4pyVXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgIDxMYW5ndWFnZUV4cGxvcmVyXG4gICAgICAgICAgICAgIG9uU2VsZWN0UGhyYXNlPXsocGhyYXNlKSA9PiB7XG4gICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRQaHJhc2UocGhyYXNlKTtcbiAgICAgICAgICAgICAgICBzZXRIb3ZlcmVkUGhyYXNlKHBocmFzZSk7XG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgIHNlbGVjdGVkUGhyYXNlSWQ9e3NlbGVjdGVkUGhyYXNlPy5pZH1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIExvdmUgQ2FyZCAmIERlZGljYXRpb24gTW9kYWwgKi99XG4gICAgICA8Q2FyZEV4cG9ydE1vZGFsXG4gICAgICAgIGlzT3Blbj17aXNDYXJkTW9kYWxPcGVufVxuICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRJc0NhcmRNb2RhbE9wZW4oZmFsc2UpfVxuICAgICAgICByZWNpcGllbnROYW1lPXtyZWNpcGllbnROYW1lfVxuICAgICAgICBvblVwZGF0ZVJlY2lwaWVudD17c2V0UmVjaXBpZW50TmFtZX1cbiAgICAgICAgdGhlbWVJZD17dGhlbWVJZH1cbiAgICAgICAgZmxvd2VyVHlwZT17Zmxvd2VyVHlwZSA9PT0gJ3BpbmtfbGlseScgPyAnbGlseScgOiAncm9zZSd9XG4gICAgICAvPlxuXG4gICAgICB7LyogR2l0SHViIFJlcG9zaXRvcnkgRXhwb3J0ZXIgTW9kYWwgKi99XG4gICAgICA8R2l0SHViRXhwb3J0TW9kYWxcbiAgICAgICAgaXNPcGVuPXtpc0dpdEh1Yk1vZGFsT3Blbn1cbiAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0SXNHaXRIdWJNb2RhbE9wZW4oZmFsc2UpfVxuICAgICAgICByZWNpcGllbnROYW1lPXtyZWNpcGllbnROYW1lfVxuICAgICAgLz5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdfQ==