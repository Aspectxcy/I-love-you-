const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport3_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=3ba6436c";
import { Play, Pause, RotateCcw, Heart, Code2, Maximize2, BookOpen, Github } from "/node_modules/.vite/deps/lucide-react.js?v=3ba6436c";
import { AVAILABLE_FLOWERS } from "/src/utils/flowerShapes.ts";
var _jsxFileName = "/app/applet/src/components/RoseControls.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3ba6436c";
export const RoseControls = ({ bloomProgress, onProgressChange, isPlaying, onTogglePlay, onReset, flowerType, onFlowerTypeChange, themeId, onThemeChange, isCinematic, onToggleCinematic, onOpenDedication, onToggleLanguages, isLanguagesOpen, onOpenGitHubExport, recipientName }) => {
	const currentFlower = AVAILABLE_FLOWERS.find((f) => f.id === flowerType) || AVAILABLE_FLOWERS[0];
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "w-full max-w-6xl mx-auto px-4 py-3 bg-zinc-950/85 backdrop-blur-xl border border-zinc-800/80 rounded-2xl shadow-2xl text-rose-50 flex flex-col md:flex-row items-center justify-between gap-4",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center gap-3 w-full md:w-auto",
			children: [
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: onTogglePlay,
					className: "p-2.5 rounded-xl bg-pink-600 hover:bg-pink-500 text-white shadow-md shadow-pink-950 transition-all active:scale-95 shrink-0",
					title: isPlaying ? "Pause Bloom" : "Play Bloom Animation",
					children: isPlaying ? /* @__PURE__ */ _jsxDEV(Pause, { className: "w-4 h-4 fill-current" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 13
					}, this) : /* @__PURE__ */ _jsxDEV(Play, { className: "w-4 h-4 fill-current ml-0.5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 65,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 57,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: onReset,
					className: "p-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-white border border-zinc-800 transition-colors shrink-0",
					title: "Restart Bloom from Seed",
					children: /* @__PURE__ */ _jsxDEV(RotateCcw, { className: "w-4 h-4" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 74,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 69,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex-1 flex items-center gap-2 min-w-[140px] md:min-w-[180px]",
					children: [
						/* @__PURE__ */ _jsxDEV("span", {
							className: "text-[10px] font-mono text-zinc-400",
							children: [Math.round(bloomProgress * 100), "%"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 79,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("input", {
							type: "range",
							min: "0",
							max: "1",
							step: "0.005",
							value: bloomProgress,
							onChange: (e) => onProgressChange(parseFloat(e.target.value)),
							className: "w-full accent-pink-500 cursor-pointer h-1.5 bg-zinc-800 rounded-lg appearance-none"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 82,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							className: "text-[11px] text-pink-300 font-medium whitespace-nowrap",
							children: bloomProgress < .3 ? "Sprouting" : bloomProgress < .6 ? "Foliage" : bloomProgress < .95 ? "Blooming" : `${currentFlower.name} ${currentFlower.emoji}`
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 91,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 78,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 56,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center gap-2 flex-wrap justify-center w-full md:w-auto",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center bg-zinc-900/90 p-1 rounded-xl border border-zinc-800 overflow-x-auto max-w-full",
					children: AVAILABLE_FLOWERS.map((f) => /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => onFlowerTypeChange(f.id),
						className: `flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${flowerType === f.id ? "bg-gradient-to-r from-pink-600 to-rose-600 text-white shadow-md" : "text-zinc-400 hover:text-zinc-200"}`,
						title: f.description,
						children: [/* @__PURE__ */ _jsxDEV("span", { children: f.emoji }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 118,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "hidden sm:inline",
							children: f.name
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 119,
							columnNumber: 15
						}, this)]
					}, f.id, true, {
						fileName: _jsxFileName,
						lineNumber: 108,
						columnNumber: 13
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 106,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: onToggleCinematic,
					className: `flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-medium transition-all ${!isCinematic ? "bg-pink-950/70 border-pink-500/60 text-pink-200 shadow-sm" : "bg-zinc-900/80 border-zinc-800 text-zinc-400 hover:text-white"}`,
					title: "Switch between Cinematic View and Python IDE View",
					children: isCinematic ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Code2, { className: "w-3.5 h-3.5 text-pink-400" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 136,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Python Code" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 137,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 135,
						columnNumber: 13
					}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Maximize2, { className: "w-3.5 h-3.5 text-pink-400" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 141,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Cinematic" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 142,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 140,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 125,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: onToggleLanguages,
					className: `flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-medium transition-all ${isLanguagesOpen ? "bg-pink-950/70 border-pink-500/60 text-pink-200 shadow-sm" : "bg-zinc-900/80 border-zinc-800 text-zinc-400 hover:text-white"}`,
					title: "Browse all 60+ Languages",
					children: [/* @__PURE__ */ _jsxDEV(BookOpen, { className: "w-3.5 h-3.5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 157,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "hidden sm:inline",
						children: "Languages"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 158,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 148,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: onOpenDedication,
					className: "flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-500 hover:to-rose-500 text-white text-xs font-semibold shadow-lg shadow-pink-950 active:scale-95 transition-all",
					children: [/* @__PURE__ */ _jsxDEV(Heart, { className: "w-3.5 h-3.5 fill-current" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 166,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: recipientName ? `For ${recipientName}` : "Dedicate" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 167,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 162,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: onOpenGitHubExport,
					className: "flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700/80 text-xs font-semibold text-zinc-200 hover:text-white transition-all shadow-sm active:scale-95",
					title: "Export complete project and Python scripts to GitHub",
					children: [/* @__PURE__ */ _jsxDEV(Github, { className: "w-3.5 h-3.5 text-white" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 176,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Export to GitHub" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 177,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 171,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 104,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 54,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQ0UsTUFDQSxPQUNBLFdBQ0EsT0FDQSxPQUNBLFdBQ0EsVUFDQSxjQUNLO0FBQ1AsU0FBUyx5QkFBcUM7OztBQXFCOUMsT0FBTyxNQUFNLGdCQUE2QyxFQUN4RCxlQUNBLGtCQUNBLFdBQ0EsY0FDQSxTQUNBLFlBQ0Esb0JBQ0EsU0FDQSxlQUNBLGFBQ0EsbUJBQ0Esa0JBQ0EsbUJBQ0EsaUJBQ0Esb0JBQ0Esb0JBQ0k7Q0FDSixNQUFNLGdCQUFnQixrQkFBa0IsTUFBTSxNQUFNLEVBQUUsT0FBTyxVQUFVLEtBQUssa0JBQWtCO0NBRTlGLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUVFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDRSx3QkFBQyxVQUFEO0tBQ0UsU0FBUztLQUNULFdBQVU7S0FDVixPQUFPLFlBQVksZ0JBQWdCO2VBRWxDLFlBQ0Msd0JBQUMsT0FBRCxFQUFPLFdBQVUsdUJBQXdCOzs7O2dCQUV6Qyx3QkFBQyxNQUFELEVBQU0sV0FBVSw4QkFBK0I7Ozs7O0lBRTNDOzs7OztJQUVSLHdCQUFDLFVBQUQ7S0FDRSxTQUFTO0tBQ1QsV0FBVTtLQUNWLE9BQU07ZUFFTix3QkFBQyxXQUFELEVBQVcsV0FBVSxVQUFXOzs7OztJQUMxQjs7Ozs7SUFHUix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWhCLENBQ0csS0FBSyxNQUFNLGdCQUFnQixHQUFHLEdBQUUsR0FDN0I7Ozs7OztNQUNOLHdCQUFDLFNBQUQ7T0FDRSxNQUFLO09BQ0wsS0FBSTtPQUNKLEtBQUk7T0FDSixNQUFLO09BQ0wsT0FBTztPQUNQLFdBQVcsTUFBTSxpQkFBaUIsV0FBVyxFQUFFLE9BQU8sS0FBSyxDQUFDO09BQzVELFdBQVU7TUFDWDs7Ozs7TUFDRCx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFDYixnQkFBZ0IsS0FDYixjQUNBLGdCQUFnQixLQUNoQixZQUNBLGdCQUFnQixNQUNoQixhQUNBLEdBQUcsY0FBYyxLQUFLLEdBQUcsY0FBYztNQUN2Qzs7Ozs7S0FDSDs7Ozs7O0dBQ0Y7Ozs7O1lBR0wsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUVFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ1osa0JBQWtCLEtBQUssTUFDdEIsd0JBQUMsVUFBRDtNQUVFLGVBQWUsbUJBQW1CLEVBQUUsRUFBRTtNQUN0QyxXQUFXLDJHQUNULGVBQWUsRUFBRSxLQUNiLG9FQUNBO01BRU4sT0FBTyxFQUFFO2dCQVJYLENBVUUsd0JBQUMsUUFBRCxZQUFPLEVBQUUsTUFBWTs7OztnQkFDckIsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQW9CLEVBQUU7TUFBVzs7OztjQUMzQztRQVhELEVBQUU7Ozs7WUFXRCxDQUNUO0lBQ0U7Ozs7O0lBR0wsd0JBQUMsVUFBRDtLQUNFLFNBQVM7S0FDVCxXQUFXLDhGQUNULENBQUMsY0FDRyw4REFDQTtLQUVOLE9BQU07ZUFFTCxjQUNDLGdEQUNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLDRCQUE2Qjs7OztlQUM5Qyx3QkFBQyxRQUFELFlBQU0sY0FBaUI7Ozs7YUFDdkI7Ozs7Z0JBRUYsZ0RBQ0Usd0JBQUMsV0FBRCxFQUFXLFdBQVUsNEJBQTZCOzs7O2VBQ2xELHdCQUFDLFFBQUQsWUFBTSxZQUFlOzs7O2FBQ3JCOzs7OztJQUVFOzs7OztJQUdSLHdCQUFDLFVBQUQ7S0FDRSxTQUFTO0tBQ1QsV0FBVyw4RkFDVCxrQkFDSSw4REFDQTtLQUVOLE9BQU07ZUFQUixDQVNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLGNBQWU7Ozs7ZUFDbkMsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQW1CO0tBQWU7Ozs7YUFDNUM7Ozs7OztJQUdSLHdCQUFDLFVBQUQ7S0FDRSxTQUFTO0tBQ1QsV0FBVTtlQUZaLENBSUUsd0JBQUMsT0FBRCxFQUFPLFdBQVUsMkJBQTRCOzs7O2VBQzdDLHdCQUFDLFFBQUQsWUFBTyxnQkFBZ0IsT0FBTyxrQkFBa0IsV0FBaUI7Ozs7YUFDM0Q7Ozs7OztJQUdSLHdCQUFDLFVBQUQ7S0FDRSxTQUFTO0tBQ1QsV0FBVTtLQUNWLE9BQU07ZUFIUixDQUtFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLHlCQUEwQjs7OztlQUM1Qyx3QkFBQyxRQUFELFlBQU0sbUJBQXNCOzs7O2FBQ3RCOzs7Ozs7R0FDTDs7Ozs7VUFDRjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUm9zZUNvbnRyb2xzLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHtcbiAgUGxheSxcbiAgUGF1c2UsXG4gIFJvdGF0ZUNjdyxcbiAgSGVhcnQsXG4gIENvZGUyLFxuICBNYXhpbWl6ZTIsXG4gIEJvb2tPcGVuLFxuICBHaXRodWIsXG59IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyBBVkFJTEFCTEVfRkxPV0VSUywgRmxvd2VyVHlwZSB9IGZyb20gJy4uL3V0aWxzL2Zsb3dlclNoYXBlcyc7XG5cbmludGVyZmFjZSBSb3NlQ29udHJvbHNQcm9wcyB7XG4gIGJsb29tUHJvZ3Jlc3M6IG51bWJlcjtcbiAgb25Qcm9ncmVzc0NoYW5nZTogKHZhbDogbnVtYmVyKSA9PiB2b2lkO1xuICBpc1BsYXlpbmc6IGJvb2xlYW47XG4gIG9uVG9nZ2xlUGxheTogKCkgPT4gdm9pZDtcbiAgb25SZXNldDogKCkgPT4gdm9pZDtcbiAgZmxvd2VyVHlwZTogRmxvd2VyVHlwZTtcbiAgb25GbG93ZXJUeXBlQ2hhbmdlOiAodHlwZTogRmxvd2VyVHlwZSkgPT4gdm9pZDtcbiAgdGhlbWVJZDogc3RyaW5nO1xuICBvblRoZW1lQ2hhbmdlOiAoaWQ6IHN0cmluZykgPT4gdm9pZDtcbiAgaXNDaW5lbWF0aWM6IGJvb2xlYW47XG4gIG9uVG9nZ2xlQ2luZW1hdGljOiAoKSA9PiB2b2lkO1xuICBvbk9wZW5EZWRpY2F0aW9uOiAoKSA9PiB2b2lkO1xuICBvblRvZ2dsZUxhbmd1YWdlczogKCkgPT4gdm9pZDtcbiAgaXNMYW5ndWFnZXNPcGVuOiBib29sZWFuO1xuICBvbk9wZW5HaXRIdWJFeHBvcnQ6ICgpID0+IHZvaWQ7XG4gIHJlY2lwaWVudE5hbWU6IHN0cmluZztcbn1cblxuZXhwb3J0IGNvbnN0IFJvc2VDb250cm9sczogUmVhY3QuRkM8Um9zZUNvbnRyb2xzUHJvcHM+ID0gKHtcbiAgYmxvb21Qcm9ncmVzcyxcbiAgb25Qcm9ncmVzc0NoYW5nZSxcbiAgaXNQbGF5aW5nLFxuICBvblRvZ2dsZVBsYXksXG4gIG9uUmVzZXQsXG4gIGZsb3dlclR5cGUsXG4gIG9uRmxvd2VyVHlwZUNoYW5nZSxcbiAgdGhlbWVJZCxcbiAgb25UaGVtZUNoYW5nZSxcbiAgaXNDaW5lbWF0aWMsXG4gIG9uVG9nZ2xlQ2luZW1hdGljLFxuICBvbk9wZW5EZWRpY2F0aW9uLFxuICBvblRvZ2dsZUxhbmd1YWdlcyxcbiAgaXNMYW5ndWFnZXNPcGVuLFxuICBvbk9wZW5HaXRIdWJFeHBvcnQsXG4gIHJlY2lwaWVudE5hbWUsXG59KSA9PiB7XG4gIGNvbnN0IGN1cnJlbnRGbG93ZXIgPSBBVkFJTEFCTEVfRkxPV0VSUy5maW5kKChmKSA9PiBmLmlkID09PSBmbG93ZXJUeXBlKSB8fCBBVkFJTEFCTEVfRkxPV0VSU1swXTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG1heC13LTZ4bCBteC1hdXRvIHB4LTQgcHktMyBiZy16aW5jLTk1MC84NSBiYWNrZHJvcC1ibHVyLXhsIGJvcmRlciBib3JkZXItemluYy04MDAvODAgcm91bmRlZC0yeGwgc2hhZG93LTJ4bCB0ZXh0LXJvc2UtNTAgZmxleCBmbGV4LWNvbCBtZDpmbGV4LXJvdyBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XG4gICAgICB7LyogUGxheWJhY2sgJiBTY3J1YiBUaW1lbGluZSAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgdy1mdWxsIG1kOnctYXV0b1wiPlxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgb25DbGljaz17b25Ub2dnbGVQbGF5fVxuICAgICAgICAgIGNsYXNzTmFtZT1cInAtMi41IHJvdW5kZWQteGwgYmctcGluay02MDAgaG92ZXI6YmctcGluay01MDAgdGV4dC13aGl0ZSBzaGFkb3ctbWQgc2hhZG93LXBpbmstOTUwIHRyYW5zaXRpb24tYWxsIGFjdGl2ZTpzY2FsZS05NSBzaHJpbmstMFwiXG4gICAgICAgICAgdGl0bGU9e2lzUGxheWluZyA/ICdQYXVzZSBCbG9vbScgOiAnUGxheSBCbG9vbSBBbmltYXRpb24nfVxuICAgICAgICA+XG4gICAgICAgICAge2lzUGxheWluZyA/IChcbiAgICAgICAgICAgIDxQYXVzZSBjbGFzc05hbWU9XCJ3LTQgaC00IGZpbGwtY3VycmVudFwiIC8+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDxQbGF5IGNsYXNzTmFtZT1cInctNCBoLTQgZmlsbC1jdXJyZW50IG1sLTAuNVwiIC8+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9e29uUmVzZXR9XG4gICAgICAgICAgY2xhc3NOYW1lPVwicC0yIHJvdW5kZWQteGwgYmctemluYy05MDAgaG92ZXI6YmctemluYy04MDAgdGV4dC16aW5jLTMwMCBob3Zlcjp0ZXh0LXdoaXRlIGJvcmRlciBib3JkZXItemluYy04MDAgdHJhbnNpdGlvbi1jb2xvcnMgc2hyaW5rLTBcIlxuICAgICAgICAgIHRpdGxlPVwiUmVzdGFydCBCbG9vbSBmcm9tIFNlZWRcIlxuICAgICAgICA+XG4gICAgICAgICAgPFJvdGF0ZUNjdyBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgey8qIFRpbWVsaW5lIFNsaWRlciAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWluLXctWzE0MHB4XSBtZDptaW4tdy1bMTgwcHhdXCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1tb25vIHRleHQtemluYy00MDBcIj5cbiAgICAgICAgICAgIHtNYXRoLnJvdW5kKGJsb29tUHJvZ3Jlc3MgKiAxMDApfSVcbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICB0eXBlPVwicmFuZ2VcIlxuICAgICAgICAgICAgbWluPVwiMFwiXG4gICAgICAgICAgICBtYXg9XCIxXCJcbiAgICAgICAgICAgIHN0ZXA9XCIwLjAwNVwiXG4gICAgICAgICAgICB2YWx1ZT17Ymxvb21Qcm9ncmVzc31cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gb25Qcm9ncmVzc0NoYW5nZShwYXJzZUZsb2F0KGUudGFyZ2V0LnZhbHVlKSl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYWNjZW50LXBpbmstNTAwIGN1cnNvci1wb2ludGVyIGgtMS41IGJnLXppbmMtODAwIHJvdW5kZWQtbGcgYXBwZWFyYW5jZS1ub25lXCJcbiAgICAgICAgICAvPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtcGluay0zMDAgZm9udC1tZWRpdW0gd2hpdGVzcGFjZS1ub3dyYXBcIj5cbiAgICAgICAgICAgIHtibG9vbVByb2dyZXNzIDwgMC4zXG4gICAgICAgICAgICAgID8gJ1Nwcm91dGluZydcbiAgICAgICAgICAgICAgOiBibG9vbVByb2dyZXNzIDwgMC42XG4gICAgICAgICAgICAgID8gJ0ZvbGlhZ2UnXG4gICAgICAgICAgICAgIDogYmxvb21Qcm9ncmVzcyA8IDAuOTVcbiAgICAgICAgICAgICAgPyAnQmxvb21pbmcnXG4gICAgICAgICAgICAgIDogYCR7Y3VycmVudEZsb3dlci5uYW1lfSAke2N1cnJlbnRGbG93ZXIuZW1vaml9YH1cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBGbG93ZXIgVHlwZSAmIEFjdGlvbiBTd2l0Y2hlcnMgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGZsZXgtd3JhcCBqdXN0aWZ5LWNlbnRlciB3LWZ1bGwgbWQ6dy1hdXRvXCI+XG4gICAgICAgIHsvKiBGbG93ZXIgU2VsZWN0aW9uIERyb3Bkb3duIC8gUGlsbHMgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgYmctemluYy05MDAvOTAgcC0xIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci16aW5jLTgwMCBvdmVyZmxvdy14LWF1dG8gbWF4LXctZnVsbFwiPlxuICAgICAgICAgIHtBVkFJTEFCTEVfRkxPV0VSUy5tYXAoKGYpID0+IChcbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAga2V5PXtmLmlkfVxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbkZsb3dlclR5cGVDaGFuZ2UoZi5pZCl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMi41IHB5LTEgcm91bmRlZC1sZyB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgd2hpdGVzcGFjZS1ub3dyYXAgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICBmbG93ZXJUeXBlID09PSBmLmlkXG4gICAgICAgICAgICAgICAgICA/ICdiZy1ncmFkaWVudC10by1yIGZyb20tcGluay02MDAgdG8tcm9zZS02MDAgdGV4dC13aGl0ZSBzaGFkb3ctbWQnXG4gICAgICAgICAgICAgICAgICA6ICd0ZXh0LXppbmMtNDAwIGhvdmVyOnRleHQtemluYy0yMDAnXG4gICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICB0aXRsZT17Zi5kZXNjcmlwdGlvbn1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPHNwYW4+e2YuZW1vaml9PC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gc206aW5saW5lXCI+e2YubmFtZX08L3NwYW4+XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFZpZXcgTW9kZSBUb2dnbGU6IENpbmVtYXRpYyB2cyBJREUgQ29kZSBNb2RlICovfVxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgb25DbGljaz17b25Ub2dnbGVDaW5lbWF0aWN9XG4gICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTEuNSByb3VuZGVkLXhsIGJvcmRlciB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgICAhaXNDaW5lbWF0aWNcbiAgICAgICAgICAgICAgPyAnYmctcGluay05NTAvNzAgYm9yZGVyLXBpbmstNTAwLzYwIHRleHQtcGluay0yMDAgc2hhZG93LXNtJ1xuICAgICAgICAgICAgICA6ICdiZy16aW5jLTkwMC84MCBib3JkZXItemluYy04MDAgdGV4dC16aW5jLTQwMCBob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgIH1gfVxuICAgICAgICAgIHRpdGxlPVwiU3dpdGNoIGJldHdlZW4gQ2luZW1hdGljIFZpZXcgYW5kIFB5dGhvbiBJREUgVmlld1wiXG4gICAgICAgID5cbiAgICAgICAgICB7aXNDaW5lbWF0aWMgPyAoXG4gICAgICAgICAgICA8PlxuICAgICAgICAgICAgICA8Q29kZTIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1waW5rLTQwMFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPlB5dGhvbiBDb2RlPC9zcGFuPlxuICAgICAgICAgICAgPC8+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgIDxNYXhpbWl6ZTIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1waW5rLTQwMFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPkNpbmVtYXRpYzwvc3Bhbj5cbiAgICAgICAgICAgIDwvPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgIHsvKiBMYW5ndWFnZXMgRHJhd2VyIFRvZ2dsZSAqL31cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9e29uVG9nZ2xlTGFuZ3VhZ2VzfVxuICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0xLjUgcm91bmRlZC14bCBib3JkZXIgdGV4dC14cyBmb250LW1lZGl1bSB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgaXNMYW5ndWFnZXNPcGVuXG4gICAgICAgICAgICAgID8gJ2JnLXBpbmstOTUwLzcwIGJvcmRlci1waW5rLTUwMC82MCB0ZXh0LXBpbmstMjAwIHNoYWRvdy1zbSdcbiAgICAgICAgICAgICAgOiAnYmctemluYy05MDAvODAgYm9yZGVyLXppbmMtODAwIHRleHQtemluYy00MDAgaG92ZXI6dGV4dC13aGl0ZSdcbiAgICAgICAgICB9YH1cbiAgICAgICAgICB0aXRsZT1cIkJyb3dzZSBhbGwgNjArIExhbmd1YWdlc1wiXG4gICAgICAgID5cbiAgICAgICAgICA8Qm9va09wZW4gY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhpZGRlbiBzbTppbmxpbmVcIj5MYW5ndWFnZXM8L3NwYW4+XG4gICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgIHsvKiBEZWRpY2F0ZSBCdXR0b24gKi99XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBvbkNsaWNrPXtvbk9wZW5EZWRpY2F0aW9ufVxuICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMy41IHB5LTEuNSByb3VuZGVkLXhsIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1waW5rLTYwMCB0by1yb3NlLTYwMCBob3Zlcjpmcm9tLXBpbmstNTAwIGhvdmVyOnRvLXJvc2UtNTAwIHRleHQtd2hpdGUgdGV4dC14cyBmb250LXNlbWlib2xkIHNoYWRvdy1sZyBzaGFkb3ctcGluay05NTAgYWN0aXZlOnNjYWxlLTk1IHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxIZWFydCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSBmaWxsLWN1cnJlbnRcIiAvPlxuICAgICAgICAgIDxzcGFuPntyZWNpcGllbnROYW1lID8gYEZvciAke3JlY2lwaWVudE5hbWV9YCA6ICdEZWRpY2F0ZSd9PC9zcGFuPlxuICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICB7LyogRXhwb3J0IG9uIEdpdEh1YiBCdXR0b24gKi99XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBvbkNsaWNrPXtvbk9wZW5HaXRIdWJFeHBvcnR9XG4gICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTEuNSByb3VuZGVkLXhsIGJnLXppbmMtOTAwIGhvdmVyOmJnLXppbmMtODAwIGJvcmRlciBib3JkZXItemluYy03MDAvODAgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtemluYy0yMDAgaG92ZXI6dGV4dC13aGl0ZSB0cmFuc2l0aW9uLWFsbCBzaGFkb3ctc20gYWN0aXZlOnNjYWxlLTk1XCJcbiAgICAgICAgICB0aXRsZT1cIkV4cG9ydCBjb21wbGV0ZSBwcm9qZWN0IGFuZCBQeXRob24gc2NyaXB0cyB0byBHaXRIdWJcIlxuICAgICAgICA+XG4gICAgICAgICAgPEdpdGh1YiBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXdoaXRlXCIgLz5cbiAgICAgICAgICA8c3Bhbj5FeHBvcnQgdG8gR2l0SHViPC9zcGFuPlxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==