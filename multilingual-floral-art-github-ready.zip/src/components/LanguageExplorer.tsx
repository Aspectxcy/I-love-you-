const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useMemo = __vite__cjsImport0_react["useMemo"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=3ba6436c";
import { LOVE_PHRASES } from "/src/data/languages.ts";
import { Search, Globe, Volume2, Heart } from "/node_modules/.vite/deps/lucide-react.js?v=3ba6436c";
var _jsxFileName = "/app/applet/src/components/LanguageExplorer.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3ba6436c";
export const LanguageExplorer = ({ onSelectPhrase, selectedPhraseId }) => {
	const [searchQuery, setSearchQuery] = useState("");
	const [selectedRegion, setSelectedRegion] = useState("all");
	const [speakingId, setSpeakingId] = useState(null);
	const regions = [
		"all",
		"Europe",
		"Asia",
		"Americas",
		"Africa",
		"Middle East",
		"Oceania"
	];
	const filteredPhrases = useMemo(() => {
		return LOVE_PHRASES.filter((p) => {
			const matchesSearch = p.phrase.toLowerCase().includes(searchQuery.toLowerCase()) || p.language.toLowerCase().includes(searchQuery.toLowerCase()) || p.native.toLowerCase().includes(searchQuery.toLowerCase()) || p.pronunciation.toLowerCase().includes(searchQuery.toLowerCase());
			const matchesRegion = selectedRegion === "all" || p.region === selectedRegion;
			return matchesSearch && matchesRegion;
		});
	}, [searchQuery, selectedRegion]);
	const handleSpeak = (p, e) => {
		e.stopPropagation();
		if (!("speechSynthesis" in window)) return;
		window.speechSynthesis.cancel();
		const utterance = new SpeechSynthesisUtterance(p.phrase);
		utterance.rate = .85;
		setSpeakingId(p.id);
		utterance.onend = () => setSpeakingId(null);
		utterance.onerror = () => setSpeakingId(null);
		window.speechSynthesis.speak(utterance);
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex flex-col h-full bg-[#0d070b]/90 border border-rose-900/30 rounded-2xl p-4 overflow-hidden backdrop-blur-xl",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center justify-between gap-2 mb-3",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV(Globe, { className: "w-4 h-4 text-rose-400" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("h3", {
						className: "text-sm font-semibold text-rose-200",
						children: [
							"Languages of Love (",
							filteredPhrases.length,
							")"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 55,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 53,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "text-[11px] text-zinc-400 font-mono",
					children: "Click any to spotlight on rose"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 59,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 52,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "space-y-2 mb-3",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "relative",
					children: [/* @__PURE__ */ _jsxDEV(Search, { className: "w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 67,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						type: "text",
						placeholder: "Search language, phrase, script, or pronunciation...",
						value: searchQuery,
						onChange: (e) => setSearchQuery(e.target.value),
						className: "w-full pl-9 pr-3 py-1.5 rounded-xl bg-zinc-900/90 border border-rose-900/40 text-xs text-rose-100 placeholder-zinc-500 focus:outline-none focus:border-rose-500"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 68,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 66,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-[11px]",
					children: regions.map((region) => /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setSelectedRegion(region),
						className: `px-2.5 py-1 rounded-full capitalize whitespace-nowrap transition-all ${selectedRegion === region ? "bg-rose-600 text-white font-medium shadow-sm" : "bg-zinc-900/60 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800"}`,
						children: region
					}, region, false, {
						fileName: _jsxFileName,
						lineNumber: 80,
						columnNumber: 13
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 78,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 65,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex-1 overflow-y-auto space-y-2 pr-1 custom-scrollbar",
				children: filteredPhrases.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
					className: "text-center py-10 text-xs text-zinc-500",
					children: [
						"No language matches \"",
						searchQuery,
						"\""
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 98,
					columnNumber: 11
				}, this) : filteredPhrases.map((p) => {
					const isSelected = selectedPhraseId === p.id;
					return /* @__PURE__ */ _jsxDEV("div", {
						onClick: () => onSelectPhrase(p),
						className: `group flex items-center justify-between p-2.5 rounded-xl border transition-all cursor-pointer ${isSelected ? "bg-rose-950/70 border-rose-500 shadow-md shadow-rose-950/40" : "bg-zinc-900/40 border-zinc-800/80 hover:bg-zinc-900/80 hover:border-rose-900/50"}`,
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2.5 min-w-0",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xl select-none",
								children: p.flag
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 115,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-1.5",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-semibold text-rose-200 truncate",
										children: p.phrase
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 118,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-zinc-400 font-mono truncate",
										children: ["• ", p.language]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 121,
										columnNumber: 23
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 117,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[11px] text-rose-400/80 truncate",
									children: p.pronunciation
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 125,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 116,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 114,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-1 shrink-0 ml-2",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								onClick: (e) => handleSpeak(p, e),
								className: "p-1.5 rounded-lg text-zinc-400 hover:text-rose-300 hover:bg-zinc-800 transition-colors",
								title: "Pronounce",
								children: /* @__PURE__ */ _jsxDEV(Volume2, { className: `w-3.5 h-3.5 ${speakingId === p.id ? "animate-pulse text-rose-400" : ""}` }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 137,
									columnNumber: 21
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 132,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								className: `p-1.5 rounded-lg transition-colors ${isSelected ? "text-rose-400 bg-rose-900/40" : "text-zinc-500 group-hover:text-rose-400"}`,
								title: "Spotlight",
								children: /* @__PURE__ */ _jsxDEV(Heart, { className: "w-3.5 h-3.5 fill-current" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 151,
									columnNumber: 21
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 143,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 131,
							columnNumber: 17
						}, this)]
					}, p.id, true, {
						fileName: _jsxFileName,
						lineNumber: 105,
						columnNumber: 15
					}, this);
				})
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 96,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 50,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsZUFBZTtBQUN6QyxTQUFTLG9CQUFnQztBQUN6QyxTQUFTLFFBQVEsT0FBTyxTQUFTLGFBQStCOzs7QUFPaEUsT0FBTyxNQUFNLG9CQUFxRCxFQUNoRSxnQkFDQSx1QkFDSTtDQUNKLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEVBQUU7Q0FDakQsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBaUIsS0FBSztDQUNsRSxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBd0IsSUFBSTtDQUVoRSxNQUFNLFVBQVU7RUFBQztFQUFPO0VBQVU7RUFBUTtFQUFZO0VBQVU7RUFBZTtDQUFTO0NBRXhGLE1BQU0sa0JBQWtCLGNBQWM7RUFDcEMsT0FBTyxhQUFhLFFBQVEsTUFBTTtHQUNoQyxNQUFNLGdCQUNKLEVBQUUsT0FBTyxZQUFZLENBQUMsQ0FBQyxTQUFTLFlBQVksWUFBWSxDQUFDLEtBQ3pELEVBQUUsU0FBUyxZQUFZLENBQUMsQ0FBQyxTQUFTLFlBQVksWUFBWSxDQUFDLEtBQzNELEVBQUUsT0FBTyxZQUFZLENBQUMsQ0FBQyxTQUFTLFlBQVksWUFBWSxDQUFDLEtBQ3pELEVBQUUsY0FBYyxZQUFZLENBQUMsQ0FBQyxTQUFTLFlBQVksWUFBWSxDQUFDO0dBRWxFLE1BQU0sZ0JBQWdCLG1CQUFtQixTQUFTLEVBQUUsV0FBVztHQUUvRCxPQUFPLGlCQUFpQjtFQUMxQixDQUFDO0NBQ0gsR0FBRyxDQUFDLGFBQWEsY0FBYyxDQUFDO0NBRWhDLE1BQU0sZUFBZSxHQUFlLE1BQXdCO0VBQzFELEVBQUUsZ0JBQWdCO0VBQ2xCLElBQUksRUFBRSxxQkFBcUIsU0FBUztFQUVwQyxPQUFPLGdCQUFnQixPQUFPO0VBQzlCLE1BQU0sWUFBWSxJQUFJLHlCQUF5QixFQUFFLE1BQU07RUFDdkQsVUFBVSxPQUFPO0VBRWpCLGNBQWMsRUFBRSxFQUFFO0VBQ2xCLFVBQVUsY0FBYyxjQUFjLElBQUk7RUFDMUMsVUFBVSxnQkFBZ0IsY0FBYyxJQUFJO0VBRTVDLE9BQU8sZ0JBQWdCLE1BQU0sU0FBUztDQUN4QztDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUVFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUsd0JBQXlCOzs7O2VBQzFDLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFkO09BQW9EO09BQzlCLGdCQUFnQjtPQUFPO01BQ3pDOzs7OzthQUNEOzs7OztjQUNMLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQXNDO0lBRWhEOzs7O1lBQ0g7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUscUVBQXNFOzs7O2VBQ3hGLHdCQUFDLFNBQUQ7TUFDRSxNQUFLO01BQ0wsYUFBWTtNQUNaLE9BQU87TUFDUCxXQUFXLE1BQU0sZUFBZSxFQUFFLE9BQU8sS0FBSztNQUM5QyxXQUFVO0tBQ1g7Ozs7YUFDRTs7Ozs7Y0FHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNaLFFBQVEsS0FBSyxXQUNaLHdCQUFDLFVBQUQ7TUFFRSxlQUFlLGtCQUFrQixNQUFNO01BQ3ZDLFdBQVcsd0VBQ1QsbUJBQW1CLFNBQ2YsaURBQ0E7Z0JBR0w7S0FDSyxHQVREOzs7O1lBU0MsQ0FDVDtJQUNFOzs7O1lBQ0Y7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ1osZ0JBQWdCLFdBQVcsSUFDMUIsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUF5RDtNQUNqQztNQUFZO0tBQy9COzs7OztlQUVMLGdCQUFnQixLQUFLLE1BQU07S0FDekIsTUFBTSxhQUFhLHFCQUFxQixFQUFFO0tBQzFDLE9BQ0Usd0JBQUMsT0FBRDtNQUVFLGVBQWUsZUFBZSxDQUFDO01BQy9CLFdBQVcsaUdBQ1QsYUFDSSxnRUFDQTtnQkFOUixDQVNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQXVCLEVBQUU7T0FBVzs7OztpQkFDcEQsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUNiLEVBQUU7U0FDQzs7OzttQkFDTix3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaEIsQ0FBK0QsTUFDMUQsRUFBRSxRQUNEOzs7OztpQkFDSDs7Ozs7a0JBQ0wsd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQ1YsRUFBRTtRQUNGOzs7O2dCQUNBOzs7OztlQUNGOzs7OztnQkFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFVBQUQ7UUFDRSxVQUFVLE1BQU0sWUFBWSxHQUFHLENBQUM7UUFDaEMsV0FBVTtRQUNWLE9BQU07a0JBRU4sd0JBQUMsU0FBRCxFQUNFLFdBQVcsZUFDVCxlQUFlLEVBQUUsS0FBSyxnQ0FBZ0MsS0FFekQ7Ozs7O09BQ0s7Ozs7aUJBQ1Isd0JBQUMsVUFBRDtRQUNFLFdBQVcsc0NBQ1QsYUFDSSxpQ0FDQTtRQUVOLE9BQU07a0JBRU4sd0JBQUMsT0FBRCxFQUFPLFdBQVUsMkJBQTRCOzs7OztPQUN2Qzs7OztlQUNMOzs7OztjQUNGO1FBaERFLEVBQUU7Ozs7WUFnREo7SUFFVCxDQUFDO0dBRUE7Ozs7O0VBQ0Y7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkxhbmd1YWdlRXhwbG9yZXIudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlTWVtbyB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IExPVkVfUEhSQVNFUywgTG92ZVBocmFzZSB9IGZyb20gJy4uL2RhdGEvbGFuZ3VhZ2VzJztcbmltcG9ydCB7IFNlYXJjaCwgR2xvYmUsIFZvbHVtZTIsIEhlYXJ0LCBTcGFya2xlcywgRmlsdGVyIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcblxuaW50ZXJmYWNlIExhbmd1YWdlRXhwbG9yZXJQcm9wcyB7XG4gIG9uU2VsZWN0UGhyYXNlOiAocGhyYXNlOiBMb3ZlUGhyYXNlKSA9PiB2b2lkO1xuICBzZWxlY3RlZFBocmFzZUlkPzogc3RyaW5nIHwgbnVsbDtcbn1cblxuZXhwb3J0IGNvbnN0IExhbmd1YWdlRXhwbG9yZXI6IFJlYWN0LkZDPExhbmd1YWdlRXhwbG9yZXJQcm9wcz4gPSAoe1xuICBvblNlbGVjdFBocmFzZSxcbiAgc2VsZWN0ZWRQaHJhc2VJZCxcbn0pID0+IHtcbiAgY29uc3QgW3NlYXJjaFF1ZXJ5LCBzZXRTZWFyY2hRdWVyeV0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtzZWxlY3RlZFJlZ2lvbiwgc2V0U2VsZWN0ZWRSZWdpb25dID0gdXNlU3RhdGU8c3RyaW5nPignYWxsJyk7XG4gIGNvbnN0IFtzcGVha2luZ0lkLCBzZXRTcGVha2luZ0lkXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuXG4gIGNvbnN0IHJlZ2lvbnMgPSBbJ2FsbCcsICdFdXJvcGUnLCAnQXNpYScsICdBbWVyaWNhcycsICdBZnJpY2EnLCAnTWlkZGxlIEVhc3QnLCAnT2NlYW5pYSddO1xuXG4gIGNvbnN0IGZpbHRlcmVkUGhyYXNlcyA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIHJldHVybiBMT1ZFX1BIUkFTRVMuZmlsdGVyKChwKSA9PiB7XG4gICAgICBjb25zdCBtYXRjaGVzU2VhcmNoID1cbiAgICAgICAgcC5waHJhc2UudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hRdWVyeS50b0xvd2VyQ2FzZSgpKSB8fFxuICAgICAgICBwLmxhbmd1YWdlLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoUXVlcnkudG9Mb3dlckNhc2UoKSkgfHxcbiAgICAgICAgcC5uYXRpdmUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hRdWVyeS50b0xvd2VyQ2FzZSgpKSB8fFxuICAgICAgICBwLnByb251bmNpYXRpb24udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hRdWVyeS50b0xvd2VyQ2FzZSgpKTtcblxuICAgICAgY29uc3QgbWF0Y2hlc1JlZ2lvbiA9IHNlbGVjdGVkUmVnaW9uID09PSAnYWxsJyB8fCBwLnJlZ2lvbiA9PT0gc2VsZWN0ZWRSZWdpb247XG5cbiAgICAgIHJldHVybiBtYXRjaGVzU2VhcmNoICYmIG1hdGNoZXNSZWdpb247XG4gICAgfSk7XG4gIH0sIFtzZWFyY2hRdWVyeSwgc2VsZWN0ZWRSZWdpb25dKTtcblxuICBjb25zdCBoYW5kbGVTcGVhayA9IChwOiBMb3ZlUGhyYXNlLCBlOiBSZWFjdC5Nb3VzZUV2ZW50KSA9PiB7XG4gICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICBpZiAoISgnc3BlZWNoU3ludGhlc2lzJyBpbiB3aW5kb3cpKSByZXR1cm47XG5cbiAgICB3aW5kb3cuc3BlZWNoU3ludGhlc2lzLmNhbmNlbCgpO1xuICAgIGNvbnN0IHV0dGVyYW5jZSA9IG5ldyBTcGVlY2hTeW50aGVzaXNVdHRlcmFuY2UocC5waHJhc2UpO1xuICAgIHV0dGVyYW5jZS5yYXRlID0gMC44NTtcblxuICAgIHNldFNwZWFraW5nSWQocC5pZCk7XG4gICAgdXR0ZXJhbmNlLm9uZW5kID0gKCkgPT4gc2V0U3BlYWtpbmdJZChudWxsKTtcbiAgICB1dHRlcmFuY2Uub25lcnJvciA9ICgpID0+IHNldFNwZWFraW5nSWQobnVsbCk7XG5cbiAgICB3aW5kb3cuc3BlZWNoU3ludGhlc2lzLnNwZWFrKHV0dGVyYW5jZSk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaC1mdWxsIGJnLVsjMGQwNzBiXS85MCBib3JkZXIgYm9yZGVyLXJvc2UtOTAwLzMwIHJvdW5kZWQtMnhsIHAtNCBvdmVyZmxvdy1oaWRkZW4gYmFja2Ryb3AtYmx1ci14bFwiPlxuICAgICAgey8qIEhlYWRlciAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0yIG1iLTNcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgIDxHbG9iZSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtcm9zZS00MDBcIiAvPlxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1yb3NlLTIwMFwiPlxuICAgICAgICAgICAgTGFuZ3VhZ2VzIG9mIExvdmUgKHtmaWx0ZXJlZFBocmFzZXMubGVuZ3RofSlcbiAgICAgICAgICA8L2gzPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC16aW5jLTQwMCBmb250LW1vbm9cIj5cbiAgICAgICAgICBDbGljayBhbnkgdG8gc3BvdGxpZ2h0IG9uIHJvc2VcbiAgICAgICAgPC9zcGFuPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBTZWFyY2ggJiBGaWx0ZXIgQmFyICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTIgbWItM1wiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgICAgPFNlYXJjaCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSBhYnNvbHV0ZSBsZWZ0LTMgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHRleHQtemluYy00MDBcIiAvPlxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggbGFuZ3VhZ2UsIHBocmFzZSwgc2NyaXB0LCBvciBwcm9udW5jaWF0aW9uLi4uXCJcbiAgICAgICAgICAgIHZhbHVlPXtzZWFyY2hRdWVyeX1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VhcmNoUXVlcnkoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHBsLTkgcHItMyBweS0xLjUgcm91bmRlZC14bCBiZy16aW5jLTkwMC85MCBib3JkZXIgYm9yZGVyLXJvc2UtOTAwLzQwIHRleHQteHMgdGV4dC1yb3NlLTEwMCBwbGFjZWhvbGRlci16aW5jLTUwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLXJvc2UtNTAwXCJcbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogUmVnaW9uIFBpbGxzICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgb3ZlcmZsb3cteC1hdXRvIHBiLTEgbm8tc2Nyb2xsYmFyIHRleHQtWzExcHhdXCI+XG4gICAgICAgICAge3JlZ2lvbnMubWFwKChyZWdpb24pID0+IChcbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAga2V5PXtyZWdpb259XG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkUmVnaW9uKHJlZ2lvbil9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTIuNSBweS0xIHJvdW5kZWQtZnVsbCBjYXBpdGFsaXplIHdoaXRlc3BhY2Utbm93cmFwIHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgICAgICAgc2VsZWN0ZWRSZWdpb24gPT09IHJlZ2lvblxuICAgICAgICAgICAgICAgICAgPyAnYmctcm9zZS02MDAgdGV4dC13aGl0ZSBmb250LW1lZGl1bSBzaGFkb3ctc20nXG4gICAgICAgICAgICAgICAgICA6ICdiZy16aW5jLTkwMC82MCB0ZXh0LXppbmMtNDAwIGhvdmVyOnRleHQtemluYy0yMDAgaG92ZXI6YmctemluYy04MDAnXG4gICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7cmVnaW9ufVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBHcmlkIG9mIExhbmd1YWdlcyAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG92ZXJmbG93LXktYXV0byBzcGFjZS15LTIgcHItMSBjdXN0b20tc2Nyb2xsYmFyXCI+XG4gICAgICAgIHtmaWx0ZXJlZFBocmFzZXMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktMTAgdGV4dC14cyB0ZXh0LXppbmMtNTAwXCI+XG4gICAgICAgICAgICBObyBsYW5ndWFnZSBtYXRjaGVzIFwie3NlYXJjaFF1ZXJ5fVwiXG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICkgOiAoXG4gICAgICAgICAgZmlsdGVyZWRQaHJhc2VzLm1hcCgocCkgPT4ge1xuICAgICAgICAgICAgY29uc3QgaXNTZWxlY3RlZCA9IHNlbGVjdGVkUGhyYXNlSWQgPT09IHAuaWQ7XG4gICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAga2V5PXtwLmlkfVxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uU2VsZWN0UGhyYXNlKHApfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGdyb3VwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwLTIuNSByb3VuZGVkLXhsIGJvcmRlciB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgICAgaXNTZWxlY3RlZFxuICAgICAgICAgICAgICAgICAgICA/ICdiZy1yb3NlLTk1MC83MCBib3JkZXItcm9zZS01MDAgc2hhZG93LW1kIHNoYWRvdy1yb3NlLTk1MC80MCdcbiAgICAgICAgICAgICAgICAgICAgOiAnYmctemluYy05MDAvNDAgYm9yZGVyLXppbmMtODAwLzgwIGhvdmVyOmJnLXppbmMtOTAwLzgwIGhvdmVyOmJvcmRlci1yb3NlLTkwMC81MCdcbiAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNSBtaW4tdy0wXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhsIHNlbGVjdC1ub25lXCI+e3AuZmxhZ308L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LTBcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtcm9zZS0yMDAgdHJ1bmNhdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtwLnBocmFzZX1cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC16aW5jLTQwMCBmb250LW1vbm8gdHJ1bmNhdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIOKAoiB7cC5sYW5ndWFnZX1cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXJvc2UtNDAwLzgwIHRydW5jYXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAge3AucHJvbnVuY2lhdGlvbn1cbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHNocmluay0wIG1sLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IGhhbmRsZVNwZWFrKHAsIGUpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSByb3VuZGVkLWxnIHRleHQtemluYy00MDAgaG92ZXI6dGV4dC1yb3NlLTMwMCBob3ZlcjpiZy16aW5jLTgwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiUHJvbm91bmNlXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPFZvbHVtZTJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LTMuNSBoLTMuNSAke1xuICAgICAgICAgICAgICAgICAgICAgICAgc3BlYWtpbmdJZCA9PT0gcC5pZCA/ICdhbmltYXRlLXB1bHNlIHRleHQtcm9zZS00MDAnIDogJydcbiAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwLTEuNSByb3VuZGVkLWxnIHRyYW5zaXRpb24tY29sb3JzICR7XG4gICAgICAgICAgICAgICAgICAgICAgaXNTZWxlY3RlZFxuICAgICAgICAgICAgICAgICAgICAgICAgPyAndGV4dC1yb3NlLTQwMCBiZy1yb3NlLTkwMC80MCdcbiAgICAgICAgICAgICAgICAgICAgICAgIDogJ3RleHQtemluYy01MDAgZ3JvdXAtaG92ZXI6dGV4dC1yb3NlLTQwMCdcbiAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiU3BvdGxpZ2h0XCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPEhlYXJ0IGNsYXNzTmFtZT1cInctMy41IGgtMy41IGZpbGwtY3VycmVudFwiIC8+XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApO1xuICAgICAgICAgIH0pXG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=