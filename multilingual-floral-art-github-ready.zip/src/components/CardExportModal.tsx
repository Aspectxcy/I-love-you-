const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useRef = __vite__cjsImport0_react["useRef"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=3ba6436c";
import confetti from "/node_modules/.vite/deps/canvas-confetti.js?v=3ba6436c";
import { Heart, Sparkles, X, Check, Copy } from "/node_modules/.vite/deps/lucide-react.js?v=3ba6436c";
import { COLOR_THEMES } from "/src/data/languages.ts";
var _jsxFileName = "/app/applet/src/components/CardExportModal.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3ba6436c";
export const CardExportModal = ({ isOpen, onClose, recipientName, onUpdateRecipient, themeId, flowerType = "lily" }) => {
	const flowerEmoji = flowerType === "lily" ? "🌸" : "🌹";
	const flowerName = flowerType === "lily" ? "Pink Lily" : "Rose";
	const [senderName, setSenderName] = useState("");
	const [loveNote, setLoveNote] = useState(flowerType === "lily" ? "If a single pink lily could say “I love you” in every language, it still could never capture all the reasons I love you. Happy moments forever." : "If a single rose could say “I love you” in every language, it still could never capture all the reasons I love you. Happy moments forever.");
	const [cardStyle, setCardStyle] = useState("classic");
	const [copiedLink, setCopiedLink] = useState(false);
	const cardPreviewRef = useRef(null);
	if (!isOpen) return null;
	const triggerConfetti = () => {
		confetti({
			particleCount: 75,
			spread: 60,
			origin: { y: .6 },
			colors: [
				"#f472b6",
				"#ec4899",
				"#fda4af",
				"#f59e0b",
				"#ffffff"
			]
		});
	};
	const handleCopyLoveNote = async () => {
		const textToCopy = `${flowerEmoji} ${flowerName} In Every Language ${flowerEmoji}\n\nTo: ${recipientName || "My Love"}\n${loveNote}\n\nWith all my heart,\n${senderName || "Yours Forever"}`;
		try {
			await navigator.clipboard.writeText(textToCopy);
			setCopiedLink(true);
			triggerConfetti();
			setTimeout(() => setCopiedLink(false), 2500);
		} catch {}
	};
	const currentTheme = COLOR_THEMES.find((t) => t.id === themeId) || COLOR_THEMES[0];
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "relative w-full max-w-2xl bg-zinc-950 border border-rose-500/30 rounded-3xl p-6 md:p-8 shadow-2xl shadow-rose-950 text-rose-50 overflow-hidden max-h-[92vh] flex flex-col",
			children: [
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: onClose,
					className: "absolute top-5 right-5 p-2 rounded-full text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors z-10",
					children: /* @__PURE__ */ _jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 69,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 65,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "text-center mb-6",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-950/80 border border-rose-500/40 text-xs font-semibold text-rose-300 mb-2",
							children: [/* @__PURE__ */ _jsxDEV(Heart, { className: "w-3.5 h-3.5 fill-rose-500 text-rose-500" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 75,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Personalized Love Dedication" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 76,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 74,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-2xl font-bold font-display tracking-tight text-white",
							children: "Create A Rose Card For Someone Special"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 78,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-zinc-400 mt-1 max-w-md mx-auto",
							children: "Dedicate the blooming rose and inscribe their name right into the heart of the flower in every language."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 81,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 73,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex-1 overflow-y-auto space-y-6 pr-2 custom-scrollbar",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-1 md:grid-cols-2 gap-4",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-xs font-semibold text-rose-300 mb-1.5",
								children: "Recipient's Name (Flower Heart)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 91,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: recipientName,
								onChange: (e) => onUpdateRecipient(e.target.value),
								placeholder: "e.g. Sophia, My Love, Alex",
								className: "w-full px-3.5 py-2 rounded-xl bg-zinc-900 border border-zinc-700 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-rose-500"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 94,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 90,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-xs font-semibold text-rose-300 mb-1.5",
								children: "From (Your Name)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 104,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: senderName,
								onChange: (e) => setSenderName(e.target.value),
								placeholder: "e.g. Ayaz, Secret Admirer",
								className: "w-full px-3.5 py-2 rounded-xl bg-zinc-900 border border-zinc-700 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-rose-500"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 107,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 103,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 89,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-xs font-semibold text-rose-300 mb-1.5",
							children: "Heartfelt Love Message / Letter"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 118,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("textarea", {
							rows: 3,
							value: loveNote,
							onChange: (e) => setLoveNote(e.target.value),
							placeholder: "Write your personal romantic note...",
							className: "w-full px-3.5 py-2.5 rounded-xl bg-zinc-900 border border-zinc-700 text-xs text-zinc-200 placeholder-zinc-500 focus:outline-none focus:border-rose-500 resize-none leading-relaxed"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 121,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 117,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-medium text-zinc-400",
								children: "Card Frame:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 132,
								columnNumber: 13
							}, this), [
								"classic",
								"velvet",
								"golden"
							].map((style) => /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setCardStyle(style),
								className: `px-3 py-1 rounded-lg text-xs capitalize transition-all ${cardStyle === style ? "bg-rose-600 text-white font-medium shadow-sm" : "bg-zinc-900 text-zinc-400 hover:text-zinc-200"}`,
								children: style
							}, style, false, {
								fileName: _jsxFileName,
								lineNumber: 134,
								columnNumber: 15
							}, this))]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 131,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							ref: cardPreviewRef,
							className: `relative p-6 rounded-2xl border text-center transition-all ${cardStyle === "classic" ? "bg-gradient-to-b from-[#1c0812] to-[#0d0208] border-rose-500/40 shadow-xl shadow-rose-950/80" : cardStyle === "velvet" ? "bg-gradient-to-b from-[#180a24] to-[#07020d] border-purple-500/40 shadow-xl shadow-purple-950/80" : "bg-gradient-to-b from-[#241a08] to-[#0d0902] border-amber-500/40 shadow-xl shadow-amber-950/80"}`,
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "absolute top-3 left-4 text-xs font-mono tracking-widest text-pink-400/60 uppercase",
									children: "★ Eternal Bloom"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 159,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "text-3xl my-2",
									children: flowerEmoji
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 162,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("h3", {
									className: "font-script text-3xl md:text-4xl text-rose-200 mb-1",
									children: ["For ", recipientName || "My Beloved"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 164,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "font-mono text-[11px] text-rose-300/80 mb-3 tracking-wide",
									children: "\"Je t'aime • Te amo • 愛してる • Ti amo • Ich liebe dich • 사랑해\""
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 168,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs italic text-zinc-300 max-w-md mx-auto leading-relaxed mb-4 px-4 font-sans",
									children: [
										"\"",
										loveNote,
										"\""
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 172,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "pt-3 border-t border-rose-500/20 text-right pr-4 text-xs text-rose-300 font-script text-xl",
									children: [
										"Forever yours, ",
										senderName || "Your Love",
										" ♥"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 176,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 149,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 87,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between gap-3 pt-4 border-t border-zinc-800/80 mt-4",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						onClick: triggerConfetti,
						className: "flex items-center gap-1.5 px-4 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-xs font-medium text-zinc-300 hover:text-white transition-all",
						children: [/* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-3.5 h-3.5 text-amber-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 188,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Celebrate with Hearts" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 189,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 184,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2",
						children: /* @__PURE__ */ _jsxDEV("button", {
							onClick: handleCopyLoveNote,
							className: "flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-500 hover:to-pink-500 text-white text-xs font-semibold shadow-lg shadow-rose-950 transition-all active:scale-95",
							children: [copiedLink ? /* @__PURE__ */ _jsxDEV(Check, { className: "w-4 h-4 text-white" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 197,
								columnNumber: 29
							}, this) : /* @__PURE__ */ _jsxDEV(Copy, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 197,
								columnNumber: 72
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: copiedLink ? "Dedication Copied!" : "Copy Dedication & Message" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 198,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 193,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 192,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 183,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 63,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 62,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsY0FBYztBQUN4QyxPQUFPLGNBQWM7QUFDckIsU0FBUyxPQUFpQixVQUFVLEdBQVMsT0FBTyxZQUFZO0FBQ2hFLFNBQVMsb0JBQW9COzs7QUFXN0IsT0FBTyxNQUFNLG1CQUFtRCxFQUM5RCxRQUNBLFNBQ0EsZUFDQSxtQkFDQSxTQUNBLGFBQWEsYUFDVDtDQUNKLE1BQU0sY0FBYyxlQUFlLFNBQVMsT0FBTztDQUNuRCxNQUFNLGFBQWEsZUFBZSxTQUFTLGNBQWM7Q0FFekQsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsRUFBRTtDQUMvQyxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQzlCLGVBQWUsU0FDWCxvSkFDQSw0SUFDTjtDQUNBLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUEwQyxTQUFTO0NBQ3JGLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLEtBQUs7Q0FDbEQsTUFBTSxpQkFBaUIsT0FBOEIsSUFBSTtDQUV6RCxJQUFJLENBQUMsUUFBUSxPQUFPO0NBRXBCLE1BQU0sd0JBQXdCO0VBQzVCLFNBQVM7R0FDUCxlQUFlO0dBQ2YsUUFBUTtHQUNSLFFBQVEsRUFBRSxHQUFHLEdBQUk7R0FDakIsUUFBUTtJQUFDO0lBQVc7SUFBVztJQUFXO0lBQVc7R0FBUztFQUNoRSxDQUFDO0NBQ0g7Q0FFQSxNQUFNLHFCQUFxQixZQUFZO0VBQ3JDLE1BQU0sYUFBYSxHQUFHLFlBQVksR0FBRyxXQUFXLHFCQUFxQixZQUFZLFVBQVUsaUJBQWlCLFVBQVUsSUFBSSxTQUFTLDBCQUEwQixjQUFjO0VBQzNLLElBQUk7R0FDRixNQUFNLFVBQVUsVUFBVSxVQUFVLFVBQVU7R0FDOUMsY0FBYyxJQUFJO0dBQ2xCLGdCQUFnQjtHQUNoQixpQkFBaUIsY0FBYyxLQUFLLEdBQUcsSUFBSTtFQUM3QyxRQUFRLENBRVI7Q0FDRjtDQUVBLE1BQU0sZUFBZSxhQUFhLE1BQU0sTUFBTSxFQUFFLE9BQU8sT0FBTyxLQUFLLGFBQWE7Q0FFaEYsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUNiLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFFRSx3QkFBQyxVQUFEO0tBQ0UsU0FBUztLQUNULFdBQVU7ZUFFVix3QkFBQyxHQUFELEVBQUcsV0FBVSxVQUFXOzs7OztJQUNsQjs7Ozs7SUFHUix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFELEVBQU8sV0FBVSwwQ0FBMkM7Ozs7aUJBQzVELHdCQUFDLFFBQUQsWUFBTSwrQkFBa0M7Ozs7ZUFDckM7Ozs7OztNQUNMLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUE0RDtNQUV0RTs7Ozs7TUFDSix3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBOEM7TUFFeEQ7Ozs7O0tBQ0E7Ozs7OztJQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFFRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBbUQ7T0FFN0Q7Ozs7aUJBQ1Asd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxPQUFPO1FBQ1AsV0FBVyxNQUFNLGtCQUFrQixFQUFFLE9BQU8sS0FBSztRQUNqRCxhQUFZO1FBQ1osV0FBVTtPQUNYOzs7O2VBQ0U7Ozs7aUJBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUFtRDtPQUU3RDs7OztpQkFDUCx3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLE9BQU87UUFDUCxXQUFXLE1BQU0sY0FBYyxFQUFFLE9BQU8sS0FBSztRQUM3QyxhQUFZO1FBQ1osV0FBVTtPQUNYOzs7O2VBQ0U7Ozs7ZUFDRjs7Ozs7O01BRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUFtRDtNQUU3RDs7OztnQkFDUCx3QkFBQyxZQUFEO09BQ0UsTUFBTTtPQUNOLE9BQU87T0FDUCxXQUFXLE1BQU0sWUFBWSxFQUFFLE9BQU8sS0FBSztPQUMzQyxhQUFZO09BQ1osV0FBVTtNQUNYOzs7O2NBQ0U7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBb0M7T0FBaUI7Ozs7aUJBQ25FO1FBQUM7UUFBVztRQUFVO09BQVEsQ0FBQyxDQUFXLEtBQUssVUFDL0Msd0JBQUMsVUFBRDtRQUVFLGVBQWUsYUFBYSxLQUFLO1FBQ2pDLFdBQVcsMERBQ1QsY0FBYyxRQUNWLGlEQUNBO2tCQUdMO09BQ0ssR0FURDs7OztjQVNDLENBQ1QsQ0FDRTs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUNFLEtBQUs7T0FDTCxXQUFXLDhEQUNULGNBQWMsWUFDVixpR0FDQSxjQUFjLFdBQ2QscUdBQ0E7aUJBUFI7UUFVRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBcUY7UUFFL0Y7Ozs7O1FBQ0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWlCO1FBQWlCOzs7OztRQUVqRCx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBZCxDQUFvRSxRQUM3RCxpQkFBaUIsWUFDcEI7Ozs7OztRQUVKLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUE0RDtRQUV0RTs7Ozs7UUFFSCx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBYjtVQUFpRztVQUM3RjtVQUFTO1NBQ1Y7Ozs7OztRQUVILHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQTRHO1VBQzFGLGNBQWM7VUFBWTtTQUN2Qzs7Ozs7O09BQ0Y7Ozs7OztLQUNGOzs7Ozs7SUFHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsVUFBRDtNQUNFLFNBQVM7TUFDVCxXQUFVO2dCQUZaLENBSUUsd0JBQUMsVUFBRCxFQUFVLFdBQVUsNkJBQThCOzs7O2dCQUNsRCx3QkFBQyxRQUFELFlBQU0sd0JBQTJCOzs7O2NBQzNCOzs7OztlQUVSLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLFVBQUQ7T0FDRSxTQUFTO09BQ1QsV0FBVTtpQkFGWixDQUlHLGFBQWEsd0JBQUMsT0FBRCxFQUFPLFdBQVUscUJBQXNCOzs7O2tCQUFJLHdCQUFDLE1BQUQsRUFBTSxXQUFVLFVBQVc7Ozs7aUJBQ3BGLHdCQUFDLFFBQUQsWUFBTyxhQUFhLHVCQUF1Qiw0QkFBa0M7Ozs7ZUFDdkU7Ozs7OztLQUNMOzs7O2FBQ0Y7Ozs7OztHQUNGOzs7Ozs7Q0FDRjs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJDYXJkRXhwb3J0TW9kYWwudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlUmVmIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IGNvbmZldHRpIGZyb20gJ2NhbnZhcy1jb25mZXR0aSc7XG5pbXBvcnQgeyBIZWFydCwgRG93bmxvYWQsIFNwYXJrbGVzLCBYLCBTZW5kLCBDaGVjaywgQ29weSB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyBDT0xPUl9USEVNRVMgfSBmcm9tICcuLi9kYXRhL2xhbmd1YWdlcyc7XG5cbmludGVyZmFjZSBDYXJkRXhwb3J0TW9kYWxQcm9wcyB7XG4gIGlzT3BlbjogYm9vbGVhbjtcbiAgb25DbG9zZTogKCkgPT4gdm9pZDtcbiAgcmVjaXBpZW50TmFtZTogc3RyaW5nO1xuICBvblVwZGF0ZVJlY2lwaWVudDogKG5hbWU6IHN0cmluZykgPT4gdm9pZDtcbiAgdGhlbWVJZDogc3RyaW5nO1xuICBmbG93ZXJUeXBlPzogJ2xpbHknIHwgJ3Jvc2UnO1xufVxuXG5leHBvcnQgY29uc3QgQ2FyZEV4cG9ydE1vZGFsOiBSZWFjdC5GQzxDYXJkRXhwb3J0TW9kYWxQcm9wcz4gPSAoe1xuICBpc09wZW4sXG4gIG9uQ2xvc2UsXG4gIHJlY2lwaWVudE5hbWUsXG4gIG9uVXBkYXRlUmVjaXBpZW50LFxuICB0aGVtZUlkLFxuICBmbG93ZXJUeXBlID0gJ2xpbHknLFxufSkgPT4ge1xuICBjb25zdCBmbG93ZXJFbW9qaSA9IGZsb3dlclR5cGUgPT09ICdsaWx5JyA/ICfwn4y4JyA6ICfwn4y5JztcbiAgY29uc3QgZmxvd2VyTmFtZSA9IGZsb3dlclR5cGUgPT09ICdsaWx5JyA/ICdQaW5rIExpbHknIDogJ1Jvc2UnO1xuXG4gIGNvbnN0IFtzZW5kZXJOYW1lLCBzZXRTZW5kZXJOYW1lXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2xvdmVOb3RlLCBzZXRMb3ZlTm90ZV0gPSB1c2VTdGF0ZShcbiAgICBmbG93ZXJUeXBlID09PSAnbGlseSdcbiAgICAgID8gJ0lmIGEgc2luZ2xlIHBpbmsgbGlseSBjb3VsZCBzYXkg4oCcSSBsb3ZlIHlvdeKAnSBpbiBldmVyeSBsYW5ndWFnZSwgaXQgc3RpbGwgY291bGQgbmV2ZXIgY2FwdHVyZSBhbGwgdGhlIHJlYXNvbnMgSSBsb3ZlIHlvdS4gSGFwcHkgbW9tZW50cyBmb3JldmVyLidcbiAgICAgIDogJ0lmIGEgc2luZ2xlIHJvc2UgY291bGQgc2F5IOKAnEkgbG92ZSB5b3XigJ0gaW4gZXZlcnkgbGFuZ3VhZ2UsIGl0IHN0aWxsIGNvdWxkIG5ldmVyIGNhcHR1cmUgYWxsIHRoZSByZWFzb25zIEkgbG92ZSB5b3UuIEhhcHB5IG1vbWVudHMgZm9yZXZlci4nXG4gICk7XG4gIGNvbnN0IFtjYXJkU3R5bGUsIHNldENhcmRTdHlsZV0gPSB1c2VTdGF0ZTwnY2xhc3NpYycgfCAndmVsdmV0JyB8ICdnb2xkZW4nPignY2xhc3NpYycpO1xuICBjb25zdCBbY29waWVkTGluaywgc2V0Q29waWVkTGlua10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IGNhcmRQcmV2aWV3UmVmID0gdXNlUmVmPEhUTUxEaXZFbGVtZW50IHwgbnVsbD4obnVsbCk7XG5cbiAgaWYgKCFpc09wZW4pIHJldHVybiBudWxsO1xuXG4gIGNvbnN0IHRyaWdnZXJDb25mZXR0aSA9ICgpID0+IHtcbiAgICBjb25mZXR0aSh7XG4gICAgICBwYXJ0aWNsZUNvdW50OiA3NSxcbiAgICAgIHNwcmVhZDogNjAsXG4gICAgICBvcmlnaW46IHsgeTogMC42IH0sXG4gICAgICBjb2xvcnM6IFsnI2Y0NzJiNicsICcjZWM0ODk5JywgJyNmZGE0YWYnLCAnI2Y1OWUwYicsICcjZmZmZmZmJ10sXG4gICAgfSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlQ29weUxvdmVOb3RlID0gYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHRleHRUb0NvcHkgPSBgJHtmbG93ZXJFbW9qaX0gJHtmbG93ZXJOYW1lfSBJbiBFdmVyeSBMYW5ndWFnZSAke2Zsb3dlckVtb2ppfVxcblxcblRvOiAke3JlY2lwaWVudE5hbWUgfHwgJ015IExvdmUnfVxcbiR7bG92ZU5vdGV9XFxuXFxuV2l0aCBhbGwgbXkgaGVhcnQsXFxuJHtzZW5kZXJOYW1lIHx8ICdZb3VycyBGb3JldmVyJ31gO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBuYXZpZ2F0b3IuY2xpcGJvYXJkLndyaXRlVGV4dCh0ZXh0VG9Db3B5KTtcbiAgICAgIHNldENvcGllZExpbmsodHJ1ZSk7XG4gICAgICB0cmlnZ2VyQ29uZmV0dGkoKTtcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0Q29waWVkTGluayhmYWxzZSksIDI1MDApO1xuICAgIH0gY2F0Y2gge1xuICAgICAgLy8gaWdub3JlXG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGN1cnJlbnRUaGVtZSA9IENPTE9SX1RIRU1FUy5maW5kKCh0KSA9PiB0LmlkID09PSB0aGVtZUlkKSB8fCBDT0xPUl9USEVNRVNbMF07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTQgYmctYmxhY2svODAgYmFja2Ryb3AtYmx1ci1tZCBhbmltYXRlLWZhZGVJblwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LWZ1bGwgbWF4LXctMnhsIGJnLXppbmMtOTUwIGJvcmRlciBib3JkZXItcm9zZS01MDAvMzAgcm91bmRlZC0zeGwgcC02IG1kOnAtOCBzaGFkb3ctMnhsIHNoYWRvdy1yb3NlLTk1MCB0ZXh0LXJvc2UtNTAgb3ZlcmZsb3ctaGlkZGVuIG1heC1oLVs5MnZoXSBmbGV4IGZsZXgtY29sXCI+XG4gICAgICAgIHsvKiBDbG9zZSBCdXR0b24gKi99XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC01IHJpZ2h0LTUgcC0yIHJvdW5kZWQtZnVsbCB0ZXh0LXppbmMtNDAwIGhvdmVyOnRleHQtd2hpdGUgaG92ZXI6YmctemluYy04MDAgdHJhbnNpdGlvbi1jb2xvcnMgei0xMFwiXG4gICAgICAgID5cbiAgICAgICAgICA8WCBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cbiAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgey8qIE1vZGFsIEhlYWRlciAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBtYi02XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtMyBweS0xIHJvdW5kZWQtZnVsbCBiZy1yb3NlLTk1MC84MCBib3JkZXIgYm9yZGVyLXJvc2UtNTAwLzQwIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXJvc2UtMzAwIG1iLTJcIj5cbiAgICAgICAgICAgIDxIZWFydCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSBmaWxsLXJvc2UtNTAwIHRleHQtcm9zZS01MDBcIiAvPlxuICAgICAgICAgICAgPHNwYW4+UGVyc29uYWxpemVkIExvdmUgRGVkaWNhdGlvbjwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIGZvbnQtZGlzcGxheSB0cmFja2luZy10aWdodCB0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICBDcmVhdGUgQSBSb3NlIENhcmQgRm9yIFNvbWVvbmUgU3BlY2lhbFxuICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXppbmMtNDAwIG10LTEgbWF4LXctbWQgbXgtYXV0b1wiPlxuICAgICAgICAgICAgRGVkaWNhdGUgdGhlIGJsb29taW5nIHJvc2UgYW5kIGluc2NyaWJlIHRoZWlyIG5hbWUgcmlnaHQgaW50byB0aGUgaGVhcnQgb2YgdGhlIGZsb3dlciBpbiBldmVyeSBsYW5ndWFnZS5cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBTY3JvbGxhYmxlIEZvcm0gJiBQcmV2aWV3IEFyZWEgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG92ZXJmbG93LXktYXV0byBzcGFjZS15LTYgcHItMiBjdXN0b20tc2Nyb2xsYmFyXCI+XG4gICAgICAgICAgey8qIElucHV0cyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1yb3NlLTMwMCBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgICBSZWNpcGllbnQncyBOYW1lIChGbG93ZXIgSGVhcnQpXG4gICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17cmVjaXBpZW50TmFtZX1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IG9uVXBkYXRlUmVjaXBpZW50KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gU29waGlhLCBNeSBMb3ZlLCBBbGV4XCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMy41IHB5LTIgcm91bmRlZC14bCBiZy16aW5jLTkwMCBib3JkZXIgYm9yZGVyLXppbmMtNzAwIHRleHQtc20gdGV4dC13aGl0ZSBwbGFjZWhvbGRlci16aW5jLTUwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLXJvc2UtNTAwXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtcm9zZS0zMDAgbWItMS41XCI+XG4gICAgICAgICAgICAgICAgRnJvbSAoWW91ciBOYW1lKVxuICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgdmFsdWU9e3NlbmRlck5hbWV9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZW5kZXJOYW1lKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gQXlheiwgU2VjcmV0IEFkbWlyZXJcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zLjUgcHktMiByb3VuZGVkLXhsIGJnLXppbmMtOTAwIGJvcmRlciBib3JkZXItemluYy03MDAgdGV4dC1zbSB0ZXh0LXdoaXRlIHBsYWNlaG9sZGVyLXppbmMtNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItcm9zZS01MDBcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXJvc2UtMzAwIG1iLTEuNVwiPlxuICAgICAgICAgICAgICBIZWFydGZlbHQgTG92ZSBNZXNzYWdlIC8gTGV0dGVyXG4gICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgIHJvd3M9ezN9XG4gICAgICAgICAgICAgIHZhbHVlPXtsb3ZlTm90ZX1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRMb3ZlTm90ZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiV3JpdGUgeW91ciBwZXJzb25hbCByb21hbnRpYyBub3RlLi4uXCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMuNSBweS0yLjUgcm91bmRlZC14bCBiZy16aW5jLTkwMCBib3JkZXIgYm9yZGVyLXppbmMtNzAwIHRleHQteHMgdGV4dC16aW5jLTIwMCBwbGFjZWhvbGRlci16aW5jLTUwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLXJvc2UtNTAwIHJlc2l6ZS1ub25lIGxlYWRpbmctcmVsYXhlZFwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIENhcmQgU3R5bGUgU2VsZWN0b3IgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXppbmMtNDAwXCI+Q2FyZCBGcmFtZTo8L3NwYW4+XG4gICAgICAgICAgICB7KFsnY2xhc3NpYycsICd2ZWx2ZXQnLCAnZ29sZGVuJ10gYXMgY29uc3QpLm1hcCgoc3R5bGUpID0+IChcbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIGtleT17c3R5bGV9XG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Q2FyZFN0eWxlKHN0eWxlKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC0zIHB5LTEgcm91bmRlZC1sZyB0ZXh0LXhzIGNhcGl0YWxpemUgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgIGNhcmRTdHlsZSA9PT0gc3R5bGVcbiAgICAgICAgICAgICAgICAgICAgPyAnYmctcm9zZS02MDAgdGV4dC13aGl0ZSBmb250LW1lZGl1bSBzaGFkb3ctc20nXG4gICAgICAgICAgICAgICAgICAgIDogJ2JnLXppbmMtOTAwIHRleHQtemluYy00MDAgaG92ZXI6dGV4dC16aW5jLTIwMCdcbiAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHtzdHlsZX1cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBMaXZlIENhcmQgUHJldmlldyAqL31cbiAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICByZWY9e2NhcmRQcmV2aWV3UmVmfVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgcmVsYXRpdmUgcC02IHJvdW5kZWQtMnhsIGJvcmRlciB0ZXh0LWNlbnRlciB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICBjYXJkU3R5bGUgPT09ICdjbGFzc2ljJ1xuICAgICAgICAgICAgICAgID8gJ2JnLWdyYWRpZW50LXRvLWIgZnJvbS1bIzFjMDgxMl0gdG8tWyMwZDAyMDhdIGJvcmRlci1yb3NlLTUwMC80MCBzaGFkb3cteGwgc2hhZG93LXJvc2UtOTUwLzgwJ1xuICAgICAgICAgICAgICAgIDogY2FyZFN0eWxlID09PSAndmVsdmV0J1xuICAgICAgICAgICAgICAgID8gJ2JnLWdyYWRpZW50LXRvLWIgZnJvbS1bIzE4MGEyNF0gdG8tWyMwNzAyMGRdIGJvcmRlci1wdXJwbGUtNTAwLzQwIHNoYWRvdy14bCBzaGFkb3ctcHVycGxlLTk1MC84MCdcbiAgICAgICAgICAgICAgICA6ICdiZy1ncmFkaWVudC10by1iIGZyb20tWyMyNDFhMDhdIHRvLVsjMGQwOTAyXSBib3JkZXItYW1iZXItNTAwLzQwIHNoYWRvdy14bCBzaGFkb3ctYW1iZXItOTUwLzgwJ1xuICAgICAgICAgICAgfWB9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMyBsZWZ0LTQgdGV4dC14cyBmb250LW1vbm8gdHJhY2tpbmctd2lkZXN0IHRleHQtcGluay00MDAvNjAgdXBwZXJjYXNlXCI+XG4gICAgICAgICAgICAgIOKYhSBFdGVybmFsIEJsb29tXG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC0zeGwgbXktMlwiPntmbG93ZXJFbW9qaX08L2Rpdj5cblxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtc2NyaXB0IHRleHQtM3hsIG1kOnRleHQtNHhsIHRleHQtcm9zZS0yMDAgbWItMVwiPlxuICAgICAgICAgICAgICBGb3Ige3JlY2lwaWVudE5hbWUgfHwgJ015IEJlbG92ZWQnfVxuICAgICAgICAgICAgPC9oMz5cblxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtWzExcHhdIHRleHQtcm9zZS0zMDAvODAgbWItMyB0cmFja2luZy13aWRlXCI+XG4gICAgICAgICAgICAgIFwiSmUgdCdhaW1lIOKAoiBUZSBhbW8g4oCiIOaEm+OBl+OBpuOCiyDigKIgVGkgYW1vIOKAoiBJY2ggbGllYmUgZGljaCDigKIg7IKs656R7ZW0XCJcbiAgICAgICAgICAgIDwvcD5cblxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBpdGFsaWMgdGV4dC16aW5jLTMwMCBtYXgtdy1tZCBteC1hdXRvIGxlYWRpbmctcmVsYXhlZCBtYi00IHB4LTQgZm9udC1zYW5zXCI+XG4gICAgICAgICAgICAgIFwie2xvdmVOb3RlfVwiXG4gICAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtMyBib3JkZXItdCBib3JkZXItcm9zZS01MDAvMjAgdGV4dC1yaWdodCBwci00IHRleHQteHMgdGV4dC1yb3NlLTMwMCBmb250LXNjcmlwdCB0ZXh0LXhsXCI+XG4gICAgICAgICAgICAgIEZvcmV2ZXIgeW91cnMsIHtzZW5kZXJOYW1lIHx8ICdZb3VyIExvdmUnfSDimaVcbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogTW9kYWwgRm9vdGVyIEFjdGlvbnMgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIHB0LTQgYm9yZGVyLXQgYm9yZGVyLXppbmMtODAwLzgwIG10LTRcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXt0cmlnZ2VyQ29uZmV0dGl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTQgcHktMiByb3VuZGVkLXhsIGJnLXppbmMtOTAwIGhvdmVyOmJnLXppbmMtODAwIGJvcmRlciBib3JkZXItemluYy03MDAgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXppbmMtMzAwIGhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxTcGFya2xlcyBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWFtYmVyLTQwMFwiIC8+XG4gICAgICAgICAgICA8c3Bhbj5DZWxlYnJhdGUgd2l0aCBIZWFydHM8L3NwYW4+XG4gICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUNvcHlMb3ZlTm90ZX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtNSBweS0yLjUgcm91bmRlZC14bCBiZy1ncmFkaWVudC10by1yIGZyb20tcm9zZS02MDAgdG8tcGluay02MDAgaG92ZXI6ZnJvbS1yb3NlLTUwMCBob3Zlcjp0by1waW5rLTUwMCB0ZXh0LXdoaXRlIHRleHQteHMgZm9udC1zZW1pYm9sZCBzaGFkb3ctbGcgc2hhZG93LXJvc2UtOTUwIHRyYW5zaXRpb24tYWxsIGFjdGl2ZTpzY2FsZS05NVwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHtjb3BpZWRMaW5rID8gPENoZWNrIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC13aGl0ZVwiIC8+IDogPENvcHkgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+fVxuICAgICAgICAgICAgICA8c3Bhbj57Y29waWVkTGluayA/ICdEZWRpY2F0aW9uIENvcGllZCEnIDogJ0NvcHkgRGVkaWNhdGlvbiAmIE1lc3NhZ2UnfTwvc3Bhbj5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==