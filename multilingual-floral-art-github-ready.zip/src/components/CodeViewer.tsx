const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=3ba6436c";
import { generatePythonCode } from "/src/utils/pythonScript.ts";
import { Copy, Check, Download, Terminal, Play, Sparkles, FileCode, Sliders } from "/node_modules/.vite/deps/lucide-react.js?v=3ba6436c";
var _jsxFileName = "/app/applet/src/components/CodeViewer.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3ba6436c";
export const CodeViewer = ({ config, onConfigChange, onRunCode }) => {
	const [copied, setCopied] = useState(false);
	const [activeTab, setActiveTab] = useState("code");
	const pythonCode = generatePythonCode(config);
	const handleCopy = async () => {
		try {
			await navigator.clipboard.writeText(pythonCode);
			setCopied(true);
			setTimeout(() => setCopied(false), 2200);
		} catch {}
	};
	const fileName = `${(config.themeName || "flower").toLowerCase().replace(/\s+/g, "_")}_of_love.py`;
	const handleDownload = () => {
		const blob = new Blob([pythonCode], { type: "text/x-python;charset=utf-8;" });
		const url = URL.createObjectURL(blob);
		const link = document.createElement("a");
		link.href = url;
		link.download = fileName;
		document.body.appendChild(link);
		link.click();
		document.body.removeChild(link);
		URL.revokeObjectURL(url);
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex flex-col h-full bg-[#0d090d] border border-rose-900/30 rounded-2xl overflow-hidden shadow-2xl",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center justify-between px-4 py-2.5 bg-[#140c13] border-b border-rose-900/30 text-xs text-zinc-400 select-none",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-1.5 mr-2",
							children: [
								/* @__PURE__ */ _jsxDEV("span", { className: "w-3 h-3 rounded-full bg-rose-500/80 inline-block" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 48,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { className: "w-3 h-3 rounded-full bg-amber-500/80 inline-block" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 49,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { className: "w-3 h-3 rounded-full bg-emerald-500/80 inline-block" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 50,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 47,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-1 text-rose-300 font-mono",
							children: [/* @__PURE__ */ _jsxDEV(FileCode, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 54,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "font-semibold",
								children: fileName
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 55,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 53,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 45,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center bg-zinc-900/80 rounded-lg p-0.5 border border-zinc-800",
						children: [
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setActiveTab("code"),
								className: `px-2.5 py-1 rounded-md text-[11px] font-medium transition-all ${activeTab === "code" ? "bg-rose-900/60 text-rose-200" : "text-zinc-400 hover:text-zinc-200"}`,
								children: "Code"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 61,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setActiveTab("params"),
								className: `px-2.5 py-1 rounded-md text-[11px] font-medium transition-all flex items-center gap-1 ${activeTab === "params" ? "bg-rose-900/60 text-rose-200" : "text-zinc-400 hover:text-zinc-200"}`,
								children: [/* @__PURE__ */ _jsxDEV(Sliders, { className: "w-3 h-3" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 75,
									columnNumber: 13
								}, this), "Params"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 69,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setActiveTab("math"),
								className: `px-2.5 py-1 rounded-md text-[11px] font-medium transition-all flex items-center gap-1 ${activeTab === "math" ? "bg-rose-900/60 text-rose-200" : "text-zinc-400 hover:text-zinc-200"}`,
								children: [/* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-3 h-3" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 84,
									columnNumber: 13
								}, this), "Math"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 78,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 60,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: onRunCode,
								className: "flex items-center gap-1.5 px-3 py-1 bg-rose-600 hover:bg-rose-500 text-white rounded-lg font-medium transition-all shadow-sm active:scale-95",
								title: "Re-run animation on canvas",
								children: [/* @__PURE__ */ _jsxDEV(Play, { className: "w-3 h-3 fill-current" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 96,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Re-Run" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 97,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 91,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: handleCopy,
								className: "flex items-center gap-1 px-2.5 py-1 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-white rounded-lg border border-zinc-700/60 transition-all text-[11px]",
								title: "Copy script",
								children: [copied ? /* @__PURE__ */ _jsxDEV(Check, { className: "w-3 h-3 text-emerald-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 105,
									columnNumber: 23
								}, this) : /* @__PURE__ */ _jsxDEV(Copy, { className: "w-3 h-3" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 105,
									columnNumber: 72
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: copied ? "Copied!" : "Copy" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 106,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 100,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: handleDownload,
								className: "flex items-center gap-1 px-2.5 py-1 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-white rounded-lg border border-zinc-700/60 transition-all text-[11px]",
								title: "Download .py file",
								children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-3 h-3" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 114,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: ".py" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 115,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 109,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 90,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 44,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex-1 overflow-auto p-4 font-mono text-xs text-zinc-300 leading-relaxed custom-scrollbar",
				children: [
					activeTab === "code" && /* @__PURE__ */ _jsxDEV("div", {
						className: "flex",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "pr-4 mr-2 border-r border-zinc-800 text-zinc-600 select-none text-right font-mono text-[11px] leading-relaxed",
							children: pythonCode.split("\n").map((_, i) => /* @__PURE__ */ _jsxDEV("div", { children: i + 1 }, i, false, {
								fileName: _jsxFileName,
								lineNumber: 127,
								columnNumber: 17
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 125,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("pre", {
							className: "flex-1 overflow-x-auto whitespace-pre font-mono text-[11.5px] leading-relaxed",
							children: /* @__PURE__ */ _jsxDEV("code", { children: pythonCode.split("\n").map((line, idx) => {
								let formatted = line;
								// Comments
								if (line.trim().startsWith("#") || line.trim().startsWith("\"\"\"")) {
									return /* @__PURE__ */ _jsxDEV("div", {
										className: "text-zinc-500 italic",
										children: line
									}, idx, false, {
										fileName: _jsxFileName,
										lineNumber: 139,
										columnNumber: 23
									}, this);
								}
								// Keyword highlights
								if (line.includes("import ") || line.includes("from ")) {
									return /* @__PURE__ */ _jsxDEV("div", {
										className: "text-rose-400",
										children: line
									}, idx, false, {
										fileName: _jsxFileName,
										lineNumber: 147,
										columnNumber: 23
									}, this);
								}
								if (line.includes("class ") || line.includes("def ")) {
									return /* @__PURE__ */ _jsxDEV("div", {
										className: "text-pink-300 font-semibold",
										children: line
									}, idx, false, {
										fileName: _jsxFileName,
										lineNumber: 154,
										columnNumber: 23
									}, this);
								}
								if (line.includes("PHRASES = [")) {
									return /* @__PURE__ */ _jsxDEV("div", {
										className: "text-amber-300 font-bold",
										children: line
									}, idx, false, {
										fileName: _jsxFileName,
										lineNumber: 161,
										columnNumber: 23
									}, this);
								}
								if (line.includes("\"I love you\"") || line.includes("\"Je t'aime\"") || line.includes("RECIPIENT")) {
									return /* @__PURE__ */ _jsxDEV("div", {
										className: "text-emerald-300",
										children: line
									}, idx, false, {
										fileName: _jsxFileName,
										lineNumber: 168,
										columnNumber: 23
									}, this);
								}
								return /* @__PURE__ */ _jsxDEV("div", {
									className: "text-zinc-300",
									children: line
								}, idx, false, {
									fileName: _jsxFileName,
									lineNumber: 174,
									columnNumber: 21
								}, this);
							}) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 133,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 132,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 123,
						columnNumber: 11
					}, this),
					activeTab === "params" && /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-5 p-2 font-sans",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h4", {
								className: "text-sm font-semibold text-rose-300 mb-1 flex items-center gap-1.5",
								children: [/* @__PURE__ */ _jsxDEV(Sliders, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 188,
									columnNumber: 17
								}, this), " Live Python Configuration"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 187,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-zinc-400",
								children: "Adjust variables in the Python script. Changes will dynamically update the rendered canvas and code download."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 190,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 186,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 md:grid-cols-2 gap-4",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "bg-zinc-900/60 p-3 rounded-xl border border-zinc-800",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex justify-between text-xs mb-1.5",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-zinc-300 font-medium",
												children: "DURATION (Bloom Speed)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 199,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-rose-400 font-mono font-bold",
												children: [config.duration, "s"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 200,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 198,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "range",
											min: "3",
											max: "25",
											step: "1",
											value: config.duration,
											onChange: (e) => onConfigChange({
												...config,
												duration: Number(e.target.value)
											}),
											className: "w-full accent-rose-500 cursor-pointer"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 202,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 197,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "bg-zinc-900/60 p-3 rounded-xl border border-zinc-800",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex justify-between text-xs mb-1.5",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-zinc-300 font-medium",
												children: "SCALE (Rose Proportions)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 218,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-rose-400 font-mono font-bold",
												children: [config.scale, "x"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 219,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 217,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "range",
											min: "0.7",
											max: "1.4",
											step: "0.05",
											value: config.scale,
											onChange: (e) => onConfigChange({
												...config,
												scale: Number(e.target.value)
											}),
											className: "w-full accent-rose-500 cursor-pointer"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 221,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 216,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "bg-zinc-900/60 p-3 rounded-xl border border-zinc-800",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex justify-between text-xs mb-1.5",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-zinc-300 font-medium",
												children: "GAP (Phrase Spacing)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 237,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-rose-400 font-mono font-bold",
												children: [config.gap, " px"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 238,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 236,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "range",
											min: "1",
											max: "8",
											step: "1",
											value: config.gap,
											onChange: (e) => onConfigChange({
												...config,
												gap: Number(e.target.value)
											}),
											className: "w-full accent-rose-500 cursor-pointer"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 240,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 235,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "bg-zinc-900/60 p-3 rounded-xl border border-zinc-800",
										children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-zinc-300 font-medium text-xs mb-1.5",
											children: "RECIPIENT (Dedicated Name)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 255,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: config.recipientName,
											onChange: (e) => onConfigChange({
												...config,
												recipientName: e.target.value
											}),
											placeholder: "e.g. My Love, Sophia, Alex",
											className: "w-full px-3 py-1.5 rounded-lg bg-zinc-950 border border-zinc-700 text-xs text-rose-200 placeholder-zinc-500 focus:outline-none focus:border-rose-500"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 258,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 254,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 195,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "pt-2",
								children: /* @__PURE__ */ _jsxDEV("button", {
									onClick: onRunCode,
									className: "w-full py-2.5 rounded-xl bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-500 hover:to-pink-500 text-white font-medium text-xs flex items-center justify-center gap-2 shadow-lg shadow-rose-950 active:scale-98 transition-all",
									children: [/* @__PURE__ */ _jsxDEV(Play, { className: "w-4 h-4 fill-current" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 275,
										columnNumber: 17
									}, this), "Apply Parameters & Bloom Rose"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 271,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 270,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 185,
						columnNumber: 11
					}, this),
					activeTab === "math" && /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-4 p-2 font-sans text-xs text-zinc-300",
						children: [
							/* @__PURE__ */ _jsxDEV("h4", {
								className: "text-sm font-semibold text-rose-300 flex items-center gap-1.5",
								children: [/* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 285,
									columnNumber: 15
								}, this), " The Creative Coding Mathematics"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 284,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "leading-relaxed",
								children: "How does code turn simple text strings into an organic, breathing floral sculpture?"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 287,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-3",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "p-3 rounded-xl bg-zinc-900/60 border border-zinc-800",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "font-semibold text-rose-400 block mb-1",
											children: "1. The Spiral Vortex (Bud Core)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 293,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-zinc-400",
											children: [
												"Calculated with Archimedean spirals: ",
												/* @__PURE__ */ _jsxDEV("span", {
													className: "font-mono text-rose-300",
													children: "r(θ) = a + b·θ"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 297,
													columnNumber: 56
												}, this),
												". Phrases wrap inward at accelerating angular velocity to create the tight velvety center."
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 296,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 292,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "p-3 rounded-xl bg-zinc-900/60 border border-zinc-800",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "font-semibold text-rose-400 block mb-1",
											children: "2. Petal Arcs (Cardioid Envelopes)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 303,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-zinc-400",
											children: [
												"Petal contours use modified cardioid parametric curves:",
												/* @__PURE__ */ _jsxDEV("span", {
													className: "font-mono text-rose-300 block my-1",
													children: "x = r·cos(θ) · (1 - sin(θ)), \xA0 y = r·sin(θ)"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 308,
													columnNumber: 19
												}, this),
												"Each word is positioned along the curve with its rotation aligned to the curve's tangent:",
												/* @__PURE__ */ _jsxDEV("span", {
													className: "font-mono text-rose-300 block my-1",
													children: "angle = atan2(dy, dx)"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 312,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 306,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 302,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "p-3 rounded-xl bg-zinc-900/60 border border-zinc-800",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "font-semibold text-rose-400 block mb-1",
											children: "3. The Organic Stem & Leaves"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 319,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-zinc-400",
											children: "Modeled as cubic Bezier splines with sinusoidal S-curve offsets simulating natural plant phototropism."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 322,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 318,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 291,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 283,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 121,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center justify-between px-4 py-1.5 bg-[#0a050a] border-t border-rose-950 text-[10px] text-zinc-500 font-mono",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV(Terminal, { className: "w-3 h-3 text-emerald-400" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 334,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Python 3.12 (Tkinter / Turtle Engine)" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 335,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 333,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ _jsxDEV("span", { children: "UTF-8" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 338,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "text-rose-400 font-semibold",
						children: "60+ Languages"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 339,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 337,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 332,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 42,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLDBCQUF3QztBQUNqRCxTQUFTLE1BQU0sT0FBTyxVQUFVLFVBQVUsTUFBTSxVQUFVLFVBQVUsZUFBZTs7O0FBUW5GLE9BQU8sTUFBTSxjQUF5QyxFQUFFLFFBQVEsZ0JBQWdCLGdCQUFnQjtDQUM5RixNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsS0FBSztDQUMxQyxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBcUMsTUFBTTtDQUU3RSxNQUFNLGFBQWEsbUJBQW1CLE1BQU07Q0FFNUMsTUFBTSxhQUFhLFlBQVk7RUFDN0IsSUFBSTtHQUNGLE1BQU0sVUFBVSxVQUFVLFVBQVUsVUFBVTtHQUM5QyxVQUFVLElBQUk7R0FDZCxpQkFBaUIsVUFBVSxLQUFLLEdBQUcsSUFBSTtFQUN6QyxRQUFRLENBRVI7Q0FDRjtDQUVBLE1BQU0sV0FBVyxJQUFJLE9BQU8sYUFBYSxTQUFRLENBQUUsWUFBWSxDQUFDLENBQUMsUUFBUSxRQUFRLEdBQUcsRUFBRTtDQUV0RixNQUFNLHVCQUF1QjtFQUMzQixNQUFNLE9BQU8sSUFBSSxLQUFLLENBQUMsVUFBVSxHQUFHLEVBQUUsTUFBTSwrQkFBK0IsQ0FBQztFQUM1RSxNQUFNLE1BQU0sSUFBSSxnQkFBZ0IsSUFBSTtFQUNwQyxNQUFNLE9BQU8sU0FBUyxjQUFjLEdBQUc7RUFDdkMsS0FBSyxPQUFPO0VBQ1osS0FBSyxXQUFXO0VBQ2hCLFNBQVMsS0FBSyxZQUFZLElBQUk7RUFDOUIsS0FBSyxNQUFNO0VBQ1gsU0FBUyxLQUFLLFlBQVksSUFBSTtFQUM5QixJQUFJLGdCQUFnQixHQUFHO0NBQ3pCO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBRUUsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBRUUsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxRQUFELEVBQU0sV0FBVSxtREFBb0Q7Ozs7O1FBQ3BFLHdCQUFDLFFBQUQsRUFBTSxXQUFVLG9EQUFxRDs7Ozs7UUFDckUsd0JBQUMsUUFBRCxFQUFNLFdBQVUsc0RBQXVEOzs7OztPQUNwRTs7Ozs7Z0JBRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxjQUFlOzs7O2lCQUNuQyx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaUI7T0FBZTs7OztlQUM3Qzs7Ozs7Y0FDRjs7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxVQUFEO1FBQ0UsZUFBZSxhQUFhLE1BQU07UUFDbEMsV0FBVyxpRUFDVCxjQUFjLFNBQVMsaUNBQWlDO2tCQUUzRDtPQUVPOzs7OztPQUNSLHdCQUFDLFVBQUQ7UUFDRSxlQUFlLGFBQWEsUUFBUTtRQUNwQyxXQUFXLHlGQUNULGNBQWMsV0FBVyxpQ0FBaUM7a0JBSDlELENBTUUsd0JBQUMsU0FBRCxFQUFTLFdBQVUsVUFBVzs7OztrQkFBQyxRQUV6Qjs7Ozs7O09BQ1Isd0JBQUMsVUFBRDtRQUNFLGVBQWUsYUFBYSxNQUFNO1FBQ2xDLFdBQVcseUZBQ1QsY0FBYyxTQUFTLGlDQUFpQztrQkFINUQsQ0FNRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxVQUFXOzs7O2tCQUFDLE1BRTFCOzs7Ozs7TUFDTDs7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxVQUFEO1FBQ0UsU0FBUztRQUNULFdBQVU7UUFDVixPQUFNO2tCQUhSLENBS0Usd0JBQUMsTUFBRCxFQUFNLFdBQVUsdUJBQXdCOzs7O2tCQUN4Qyx3QkFBQyxRQUFELFlBQU0sU0FBWTs7OztnQkFDWjs7Ozs7O09BRVIsd0JBQUMsVUFBRDtRQUNFLFNBQVM7UUFDVCxXQUFVO1FBQ1YsT0FBTTtrQkFIUixDQUtHLFNBQVMsd0JBQUMsT0FBRCxFQUFPLFdBQVUsMkJBQTRCOzs7O21CQUFJLHdCQUFDLE1BQUQsRUFBTSxXQUFVLFVBQVc7Ozs7a0JBQ3RGLHdCQUFDLFFBQUQsWUFBTyxTQUFTLFlBQVksT0FBYTs7OztnQkFDbkM7Ozs7OztPQUVSLHdCQUFDLFVBQUQ7UUFDRSxTQUFTO1FBQ1QsV0FBVTtRQUNWLE9BQU07a0JBSFIsQ0FLRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxVQUFXOzs7O2tCQUMvQix3QkFBQyxRQUFELFlBQU0sTUFBUzs7OztnQkFDVDs7Ozs7O01BQ0w7Ozs7OztJQUNGOzs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0csY0FBYyxVQUNiLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBRUUsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ1osV0FBVyxNQUFNLElBQUksQ0FBQyxDQUFDLEtBQUssR0FBRyxNQUM5Qix3QkFBQyxPQUFELFlBQWMsSUFBSSxFQUFPLEdBQWY7Ozs7Y0FBZSxDQUMxQjtNQUNFOzs7O2dCQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLFFBQUQsWUFDRyxXQUFXLE1BQU0sSUFBSSxDQUFDLENBQUMsS0FBSyxNQUFNLFFBQVE7UUFDekMsSUFBSSxZQUFZOztRQUVoQixJQUFJLEtBQUssS0FBSyxDQUFDLENBQUMsV0FBVyxHQUFHLEtBQUssS0FBSyxLQUFLLENBQUMsQ0FBQyxXQUFXLFFBQUssR0FBRztTQUNoRSxPQUNFLHdCQUFDLE9BQUQ7VUFBZSxXQUFVO29CQUN0QjtTQUNFLEdBRks7Ozs7Z0JBRUw7UUFFVDs7UUFFQSxJQUFJLEtBQUssU0FBUyxTQUFTLEtBQUssS0FBSyxTQUFTLE9BQU8sR0FBRztTQUN0RCxPQUNFLHdCQUFDLE9BQUQ7VUFBZSxXQUFVO29CQUN0QjtTQUNFLEdBRks7Ozs7Z0JBRUw7UUFFVDtRQUNBLElBQUksS0FBSyxTQUFTLFFBQVEsS0FBSyxLQUFLLFNBQVMsTUFBTSxHQUFHO1NBQ3BELE9BQ0Usd0JBQUMsT0FBRDtVQUFlLFdBQVU7b0JBQ3RCO1NBQ0UsR0FGSzs7OztnQkFFTDtRQUVUO1FBQ0EsSUFBSSxLQUFLLFNBQVMsYUFBYSxHQUFHO1NBQ2hDLE9BQ0Usd0JBQUMsT0FBRDtVQUFlLFdBQVU7b0JBQ3RCO1NBQ0UsR0FGSzs7OztnQkFFTDtRQUVUO1FBQ0EsSUFBSSxLQUFLLFNBQVMsZ0JBQWMsS0FBSyxLQUFLLFNBQVMsZUFBYyxLQUFLLEtBQUssU0FBUyxXQUFXLEdBQUc7U0FDaEcsT0FDRSx3QkFBQyxPQUFEO1VBQWUsV0FBVTtvQkFDdEI7U0FDRSxHQUZLOzs7O2dCQUVMO1FBRVQ7UUFDQSxPQUNFLHdCQUFDLE9BQUQ7U0FBZSxXQUFVO21CQUN0QjtRQUNFLEdBRks7Ozs7ZUFFTDtPQUVULENBQUMsRUFDRzs7Ozs7TUFDSDs7OztjQUNGOzs7Ozs7S0FHTixjQUFjLFlBQ2Isd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWQsQ0FDRSx3QkFBQyxTQUFELEVBQVMsV0FBVSxVQUFXOzs7O2tCQUFDLDRCQUM3Qjs7Ozs7aUJBQ0osd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQXdCO09BRWxDOzs7O2VBQ0E7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FFRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQTRCO1dBQTRCOzs7O3FCQUN4RSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBaEIsQ0FBcUQsT0FBTyxVQUFTLEdBQU87Ozs7O21CQUN6RTs7Ozs7b0JBQ0wsd0JBQUMsU0FBRDtXQUNFLE1BQUs7V0FDTCxLQUFJO1dBQ0osS0FBSTtXQUNKLE1BQUs7V0FDTCxPQUFPLE9BQU87V0FDZCxXQUFXLE1BQ1QsZUFBZTtZQUFFLEdBQUc7WUFBUSxVQUFVLE9BQU8sRUFBRSxPQUFPLEtBQUs7V0FBRSxDQUFDO1dBRWhFLFdBQVU7VUFDWDs7OztrQkFDRTs7Ozs7O1NBR0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUE0QjtXQUE4Qjs7OztxQkFDMUUsd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQWhCLENBQXFELE9BQU8sT0FBTSxHQUFPOzs7OzttQkFDdEU7Ozs7O29CQUNMLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsS0FBSTtXQUNKLEtBQUk7V0FDSixNQUFLO1dBQ0wsT0FBTyxPQUFPO1dBQ2QsV0FBVyxNQUNULGVBQWU7WUFBRSxHQUFHO1lBQVEsT0FBTyxPQUFPLEVBQUUsT0FBTyxLQUFLO1dBQUUsQ0FBQztXQUU3RCxXQUFVO1VBQ1g7Ozs7a0JBQ0U7Ozs7OztTQUdMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBNEI7V0FBMEI7Ozs7cUJBQ3RFLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFoQixDQUFxRCxPQUFPLEtBQUksS0FBUzs7Ozs7bUJBQ3RFOzs7OztvQkFDTCx3QkFBQyxTQUFEO1dBQ0UsTUFBSztXQUNMLEtBQUk7V0FDSixLQUFJO1dBQ0osTUFBSztXQUNMLE9BQU8sT0FBTztXQUNkLFdBQVcsTUFDVCxlQUFlO1lBQUUsR0FBRztZQUFRLEtBQUssT0FBTyxFQUFFLE9BQU8sS0FBSztXQUFFLENBQUM7V0FFM0QsV0FBVTtVQUNYOzs7O2tCQUNFOzs7Ozs7U0FHTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFNBQUQ7V0FBTyxXQUFVO3FCQUFpRDtVQUUzRDs7OztvQkFDUCx3QkFBQyxTQUFEO1dBQ0UsTUFBSztXQUNMLE9BQU8sT0FBTztXQUNkLFdBQVcsTUFDVCxlQUFlO1lBQUUsR0FBRztZQUFRLGVBQWUsRUFBRSxPQUFPO1dBQU0sQ0FBQztXQUU3RCxhQUFZO1dBQ1osV0FBVTtVQUNYOzs7O2tCQUNFOzs7Ozs7UUFDRjs7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMsVUFBRDtTQUNFLFNBQVM7U0FDVCxXQUFVO21CQUZaLENBSUUsd0JBQUMsTUFBRCxFQUFNLFdBQVUsdUJBQXdCOzs7O21CQUFDLCtCQUVuQzs7Ozs7O09BQ0w7Ozs7O01BQ0Y7Ozs7OztLQUdOLGNBQWMsVUFDYix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFkLENBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsVUFBVzs7OztrQkFBQyxrQ0FDOUI7Ozs7OztPQUNKLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFrQjtPQUU1Qjs7Ozs7T0FFSCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQXlDO1VBRW5EOzs7O29CQUNOLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUFiO1lBQTZCO1lBQ1Usd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQTBCO1lBQW9COzs7OztZQUFDO1dBRW5HOzs7OztrQkFDQTs7Ozs7O1NBRUwsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBeUM7VUFFbkQ7Ozs7b0JBQ04sd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQWI7WUFBNkI7WUFFM0Isd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQXFDO1lBRS9DOzs7OztZQUFDO1lBRVAsd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQXFDO1lBRS9DOzs7OztXQUNMOzs7OztrQkFDQTs7Ozs7O1NBRUwsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBeUM7VUFFbkQ7Ozs7b0JBQ04sd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQWdCO1VBRTFCOzs7O2tCQUNBOzs7Ozs7UUFDRjs7Ozs7O01BQ0Y7Ozs7OztJQUVKOzs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLDJCQUE0Qjs7OztlQUNoRCx3QkFBQyxRQUFELFlBQU0sd0NBQTJDOzs7O2FBQzlDOzs7OztjQUNMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU0sUUFBVzs7OztlQUNqQix3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBOEI7S0FBbUI7Ozs7YUFDOUQ7Ozs7O1lBQ0Y7Ozs7OztFQUNGOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJDb2RlVmlld2VyLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBnZW5lcmF0ZVB5dGhvbkNvZGUsIFB5dGhvbkNvbmZpZyB9IGZyb20gJy4uL3V0aWxzL3B5dGhvblNjcmlwdCc7XG5pbXBvcnQgeyBDb3B5LCBDaGVjaywgRG93bmxvYWQsIFRlcm1pbmFsLCBQbGF5LCBTcGFya2xlcywgRmlsZUNvZGUsIFNsaWRlcnMgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuXG5pbnRlcmZhY2UgQ29kZVZpZXdlclByb3BzIHtcbiAgY29uZmlnOiBQeXRob25Db25maWc7XG4gIG9uQ29uZmlnQ2hhbmdlOiAobmV3Q29uZmlnOiBQeXRob25Db25maWcpID0+IHZvaWQ7XG4gIG9uUnVuQ29kZTogKCkgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGNvbnN0IENvZGVWaWV3ZXI6IFJlYWN0LkZDPENvZGVWaWV3ZXJQcm9wcz4gPSAoeyBjb25maWcsIG9uQ29uZmlnQ2hhbmdlLCBvblJ1bkNvZGUgfSkgPT4ge1xuICBjb25zdCBbY29waWVkLCBzZXRDb3BpZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbYWN0aXZlVGFiLCBzZXRBY3RpdmVUYWJdID0gdXNlU3RhdGU8J2NvZGUnIHwgJ3BhcmFtcycgfCAnbWF0aCc+KCdjb2RlJyk7XG5cbiAgY29uc3QgcHl0aG9uQ29kZSA9IGdlbmVyYXRlUHl0aG9uQ29kZShjb25maWcpO1xuXG4gIGNvbnN0IGhhbmRsZUNvcHkgPSBhc3luYyAoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IG5hdmlnYXRvci5jbGlwYm9hcmQud3JpdGVUZXh0KHB5dGhvbkNvZGUpO1xuICAgICAgc2V0Q29waWVkKHRydWUpO1xuICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRDb3BpZWQoZmFsc2UpLCAyMjAwKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIC8vIEZhbGxiYWNrXG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGZpbGVOYW1lID0gYCR7KGNvbmZpZy50aGVtZU5hbWUgfHwgJ2Zsb3dlcicpLnRvTG93ZXJDYXNlKCkucmVwbGFjZSgvXFxzKy9nLCAnXycpfV9vZl9sb3ZlLnB5YDtcblxuICBjb25zdCBoYW5kbGVEb3dubG9hZCA9ICgpID0+IHtcbiAgICBjb25zdCBibG9iID0gbmV3IEJsb2IoW3B5dGhvbkNvZGVdLCB7IHR5cGU6ICd0ZXh0L3gtcHl0aG9uO2NoYXJzZXQ9dXRmLTg7JyB9KTtcbiAgICBjb25zdCB1cmwgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpO1xuICAgIGNvbnN0IGxpbmsgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XG4gICAgbGluay5ocmVmID0gdXJsO1xuICAgIGxpbmsuZG93bmxvYWQgPSBmaWxlTmFtZTtcbiAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGxpbmspO1xuICAgIGxpbmsuY2xpY2soKTtcbiAgICBkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKGxpbmspO1xuICAgIFVSTC5yZXZva2VPYmplY3RVUkwodXJsKTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBoLWZ1bGwgYmctWyMwZDA5MGRdIGJvcmRlciBib3JkZXItcm9zZS05MDAvMzAgcm91bmRlZC0yeGwgb3ZlcmZsb3ctaGlkZGVuIHNoYWRvdy0yeGxcIj5cbiAgICAgIHsvKiBFZGl0b3IgVG9wIEJhciAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB4LTQgcHktMi41IGJnLVsjMTQwYzEzXSBib3JkZXItYiBib3JkZXItcm9zZS05MDAvMzAgdGV4dC14cyB0ZXh0LXppbmMtNDAwIHNlbGVjdC1ub25lXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICB7LyogTWFjLXN0eWxlIHRyYWZmaWMgbGlnaHRzICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBtci0yXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTMgaC0zIHJvdW5kZWQtZnVsbCBiZy1yb3NlLTUwMC84MCBpbmxpbmUtYmxvY2tcIiAvPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0zIGgtMyByb3VuZGVkLWZ1bGwgYmctYW1iZXItNTAwLzgwIGlubGluZS1ibG9ja1wiIC8+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTMgaC0zIHJvdW5kZWQtZnVsbCBiZy1lbWVyYWxkLTUwMC84MCBpbmxpbmUtYmxvY2tcIiAvPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSB0ZXh0LXJvc2UtMzAwIGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgPEZpbGVDb2RlIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj57ZmlsZU5hbWV9PC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogVGFiIHN3aXRjaGVycyAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBiZy16aW5jLTkwMC84MCByb3VuZGVkLWxnIHAtMC41IGJvcmRlciBib3JkZXItemluYy04MDBcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoJ2NvZGUnKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTIuNSBweS0xIHJvdW5kZWQtbWQgdGV4dC1bMTFweF0gZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgYWN0aXZlVGFiID09PSAnY29kZScgPyAnYmctcm9zZS05MDAvNjAgdGV4dC1yb3NlLTIwMCcgOiAndGV4dC16aW5jLTQwMCBob3Zlcjp0ZXh0LXppbmMtMjAwJ1xuICAgICAgICAgICAgfWB9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgQ29kZVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYigncGFyYW1zJyl9XG4gICAgICAgICAgICBjbGFzc05hbWU9e2BweC0yLjUgcHktMSByb3VuZGVkLW1kIHRleHQtWzExcHhdIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tYWxsIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xICR7XG4gICAgICAgICAgICAgIGFjdGl2ZVRhYiA9PT0gJ3BhcmFtcycgPyAnYmctcm9zZS05MDAvNjAgdGV4dC1yb3NlLTIwMCcgOiAndGV4dC16aW5jLTQwMCBob3Zlcjp0ZXh0LXppbmMtMjAwJ1xuICAgICAgICAgICAgfWB9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFNsaWRlcnMgY2xhc3NOYW1lPVwidy0zIGgtM1wiIC8+XG4gICAgICAgICAgICBQYXJhbXNcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoJ21hdGgnKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTIuNSBweS0xIHJvdW5kZWQtbWQgdGV4dC1bMTFweF0gZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1hbGwgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgJHtcbiAgICAgICAgICAgICAgYWN0aXZlVGFiID09PSAnbWF0aCcgPyAnYmctcm9zZS05MDAvNjAgdGV4dC1yb3NlLTIwMCcgOiAndGV4dC16aW5jLTQwMCBob3Zlcjp0ZXh0LXppbmMtMjAwJ1xuICAgICAgICAgICAgfWB9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFNwYXJrbGVzIGNsYXNzTmFtZT1cInctMyBoLTNcIiAvPlxuICAgICAgICAgICAgTWF0aFxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogQWN0aW9uIGljb25zICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17b25SdW5Db2RlfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTEgYmctcm9zZS02MDAgaG92ZXI6Ymctcm9zZS01MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tYWxsIHNoYWRvdy1zbSBhY3RpdmU6c2NhbGUtOTVcIlxuICAgICAgICAgICAgdGl0bGU9XCJSZS1ydW4gYW5pbWF0aW9uIG9uIGNhbnZhc1wiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFBsYXkgY2xhc3NOYW1lPVwidy0zIGgtMyBmaWxsLWN1cnJlbnRcIiAvPlxuICAgICAgICAgICAgPHNwYW4+UmUtUnVuPC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ29weX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHB4LTIuNSBweS0xIGJnLXppbmMtOTAwIGhvdmVyOmJnLXppbmMtODAwIHRleHQtemluYy0zMDAgaG92ZXI6dGV4dC13aGl0ZSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItemluYy03MDAvNjAgdHJhbnNpdGlvbi1hbGwgdGV4dC1bMTFweF1cIlxuICAgICAgICAgICAgdGl0bGU9XCJDb3B5IHNjcmlwdFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAge2NvcGllZCA/IDxDaGVjayBjbGFzc05hbWU9XCJ3LTMgaC0zIHRleHQtZW1lcmFsZC00MDBcIiAvPiA6IDxDb3B5IGNsYXNzTmFtZT1cInctMyBoLTNcIiAvPn1cbiAgICAgICAgICAgIDxzcGFuPntjb3BpZWQgPyAnQ29waWVkIScgOiAnQ29weSd9PC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRG93bmxvYWR9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBweC0yLjUgcHktMSBiZy16aW5jLTkwMCBob3ZlcjpiZy16aW5jLTgwMCB0ZXh0LXppbmMtMzAwIGhvdmVyOnRleHQtd2hpdGUgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXppbmMtNzAwLzYwIHRyYW5zaXRpb24tYWxsIHRleHQtWzExcHhdXCJcbiAgICAgICAgICAgIHRpdGxlPVwiRG93bmxvYWQgLnB5IGZpbGVcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxEb3dubG9hZCBjbGFzc05hbWU9XCJ3LTMgaC0zXCIgLz5cbiAgICAgICAgICAgIDxzcGFuPi5weTwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIEVkaXRvciBDb250ZW50IEFyZWEgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBvdmVyZmxvdy1hdXRvIHAtNCBmb250LW1vbm8gdGV4dC14cyB0ZXh0LXppbmMtMzAwIGxlYWRpbmctcmVsYXhlZCBjdXN0b20tc2Nyb2xsYmFyXCI+XG4gICAgICAgIHthY3RpdmVUYWIgPT09ICdjb2RlJyAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4XCI+XG4gICAgICAgICAgICB7LyogTGluZSBudW1iZXJzICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwci00IG1yLTIgYm9yZGVyLXIgYm9yZGVyLXppbmMtODAwIHRleHQtemluYy02MDAgc2VsZWN0LW5vbmUgdGV4dC1yaWdodCBmb250LW1vbm8gdGV4dC1bMTFweF0gbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgIHtweXRob25Db2RlLnNwbGl0KCdcXG4nKS5tYXAoKF8sIGkpID0+IChcbiAgICAgICAgICAgICAgICA8ZGl2IGtleT17aX0+e2kgKyAxfTwvZGl2PlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogQ29kZSB0ZXh0IHdpdGggc3R5bGl6ZWQgaGlnaGxpZ2h0cyAqL31cbiAgICAgICAgICAgIDxwcmUgY2xhc3NOYW1lPVwiZmxleC0xIG92ZXJmbG93LXgtYXV0byB3aGl0ZXNwYWNlLXByZSBmb250LW1vbm8gdGV4dC1bMTEuNXB4XSBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgPGNvZGU+XG4gICAgICAgICAgICAgICAge3B5dGhvbkNvZGUuc3BsaXQoJ1xcbicpLm1hcCgobGluZSwgaWR4KSA9PiB7XG4gICAgICAgICAgICAgICAgICBsZXQgZm9ybWF0dGVkID0gbGluZTtcbiAgICAgICAgICAgICAgICAgIC8vIENvbW1lbnRzXG4gICAgICAgICAgICAgICAgICBpZiAobGluZS50cmltKCkuc3RhcnRzV2l0aCgnIycpIHx8IGxpbmUudHJpbSgpLnN0YXJ0c1dpdGgoJ1wiXCJcIicpKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2lkeH0gY2xhc3NOYW1lPVwidGV4dC16aW5jLTUwMCBpdGFsaWNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtsaW5lfVxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgLy8gS2V5d29yZCBoaWdobGlnaHRzXG4gICAgICAgICAgICAgICAgICBpZiAobGluZS5pbmNsdWRlcygnaW1wb3J0ICcpIHx8IGxpbmUuaW5jbHVkZXMoJ2Zyb20gJykpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17aWR4fSBjbGFzc05hbWU9XCJ0ZXh0LXJvc2UtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7bGluZX1cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIGlmIChsaW5lLmluY2x1ZGVzKCdjbGFzcyAnKSB8fCBsaW5lLmluY2x1ZGVzKCdkZWYgJykpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17aWR4fSBjbGFzc05hbWU9XCJ0ZXh0LXBpbmstMzAwIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtsaW5lfVxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgaWYgKGxpbmUuaW5jbHVkZXMoJ1BIUkFTRVMgPSBbJykpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17aWR4fSBjbGFzc05hbWU9XCJ0ZXh0LWFtYmVyLTMwMCBmb250LWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtsaW5lfVxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgaWYgKGxpbmUuaW5jbHVkZXMoJ1wiSSBsb3ZlIHlvdVwiJykgfHwgbGluZS5pbmNsdWRlcygnXCJKZSB0XFwnYWltZVwiJykgfHwgbGluZS5pbmNsdWRlcygnUkVDSVBJRU5UJykpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17aWR4fSBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7bGluZX1cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpZHh9IGNsYXNzTmFtZT1cInRleHQtemluYy0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7bGluZX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICA8L2NvZGU+XG4gICAgICAgICAgICA8L3ByZT5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cblxuICAgICAgICB7YWN0aXZlVGFiID09PSAncGFyYW1zJyAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTUgcC0yIGZvbnQtc2Fuc1wiPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXJvc2UtMzAwIG1iLTEgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgIDxTbGlkZXJzIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPiBMaXZlIFB5dGhvbiBDb25maWd1cmF0aW9uXG4gICAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC16aW5jLTQwMFwiPlxuICAgICAgICAgICAgICAgIEFkanVzdCB2YXJpYWJsZXMgaW4gdGhlIFB5dGhvbiBzY3JpcHQuIENoYW5nZXMgd2lsbCBkeW5hbWljYWxseSB1cGRhdGUgdGhlIHJlbmRlcmVkIGNhbnZhcyBhbmQgY29kZSBkb3dubG9hZC5cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxuICAgICAgICAgICAgICB7LyogRHVyYXRpb24gKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctemluYy05MDAvNjAgcC0zIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci16aW5jLTgwMFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC14cyBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtemluYy0zMDAgZm9udC1tZWRpdW1cIj5EVVJBVElPTiAoQmxvb20gU3BlZWQpPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yb3NlLTQwMCBmb250LW1vbm8gZm9udC1ib2xkXCI+e2NvbmZpZy5kdXJhdGlvbn1zPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInJhbmdlXCJcbiAgICAgICAgICAgICAgICAgIG1pbj1cIjNcIlxuICAgICAgICAgICAgICAgICAgbWF4PVwiMjVcIlxuICAgICAgICAgICAgICAgICAgc3RlcD1cIjFcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2NvbmZpZy5kdXJhdGlvbn1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cbiAgICAgICAgICAgICAgICAgICAgb25Db25maWdDaGFuZ2UoeyAuLi5jb25maWcsIGR1cmF0aW9uOiBOdW1iZXIoZS50YXJnZXQudmFsdWUpIH0pXG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYWNjZW50LXJvc2UtNTAwIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogU2NhbGUgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctemluYy05MDAvNjAgcC0zIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci16aW5jLTgwMFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC14cyBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtemluYy0zMDAgZm9udC1tZWRpdW1cIj5TQ0FMRSAoUm9zZSBQcm9wb3J0aW9ucyk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJvc2UtNDAwIGZvbnQtbW9ubyBmb250LWJvbGRcIj57Y29uZmlnLnNjYWxlfXg8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwicmFuZ2VcIlxuICAgICAgICAgICAgICAgICAgbWluPVwiMC43XCJcbiAgICAgICAgICAgICAgICAgIG1heD1cIjEuNFwiXG4gICAgICAgICAgICAgICAgICBzdGVwPVwiMC4wNVwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Y29uZmlnLnNjYWxlfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxuICAgICAgICAgICAgICAgICAgICBvbkNvbmZpZ0NoYW5nZSh7IC4uLmNvbmZpZywgc2NhbGU6IE51bWJlcihlLnRhcmdldC52YWx1ZSkgfSlcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBhY2NlbnQtcm9zZS01MDAgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBUZXh0IFNwYWNpbmcgR2FwICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXppbmMtOTAwLzYwIHAtMyByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItemluYy04MDBcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQteHMgbWItMS41XCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXppbmMtMzAwIGZvbnQtbWVkaXVtXCI+R0FQIChQaHJhc2UgU3BhY2luZyk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJvc2UtNDAwIGZvbnQtbW9ubyBmb250LWJvbGRcIj57Y29uZmlnLmdhcH0gcHg8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwicmFuZ2VcIlxuICAgICAgICAgICAgICAgICAgbWluPVwiMVwiXG4gICAgICAgICAgICAgICAgICBtYXg9XCI4XCJcbiAgICAgICAgICAgICAgICAgIHN0ZXA9XCIxXCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtjb25maWcuZ2FwfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxuICAgICAgICAgICAgICAgICAgICBvbkNvbmZpZ0NoYW5nZSh7IC4uLmNvbmZpZywgZ2FwOiBOdW1iZXIoZS50YXJnZXQudmFsdWUpIH0pXG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYWNjZW50LXJvc2UtNTAwIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogUmVjaXBpZW50IE5hbWUgaW4gQ29kZSAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy16aW5jLTkwMC82MCBwLTMgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXppbmMtODAwXCI+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtemluYy0zMDAgZm9udC1tZWRpdW0gdGV4dC14cyBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIFJFQ0lQSUVOVCAoRGVkaWNhdGVkIE5hbWUpXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtjb25maWcucmVjaXBpZW50TmFtZX1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cbiAgICAgICAgICAgICAgICAgICAgb25Db25maWdDaGFuZ2UoeyAuLi5jb25maWcsIHJlY2lwaWVudE5hbWU6IGUudGFyZ2V0LnZhbHVlIH0pXG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gTXkgTG92ZSwgU29waGlhLCBBbGV4XCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTEuNSByb3VuZGVkLWxnIGJnLXppbmMtOTUwIGJvcmRlciBib3JkZXItemluYy03MDAgdGV4dC14cyB0ZXh0LXJvc2UtMjAwIHBsYWNlaG9sZGVyLXppbmMtNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItcm9zZS01MDBcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtMlwiPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17b25SdW5Db2RlfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0yLjUgcm91bmRlZC14bCBiZy1ncmFkaWVudC10by1yIGZyb20tcm9zZS02MDAgdG8tcGluay02MDAgaG92ZXI6ZnJvbS1yb3NlLTUwMCBob3Zlcjp0by1waW5rLTUwMCB0ZXh0LXdoaXRlIGZvbnQtbWVkaXVtIHRleHQteHMgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgc2hhZG93LWxnIHNoYWRvdy1yb3NlLTk1MCBhY3RpdmU6c2NhbGUtOTggdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFBsYXkgY2xhc3NOYW1lPVwidy00IGgtNCBmaWxsLWN1cnJlbnRcIiAvPlxuICAgICAgICAgICAgICAgIEFwcGx5IFBhcmFtZXRlcnMgJiBCbG9vbSBSb3NlXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ21hdGgnICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNCBwLTIgZm9udC1zYW5zIHRleHQteHMgdGV4dC16aW5jLTMwMFwiPlxuICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXJvc2UtMzAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgPFNwYXJrbGVzIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPiBUaGUgQ3JlYXRpdmUgQ29kaW5nIE1hdGhlbWF0aWNzXG4gICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgIEhvdyBkb2VzIGNvZGUgdHVybiBzaW1wbGUgdGV4dCBzdHJpbmdzIGludG8gYW4gb3JnYW5pYywgYnJlYXRoaW5nIGZsb3JhbCBzY3VscHR1cmU/XG4gICAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIHJvdW5kZWQteGwgYmctemluYy05MDAvNjAgYm9yZGVyIGJvcmRlci16aW5jLTgwMFwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1yb3NlLTQwMCBibG9jayBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICAxLiBUaGUgU3BpcmFsIFZvcnRleCAoQnVkIENvcmUpXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtemluYy00MDBcIj5cbiAgICAgICAgICAgICAgICAgIENhbGN1bGF0ZWQgd2l0aCBBcmNoaW1lZGVhbiBzcGlyYWxzOiA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1yb3NlLTMwMFwiPnIozrgpID0gYSArIGLCt864PC9zcGFuPi5cbiAgICAgICAgICAgICAgICAgIFBocmFzZXMgd3JhcCBpbndhcmQgYXQgYWNjZWxlcmF0aW5nIGFuZ3VsYXIgdmVsb2NpdHkgdG8gY3JlYXRlIHRoZSB0aWdodCB2ZWx2ZXR5IGNlbnRlci5cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIHJvdW5kZWQteGwgYmctemluYy05MDAvNjAgYm9yZGVyIGJvcmRlci16aW5jLTgwMFwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1yb3NlLTQwMCBibG9jayBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICAyLiBQZXRhbCBBcmNzIChDYXJkaW9pZCBFbnZlbG9wZXMpXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtemluYy00MDBcIj5cbiAgICAgICAgICAgICAgICAgIFBldGFsIGNvbnRvdXJzIHVzZSBtb2RpZmllZCBjYXJkaW9pZCBwYXJhbWV0cmljIGN1cnZlczpcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXJvc2UtMzAwIGJsb2NrIG15LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgeCA9IHLCt2NvcyjOuCkgwrcgKDEgLSBzaW4ozrgpKSwgJm5ic3A7IHkgPSBywrdzaW4ozrgpXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICBFYWNoIHdvcmQgaXMgcG9zaXRpb25lZCBhbG9uZyB0aGUgY3VydmUgd2l0aCBpdHMgcm90YXRpb24gYWxpZ25lZCB0byB0aGUgY3VydmUncyB0YW5nZW50OlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtcm9zZS0zMDAgYmxvY2sgbXktMVwiPlxuICAgICAgICAgICAgICAgICAgICBhbmdsZSA9IGF0YW4yKGR5LCBkeClcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIHJvdW5kZWQteGwgYmctemluYy05MDAvNjAgYm9yZGVyIGJvcmRlci16aW5jLTgwMFwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1yb3NlLTQwMCBibG9jayBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICAzLiBUaGUgT3JnYW5pYyBTdGVtICYgTGVhdmVzXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtemluYy00MDBcIj5cbiAgICAgICAgICAgICAgICAgIE1vZGVsZWQgYXMgY3ViaWMgQmV6aWVyIHNwbGluZXMgd2l0aCBzaW51c29pZGFsIFMtY3VydmUgb2Zmc2V0cyBzaW11bGF0aW5nIG5hdHVyYWwgcGxhbnQgcGhvdG90cm9waXNtLlxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogVGVybWluYWwgc3RhdHVzIGJhciAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB4LTQgcHktMS41IGJnLVsjMGEwNTBhXSBib3JkZXItdCBib3JkZXItcm9zZS05NTAgdGV4dC1bMTBweF0gdGV4dC16aW5jLTUwMCBmb250LW1vbm9cIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgIDxUZXJtaW5hbCBjbGFzc05hbWU9XCJ3LTMgaC0zIHRleHQtZW1lcmFsZC00MDBcIiAvPlxuICAgICAgICAgIDxzcGFuPlB5dGhvbiAzLjEyIChUa2ludGVyIC8gVHVydGxlIEVuZ2luZSk8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgPHNwYW4+VVRGLTg8L3NwYW4+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yb3NlLTQwMCBmb250LXNlbWlib2xkXCI+NjArIExhbmd1YWdlczwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=