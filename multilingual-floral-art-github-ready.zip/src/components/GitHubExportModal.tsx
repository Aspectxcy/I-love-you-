const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const JSZip = __vite__cjsImport1_jszip;const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=3ba6436c";
import __vite__cjsImport1_jszip from "/node_modules/.vite/deps/jszip.js?v=3ba6436c";
import { Download, Github, Check, Copy, Terminal, FolderArchive, FileCode, CheckCircle2 } from "/node_modules/.vite/deps/lucide-react.js?v=3ba6436c";
import { generatePythonCode } from "/src/utils/pythonScript.ts";
var _jsxFileName = "/app/applet/src/components/GitHubExportModal.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3ba6436c";
export const GitHubExportModal = ({ isOpen, onClose, recipientName }) => {
	const [isExporting, setIsExporting] = useState(false);
	const [downloadSuccess, setDownloadSuccess] = useState(false);
	const [copiedCommands, setCopiedCommands] = useState(false);
	const [repoName, setRepoName] = useState("multilingual-floral-art");
	if (!isOpen) return null;
	const gitCommands = `# 1. Initialize git repository
git init
git add .
git commit -m "feat: Multilingual Flowers In Every Language 🌸"

# 2. Push to GitHub using GitHub CLI (Fastest):
gh repo create ${repoName} --public --source=. --push

# OR using standard Git remote:
# git remote add origin https://github.com/YOUR_USERNAME/${repoName}.git
# git branch -M main
# git push -u origin main`;
	const handleCopyCommands = async () => {
		try {
			await navigator.clipboard.writeText(gitCommands);
			setCopiedCommands(true);
			setTimeout(() => setCopiedCommands(false), 2200);
		} catch {}
	};
	const handleDownloadZip = async () => {
		setIsExporting(true);
		try {
			const zip = new JSZip();
			// 1. README.md
			const readmeContent = `# Pink Rose In Every Language 🌹

> *"What if a single rose could say 'I love you' in 60+ world languages?"*

An interactive creative coding art experience inspired by [@halo.ushaa](https://www.instagram.com/p/DejzdrYy0Za/), rendering blooming flowers (Pink Rose, Red Rose, Pink Lily, Sunflower, Royal Tulip) entirely from multilingual declarations of love.

![Preview](https://raw.githubusercontent.com/ayazsobhan/assets/main/rose-preview.png)

## ✨ Features

- **Multilingual Typographic Art**: Flowers composed entirely of horizontal, razor-sharp "I love you" phrases in 60+ languages (French, Japanese, Spanish, Hindi, Tagalog, Arabic, Swahili, Telugu, Russian, etc.).
- **Interactive Audio & Pronunciation**: Click/hover on any word to hear speech synthesis pronunciation, country flags, and romantic cultural lore.
- **Parametric Bloom Animation**: Play, pause, or scrub through the biological bloom timeline from root sprout to full star blossom.
- **Flower Switcher**: Pink Rose, Classic Red Rose, Stargazer Lily, Golden Sunflower, Royal Tulip, and Moonlight White Rose.
- **Python Creative Coding Studio**: Includes standalone runnable Python Tkinter scripts (\`pink_rose.py\`, \`pink_lily.py\`).
- **Love Dedication Cards**: Inscribe a loved one's name into the flower heart and export shareable postcards.

## 🚀 Running the Web App Locally

\`\`\`bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/${repoName}.git
cd ${repoName}

# Install dependencies
npm install

# Start development server
npm run dev
\`\`\`

Open [http://localhost:3000](http://localhost:3000) in your browser.

## 🐍 Running Standalone Python Tkinter Scripts

You can also run the Python script directly on your computer (no web browser required):

\`\`\`bash
python3 pink_rose.py
\`\`\`

## 📜 License

MIT License. Created with love for creative coders worldwide.
`;
			zip.file("README.md", readmeContent);
			// 2. LICENSE (MIT)
			const licenseContent = `MIT License

Copyright (c) 2026 Creative Coder

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.
`;
			zip.file("LICENSE", licenseContent);
			// 3. .gitignore
			const gitignoreContent = `node_modules/
dist/
dist-ssr/
*.local
.env
.DS_Store
`;
			zip.file(".gitignore", gitignoreContent);
			// 4. Standalone Python scripts
			zip.file("pink_rose.py", generatePythonCode({
				width: 600,
				height: 800,
				duration: 10,
				gap: 3,
				scale: 1,
				flowerType: "rose",
				themeName: "Pink Rose",
				recipientName
			}));
			zip.file("pink_lily.py", generatePythonCode({
				width: 600,
				height: 800,
				duration: 10,
				gap: 3,
				scale: 1,
				flowerType: "lily",
				themeName: "Pink Lily",
				recipientName
			}));
			// 5. Fetch project source files from the current applet
			const filePaths = [
				"package.json",
				"tsconfig.json",
				"vite.config.ts",
				"index.html",
				"src/main.tsx",
				"src/App.tsx",
				"src/index.css",
				"src/data/languages.ts",
				"src/data/roseExactData.ts",
				"src/data/lilyExactData.ts",
				"src/utils/exactRoseGenerator.ts",
				"src/utils/flowerShapes.ts",
				"src/utils/lilyGenerator.ts",
				"src/utils/roseGenerator.ts",
				"src/utils/pythonScript.ts",
				"src/utils/audioSynthesizer.ts",
				"src/utils/tumAudioSynthesizer.ts",
				"src/components/RoseCanvas.tsx",
				"src/components/RoseControls.tsx",
				"src/components/TumAudioPlayer.tsx",
				"src/components/PhraseCard.tsx",
				"src/components/CodeViewer.tsx",
				"src/components/LanguageExplorer.tsx",
				"src/components/CardExportModal.tsx",
				"src/components/GitHubExportModal.tsx"
			];
			for (const p of filePaths) {
				try {
					const res = await fetch(`/${p}`);
					if (res.ok) {
						const text = await res.text();
						zip.file(p, text);
					}
				} catch {}
			}
			// Generate ZIP blob and trigger download
			const blob = await zip.generateAsync({ type: "blob" });
			const url = URL.createObjectURL(blob);
			const link = document.createElement("a");
			link.href = url;
			link.download = `${repoName}-github-ready.zip`;
			document.body.appendChild(link);
			link.click();
			document.body.removeChild(link);
			URL.revokeObjectURL(url);
			setDownloadSuccess(true);
			setTimeout(() => setDownloadSuccess(false), 4e3);
		} catch (err) {
			console.error("Failed to create zip", err);
		} finally {
			setIsExporting(false);
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "relative w-full max-w-2xl bg-zinc-950 border border-zinc-800 rounded-3xl p-6 md:p-8 shadow-2xl text-rose-50 overflow-hidden flex flex-col max-h-[92vh]",
			children: [
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: onClose,
					className: "absolute top-5 right-5 p-2 rounded-full text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors z-10",
					children: "✕"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 221,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "text-center mb-6",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "inline-flex items-center gap-2 px-3 py-1 rounded-full bg-zinc-900 border border-zinc-700/80 text-xs font-semibold text-zinc-300 mb-2",
							children: [/* @__PURE__ */ _jsxDEV(Github, { className: "w-3.5 h-3.5 text-white" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 231,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "GitHub Repository Exporter" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 232,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 230,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-2xl font-bold font-display tracking-tight text-white",
							children: "Export Project to GitHub"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 234,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-zinc-400 mt-1 max-w-md mx-auto",
							children: "Download a ready-to-push repository ZIP with all code, Python scripts, README.md, and license included."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 237,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 229,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex-1 overflow-y-auto space-y-5 pr-1 custom-scrollbar",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-zinc-900/60 p-4 rounded-2xl border border-zinc-800",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-xs font-semibold text-zinc-300 mb-1.5",
								children: "GitHub Repository Name"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 246,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-mono text-zinc-500",
									children: "github.com/you/"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 250,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: repoName,
									onChange: (e) => setRepoName(e.target.value.toLowerCase().replace(/[^a-z0-9-_]/g, "-")),
									placeholder: "a-rose-made-of-love",
									className: "flex-1 px-3 py-1.5 rounded-xl bg-zinc-950 border border-zinc-700 text-xs text-white font-mono focus:outline-none focus:border-rose-500"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 251,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 249,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 245,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-4 rounded-2xl bg-gradient-to-br from-zinc-900 to-zinc-950 border border-zinc-800 flex flex-col md:flex-row items-center justify-between gap-4",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV(FolderArchive, { className: "w-4 h-4 text-emerald-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 265,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("h4", {
									className: "text-sm font-semibold text-white",
									children: "Download Complete GitHub Repository (.zip)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 266,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 264,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-zinc-400 mt-1",
								children: "Contains full TypeScript/React source, standalone Python scripts, README, .gitignore, and LICENSE."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 270,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 263,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: handleDownloadZip,
								disabled: isExporting,
								className: "flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-semibold shadow-lg shadow-emerald-950 transition-all shrink-0 active:scale-95 disabled:opacity-50",
								children: downloadSuccess ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 282,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Downloaded!" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 283,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 281,
									columnNumber: 17
								}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 287,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: isExporting ? "Generating ZIP..." : "Download Repo ZIP" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 288,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 286,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 275,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 262,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-zinc-900/60 p-4 rounded-2xl border border-zinc-800",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between mb-2",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2 text-xs font-semibold text-zinc-200",
									children: [/* @__PURE__ */ _jsxDEV(Terminal, { className: "w-3.5 h-3.5 text-rose-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 298,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Command Line Quick-Push" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 299,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 297,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: handleCopyCommands,
									className: "flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-[11px] text-zinc-200 font-medium transition-colors",
									children: [copiedCommands ? /* @__PURE__ */ _jsxDEV(Check, { className: "w-3 h-3 text-emerald-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 305,
										columnNumber: 35
									}, this) : /* @__PURE__ */ _jsxDEV(Copy, { className: "w-3 h-3" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 305,
										columnNumber: 84
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: copiedCommands ? "Copied Commands!" : "Copy Commands" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 306,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 301,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 296,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("pre", {
								className: "p-3 rounded-xl bg-black font-mono text-[11px] text-zinc-300 overflow-x-auto leading-relaxed border border-zinc-800",
								children: /* @__PURE__ */ _jsxDEV("code", { children: gitCommands }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 311,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 310,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 295,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-zinc-900/40 p-3.5 rounded-2xl border border-zinc-800/60 text-xs text-zinc-400",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-1.5 text-zinc-300 font-medium mb-1.5",
								children: [/* @__PURE__ */ _jsxDEV(FileCode, { className: "w-3.5 h-3.5 text-pink-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 318,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Included Files in GitHub Archive:" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 319,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 317,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-2 gap-y-1 gap-x-4 font-mono text-[11px] text-zinc-400",
								children: [
									/* @__PURE__ */ _jsxDEV("div", { children: "✓ README.md (Docs & Badges)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 322,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: "✓ pink_rose_of_love.py" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 323,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: "✓ pink_lily_of_love.py" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 324,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: "✓ src/ (All 6 Flowers & Audio)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 325,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: "✓ package.json & Vite config" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 326,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: "✓ MIT LICENSE & .gitignore" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 327,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 321,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 316,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 243,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "pt-4 border-t border-zinc-800 mt-4 flex items-center justify-between text-xs text-zinc-500",
					children: [/* @__PURE__ */ _jsxDEV("span", { children: "Ready for GitHub Pages, Vercel, or Netlify deployment" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 334,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						className: "px-4 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-white transition-colors",
						children: "Close"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 335,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 333,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 219,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 218,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxPQUFPLFdBQVc7QUFDbEIsU0FBUyxVQUFVLFFBQVEsT0FBTyxNQUFNLFVBQWtDLGVBQWUsVUFBVSxvQkFBb0I7QUFDdkgsU0FBUywwQkFBMEI7OztBQVFuQyxPQUFPLE1BQU0scUJBQXVELEVBQ2xFLFFBQ0EsU0FDQSxvQkFDSTtDQUNKLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEtBQUs7Q0FDcEQsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBUyxLQUFLO0NBQzVELE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQVMsS0FBSztDQUMxRCxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMseUJBQXlCO0NBRWxFLElBQUksQ0FBQyxRQUFRLE9BQU87Q0FFcEIsTUFBTSxjQUFjOzs7Ozs7aUJBTUwsU0FBUzs7OzJEQUdpQyxTQUFTOzs7Q0FJbEUsTUFBTSxxQkFBcUIsWUFBWTtFQUNyQyxJQUFJO0dBQ0YsTUFBTSxVQUFVLFVBQVUsVUFBVSxXQUFXO0dBQy9DLGtCQUFrQixJQUFJO0dBQ3RCLGlCQUFpQixrQkFBa0IsS0FBSyxHQUFHLElBQUk7RUFDakQsUUFBUSxDQUVSO0NBQ0Y7Q0FFQSxNQUFNLG9CQUFvQixZQUFZO0VBQ3BDLGVBQWUsSUFBSTtFQUNuQixJQUFJO0dBQ0YsTUFBTSxNQUFNLElBQUksTUFBTTs7R0FHdEIsTUFBTSxnQkFBZ0I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs2Q0FxQmlCLFNBQVM7S0FDakQsU0FBUzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7R0F1QlIsSUFBSSxLQUFLLGFBQWEsYUFBYTs7R0FHbkMsTUFBTSxpQkFBaUI7Ozs7Ozs7Ozs7Ozs7O0dBY3ZCLElBQUksS0FBSyxXQUFXLGNBQWM7O0dBR2xDLE1BQU0sbUJBQW1COzs7Ozs7O0dBT3pCLElBQUksS0FBSyxjQUFjLGdCQUFnQjs7R0FHdkMsSUFBSSxLQUNGLGdCQUNBLG1CQUFtQjtJQUNqQixPQUFPO0lBQ1AsUUFBUTtJQUNSLFVBQVU7SUFDVixLQUFLO0lBQ0wsT0FBTztJQUNQLFlBQVk7SUFDWixXQUFXO0lBQ1g7R0FDRixDQUFDLENBQ0g7R0FFQSxJQUFJLEtBQ0YsZ0JBQ0EsbUJBQW1CO0lBQ2pCLE9BQU87SUFDUCxRQUFRO0lBQ1IsVUFBVTtJQUNWLEtBQUs7SUFDTCxPQUFPO0lBQ1AsWUFBWTtJQUNaLFdBQVc7SUFDWDtHQUNGLENBQUMsQ0FDSDs7R0FHQSxNQUFNLFlBQVk7SUFDaEI7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7R0FDRjtHQUVBLEtBQUssTUFBTSxLQUFLLFdBQVc7SUFDekIsSUFBSTtLQUNGLE1BQU0sTUFBTSxNQUFNLE1BQU0sSUFBSSxHQUFHO0tBQy9CLElBQUksSUFBSSxJQUFJO01BQ1YsTUFBTSxPQUFPLE1BQU0sSUFBSSxLQUFLO01BQzVCLElBQUksS0FBSyxHQUFHLElBQUk7S0FDbEI7SUFDRixRQUFRLENBRVI7R0FDRjs7R0FHQSxNQUFNLE9BQU8sTUFBTSxJQUFJLGNBQWMsRUFBRSxNQUFNLE9BQU8sQ0FBQztHQUNyRCxNQUFNLE1BQU0sSUFBSSxnQkFBZ0IsSUFBSTtHQUNwQyxNQUFNLE9BQU8sU0FBUyxjQUFjLEdBQUc7R0FDdkMsS0FBSyxPQUFPO0dBQ1osS0FBSyxXQUFXLEdBQUcsU0FBUztHQUM1QixTQUFTLEtBQUssWUFBWSxJQUFJO0dBQzlCLEtBQUssTUFBTTtHQUNYLFNBQVMsS0FBSyxZQUFZLElBQUk7R0FDOUIsSUFBSSxnQkFBZ0IsR0FBRztHQUV2QixtQkFBbUIsSUFBSTtHQUN2QixpQkFBaUIsbUJBQW1CLEtBQUssR0FBRyxHQUFJO0VBQ2xELFNBQVMsS0FBSztHQUNaLFFBQVEsTUFBTSx3QkFBd0IsR0FBRztFQUMzQyxVQUFVO0dBQ1IsZUFBZSxLQUFLO0VBQ3RCO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQ2Isd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUVFLHdCQUFDLFVBQUQ7S0FDRSxTQUFTO0tBQ1QsV0FBVTtlQUNYO0lBRU87Ozs7O0lBR1Isd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUseUJBQTBCOzs7O2lCQUM1Qyx3QkFBQyxRQUFELFlBQU0sNkJBQWdDOzs7O2VBQ25DOzs7Ozs7TUFDTCx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBNEQ7TUFFdEU7Ozs7O01BQ0osd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQThDO01BRXhEOzs7OztLQUNBOzs7Ozs7SUFHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BRUUsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBbUQ7T0FFN0Q7Ozs7aUJBQ1Asd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBa0M7UUFBcUI7Ozs7a0JBQ3ZFLHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0wsT0FBTztTQUNQLFdBQVcsTUFBTSxZQUFZLEVBQUUsT0FBTyxNQUFNLFlBQVksQ0FBQyxDQUFDLFFBQVEsZ0JBQWdCLEdBQUcsQ0FBQztTQUN0RixhQUFZO1NBQ1osV0FBVTtRQUNYOzs7O2dCQUNFOzs7OztlQUNGOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLGVBQUQsRUFBZSxXQUFVLDJCQUE0Qjs7OztrQkFDckQsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQW1DO1FBRTdDOzs7O2dCQUNEOzs7OztpQkFDTCx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBNkI7T0FFdkM7Ozs7ZUFDQTs7OztpQkFFTCx3QkFBQyxVQUFEO1FBQ0UsU0FBUztRQUNULFVBQVU7UUFDVixXQUFVO2tCQUVULGtCQUNDLGdEQUNFLHdCQUFDLGNBQUQsRUFBYyxXQUFVLFVBQVc7Ozs7a0JBQ25DLHdCQUFDLFFBQUQsWUFBTSxjQUFpQjs7OztnQkFDdkI7Ozs7bUJBRUYsZ0RBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsVUFBVzs7OztrQkFDL0Isd0JBQUMsUUFBRCxZQUFPLGNBQWMsc0JBQXNCLG9CQUEwQjs7OztnQkFDckU7Ozs7O09BRUU7Ozs7ZUFDTDs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsNEJBQTZCOzs7O21CQUNqRCx3QkFBQyxRQUFELFlBQU0sMEJBQTZCOzs7O2lCQUNoQzs7Ozs7a0JBQ0wsd0JBQUMsVUFBRDtTQUNFLFNBQVM7U0FDVCxXQUFVO21CQUZaLENBSUcsaUJBQWlCLHdCQUFDLE9BQUQsRUFBTyxXQUFVLDJCQUE0Qjs7OztvQkFBSSx3QkFBQyxNQUFELEVBQU0sV0FBVSxVQUFXOzs7O21CQUM5Rix3QkFBQyxRQUFELFlBQU8saUJBQWlCLHFCQUFxQixnQkFBc0I7Ozs7aUJBQzdEOzs7OztnQkFDTDs7Ozs7aUJBRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMsUUFBRCxZQUFPLFlBQWtCOzs7OztPQUN0Qjs7OztlQUNGOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsNEJBQTZCOzs7O2tCQUNqRCx3QkFBQyxRQUFELFlBQU0sb0NBQXVDOzs7O2dCQUMxQzs7Ozs7aUJBQ0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxPQUFELFlBQUssOEJBQWdDOzs7OztTQUNyQyx3QkFBQyxPQUFELFlBQUsseUJBQTJCOzs7OztTQUNoQyx3QkFBQyxPQUFELFlBQUsseUJBQTJCOzs7OztTQUNoQyx3QkFBQyxPQUFELFlBQUssaUNBQW1DOzs7OztTQUN4Qyx3QkFBQyxPQUFELFlBQUssK0JBQWlDOzs7OztTQUN0Qyx3QkFBQyxPQUFELFlBQUssNkJBQStCOzs7OztRQUNqQzs7Ozs7ZUFDRjs7Ozs7O0tBQ0Y7Ozs7OztJQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU0sd0RBQTJEOzs7O2VBQ2pFLHdCQUFDLFVBQUQ7TUFDRSxTQUFTO01BQ1QsV0FBVTtnQkFDWDtLQUVPOzs7O2FBQ0w7Ozs7OztHQUNGOzs7Ozs7Q0FDRjs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJHaXRIdWJFeHBvcnRNb2RhbC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IEpTWmlwIGZyb20gJ2pzemlwJztcbmltcG9ydCB7IERvd25sb2FkLCBHaXRodWIsIENoZWNrLCBDb3B5LCBUZXJtaW5hbCwgRXh0ZXJuYWxMaW5rLCBTcGFya2xlcywgRm9sZGVyQXJjaGl2ZSwgRmlsZUNvZGUsIENoZWNrQ2lyY2xlMiB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyBnZW5lcmF0ZVB5dGhvbkNvZGUgfSBmcm9tICcuLi91dGlscy9weXRob25TY3JpcHQnO1xuXG5pbnRlcmZhY2UgR2l0SHViRXhwb3J0TW9kYWxQcm9wcyB7XG4gIGlzT3BlbjogYm9vbGVhbjtcbiAgb25DbG9zZTogKCkgPT4gdm9pZDtcbiAgcmVjaXBpZW50TmFtZTogc3RyaW5nO1xufVxuXG5leHBvcnQgY29uc3QgR2l0SHViRXhwb3J0TW9kYWw6IFJlYWN0LkZDPEdpdEh1YkV4cG9ydE1vZGFsUHJvcHM+ID0gKHtcbiAgaXNPcGVuLFxuICBvbkNsb3NlLFxuICByZWNpcGllbnROYW1lLFxufSkgPT4ge1xuICBjb25zdCBbaXNFeHBvcnRpbmcsIHNldElzRXhwb3J0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2Rvd25sb2FkU3VjY2Vzcywgc2V0RG93bmxvYWRTdWNjZXNzXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2NvcGllZENvbW1hbmRzLCBzZXRDb3BpZWRDb21tYW5kc10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtyZXBvTmFtZSwgc2V0UmVwb05hbWVdID0gdXNlU3RhdGUoJ211bHRpbGluZ3VhbC1mbG9yYWwtYXJ0Jyk7XG5cbiAgaWYgKCFpc09wZW4pIHJldHVybiBudWxsO1xuXG4gIGNvbnN0IGdpdENvbW1hbmRzID0gYCMgMS4gSW5pdGlhbGl6ZSBnaXQgcmVwb3NpdG9yeVxuZ2l0IGluaXRcbmdpdCBhZGQgLlxuZ2l0IGNvbW1pdCAtbSBcImZlYXQ6IE11bHRpbGluZ3VhbCBGbG93ZXJzIEluIEV2ZXJ5IExhbmd1YWdlIPCfjLhcIlxuXG4jIDIuIFB1c2ggdG8gR2l0SHViIHVzaW5nIEdpdEh1YiBDTEkgKEZhc3Rlc3QpOlxuZ2ggcmVwbyBjcmVhdGUgJHtyZXBvTmFtZX0gLS1wdWJsaWMgLS1zb3VyY2U9LiAtLXB1c2hcblxuIyBPUiB1c2luZyBzdGFuZGFyZCBHaXQgcmVtb3RlOlxuIyBnaXQgcmVtb3RlIGFkZCBvcmlnaW4gaHR0cHM6Ly9naXRodWIuY29tL1lPVVJfVVNFUk5BTUUvJHtyZXBvTmFtZX0uZ2l0XG4jIGdpdCBicmFuY2ggLU0gbWFpblxuIyBnaXQgcHVzaCAtdSBvcmlnaW4gbWFpbmA7XG5cbiAgY29uc3QgaGFuZGxlQ29weUNvbW1hbmRzID0gYXN5bmMgKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBuYXZpZ2F0b3IuY2xpcGJvYXJkLndyaXRlVGV4dChnaXRDb21tYW5kcyk7XG4gICAgICBzZXRDb3BpZWRDb21tYW5kcyh0cnVlKTtcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0Q29waWVkQ29tbWFuZHMoZmFsc2UpLCAyMjAwKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIC8vIGZhbGxiYWNrXG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZURvd25sb2FkWmlwID0gYXN5bmMgKCkgPT4ge1xuICAgIHNldElzRXhwb3J0aW5nKHRydWUpO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB6aXAgPSBuZXcgSlNaaXAoKTtcblxuICAgICAgLy8gMS4gUkVBRE1FLm1kXG4gICAgICBjb25zdCByZWFkbWVDb250ZW50ID0gYCMgUGluayBSb3NlIEluIEV2ZXJ5IExhbmd1YWdlIPCfjLlcblxuPiAqXCJXaGF0IGlmIGEgc2luZ2xlIHJvc2UgY291bGQgc2F5ICdJIGxvdmUgeW91JyBpbiA2MCsgd29ybGQgbGFuZ3VhZ2VzP1wiKlxuXG5BbiBpbnRlcmFjdGl2ZSBjcmVhdGl2ZSBjb2RpbmcgYXJ0IGV4cGVyaWVuY2UgaW5zcGlyZWQgYnkgW0BoYWxvLnVzaGFhXShodHRwczovL3d3dy5pbnN0YWdyYW0uY29tL3AvRGVqemRyWXkwWmEvKSwgcmVuZGVyaW5nIGJsb29taW5nIGZsb3dlcnMgKFBpbmsgUm9zZSwgUmVkIFJvc2UsIFBpbmsgTGlseSwgU3VuZmxvd2VyLCBSb3lhbCBUdWxpcCkgZW50aXJlbHkgZnJvbSBtdWx0aWxpbmd1YWwgZGVjbGFyYXRpb25zIG9mIGxvdmUuXG5cbiFbUHJldmlld10oaHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL2F5YXpzb2JoYW4vYXNzZXRzL21haW4vcm9zZS1wcmV2aWV3LnBuZylcblxuIyMg4pyoIEZlYXR1cmVzXG5cbi0gKipNdWx0aWxpbmd1YWwgVHlwb2dyYXBoaWMgQXJ0Kio6IEZsb3dlcnMgY29tcG9zZWQgZW50aXJlbHkgb2YgaG9yaXpvbnRhbCwgcmF6b3Itc2hhcnAgXCJJIGxvdmUgeW91XCIgcGhyYXNlcyBpbiA2MCsgbGFuZ3VhZ2VzIChGcmVuY2gsIEphcGFuZXNlLCBTcGFuaXNoLCBIaW5kaSwgVGFnYWxvZywgQXJhYmljLCBTd2FoaWxpLCBUZWx1Z3UsIFJ1c3NpYW4sIGV0Yy4pLlxuLSAqKkludGVyYWN0aXZlIEF1ZGlvICYgUHJvbnVuY2lhdGlvbioqOiBDbGljay9ob3ZlciBvbiBhbnkgd29yZCB0byBoZWFyIHNwZWVjaCBzeW50aGVzaXMgcHJvbnVuY2lhdGlvbiwgY291bnRyeSBmbGFncywgYW5kIHJvbWFudGljIGN1bHR1cmFsIGxvcmUuXG4tICoqUGFyYW1ldHJpYyBCbG9vbSBBbmltYXRpb24qKjogUGxheSwgcGF1c2UsIG9yIHNjcnViIHRocm91Z2ggdGhlIGJpb2xvZ2ljYWwgYmxvb20gdGltZWxpbmUgZnJvbSByb290IHNwcm91dCB0byBmdWxsIHN0YXIgYmxvc3NvbS5cbi0gKipGbG93ZXIgU3dpdGNoZXIqKjogUGluayBSb3NlLCBDbGFzc2ljIFJlZCBSb3NlLCBTdGFyZ2F6ZXIgTGlseSwgR29sZGVuIFN1bmZsb3dlciwgUm95YWwgVHVsaXAsIGFuZCBNb29ubGlnaHQgV2hpdGUgUm9zZS5cbi0gKipQeXRob24gQ3JlYXRpdmUgQ29kaW5nIFN0dWRpbyoqOiBJbmNsdWRlcyBzdGFuZGFsb25lIHJ1bm5hYmxlIFB5dGhvbiBUa2ludGVyIHNjcmlwdHMgKFxcYHBpbmtfcm9zZS5weVxcYCwgXFxgcGlua19saWx5LnB5XFxgKS5cbi0gKipMb3ZlIERlZGljYXRpb24gQ2FyZHMqKjogSW5zY3JpYmUgYSBsb3ZlZCBvbmUncyBuYW1lIGludG8gdGhlIGZsb3dlciBoZWFydCBhbmQgZXhwb3J0IHNoYXJlYWJsZSBwb3N0Y2FyZHMuXG5cbiMjIPCfmoAgUnVubmluZyB0aGUgV2ViIEFwcCBMb2NhbGx5XG5cblxcYFxcYFxcYGJhc2hcbiMgQ2xvbmUgdGhlIHJlcG9zaXRvcnlcbmdpdCBjbG9uZSBodHRwczovL2dpdGh1Yi5jb20vWU9VUl9VU0VSTkFNRS8ke3JlcG9OYW1lfS5naXRcbmNkICR7cmVwb05hbWV9XG5cbiMgSW5zdGFsbCBkZXBlbmRlbmNpZXNcbm5wbSBpbnN0YWxsXG5cbiMgU3RhcnQgZGV2ZWxvcG1lbnQgc2VydmVyXG5ucG0gcnVuIGRldlxuXFxgXFxgXFxgXG5cbk9wZW4gW2h0dHA6Ly9sb2NhbGhvc3Q6MzAwMF0oaHR0cDovL2xvY2FsaG9zdDozMDAwKSBpbiB5b3VyIGJyb3dzZXIuXG5cbiMjIPCfkI0gUnVubmluZyBTdGFuZGFsb25lIFB5dGhvbiBUa2ludGVyIFNjcmlwdHNcblxuWW91IGNhbiBhbHNvIHJ1biB0aGUgUHl0aG9uIHNjcmlwdCBkaXJlY3RseSBvbiB5b3VyIGNvbXB1dGVyIChubyB3ZWIgYnJvd3NlciByZXF1aXJlZCk6XG5cblxcYFxcYFxcYGJhc2hcbnB5dGhvbjMgcGlua19yb3NlLnB5XG5cXGBcXGBcXGBcblxuIyMg8J+TnCBMaWNlbnNlXG5cbk1JVCBMaWNlbnNlLiBDcmVhdGVkIHdpdGggbG92ZSBmb3IgY3JlYXRpdmUgY29kZXJzIHdvcmxkd2lkZS5cbmA7XG4gICAgICB6aXAuZmlsZSgnUkVBRE1FLm1kJywgcmVhZG1lQ29udGVudCk7XG5cbiAgICAgIC8vIDIuIExJQ0VOU0UgKE1JVClcbiAgICAgIGNvbnN0IGxpY2Vuc2VDb250ZW50ID0gYE1JVCBMaWNlbnNlXG5cbkNvcHlyaWdodCAoYykgMjAyNiBDcmVhdGl2ZSBDb2RlclxuXG5QZXJtaXNzaW9uIGlzIGhlcmVieSBncmFudGVkLCBmcmVlIG9mIGNoYXJnZSwgdG8gYW55IHBlcnNvbiBvYnRhaW5pbmcgYSBjb3B5XG5vZiB0aGlzIHNvZnR3YXJlIGFuZCBhc3NvY2lhdGVkIGRvY3VtZW50YXRpb24gZmlsZXMgKHRoZSBcIlNvZnR3YXJlXCIpLCB0byBkZWFsXG5pbiB0aGUgU29mdHdhcmUgd2l0aG91dCByZXN0cmljdGlvbiwgaW5jbHVkaW5nIHdpdGhvdXQgbGltaXRhdGlvbiB0aGUgcmlnaHRzXG50byB1c2UsIGNvcHksIG1vZGlmeSwgbWVyZ2UsIHB1Ymxpc2gsIGRpc3RyaWJ1dGUsIHN1YmxpY2Vuc2UsIGFuZC9vciBzZWxsXG5jb3BpZXMgb2YgdGhlIFNvZnR3YXJlLCBhbmQgdG8gcGVybWl0IHBlcnNvbnMgdG8gd2hvbSB0aGUgU29mdHdhcmUgaXNcbmZ1cm5pc2hlZCB0byBkbyBzbywgc3ViamVjdCB0byB0aGUgZm9sbG93aW5nIGNvbmRpdGlvbnM6XG5cblRoZSBhYm92ZSBjb3B5cmlnaHQgbm90aWNlIGFuZCB0aGlzIHBlcm1pc3Npb24gbm90aWNlIHNoYWxsIGJlIGluY2x1ZGVkIGluIGFsbFxuY29waWVzIG9yIHN1YnN0YW50aWFsIHBvcnRpb25zIG9mIHRoZSBTb2Z0d2FyZS5cbmA7XG4gICAgICB6aXAuZmlsZSgnTElDRU5TRScsIGxpY2Vuc2VDb250ZW50KTtcblxuICAgICAgLy8gMy4gLmdpdGlnbm9yZVxuICAgICAgY29uc3QgZ2l0aWdub3JlQ29udGVudCA9IGBub2RlX21vZHVsZXMvXG5kaXN0L1xuZGlzdC1zc3IvXG4qLmxvY2FsXG4uZW52XG4uRFNfU3RvcmVcbmA7XG4gICAgICB6aXAuZmlsZSgnLmdpdGlnbm9yZScsIGdpdGlnbm9yZUNvbnRlbnQpO1xuXG4gICAgICAvLyA0LiBTdGFuZGFsb25lIFB5dGhvbiBzY3JpcHRzXG4gICAgICB6aXAuZmlsZShcbiAgICAgICAgJ3Bpbmtfcm9zZS5weScsXG4gICAgICAgIGdlbmVyYXRlUHl0aG9uQ29kZSh7XG4gICAgICAgICAgd2lkdGg6IDYwMCxcbiAgICAgICAgICBoZWlnaHQ6IDgwMCxcbiAgICAgICAgICBkdXJhdGlvbjogMTAsXG4gICAgICAgICAgZ2FwOiAzLFxuICAgICAgICAgIHNjYWxlOiAxLjAsXG4gICAgICAgICAgZmxvd2VyVHlwZTogJ3Jvc2UnLFxuICAgICAgICAgIHRoZW1lTmFtZTogJ1BpbmsgUm9zZScsXG4gICAgICAgICAgcmVjaXBpZW50TmFtZSxcbiAgICAgICAgfSlcbiAgICAgICk7XG5cbiAgICAgIHppcC5maWxlKFxuICAgICAgICAncGlua19saWx5LnB5JyxcbiAgICAgICAgZ2VuZXJhdGVQeXRob25Db2RlKHtcbiAgICAgICAgICB3aWR0aDogNjAwLFxuICAgICAgICAgIGhlaWdodDogODAwLFxuICAgICAgICAgIGR1cmF0aW9uOiAxMCxcbiAgICAgICAgICBnYXA6IDMsXG4gICAgICAgICAgc2NhbGU6IDEuMCxcbiAgICAgICAgICBmbG93ZXJUeXBlOiAnbGlseScsXG4gICAgICAgICAgdGhlbWVOYW1lOiAnUGluayBMaWx5JyxcbiAgICAgICAgICByZWNpcGllbnROYW1lLFxuICAgICAgICB9KVxuICAgICAgKTtcblxuICAgICAgLy8gNS4gRmV0Y2ggcHJvamVjdCBzb3VyY2UgZmlsZXMgZnJvbSB0aGUgY3VycmVudCBhcHBsZXRcbiAgICAgIGNvbnN0IGZpbGVQYXRocyA9IFtcbiAgICAgICAgJ3BhY2thZ2UuanNvbicsXG4gICAgICAgICd0c2NvbmZpZy5qc29uJyxcbiAgICAgICAgJ3ZpdGUuY29uZmlnLnRzJyxcbiAgICAgICAgJ2luZGV4Lmh0bWwnLFxuICAgICAgICAnc3JjL21haW4udHN4JyxcbiAgICAgICAgJ3NyYy9BcHAudHN4JyxcbiAgICAgICAgJ3NyYy9pbmRleC5jc3MnLFxuICAgICAgICAnc3JjL2RhdGEvbGFuZ3VhZ2VzLnRzJyxcbiAgICAgICAgJ3NyYy9kYXRhL3Jvc2VFeGFjdERhdGEudHMnLFxuICAgICAgICAnc3JjL2RhdGEvbGlseUV4YWN0RGF0YS50cycsXG4gICAgICAgICdzcmMvdXRpbHMvZXhhY3RSb3NlR2VuZXJhdG9yLnRzJyxcbiAgICAgICAgJ3NyYy91dGlscy9mbG93ZXJTaGFwZXMudHMnLFxuICAgICAgICAnc3JjL3V0aWxzL2xpbHlHZW5lcmF0b3IudHMnLFxuICAgICAgICAnc3JjL3V0aWxzL3Jvc2VHZW5lcmF0b3IudHMnLFxuICAgICAgICAnc3JjL3V0aWxzL3B5dGhvblNjcmlwdC50cycsXG4gICAgICAgICdzcmMvdXRpbHMvYXVkaW9TeW50aGVzaXplci50cycsXG4gICAgICAgICdzcmMvdXRpbHMvdHVtQXVkaW9TeW50aGVzaXplci50cycsXG4gICAgICAgICdzcmMvY29tcG9uZW50cy9Sb3NlQ2FudmFzLnRzeCcsXG4gICAgICAgICdzcmMvY29tcG9uZW50cy9Sb3NlQ29udHJvbHMudHN4JyxcbiAgICAgICAgJ3NyYy9jb21wb25lbnRzL1R1bUF1ZGlvUGxheWVyLnRzeCcsXG4gICAgICAgICdzcmMvY29tcG9uZW50cy9QaHJhc2VDYXJkLnRzeCcsXG4gICAgICAgICdzcmMvY29tcG9uZW50cy9Db2RlVmlld2VyLnRzeCcsXG4gICAgICAgICdzcmMvY29tcG9uZW50cy9MYW5ndWFnZUV4cGxvcmVyLnRzeCcsXG4gICAgICAgICdzcmMvY29tcG9uZW50cy9DYXJkRXhwb3J0TW9kYWwudHN4JyxcbiAgICAgICAgJ3NyYy9jb21wb25lbnRzL0dpdEh1YkV4cG9ydE1vZGFsLnRzeCcsXG4gICAgICBdO1xuXG4gICAgICBmb3IgKGNvbnN0IHAgb2YgZmlsZVBhdGhzKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYC8ke3B9YCk7XG4gICAgICAgICAgaWYgKHJlcy5vaykge1xuICAgICAgICAgICAgY29uc3QgdGV4dCA9IGF3YWl0IHJlcy50ZXh0KCk7XG4gICAgICAgICAgICB6aXAuZmlsZShwLCB0ZXh0KTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgIC8vIGlnbm9yZSBpbmRpdmlkdWFsIGZldGNoIGVycm9yc1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIC8vIEdlbmVyYXRlIFpJUCBibG9iIGFuZCB0cmlnZ2VyIGRvd25sb2FkXG4gICAgICBjb25zdCBibG9iID0gYXdhaXQgemlwLmdlbmVyYXRlQXN5bmMoeyB0eXBlOiAnYmxvYicgfSk7XG4gICAgICBjb25zdCB1cmwgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpO1xuICAgICAgY29uc3QgbGluayA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKTtcbiAgICAgIGxpbmsuaHJlZiA9IHVybDtcbiAgICAgIGxpbmsuZG93bmxvYWQgPSBgJHtyZXBvTmFtZX0tZ2l0aHViLXJlYWR5LnppcGA7XG4gICAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGxpbmspO1xuICAgICAgbGluay5jbGljaygpO1xuICAgICAgZG9jdW1lbnQuYm9keS5yZW1vdmVDaGlsZChsaW5rKTtcbiAgICAgIFVSTC5yZXZva2VPYmplY3RVUkwodXJsKTtcblxuICAgICAgc2V0RG93bmxvYWRTdWNjZXNzKHRydWUpO1xuICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXREb3dubG9hZFN1Y2Nlc3MoZmFsc2UpLCA0MDAwKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0ZhaWxlZCB0byBjcmVhdGUgemlwJywgZXJyKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0SXNFeHBvcnRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNCBiZy1ibGFjay84NSBiYWNrZHJvcC1ibHVyLW1kIGFuaW1hdGUtZmFkZUluXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHctZnVsbCBtYXgtdy0yeGwgYmctemluYy05NTAgYm9yZGVyIGJvcmRlci16aW5jLTgwMCByb3VuZGVkLTN4bCBwLTYgbWQ6cC04IHNoYWRvdy0yeGwgdGV4dC1yb3NlLTUwIG92ZXJmbG93LWhpZGRlbiBmbGV4IGZsZXgtY29sIG1heC1oLVs5MnZoXVwiPlxuICAgICAgICB7LyogQ2xvc2UgQnV0dG9uICovfVxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtNSByaWdodC01IHAtMiByb3VuZGVkLWZ1bGwgdGV4dC16aW5jLTQwMCBob3Zlcjp0ZXh0LXdoaXRlIGhvdmVyOmJnLXppbmMtODAwIHRyYW5zaXRpb24tY29sb3JzIHotMTBcIlxuICAgICAgICA+XG4gICAgICAgICAg4pyVXG4gICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgIHsvKiBNb2RhbCBIZWFkZXIgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgbWItNlwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTMgcHktMSByb3VuZGVkLWZ1bGwgYmctemluYy05MDAgYm9yZGVyIGJvcmRlci16aW5jLTcwMC84MCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC16aW5jLTMwMCBtYi0yXCI+XG4gICAgICAgICAgICA8R2l0aHViIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtd2hpdGVcIiAvPlxuICAgICAgICAgICAgPHNwYW4+R2l0SHViIFJlcG9zaXRvcnkgRXhwb3J0ZXI8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCBmb250LWRpc3BsYXkgdHJhY2tpbmctdGlnaHQgdGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgRXhwb3J0IFByb2plY3QgdG8gR2l0SHViXG4gICAgICAgICAgPC9oMj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtemluYy00MDAgbXQtMSBtYXgtdy1tZCBteC1hdXRvXCI+XG4gICAgICAgICAgICBEb3dubG9hZCBhIHJlYWR5LXRvLXB1c2ggcmVwb3NpdG9yeSBaSVAgd2l0aCBhbGwgY29kZSwgUHl0aG9uIHNjcmlwdHMsIFJFQURNRS5tZCwgYW5kIGxpY2Vuc2UgaW5jbHVkZWQuXG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogQ29udGVudCBBcmVhICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBvdmVyZmxvdy15LWF1dG8gc3BhY2UteS01IHByLTEgY3VzdG9tLXNjcm9sbGJhclwiPlxuICAgICAgICAgIHsvKiBSZXBvc2l0b3J5IE5hbWUgSW5wdXQgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy16aW5jLTkwMC82MCBwLTQgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci16aW5jLTgwMFwiPlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXppbmMtMzAwIG1iLTEuNVwiPlxuICAgICAgICAgICAgICBHaXRIdWIgUmVwb3NpdG9yeSBOYW1lXG4gICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbW9ubyB0ZXh0LXppbmMtNTAwXCI+Z2l0aHViLmNvbS95b3UvPC9zcGFuPlxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgdmFsdWU9e3JlcG9OYW1lfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UmVwb05hbWUoZS50YXJnZXQudmFsdWUudG9Mb3dlckNhc2UoKS5yZXBsYWNlKC9bXmEtejAtOS1fXS9nLCAnLScpKX1cbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImEtcm9zZS1tYWRlLW9mLWxvdmVcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBweC0zIHB5LTEuNSByb3VuZGVkLXhsIGJnLXppbmMtOTUwIGJvcmRlciBib3JkZXItemluYy03MDAgdGV4dC14cyB0ZXh0LXdoaXRlIGZvbnQtbW9ubyBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLXJvc2UtNTAwXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIE9wdGlvbiAxOiBPbmUtQ2xpY2sgWklQIERvd25sb2FkICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQtMnhsIGJnLWdyYWRpZW50LXRvLWJyIGZyb20temluYy05MDAgdG8temluYy05NTAgYm9yZGVyIGJvcmRlci16aW5jLTgwMCBmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8Rm9sZGVyQXJjaGl2ZSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZW1lcmFsZC00MDBcIiAvPlxuICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgRG93bmxvYWQgQ29tcGxldGUgR2l0SHViIFJlcG9zaXRvcnkgKC56aXApXG4gICAgICAgICAgICAgICAgPC9oND5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC16aW5jLTQwMCBtdC0xXCI+XG4gICAgICAgICAgICAgICAgQ29udGFpbnMgZnVsbCBUeXBlU2NyaXB0L1JlYWN0IHNvdXJjZSwgc3RhbmRhbG9uZSBQeXRob24gc2NyaXB0cywgUkVBRE1FLCAuZ2l0aWdub3JlLCBhbmQgTElDRU5TRS5cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRG93bmxvYWRaaXB9XG4gICAgICAgICAgICAgIGRpc2FibGVkPXtpc0V4cG9ydGluZ31cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtNSBweS0yLjUgcm91bmRlZC14bCBiZy1ncmFkaWVudC10by1yIGZyb20tZW1lcmFsZC02MDAgdG8tdGVhbC02MDAgaG92ZXI6ZnJvbS1lbWVyYWxkLTUwMCBob3Zlcjp0by10ZWFsLTUwMCB0ZXh0LXdoaXRlIHRleHQteHMgZm9udC1zZW1pYm9sZCBzaGFkb3ctbGcgc2hhZG93LWVtZXJhbGQtOTUwIHRyYW5zaXRpb24tYWxsIHNocmluay0wIGFjdGl2ZTpzY2FsZS05NSBkaXNhYmxlZDpvcGFjaXR5LTUwXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge2Rvd25sb2FkU3VjY2VzcyA/IChcbiAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPkRvd25sb2FkZWQhPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICA8RG93bmxvYWQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj57aXNFeHBvcnRpbmcgPyAnR2VuZXJhdGluZyBaSVAuLi4nIDogJ0Rvd25sb2FkIFJlcG8gWklQJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBPcHRpb24gMjogUHVzaCB1c2luZyBHaXQgQ0xJIGNvbW1hbmRzICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctemluYy05MDAvNjAgcC00IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItemluYy04MDBcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTJcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC16aW5jLTIwMFwiPlxuICAgICAgICAgICAgICAgIDxUZXJtaW5hbCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXJvc2UtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5Db21tYW5kIExpbmUgUXVpY2stUHVzaDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVDb3B5Q29tbWFuZHN9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0yLjUgcHktMSByb3VuZGVkLWxnIGJnLXppbmMtODAwIGhvdmVyOmJnLXppbmMtNzAwIHRleHQtWzExcHhdIHRleHQtemluYy0yMDAgZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAge2NvcGllZENvbW1hbmRzID8gPENoZWNrIGNsYXNzTmFtZT1cInctMyBoLTMgdGV4dC1lbWVyYWxkLTQwMFwiIC8+IDogPENvcHkgY2xhc3NOYW1lPVwidy0zIGgtM1wiIC8+fVxuICAgICAgICAgICAgICAgIDxzcGFuPntjb3BpZWRDb21tYW5kcyA/ICdDb3BpZWQgQ29tbWFuZHMhJyA6ICdDb3B5IENvbW1hbmRzJ308L3NwYW4+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxwcmUgY2xhc3NOYW1lPVwicC0zIHJvdW5kZWQteGwgYmctYmxhY2sgZm9udC1tb25vIHRleHQtWzExcHhdIHRleHQtemluYy0zMDAgb3ZlcmZsb3cteC1hdXRvIGxlYWRpbmctcmVsYXhlZCBib3JkZXIgYm9yZGVyLXppbmMtODAwXCI+XG4gICAgICAgICAgICAgIDxjb2RlPntnaXRDb21tYW5kc308L2NvZGU+XG4gICAgICAgICAgICA8L3ByZT5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBJbmNsdWRlZCBGaWxlcyBTdW1tYXJ5ICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctemluYy05MDAvNDAgcC0zLjUgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci16aW5jLTgwMC82MCB0ZXh0LXhzIHRleHQtemluYy00MDBcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LXppbmMtMzAwIGZvbnQtbWVkaXVtIG1iLTEuNVwiPlxuICAgICAgICAgICAgICA8RmlsZUNvZGUgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1waW5rLTQwMFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPkluY2x1ZGVkIEZpbGVzIGluIEdpdEh1YiBBcmNoaXZlOjwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC15LTEgZ2FwLXgtNCBmb250LW1vbm8gdGV4dC1bMTFweF0gdGV4dC16aW5jLTQwMFwiPlxuICAgICAgICAgICAgICA8ZGl2PuKckyBSRUFETUUubWQgKERvY3MgJiBCYWRnZXMpPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXY+4pyTIHBpbmtfcm9zZV9vZl9sb3ZlLnB5PC9kaXY+XG4gICAgICAgICAgICAgIDxkaXY+4pyTIHBpbmtfbGlseV9vZl9sb3ZlLnB5PC9kaXY+XG4gICAgICAgICAgICAgIDxkaXY+4pyTIHNyYy8gKEFsbCA2IEZsb3dlcnMgJiBBdWRpbyk8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdj7inJMgcGFja2FnZS5qc29uICYgVml0ZSBjb25maWc8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdj7inJMgTUlUIExJQ0VOU0UgJiAuZ2l0aWdub3JlPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIE1vZGFsIEZvb3RlciAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC00IGJvcmRlci10IGJvcmRlci16aW5jLTgwMCBtdC00IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0ZXh0LXhzIHRleHQtemluYy01MDBcIj5cbiAgICAgICAgICA8c3Bhbj5SZWFkeSBmb3IgR2l0SHViIFBhZ2VzLCBWZXJjZWwsIG9yIE5ldGxpZnkgZGVwbG95bWVudDwvc3Bhbj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0xLjUgcm91bmRlZC14bCBiZy16aW5jLTkwMCBob3ZlcjpiZy16aW5jLTgwMCB0ZXh0LXppbmMtMzAwIGhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIENsb3NlXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl19