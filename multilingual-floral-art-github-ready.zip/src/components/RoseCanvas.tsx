const React = __vite__cjsImport0_react; const useRef = __vite__cjsImport0_react["useRef"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useCallback = __vite__cjsImport0_react["useCallback"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=3ba6436c";
import { createAtmosphericParticles } from "/src/utils/roseGenerator.ts";
import { generateUnifiedFlowerElements } from "/src/utils/flowerShapes.ts";
import { COLOR_THEMES } from "/src/data/languages.ts";
import { ZoomIn, ZoomOut, RotateCcw } from "/node_modules/.vite/deps/lucide-react.js?v=3ba6436c";
var _jsxFileName = "/app/applet/src/components/RoseCanvas.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3ba6436c";
export const RoseCanvas = ({ bloomProgress, themeId, recipientName, flowerType = "pink_rose", isCinematic, onSelectPhrase, selectedPhraseId, onHoverPhrase }) => {
	const canvasRef = useRef(null);
	const elementsRef = useRef([]);
	const particlesRef = useRef([]);
	const animationFrameRef = useRef(null);
	const mouseRef = useRef({
		x: -1e3,
		y: -1e3,
		active: false
	});
	const hoveredElementRef = useRef(null);
	const sparkleTrailRef = useRef([]);
	// Zoom & Pan state for ultimate text inspection
	const [zoomLevel, setZoomLevel] = useState(1);
	// Parallax tilt angles
	const tiltRef = useRef({
		rx: 0,
		ry: 0
	});
	const currentTheme = COLOR_THEMES.find((t) => t.id === themeId) || COLOR_THEMES[0];
	// Initialize or regenerate flower elements on resize or recipient name change
	const rebuildElements = useCallback(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const width = canvas.clientWidth;
		const height = canvas.clientHeight;
		elementsRef.current = generateUnifiedFlowerElements(flowerType, width, height, recipientName);
		particlesRef.current = createAtmosphericParticles(30, width, height);
	}, [recipientName, flowerType]);
	// Handle Canvas Resize with high DPR for maximum sharpness
	useEffect(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const handleResize = () => {
			const dpr = Math.max(2, window.devicePixelRatio || 1);
			const rect = canvas.getBoundingClientRect();
			canvas.width = Math.round(rect.width * dpr);
			canvas.height = Math.round(rect.height * dpr);
			rebuildElements();
		};
		handleResize();
		window.addEventListener("resize", handleResize);
		return () => window.removeEventListener("resize", handleResize);
	}, [rebuildElements]);
	// Mouse / Touch handlers for interaction
	const handlePointerMove = (e) => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const rect = canvas.getBoundingClientRect();
		const rawMx = e.clientX - rect.left;
		const rawMy = e.clientY - rect.top;
		const centerX = rect.width / 2;
		const centerY = rect.height / 2;
		const mx = centerX + (rawMx - centerX) / zoomLevel;
		const my = centerY + (rawMy - centerY) / zoomLevel;
		mouseRef.current = {
			x: mx,
			y: my,
			active: true
		};
		// Gentle 3D perspective tilt
		const normX = (rawMx / rect.width - .5) * 2;
		const normY = (rawMy / rect.height - .5) * 2;
		tiltRef.current = {
			rx: normY * 3,
			ry: -normX * 4
		};
		// Add glowing mouse sparkler dust
		if (Math.random() < .4) {
			sparkleTrailRef.current.push({
				x: mx + (Math.random() - .5) * 12,
				y: my + (Math.random() - .5) * 12,
				alpha: .9,
				size: 2 + Math.random() * 3
			});
		}
		// Precise Bounding Box collision test for every word
		let found = null;
		const elems = elementsRef.current;
		for (let i = elems.length - 1; i >= 0; i--) {
			const el = elems[i];
			if (el.order > bloomProgress) continue;
			const halfW = el.width / 2 + 6;
			const halfH = el.height / 2 + 4;
			if (mx >= el.x - halfW && mx <= el.x + halfW && my >= el.y - halfH && my <= el.y + halfH) {
				found = el;
				break;
			}
		}
		if (found !== hoveredElementRef.current) {
			hoveredElementRef.current = found;
			if (onHoverPhrase) {
				onHoverPhrase(found ? found.phrase : null);
			}
		}
	};
	const handlePointerLeave = () => {
		mouseRef.current.active = false;
		hoveredElementRef.current = null;
		tiltRef.current = {
			rx: 0,
			ry: 0
		};
		if (onHoverPhrase) onHoverPhrase(null);
	};
	const handleClick = () => {
		if (hoveredElementRef.current) {
			if (onSelectPhrase) {
				onSelectPhrase(hoveredElementRef.current.phrase);
			}
		}
	};
	// Main Render Loop with High-Clarity Typography
	useEffect(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d", { alpha: false });
		if (!ctx) return;
		let time = 0;
		const render = () => {
			time += .02;
			const dpr = Math.max(2, window.devicePixelRatio || 1);
			const width = canvas.width / dpr;
			const height = canvas.height / dpr;
			ctx.save();
			ctx.scale(dpr, dpr);
			// Pitch black background (#000000 as in reference image)
			ctx.fillStyle = "#000000";
			ctx.fillRect(0, 0, width, height);
			// Apply Zoom transformation
			const cx = width / 2;
			const cy = height * .36;
			ctx.translate(cx, cy);
			ctx.scale(zoomLevel, zoomLevel);
			ctx.translate(-cx, -cy);
			// 1. Subtle warm ambient glow behind the flower
			const radialGrad = ctx.createRadialGradient(cx, cy, 20, cx, cy, width * .6);
			if (flowerType === "pink_rose" || flowerType === "pink_lily") {
				radialGrad.addColorStop(0, "rgba(244, 114, 182, 0.22)");
				radialGrad.addColorStop(.45, "rgba(190, 24, 93, 0.06)");
			} else if (flowerType === "golden_sunflower") {
				radialGrad.addColorStop(0, "rgba(245, 158, 11, 0.22)");
				radialGrad.addColorStop(.45, "rgba(180, 83, 9, 0.06)");
			} else if (flowerType === "royal_tulip") {
				radialGrad.addColorStop(0, "rgba(168, 85, 247, 0.22)");
				radialGrad.addColorStop(.45, "rgba(88, 28, 135, 0.06)");
			} else {
				radialGrad.addColorStop(0, "rgba(225, 29, 72, 0.22)");
				radialGrad.addColorStop(.45, "rgba(159, 18, 57, 0.06)");
			}
			radialGrad.addColorStop(1, "rgba(0, 0, 0, 0)");
			ctx.fillStyle = radialGrad;
			ctx.fillRect(0, 0, width, height);
			// 2. Render Atmospheric Floating Petals & Fairy Lights
			const particles = particlesRef.current;
			particles.forEach((p) => {
				p.y += p.speedY;
				p.x += p.speedX + Math.sin(time + p.y * .01) * .3;
				p.rotation += p.rotationSpeed;
				if (p.y > height + 30) {
					p.y = -20;
					p.x = Math.random() * width;
				}
				if (p.x < -30) p.x = width + 20;
				if (p.x > width + 30) p.x = -20;
				ctx.save();
				ctx.translate(p.x, p.y);
				ctx.rotate(p.rotation);
				if (p.type === "bokeh") {
					const bokehGrad = ctx.createRadialGradient(0, 0, 0, 0, 0, p.size);
					bokehGrad.addColorStop(0, flowerType === "pink_rose" ? "rgba(244, 114, 182, 0.18)" : "rgba(244, 63, 94, 0.18)");
					bokehGrad.addColorStop(1, "rgba(0, 0, 0, 0)");
					ctx.fillStyle = bokehGrad;
					ctx.beginPath();
					ctx.arc(0, 0, p.size, 0, Math.PI * 2);
					ctx.fill();
				} else if (p.type === "sparkle") {
					ctx.fillStyle = flowerType === "pink_rose" ? "#fbcfe8" : "#fda4af";
					ctx.beginPath();
					ctx.arc(0, 0, p.size * (1 + .3 * Math.sin(time * 3 + p.x)), 0, Math.PI * 2);
					ctx.fill();
				} else {
					ctx.globalAlpha = p.opacity * .8;
					ctx.fillStyle = flowerType === "pink_rose" ? "#f472b6" : flowerType === "golden_sunflower" ? "#f59e0b" : "#e11d48";
					ctx.beginPath();
					ctx.ellipse(0, 0, p.size * .45, p.size * 1.1, Math.PI / 4, 0, Math.PI * 2);
					ctx.fill();
				}
				ctx.restore();
			});
			// 3. Render Mouse Sparkler Trails
			const trail = sparkleTrailRef.current;
			for (let i = trail.length - 1; i >= 0; i--) {
				const s = trail[i];
				s.alpha -= .03;
				s.y -= .3;
				if (s.alpha <= 0) {
					trail.splice(i, 1);
					continue;
				}
				ctx.save();
				ctx.globalAlpha = s.alpha;
				ctx.fillStyle = flowerType === "pink_rose" ? "#fbcfe8" : "#fda4af";
				ctx.beginPath();
				ctx.arc(s.x, s.y, s.size, 0, Math.PI * 2);
				ctx.fill();
				ctx.restore();
			}
			// 4. Render Razor-Sharp, Generously Spaced Horizontal Flower Words
			const elems = elementsRef.current;
			const hovered = hoveredElementRef.current;
			elems.forEach((el) => {
				if (el.order > bloomProgress) return;
				const bloomFade = Math.min(1, (bloomProgress - el.order) / .05);
				if (bloomFade <= .01) return;
				ctx.save();
				ctx.translate(el.x, el.y);
				const isHovered = hovered?.id === el.id;
				const isSelected = selectedPhraseId && el.phrase.id === selectedPhraseId;
				const fontFam = "-apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, sans-serif";
				if (isHovered || isSelected) {
					ctx.fillStyle = "rgba(255, 255, 255, 0.22)";
					ctx.strokeStyle = "#ffffff";
					ctx.lineWidth = 1.5;
					const pw = el.width + 12;
					const ph = el.height + 6;
					ctx.beginPath();
					ctx.roundRect(-pw / 2, -ph / 2, pw, ph, 6);
					ctx.fill();
					ctx.stroke();
					ctx.shadowBlur = 0;
					ctx.fillStyle = "#ffffff";
					ctx.font = `bold ${el.fontSize + 1}px ${fontFam}`;
				} else {
					ctx.shadowBlur = 0;
					ctx.fillStyle = el.color;
					ctx.font = `${el.fontWeight} ${el.fontSize}px ${fontFam}`;
				}
				ctx.textAlign = "center";
				ctx.textBaseline = "middle";
				ctx.globalAlpha = bloomFade;
				ctx.fillText(el.text, 0, 0);
				ctx.restore();
			});
			ctx.restore();
			animationFrameRef.current = requestAnimationFrame(render);
		};
		animationFrameRef.current = requestAnimationFrame(render);
		return () => {
			if (animationFrameRef.current) {
				cancelAnimationFrame(animationFrameRef.current);
			}
		};
	}, [
		bloomProgress,
		currentTheme,
		selectedPhraseId,
		flowerType,
		zoomLevel
	]);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: `relative w-full h-full flex items-center justify-center overflow-hidden transition-all duration-700 bg-black ${isCinematic ? "rounded-none" : "rounded-2xl border border-zinc-900"}`,
		style: {
			background: "#000000",
			perspective: "1000px"
		},
		children: [/* @__PURE__ */ _jsxDEV("canvas", {
			ref: canvasRef,
			onPointerMove: handlePointerMove,
			onPointerLeave: handlePointerLeave,
			onClick: handleClick,
			className: "w-full h-full cursor-pointer touch-none select-none transition-transform duration-300 ease-out",
			style: { transform: `rotateX(${tiltRef.current.rx}deg) rotateY(${tiltRef.current.ry}deg)` }
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 331,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "absolute top-4 right-4 z-20 flex items-center gap-1.5 bg-zinc-950/85 border border-zinc-800/80 rounded-xl p-1.5 backdrop-blur-md text-xs text-zinc-300 shadow-xl",
			children: [
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: () => setZoomLevel((z) => Math.min(2, Number((z + .25).toFixed(2)))),
					className: "p-1.5 rounded-lg hover:bg-zinc-800 text-zinc-300 hover:text-white transition-colors",
					title: "Zoom In (Inspect words)",
					children: /* @__PURE__ */ _jsxDEV(ZoomIn, { className: "w-3.5 h-3.5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 349,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 344,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("span", {
					className: "font-mono text-[11px] px-1 text-pink-300 font-semibold select-none",
					children: [Math.round(zoomLevel * 100), "%"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 352,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: () => setZoomLevel((z) => Math.max(.75, Number((z - .25).toFixed(2)))),
					className: "p-1.5 rounded-lg hover:bg-zinc-800 text-zinc-300 hover:text-white transition-colors",
					title: "Zoom Out",
					children: /* @__PURE__ */ _jsxDEV(ZoomOut, { className: "w-3.5 h-3.5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 361,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 356,
					columnNumber: 9
				}, this),
				zoomLevel !== 1 && /* @__PURE__ */ _jsxDEV("button", {
					onClick: () => setZoomLevel(1),
					className: "p-1.5 rounded-lg hover:bg-zinc-800 text-zinc-400 hover:text-white transition-colors",
					title: "Reset Zoom",
					children: /* @__PURE__ */ _jsxDEV(RotateCcw, { className: "w-3 h-3" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 370,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 365,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 343,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 322,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFFBQVEsV0FBVyxhQUFhLGdCQUFnQjtBQUNoRSxTQUFTLGtDQUFvRDtBQUM3RCxTQUFTLHFDQUFpRDtBQUUxRCxTQUFTLG9CQUFnQztBQUN6QyxTQUFTLFFBQVEsU0FBUyxpQkFBaUI7OztBQWEzQyxPQUFPLE1BQU0sY0FBeUMsRUFDcEQsZUFDQSxTQUNBLGVBQ0EsYUFBYSxhQUNiLGFBQ0EsZ0JBQ0Esa0JBQ0Esb0JBQ0k7Q0FDSixNQUFNLFlBQVksT0FBaUMsSUFBSTtDQUN2RCxNQUFNLGNBQWMsT0FBNEIsQ0FBQyxDQUFDO0NBQ2xELE1BQU0sZUFBZSxPQUEyQixDQUFDLENBQUM7Q0FDbEQsTUFBTSxvQkFBb0IsT0FBc0IsSUFBSTtDQUNwRCxNQUFNLFdBQVcsT0FBa0Q7RUFBRSxHQUFHLENBQUM7RUFBTSxHQUFHLENBQUM7RUFBTSxRQUFRO0NBQU0sQ0FBQztDQUN4RyxNQUFNLG9CQUFvQixPQUFpQyxJQUFJO0NBQy9ELE1BQU0sa0JBQWtCLE9BQWdFLENBQUMsQ0FBQzs7Q0FHMUYsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQWlCLENBQUc7O0NBR3RELE1BQU0sVUFBVSxPQUFtQztFQUFFLElBQUk7RUFBRyxJQUFJO0NBQUUsQ0FBQztDQUVuRSxNQUFNLGVBQWUsYUFBYSxNQUFNLE1BQU0sRUFBRSxPQUFPLE9BQU8sS0FBSyxhQUFhOztDQUdoRixNQUFNLGtCQUFrQixrQkFBa0I7RUFDeEMsTUFBTSxTQUFTLFVBQVU7RUFDekIsSUFBSSxDQUFDLFFBQVE7RUFDYixNQUFNLFFBQVEsT0FBTztFQUNyQixNQUFNLFNBQVMsT0FBTztFQUV0QixZQUFZLFVBQVUsOEJBQThCLFlBQVksT0FBTyxRQUFRLGFBQWE7RUFDNUYsYUFBYSxVQUFVLDJCQUEyQixJQUFJLE9BQU8sTUFBTTtDQUNyRSxHQUFHLENBQUMsZUFBZSxVQUFVLENBQUM7O0NBRzlCLGdCQUFnQjtFQUNkLE1BQU0sU0FBUyxVQUFVO0VBQ3pCLElBQUksQ0FBQyxRQUFRO0VBRWIsTUFBTSxxQkFBcUI7R0FDekIsTUFBTSxNQUFNLEtBQUssSUFBSSxHQUFHLE9BQU8sb0JBQW9CLENBQUM7R0FDcEQsTUFBTSxPQUFPLE9BQU8sc0JBQXNCO0dBQzFDLE9BQU8sUUFBUSxLQUFLLE1BQU0sS0FBSyxRQUFRLEdBQUc7R0FDMUMsT0FBTyxTQUFTLEtBQUssTUFBTSxLQUFLLFNBQVMsR0FBRztHQUM1QyxnQkFBZ0I7RUFDbEI7RUFFQSxhQUFhO0VBQ2IsT0FBTyxpQkFBaUIsVUFBVSxZQUFZO0VBQzlDLGFBQWEsT0FBTyxvQkFBb0IsVUFBVSxZQUFZO0NBQ2hFLEdBQUcsQ0FBQyxlQUFlLENBQUM7O0NBR3BCLE1BQU0scUJBQXFCLE1BQTZDO0VBQ3RFLE1BQU0sU0FBUyxVQUFVO0VBQ3pCLElBQUksQ0FBQyxRQUFRO0VBQ2IsTUFBTSxPQUFPLE9BQU8sc0JBQXNCO0VBRTFDLE1BQU0sUUFBUSxFQUFFLFVBQVUsS0FBSztFQUMvQixNQUFNLFFBQVEsRUFBRSxVQUFVLEtBQUs7RUFFL0IsTUFBTSxVQUFVLEtBQUssUUFBUTtFQUM3QixNQUFNLFVBQVUsS0FBSyxTQUFTO0VBRTlCLE1BQU0sS0FBSyxXQUFXLFFBQVEsV0FBVztFQUN6QyxNQUFNLEtBQUssV0FBVyxRQUFRLFdBQVc7RUFFekMsU0FBUyxVQUFVO0dBQUUsR0FBRztHQUFJLEdBQUc7R0FBSSxRQUFRO0VBQUs7O0VBR2hELE1BQU0sU0FBUyxRQUFRLEtBQUssUUFBUSxNQUFPO0VBQzNDLE1BQU0sU0FBUyxRQUFRLEtBQUssU0FBUyxNQUFPO0VBQzVDLFFBQVEsVUFBVTtHQUFFLElBQUksUUFBUTtHQUFHLElBQUksQ0FBQyxRQUFRO0VBQUU7O0VBR2xELElBQUksS0FBSyxPQUFPLElBQUksSUFBSztHQUN2QixnQkFBZ0IsUUFBUSxLQUFLO0lBQzNCLEdBQUcsTUFBTSxLQUFLLE9BQU8sSUFBSSxNQUFPO0lBQ2hDLEdBQUcsTUFBTSxLQUFLLE9BQU8sSUFBSSxNQUFPO0lBQ2hDLE9BQU87SUFDUCxNQUFNLElBQUksS0FBSyxPQUFPLElBQUk7R0FDNUIsQ0FBQztFQUNIOztFQUdBLElBQUksUUFBa0M7RUFDdEMsTUFBTSxRQUFRLFlBQVk7RUFDMUIsS0FBSyxJQUFJLElBQUksTUFBTSxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUs7R0FDMUMsTUFBTSxLQUFLLE1BQU07R0FDakIsSUFBSSxHQUFHLFFBQVEsZUFBZTtHQUU5QixNQUFNLFFBQVEsR0FBRyxRQUFRLElBQUk7R0FDN0IsTUFBTSxRQUFRLEdBQUcsU0FBUyxJQUFJO0dBRTlCLElBQ0UsTUFBTSxHQUFHLElBQUksU0FDYixNQUFNLEdBQUcsSUFBSSxTQUNiLE1BQU0sR0FBRyxJQUFJLFNBQ2IsTUFBTSxHQUFHLElBQUksT0FDYjtJQUNBLFFBQVE7SUFDUjtHQUNGO0VBQ0Y7RUFFQSxJQUFJLFVBQVUsa0JBQWtCLFNBQVM7R0FDdkMsa0JBQWtCLFVBQVU7R0FDNUIsSUFBSSxlQUFlO0lBQ2pCLGNBQWMsUUFBUSxNQUFNLFNBQVMsSUFBSTtHQUMzQztFQUNGO0NBQ0Y7Q0FFQSxNQUFNLDJCQUEyQjtFQUMvQixTQUFTLFFBQVEsU0FBUztFQUMxQixrQkFBa0IsVUFBVTtFQUM1QixRQUFRLFVBQVU7R0FBRSxJQUFJO0dBQUcsSUFBSTtFQUFFO0VBQ2pDLElBQUksZUFBZSxjQUFjLElBQUk7Q0FDdkM7Q0FFQSxNQUFNLG9CQUFvQjtFQUN4QixJQUFJLGtCQUFrQixTQUFTO0dBQzdCLElBQUksZ0JBQWdCO0lBQ2xCLGVBQWUsa0JBQWtCLFFBQVEsTUFBTTtHQUNqRDtFQUNGO0NBQ0Y7O0NBR0EsZ0JBQWdCO0VBQ2QsTUFBTSxTQUFTLFVBQVU7RUFDekIsSUFBSSxDQUFDLFFBQVE7RUFDYixNQUFNLE1BQU0sT0FBTyxXQUFXLE1BQU0sRUFBRSxPQUFPLE1BQU0sQ0FBQztFQUNwRCxJQUFJLENBQUMsS0FBSztFQUVWLElBQUksT0FBTztFQUVYLE1BQU0sZUFBZTtHQUNuQixRQUFRO0dBQ1IsTUFBTSxNQUFNLEtBQUssSUFBSSxHQUFHLE9BQU8sb0JBQW9CLENBQUM7R0FDcEQsTUFBTSxRQUFRLE9BQU8sUUFBUTtHQUM3QixNQUFNLFNBQVMsT0FBTyxTQUFTO0dBRS9CLElBQUksS0FBSztHQUNULElBQUksTUFBTSxLQUFLLEdBQUc7O0dBR2xCLElBQUksWUFBWTtHQUNoQixJQUFJLFNBQVMsR0FBRyxHQUFHLE9BQU8sTUFBTTs7R0FHaEMsTUFBTSxLQUFLLFFBQVE7R0FDbkIsTUFBTSxLQUFLLFNBQVM7R0FFcEIsSUFBSSxVQUFVLElBQUksRUFBRTtHQUNwQixJQUFJLE1BQU0sV0FBVyxTQUFTO0dBQzlCLElBQUksVUFBVSxDQUFDLElBQUksQ0FBQyxFQUFFOztHQUd0QixNQUFNLGFBQWEsSUFBSSxxQkFBcUIsSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLFFBQVEsRUFBSTtHQUM1RSxJQUFJLGVBQWUsZUFBZSxlQUFlLGFBQWE7SUFDNUQsV0FBVyxhQUFhLEdBQUcsMkJBQTJCO0lBQ3RELFdBQVcsYUFBYSxLQUFNLHlCQUF5QjtHQUN6RCxPQUFPLElBQUksZUFBZSxvQkFBb0I7SUFDNUMsV0FBVyxhQUFhLEdBQUcsMEJBQTBCO0lBQ3JELFdBQVcsYUFBYSxLQUFNLHdCQUF3QjtHQUN4RCxPQUFPLElBQUksZUFBZSxlQUFlO0lBQ3ZDLFdBQVcsYUFBYSxHQUFHLDBCQUEwQjtJQUNyRCxXQUFXLGFBQWEsS0FBTSx5QkFBeUI7R0FDekQsT0FBTztJQUNMLFdBQVcsYUFBYSxHQUFHLHlCQUF5QjtJQUNwRCxXQUFXLGFBQWEsS0FBTSx5QkFBeUI7R0FDekQ7R0FDQSxXQUFXLGFBQWEsR0FBRyxrQkFBa0I7R0FDN0MsSUFBSSxZQUFZO0dBQ2hCLElBQUksU0FBUyxHQUFHLEdBQUcsT0FBTyxNQUFNOztHQUdoQyxNQUFNLFlBQVksYUFBYTtHQUMvQixVQUFVLFNBQVMsTUFBTTtJQUN2QixFQUFFLEtBQUssRUFBRTtJQUNULEVBQUUsS0FBSyxFQUFFLFNBQVMsS0FBSyxJQUFJLE9BQU8sRUFBRSxJQUFJLEdBQUksSUFBSTtJQUNoRCxFQUFFLFlBQVksRUFBRTtJQUVoQixJQUFJLEVBQUUsSUFBSSxTQUFTLElBQUk7S0FDckIsRUFBRSxJQUFJLENBQUM7S0FDUCxFQUFFLElBQUksS0FBSyxPQUFPLElBQUk7SUFDeEI7SUFDQSxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLFFBQVE7SUFDN0IsSUFBSSxFQUFFLElBQUksUUFBUSxJQUFJLEVBQUUsSUFBSSxDQUFDO0lBRTdCLElBQUksS0FBSztJQUNULElBQUksVUFBVSxFQUFFLEdBQUcsRUFBRSxDQUFDO0lBQ3RCLElBQUksT0FBTyxFQUFFLFFBQVE7SUFFckIsSUFBSSxFQUFFLFNBQVMsU0FBUztLQUN0QixNQUFNLFlBQVksSUFBSSxxQkFBcUIsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSTtLQUNoRSxVQUFVLGFBQWEsR0FBRyxlQUFlLGNBQWMsOEJBQThCLHlCQUF5QjtLQUM5RyxVQUFVLGFBQWEsR0FBRyxrQkFBa0I7S0FDNUMsSUFBSSxZQUFZO0tBQ2hCLElBQUksVUFBVTtLQUNkLElBQUksSUFBSSxHQUFHLEdBQUcsRUFBRSxNQUFNLEdBQUcsS0FBSyxLQUFLLENBQUM7S0FDcEMsSUFBSSxLQUFLO0lBQ1gsT0FBTyxJQUFJLEVBQUUsU0FBUyxXQUFXO0tBQy9CLElBQUksWUFBWSxlQUFlLGNBQWMsWUFBWTtLQUN6RCxJQUFJLFVBQVU7S0FDZCxJQUFJLElBQUksR0FBRyxHQUFHLEVBQUUsUUFBUSxJQUFJLEtBQU0sS0FBSyxJQUFJLE9BQU8sSUFBSSxFQUFFLENBQUMsSUFBSSxHQUFHLEtBQUssS0FBSyxDQUFDO0tBQzNFLElBQUksS0FBSztJQUNYLE9BQU87S0FDTCxJQUFJLGNBQWMsRUFBRSxVQUFVO0tBQzlCLElBQUksWUFBWSxlQUFlLGNBQWMsWUFBYSxlQUFlLHFCQUFxQixZQUFZO0tBQzFHLElBQUksVUFBVTtLQUNkLElBQUksUUFBUSxHQUFHLEdBQUcsRUFBRSxPQUFPLEtBQU0sRUFBRSxPQUFPLEtBQUssS0FBSyxLQUFLLEdBQUcsR0FBRyxLQUFLLEtBQUssQ0FBQztLQUMxRSxJQUFJLEtBQUs7SUFDWDtJQUVBLElBQUksUUFBUTtHQUNkLENBQUM7O0dBR0QsTUFBTSxRQUFRLGdCQUFnQjtHQUM5QixLQUFLLElBQUksSUFBSSxNQUFNLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FBSztJQUMxQyxNQUFNLElBQUksTUFBTTtJQUNoQixFQUFFLFNBQVM7SUFDWCxFQUFFLEtBQUs7SUFDUCxJQUFJLEVBQUUsU0FBUyxHQUFHO0tBQ2hCLE1BQU0sT0FBTyxHQUFHLENBQUM7S0FDakI7SUFDRjtJQUNBLElBQUksS0FBSztJQUNULElBQUksY0FBYyxFQUFFO0lBQ3BCLElBQUksWUFBWSxlQUFlLGNBQWMsWUFBWTtJQUN6RCxJQUFJLFVBQVU7SUFDZCxJQUFJLElBQUksRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLE1BQU0sR0FBRyxLQUFLLEtBQUssQ0FBQztJQUN4QyxJQUFJLEtBQUs7SUFDVCxJQUFJLFFBQVE7R0FDZDs7R0FHQSxNQUFNLFFBQVEsWUFBWTtHQUMxQixNQUFNLFVBQVUsa0JBQWtCO0dBRWxDLE1BQU0sU0FBUyxPQUFPO0lBQ3BCLElBQUksR0FBRyxRQUFRLGVBQWU7SUFFOUIsTUFBTSxZQUFZLEtBQUssSUFBSSxJQUFNLGdCQUFnQixHQUFHLFNBQVMsR0FBSTtJQUNqRSxJQUFJLGFBQWEsS0FBTTtJQUV2QixJQUFJLEtBQUs7SUFDVCxJQUFJLFVBQVUsR0FBRyxHQUFHLEdBQUcsQ0FBQztJQUV4QixNQUFNLFlBQVksU0FBUyxPQUFPLEdBQUc7SUFDckMsTUFBTSxhQUFhLG9CQUFvQixHQUFHLE9BQU8sT0FBTztJQUV4RCxNQUFNLFVBQVU7SUFFaEIsSUFBSSxhQUFhLFlBQVk7S0FDM0IsSUFBSSxZQUFZO0tBQ2hCLElBQUksY0FBYztLQUNsQixJQUFJLFlBQVk7S0FDaEIsTUFBTSxLQUFLLEdBQUcsUUFBUTtLQUN0QixNQUFNLEtBQUssR0FBRyxTQUFTO0tBQ3ZCLElBQUksVUFBVTtLQUNkLElBQUksVUFBVSxDQUFDLEtBQUssR0FBRyxDQUFDLEtBQUssR0FBRyxJQUFJLElBQUksQ0FBQztLQUN6QyxJQUFJLEtBQUs7S0FDVCxJQUFJLE9BQU87S0FFWCxJQUFJLGFBQWE7S0FDakIsSUFBSSxZQUFZO0tBQ2hCLElBQUksT0FBTyxRQUFRLEdBQUcsV0FBVyxFQUFFLEtBQUs7SUFDMUMsT0FBTztLQUNMLElBQUksYUFBYTtLQUNqQixJQUFJLFlBQVksR0FBRztLQUNuQixJQUFJLE9BQU8sR0FBRyxHQUFHLFdBQVcsR0FBRyxHQUFHLFNBQVMsS0FBSztJQUNsRDtJQUVBLElBQUksWUFBWTtJQUNoQixJQUFJLGVBQWU7SUFDbkIsSUFBSSxjQUFjO0lBRWxCLElBQUksU0FBUyxHQUFHLE1BQU0sR0FBRyxDQUFDO0lBRTFCLElBQUksUUFBUTtHQUNkLENBQUM7R0FFRCxJQUFJLFFBQVE7R0FFWixrQkFBa0IsVUFBVSxzQkFBc0IsTUFBTTtFQUMxRDtFQUVBLGtCQUFrQixVQUFVLHNCQUFzQixNQUFNO0VBRXhELGFBQWE7R0FDWCxJQUFJLGtCQUFrQixTQUFTO0lBQzdCLHFCQUFxQixrQkFBa0IsT0FBTztHQUNoRDtFQUNGO0NBQ0YsR0FBRztFQUFDO0VBQWU7RUFBYztFQUFrQjtFQUFZO0NBQVMsQ0FBQztDQUV6RSxPQUNFLHdCQUFDLE9BQUQ7RUFDRSxXQUFXLGdIQUNULGNBQWMsaUJBQWlCO0VBRWpDLE9BQU87R0FDTCxZQUFZO0dBQ1osYUFBYTtFQUNmO1lBUEYsQ0FTRSx3QkFBQyxVQUFEO0dBQ0UsS0FBSztHQUNMLGVBQWU7R0FDZixnQkFBZ0I7R0FDaEIsU0FBUztHQUNULFdBQVU7R0FDVixPQUFPLEVBQ0wsV0FBVyxXQUFXLFFBQVEsUUFBUSxHQUFHLGVBQWUsUUFBUSxRQUFRLEdBQUcsTUFDN0U7RUFDRDs7OztZQUdELHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDRSx3QkFBQyxVQUFEO0tBQ0UsZUFBZSxjQUFjLE1BQU0sS0FBSyxJQUFJLEdBQUssUUFBUSxJQUFJLElBQUksQ0FBRSxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7S0FDL0UsV0FBVTtLQUNWLE9BQU07ZUFFTix3QkFBQyxRQUFELEVBQVEsV0FBVSxjQUFlOzs7OztJQUMzQjs7Ozs7SUFFUix3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFoQixDQUNHLEtBQUssTUFBTSxZQUFZLEdBQUcsR0FBRSxHQUN6Qjs7Ozs7O0lBRU4sd0JBQUMsVUFBRDtLQUNFLGVBQWUsY0FBYyxNQUFNLEtBQUssSUFBSSxLQUFNLFFBQVEsSUFBSSxJQUFJLENBQUUsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO0tBQ2hGLFdBQVU7S0FDVixPQUFNO2VBRU4sd0JBQUMsU0FBRCxFQUFTLFdBQVUsY0FBZTs7Ozs7SUFDNUI7Ozs7O0lBRVAsY0FBYyxLQUNiLHdCQUFDLFVBQUQ7S0FDRSxlQUFlLGFBQWEsQ0FBRztLQUMvQixXQUFVO0tBQ1YsT0FBTTtlQUVOLHdCQUFDLFdBQUQsRUFBVyxXQUFVLFVBQVc7Ozs7O0lBQzFCOzs7OztHQUVQOzs7OztVQUNGOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJSb3NlQ2FudmFzLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlUmVmLCB1c2VFZmZlY3QsIHVzZUNhbGxiYWNrLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGNyZWF0ZUF0bW9zcGhlcmljUGFydGljbGVzLCBGbG9hdGluZ1BhcnRpY2xlIH0gZnJvbSAnLi4vdXRpbHMvcm9zZUdlbmVyYXRvcic7XG5pbXBvcnQgeyBnZW5lcmF0ZVVuaWZpZWRGbG93ZXJFbGVtZW50cywgRmxvd2VyVHlwZSB9IGZyb20gJy4uL3V0aWxzL2Zsb3dlclNoYXBlcyc7XG5pbXBvcnQgeyBGbG93ZXJUZXh0RWxlbWVudCB9IGZyb20gJy4uL3V0aWxzL2xpbHlHZW5lcmF0b3InO1xuaW1wb3J0IHsgQ09MT1JfVEhFTUVTLCBMb3ZlUGhyYXNlIH0gZnJvbSAnLi4vZGF0YS9sYW5ndWFnZXMnO1xuaW1wb3J0IHsgWm9vbUluLCBab29tT3V0LCBSb3RhdGVDY3cgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuXG5pbnRlcmZhY2UgUm9zZUNhbnZhc1Byb3BzIHtcbiAgYmxvb21Qcm9ncmVzczogbnVtYmVyOyAgICAgICAgICAvLyAwIHRvIDFcbiAgdGhlbWVJZDogc3RyaW5nO1xuICByZWNpcGllbnROYW1lOiBzdHJpbmc7XG4gIGZsb3dlclR5cGU/OiBGbG93ZXJUeXBlO1xuICBpc0NpbmVtYXRpYzogYm9vbGVhbjtcbiAgb25TZWxlY3RQaHJhc2U/OiAocGhyYXNlOiBMb3ZlUGhyYXNlKSA9PiB2b2lkO1xuICBzZWxlY3RlZFBocmFzZUlkPzogc3RyaW5nIHwgbnVsbDtcbiAgb25Ib3ZlclBocmFzZT86IChwaHJhc2U6IExvdmVQaHJhc2UgfCBudWxsKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgY29uc3QgUm9zZUNhbnZhczogUmVhY3QuRkM8Um9zZUNhbnZhc1Byb3BzPiA9ICh7XG4gIGJsb29tUHJvZ3Jlc3MsXG4gIHRoZW1lSWQsXG4gIHJlY2lwaWVudE5hbWUsXG4gIGZsb3dlclR5cGUgPSAncGlua19yb3NlJyxcbiAgaXNDaW5lbWF0aWMsXG4gIG9uU2VsZWN0UGhyYXNlLFxuICBzZWxlY3RlZFBocmFzZUlkLFxuICBvbkhvdmVyUGhyYXNlLFxufSkgPT4ge1xuICBjb25zdCBjYW52YXNSZWYgPSB1c2VSZWY8SFRNTENhbnZhc0VsZW1lbnQgfCBudWxsPihudWxsKTtcbiAgY29uc3QgZWxlbWVudHNSZWYgPSB1c2VSZWY8Rmxvd2VyVGV4dEVsZW1lbnRbXT4oW10pO1xuICBjb25zdCBwYXJ0aWNsZXNSZWYgPSB1c2VSZWY8RmxvYXRpbmdQYXJ0aWNsZVtdPihbXSk7XG4gIGNvbnN0IGFuaW1hdGlvbkZyYW1lUmVmID0gdXNlUmVmPG51bWJlciB8IG51bGw+KG51bGwpO1xuICBjb25zdCBtb3VzZVJlZiA9IHVzZVJlZjx7IHg6IG51bWJlcjsgeTogbnVtYmVyOyBhY3RpdmU6IGJvb2xlYW4gfT4oeyB4OiAtMTAwMCwgeTogLTEwMDAsIGFjdGl2ZTogZmFsc2UgfSk7XG4gIGNvbnN0IGhvdmVyZWRFbGVtZW50UmVmID0gdXNlUmVmPEZsb3dlclRleHRFbGVtZW50IHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IHNwYXJrbGVUcmFpbFJlZiA9IHVzZVJlZjx7IHg6IG51bWJlcjsgeTogbnVtYmVyOyBhbHBoYTogbnVtYmVyOyBzaXplOiBudW1iZXIgfVtdPihbXSk7XG5cbiAgLy8gWm9vbSAmIFBhbiBzdGF0ZSBmb3IgdWx0aW1hdGUgdGV4dCBpbnNwZWN0aW9uXG4gIGNvbnN0IFt6b29tTGV2ZWwsIHNldFpvb21MZXZlbF0gPSB1c2VTdGF0ZTxudW1iZXI+KDEuMCk7XG5cbiAgLy8gUGFyYWxsYXggdGlsdCBhbmdsZXNcbiAgY29uc3QgdGlsdFJlZiA9IHVzZVJlZjx7IHJ4OiBudW1iZXI7IHJ5OiBudW1iZXIgfT4oeyByeDogMCwgcnk6IDAgfSk7XG5cbiAgY29uc3QgY3VycmVudFRoZW1lID0gQ09MT1JfVEhFTUVTLmZpbmQoKHQpID0+IHQuaWQgPT09IHRoZW1lSWQpIHx8IENPTE9SX1RIRU1FU1swXTtcblxuICAvLyBJbml0aWFsaXplIG9yIHJlZ2VuZXJhdGUgZmxvd2VyIGVsZW1lbnRzIG9uIHJlc2l6ZSBvciByZWNpcGllbnQgbmFtZSBjaGFuZ2VcbiAgY29uc3QgcmVidWlsZEVsZW1lbnRzID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIGNvbnN0IGNhbnZhcyA9IGNhbnZhc1JlZi5jdXJyZW50O1xuICAgIGlmICghY2FudmFzKSByZXR1cm47XG4gICAgY29uc3Qgd2lkdGggPSBjYW52YXMuY2xpZW50V2lkdGg7XG4gICAgY29uc3QgaGVpZ2h0ID0gY2FudmFzLmNsaWVudEhlaWdodDtcblxuICAgIGVsZW1lbnRzUmVmLmN1cnJlbnQgPSBnZW5lcmF0ZVVuaWZpZWRGbG93ZXJFbGVtZW50cyhmbG93ZXJUeXBlLCB3aWR0aCwgaGVpZ2h0LCByZWNpcGllbnROYW1lKTtcbiAgICBwYXJ0aWNsZXNSZWYuY3VycmVudCA9IGNyZWF0ZUF0bW9zcGhlcmljUGFydGljbGVzKDMwLCB3aWR0aCwgaGVpZ2h0KTtcbiAgfSwgW3JlY2lwaWVudE5hbWUsIGZsb3dlclR5cGVdKTtcblxuICAvLyBIYW5kbGUgQ2FudmFzIFJlc2l6ZSB3aXRoIGhpZ2ggRFBSIGZvciBtYXhpbXVtIHNoYXJwbmVzc1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IGNhbnZhcyA9IGNhbnZhc1JlZi5jdXJyZW50O1xuICAgIGlmICghY2FudmFzKSByZXR1cm47XG5cbiAgICBjb25zdCBoYW5kbGVSZXNpemUgPSAoKSA9PiB7XG4gICAgICBjb25zdCBkcHIgPSBNYXRoLm1heCgyLCB3aW5kb3cuZGV2aWNlUGl4ZWxSYXRpbyB8fCAxKTtcbiAgICAgIGNvbnN0IHJlY3QgPSBjYW52YXMuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgICBjYW52YXMud2lkdGggPSBNYXRoLnJvdW5kKHJlY3Qud2lkdGggKiBkcHIpO1xuICAgICAgY2FudmFzLmhlaWdodCA9IE1hdGgucm91bmQocmVjdC5oZWlnaHQgKiBkcHIpO1xuICAgICAgcmVidWlsZEVsZW1lbnRzKCk7XG4gICAgfTtcblxuICAgIGhhbmRsZVJlc2l6ZSgpO1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdyZXNpemUnLCBoYW5kbGVSZXNpemUpO1xuICAgIHJldHVybiAoKSA9PiB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcigncmVzaXplJywgaGFuZGxlUmVzaXplKTtcbiAgfSwgW3JlYnVpbGRFbGVtZW50c10pO1xuXG4gIC8vIE1vdXNlIC8gVG91Y2ggaGFuZGxlcnMgZm9yIGludGVyYWN0aW9uXG4gIGNvbnN0IGhhbmRsZVBvaW50ZXJNb3ZlID0gKGU6IFJlYWN0LlBvaW50ZXJFdmVudDxIVE1MQ2FudmFzRWxlbWVudD4pID0+IHtcbiAgICBjb25zdCBjYW52YXMgPSBjYW52YXNSZWYuY3VycmVudDtcbiAgICBpZiAoIWNhbnZhcykgcmV0dXJuO1xuICAgIGNvbnN0IHJlY3QgPSBjYW52YXMuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG5cbiAgICBjb25zdCByYXdNeCA9IGUuY2xpZW50WCAtIHJlY3QubGVmdDtcbiAgICBjb25zdCByYXdNeSA9IGUuY2xpZW50WSAtIHJlY3QudG9wO1xuXG4gICAgY29uc3QgY2VudGVyWCA9IHJlY3Qud2lkdGggLyAyO1xuICAgIGNvbnN0IGNlbnRlclkgPSByZWN0LmhlaWdodCAvIDI7XG5cbiAgICBjb25zdCBteCA9IGNlbnRlclggKyAocmF3TXggLSBjZW50ZXJYKSAvIHpvb21MZXZlbDtcbiAgICBjb25zdCBteSA9IGNlbnRlclkgKyAocmF3TXkgLSBjZW50ZXJZKSAvIHpvb21MZXZlbDtcblxuICAgIG1vdXNlUmVmLmN1cnJlbnQgPSB7IHg6IG14LCB5OiBteSwgYWN0aXZlOiB0cnVlIH07XG5cbiAgICAvLyBHZW50bGUgM0QgcGVyc3BlY3RpdmUgdGlsdFxuICAgIGNvbnN0IG5vcm1YID0gKHJhd014IC8gcmVjdC53aWR0aCAtIDAuNSkgKiAyO1xuICAgIGNvbnN0IG5vcm1ZID0gKHJhd015IC8gcmVjdC5oZWlnaHQgLSAwLjUpICogMjtcbiAgICB0aWx0UmVmLmN1cnJlbnQgPSB7IHJ4OiBub3JtWSAqIDMsIHJ5OiAtbm9ybVggKiA0IH07XG5cbiAgICAvLyBBZGQgZ2xvd2luZyBtb3VzZSBzcGFya2xlciBkdXN0XG4gICAgaWYgKE1hdGgucmFuZG9tKCkgPCAwLjQpIHtcbiAgICAgIHNwYXJrbGVUcmFpbFJlZi5jdXJyZW50LnB1c2goe1xuICAgICAgICB4OiBteCArIChNYXRoLnJhbmRvbSgpIC0gMC41KSAqIDEyLFxuICAgICAgICB5OiBteSArIChNYXRoLnJhbmRvbSgpIC0gMC41KSAqIDEyLFxuICAgICAgICBhbHBoYTogMC45LFxuICAgICAgICBzaXplOiAyICsgTWF0aC5yYW5kb20oKSAqIDMsXG4gICAgICB9KTtcbiAgICB9XG5cbiAgICAvLyBQcmVjaXNlIEJvdW5kaW5nIEJveCBjb2xsaXNpb24gdGVzdCBmb3IgZXZlcnkgd29yZFxuICAgIGxldCBmb3VuZDogRmxvd2VyVGV4dEVsZW1lbnQgfCBudWxsID0gbnVsbDtcbiAgICBjb25zdCBlbGVtcyA9IGVsZW1lbnRzUmVmLmN1cnJlbnQ7XG4gICAgZm9yIChsZXQgaSA9IGVsZW1zLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG4gICAgICBjb25zdCBlbCA9IGVsZW1zW2ldO1xuICAgICAgaWYgKGVsLm9yZGVyID4gYmxvb21Qcm9ncmVzcykgY29udGludWU7XG5cbiAgICAgIGNvbnN0IGhhbGZXID0gZWwud2lkdGggLyAyICsgNjtcbiAgICAgIGNvbnN0IGhhbGZIID0gZWwuaGVpZ2h0IC8gMiArIDQ7XG5cbiAgICAgIGlmIChcbiAgICAgICAgbXggPj0gZWwueCAtIGhhbGZXICYmXG4gICAgICAgIG14IDw9IGVsLnggKyBoYWxmVyAmJlxuICAgICAgICBteSA+PSBlbC55IC0gaGFsZkggJiZcbiAgICAgICAgbXkgPD0gZWwueSArIGhhbGZIXG4gICAgICApIHtcbiAgICAgICAgZm91bmQgPSBlbDtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKGZvdW5kICE9PSBob3ZlcmVkRWxlbWVudFJlZi5jdXJyZW50KSB7XG4gICAgICBob3ZlcmVkRWxlbWVudFJlZi5jdXJyZW50ID0gZm91bmQ7XG4gICAgICBpZiAob25Ib3ZlclBocmFzZSkge1xuICAgICAgICBvbkhvdmVyUGhyYXNlKGZvdW5kID8gZm91bmQucGhyYXNlIDogbnVsbCk7XG4gICAgICB9XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVBvaW50ZXJMZWF2ZSA9ICgpID0+IHtcbiAgICBtb3VzZVJlZi5jdXJyZW50LmFjdGl2ZSA9IGZhbHNlO1xuICAgIGhvdmVyZWRFbGVtZW50UmVmLmN1cnJlbnQgPSBudWxsO1xuICAgIHRpbHRSZWYuY3VycmVudCA9IHsgcng6IDAsIHJ5OiAwIH07XG4gICAgaWYgKG9uSG92ZXJQaHJhc2UpIG9uSG92ZXJQaHJhc2UobnVsbCk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlQ2xpY2sgPSAoKSA9PiB7XG4gICAgaWYgKGhvdmVyZWRFbGVtZW50UmVmLmN1cnJlbnQpIHtcbiAgICAgIGlmIChvblNlbGVjdFBocmFzZSkge1xuICAgICAgICBvblNlbGVjdFBocmFzZShob3ZlcmVkRWxlbWVudFJlZi5jdXJyZW50LnBocmFzZSk7XG4gICAgICB9XG4gICAgfVxuICB9O1xuXG4gIC8vIE1haW4gUmVuZGVyIExvb3Agd2l0aCBIaWdoLUNsYXJpdHkgVHlwb2dyYXBoeVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IGNhbnZhcyA9IGNhbnZhc1JlZi5jdXJyZW50O1xuICAgIGlmICghY2FudmFzKSByZXR1cm47XG4gICAgY29uc3QgY3R4ID0gY2FudmFzLmdldENvbnRleHQoJzJkJywgeyBhbHBoYTogZmFsc2UgfSk7XG4gICAgaWYgKCFjdHgpIHJldHVybjtcblxuICAgIGxldCB0aW1lID0gMDtcblxuICAgIGNvbnN0IHJlbmRlciA9ICgpID0+IHtcbiAgICAgIHRpbWUgKz0gMC4wMjtcbiAgICAgIGNvbnN0IGRwciA9IE1hdGgubWF4KDIsIHdpbmRvdy5kZXZpY2VQaXhlbFJhdGlvIHx8IDEpO1xuICAgICAgY29uc3Qgd2lkdGggPSBjYW52YXMud2lkdGggLyBkcHI7XG4gICAgICBjb25zdCBoZWlnaHQgPSBjYW52YXMuaGVpZ2h0IC8gZHByO1xuXG4gICAgICBjdHguc2F2ZSgpO1xuICAgICAgY3R4LnNjYWxlKGRwciwgZHByKTtcblxuICAgICAgLy8gUGl0Y2ggYmxhY2sgYmFja2dyb3VuZCAoIzAwMDAwMCBhcyBpbiByZWZlcmVuY2UgaW1hZ2UpXG4gICAgICBjdHguZmlsbFN0eWxlID0gJyMwMDAwMDAnO1xuICAgICAgY3R4LmZpbGxSZWN0KDAsIDAsIHdpZHRoLCBoZWlnaHQpO1xuXG4gICAgICAvLyBBcHBseSBab29tIHRyYW5zZm9ybWF0aW9uXG4gICAgICBjb25zdCBjeCA9IHdpZHRoIC8gMjtcbiAgICAgIGNvbnN0IGN5ID0gaGVpZ2h0ICogMC4zNjtcblxuICAgICAgY3R4LnRyYW5zbGF0ZShjeCwgY3kpO1xuICAgICAgY3R4LnNjYWxlKHpvb21MZXZlbCwgem9vbUxldmVsKTtcbiAgICAgIGN0eC50cmFuc2xhdGUoLWN4LCAtY3kpO1xuXG4gICAgICAvLyAxLiBTdWJ0bGUgd2FybSBhbWJpZW50IGdsb3cgYmVoaW5kIHRoZSBmbG93ZXJcbiAgICAgIGNvbnN0IHJhZGlhbEdyYWQgPSBjdHguY3JlYXRlUmFkaWFsR3JhZGllbnQoY3gsIGN5LCAyMCwgY3gsIGN5LCB3aWR0aCAqIDAuNjApO1xuICAgICAgaWYgKGZsb3dlclR5cGUgPT09ICdwaW5rX3Jvc2UnIHx8IGZsb3dlclR5cGUgPT09ICdwaW5rX2xpbHknKSB7XG4gICAgICAgIHJhZGlhbEdyYWQuYWRkQ29sb3JTdG9wKDAsICdyZ2JhKDI0NCwgMTE0LCAxODIsIDAuMjIpJyk7XG4gICAgICAgIHJhZGlhbEdyYWQuYWRkQ29sb3JTdG9wKDAuNDUsICdyZ2JhKDE5MCwgMjQsIDkzLCAwLjA2KScpO1xuICAgICAgfSBlbHNlIGlmIChmbG93ZXJUeXBlID09PSAnZ29sZGVuX3N1bmZsb3dlcicpIHtcbiAgICAgICAgcmFkaWFsR3JhZC5hZGRDb2xvclN0b3AoMCwgJ3JnYmEoMjQ1LCAxNTgsIDExLCAwLjIyKScpO1xuICAgICAgICByYWRpYWxHcmFkLmFkZENvbG9yU3RvcCgwLjQ1LCAncmdiYSgxODAsIDgzLCA5LCAwLjA2KScpO1xuICAgICAgfSBlbHNlIGlmIChmbG93ZXJUeXBlID09PSAncm95YWxfdHVsaXAnKSB7XG4gICAgICAgIHJhZGlhbEdyYWQuYWRkQ29sb3JTdG9wKDAsICdyZ2JhKDE2OCwgODUsIDI0NywgMC4yMiknKTtcbiAgICAgICAgcmFkaWFsR3JhZC5hZGRDb2xvclN0b3AoMC40NSwgJ3JnYmEoODgsIDI4LCAxMzUsIDAuMDYpJyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByYWRpYWxHcmFkLmFkZENvbG9yU3RvcCgwLCAncmdiYSgyMjUsIDI5LCA3MiwgMC4yMiknKTtcbiAgICAgICAgcmFkaWFsR3JhZC5hZGRDb2xvclN0b3AoMC40NSwgJ3JnYmEoMTU5LCAxOCwgNTcsIDAuMDYpJyk7XG4gICAgICB9XG4gICAgICByYWRpYWxHcmFkLmFkZENvbG9yU3RvcCgxLCAncmdiYSgwLCAwLCAwLCAwKScpO1xuICAgICAgY3R4LmZpbGxTdHlsZSA9IHJhZGlhbEdyYWQ7XG4gICAgICBjdHguZmlsbFJlY3QoMCwgMCwgd2lkdGgsIGhlaWdodCk7XG5cbiAgICAgIC8vIDIuIFJlbmRlciBBdG1vc3BoZXJpYyBGbG9hdGluZyBQZXRhbHMgJiBGYWlyeSBMaWdodHNcbiAgICAgIGNvbnN0IHBhcnRpY2xlcyA9IHBhcnRpY2xlc1JlZi5jdXJyZW50O1xuICAgICAgcGFydGljbGVzLmZvckVhY2goKHApID0+IHtcbiAgICAgICAgcC55ICs9IHAuc3BlZWRZO1xuICAgICAgICBwLnggKz0gcC5zcGVlZFggKyBNYXRoLnNpbih0aW1lICsgcC55ICogMC4wMSkgKiAwLjM7XG4gICAgICAgIHAucm90YXRpb24gKz0gcC5yb3RhdGlvblNwZWVkO1xuXG4gICAgICAgIGlmIChwLnkgPiBoZWlnaHQgKyAzMCkge1xuICAgICAgICAgIHAueSA9IC0yMDtcbiAgICAgICAgICBwLnggPSBNYXRoLnJhbmRvbSgpICogd2lkdGg7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHAueCA8IC0zMCkgcC54ID0gd2lkdGggKyAyMDtcbiAgICAgICAgaWYgKHAueCA+IHdpZHRoICsgMzApIHAueCA9IC0yMDtcblxuICAgICAgICBjdHguc2F2ZSgpO1xuICAgICAgICBjdHgudHJhbnNsYXRlKHAueCwgcC55KTtcbiAgICAgICAgY3R4LnJvdGF0ZShwLnJvdGF0aW9uKTtcblxuICAgICAgICBpZiAocC50eXBlID09PSAnYm9rZWgnKSB7XG4gICAgICAgICAgY29uc3QgYm9rZWhHcmFkID0gY3R4LmNyZWF0ZVJhZGlhbEdyYWRpZW50KDAsIDAsIDAsIDAsIDAsIHAuc2l6ZSk7XG4gICAgICAgICAgYm9rZWhHcmFkLmFkZENvbG9yU3RvcCgwLCBmbG93ZXJUeXBlID09PSAncGlua19yb3NlJyA/ICdyZ2JhKDI0NCwgMTE0LCAxODIsIDAuMTgpJyA6ICdyZ2JhKDI0NCwgNjMsIDk0LCAwLjE4KScpO1xuICAgICAgICAgIGJva2VoR3JhZC5hZGRDb2xvclN0b3AoMSwgJ3JnYmEoMCwgMCwgMCwgMCknKTtcbiAgICAgICAgICBjdHguZmlsbFN0eWxlID0gYm9rZWhHcmFkO1xuICAgICAgICAgIGN0eC5iZWdpblBhdGgoKTtcbiAgICAgICAgICBjdHguYXJjKDAsIDAsIHAuc2l6ZSwgMCwgTWF0aC5QSSAqIDIpO1xuICAgICAgICAgIGN0eC5maWxsKCk7XG4gICAgICAgIH0gZWxzZSBpZiAocC50eXBlID09PSAnc3BhcmtsZScpIHtcbiAgICAgICAgICBjdHguZmlsbFN0eWxlID0gZmxvd2VyVHlwZSA9PT0gJ3Bpbmtfcm9zZScgPyAnI2ZiY2ZlOCcgOiAnI2ZkYTRhZic7XG4gICAgICAgICAgY3R4LmJlZ2luUGF0aCgpO1xuICAgICAgICAgIGN0eC5hcmMoMCwgMCwgcC5zaXplICogKDEgKyAwLjMgKiBNYXRoLnNpbih0aW1lICogMyArIHAueCkpLCAwLCBNYXRoLlBJICogMik7XG4gICAgICAgICAgY3R4LmZpbGwoKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjdHguZ2xvYmFsQWxwaGEgPSBwLm9wYWNpdHkgKiAwLjg7XG4gICAgICAgICAgY3R4LmZpbGxTdHlsZSA9IGZsb3dlclR5cGUgPT09ICdwaW5rX3Jvc2UnID8gJyNmNDcyYjYnIDogKGZsb3dlclR5cGUgPT09ICdnb2xkZW5fc3VuZmxvd2VyJyA/ICcjZjU5ZTBiJyA6ICcjZTExZDQ4Jyk7XG4gICAgICAgICAgY3R4LmJlZ2luUGF0aCgpO1xuICAgICAgICAgIGN0eC5lbGxpcHNlKDAsIDAsIHAuc2l6ZSAqIDAuNDUsIHAuc2l6ZSAqIDEuMSwgTWF0aC5QSSAvIDQsIDAsIE1hdGguUEkgKiAyKTtcbiAgICAgICAgICBjdHguZmlsbCgpO1xuICAgICAgICB9XG5cbiAgICAgICAgY3R4LnJlc3RvcmUoKTtcbiAgICAgIH0pO1xuXG4gICAgICAvLyAzLiBSZW5kZXIgTW91c2UgU3BhcmtsZXIgVHJhaWxzXG4gICAgICBjb25zdCB0cmFpbCA9IHNwYXJrbGVUcmFpbFJlZi5jdXJyZW50O1xuICAgICAgZm9yIChsZXQgaSA9IHRyYWlsLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG4gICAgICAgIGNvbnN0IHMgPSB0cmFpbFtpXTtcbiAgICAgICAgcy5hbHBoYSAtPSAwLjAzO1xuICAgICAgICBzLnkgLT0gMC4zO1xuICAgICAgICBpZiAocy5hbHBoYSA8PSAwKSB7XG4gICAgICAgICAgdHJhaWwuc3BsaWNlKGksIDEpO1xuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIGN0eC5zYXZlKCk7XG4gICAgICAgIGN0eC5nbG9iYWxBbHBoYSA9IHMuYWxwaGE7XG4gICAgICAgIGN0eC5maWxsU3R5bGUgPSBmbG93ZXJUeXBlID09PSAncGlua19yb3NlJyA/ICcjZmJjZmU4JyA6ICcjZmRhNGFmJztcbiAgICAgICAgY3R4LmJlZ2luUGF0aCgpO1xuICAgICAgICBjdHguYXJjKHMueCwgcy55LCBzLnNpemUsIDAsIE1hdGguUEkgKiAyKTtcbiAgICAgICAgY3R4LmZpbGwoKTtcbiAgICAgICAgY3R4LnJlc3RvcmUoKTtcbiAgICAgIH1cblxuICAgICAgLy8gNC4gUmVuZGVyIFJhem9yLVNoYXJwLCBHZW5lcm91c2x5IFNwYWNlZCBIb3Jpem9udGFsIEZsb3dlciBXb3Jkc1xuICAgICAgY29uc3QgZWxlbXMgPSBlbGVtZW50c1JlZi5jdXJyZW50O1xuICAgICAgY29uc3QgaG92ZXJlZCA9IGhvdmVyZWRFbGVtZW50UmVmLmN1cnJlbnQ7XG5cbiAgICAgIGVsZW1zLmZvckVhY2goKGVsKSA9PiB7XG4gICAgICAgIGlmIChlbC5vcmRlciA+IGJsb29tUHJvZ3Jlc3MpIHJldHVybjtcblxuICAgICAgICBjb25zdCBibG9vbUZhZGUgPSBNYXRoLm1pbigxLjAsIChibG9vbVByb2dyZXNzIC0gZWwub3JkZXIpIC8gMC4wNSk7XG4gICAgICAgIGlmIChibG9vbUZhZGUgPD0gMC4wMSkgcmV0dXJuO1xuXG4gICAgICAgIGN0eC5zYXZlKCk7XG4gICAgICAgIGN0eC50cmFuc2xhdGUoZWwueCwgZWwueSk7XG5cbiAgICAgICAgY29uc3QgaXNIb3ZlcmVkID0gaG92ZXJlZD8uaWQgPT09IGVsLmlkO1xuICAgICAgICBjb25zdCBpc1NlbGVjdGVkID0gc2VsZWN0ZWRQaHJhc2VJZCAmJiBlbC5waHJhc2UuaWQgPT09IHNlbGVjdGVkUGhyYXNlSWQ7XG5cbiAgICAgICAgY29uc3QgZm9udEZhbSA9ICctYXBwbGUtc3lzdGVtLCBCbGlua01hY1N5c3RlbUZvbnQsIFwiU2Vnb2UgVUlcIiwgUm9ib3RvLCBcIkhlbHZldGljYSBOZXVlXCIsIEFyaWFsLCBzYW5zLXNlcmlmJztcblxuICAgICAgICBpZiAoaXNIb3ZlcmVkIHx8IGlzU2VsZWN0ZWQpIHtcbiAgICAgICAgICBjdHguZmlsbFN0eWxlID0gJ3JnYmEoMjU1LCAyNTUsIDI1NSwgMC4yMiknO1xuICAgICAgICAgIGN0eC5zdHJva2VTdHlsZSA9ICcjZmZmZmZmJztcbiAgICAgICAgICBjdHgubGluZVdpZHRoID0gMS41O1xuICAgICAgICAgIGNvbnN0IHB3ID0gZWwud2lkdGggKyAxMjtcbiAgICAgICAgICBjb25zdCBwaCA9IGVsLmhlaWdodCArIDY7XG4gICAgICAgICAgY3R4LmJlZ2luUGF0aCgpO1xuICAgICAgICAgIGN0eC5yb3VuZFJlY3QoLXB3IC8gMiwgLXBoIC8gMiwgcHcsIHBoLCA2KTtcbiAgICAgICAgICBjdHguZmlsbCgpO1xuICAgICAgICAgIGN0eC5zdHJva2UoKTtcblxuICAgICAgICAgIGN0eC5zaGFkb3dCbHVyID0gMDtcbiAgICAgICAgICBjdHguZmlsbFN0eWxlID0gJyNmZmZmZmYnO1xuICAgICAgICAgIGN0eC5mb250ID0gYGJvbGQgJHtlbC5mb250U2l6ZSArIDF9cHggJHtmb250RmFtfWA7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY3R4LnNoYWRvd0JsdXIgPSAwO1xuICAgICAgICAgIGN0eC5maWxsU3R5bGUgPSBlbC5jb2xvcjtcbiAgICAgICAgICBjdHguZm9udCA9IGAke2VsLmZvbnRXZWlnaHR9ICR7ZWwuZm9udFNpemV9cHggJHtmb250RmFtfWA7XG4gICAgICAgIH1cblxuICAgICAgICBjdHgudGV4dEFsaWduID0gJ2NlbnRlcic7XG4gICAgICAgIGN0eC50ZXh0QmFzZWxpbmUgPSAnbWlkZGxlJztcbiAgICAgICAgY3R4Lmdsb2JhbEFscGhhID0gYmxvb21GYWRlO1xuXG4gICAgICAgIGN0eC5maWxsVGV4dChlbC50ZXh0LCAwLCAwKTtcblxuICAgICAgICBjdHgucmVzdG9yZSgpO1xuICAgICAgfSk7XG5cbiAgICAgIGN0eC5yZXN0b3JlKCk7XG5cbiAgICAgIGFuaW1hdGlvbkZyYW1lUmVmLmN1cnJlbnQgPSByZXF1ZXN0QW5pbWF0aW9uRnJhbWUocmVuZGVyKTtcbiAgICB9O1xuXG4gICAgYW5pbWF0aW9uRnJhbWVSZWYuY3VycmVudCA9IHJlcXVlc3RBbmltYXRpb25GcmFtZShyZW5kZXIpO1xuXG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGlmIChhbmltYXRpb25GcmFtZVJlZi5jdXJyZW50KSB7XG4gICAgICAgIGNhbmNlbEFuaW1hdGlvbkZyYW1lKGFuaW1hdGlvbkZyYW1lUmVmLmN1cnJlbnQpO1xuICAgICAgfVxuICAgIH07XG4gIH0sIFtibG9vbVByb2dyZXNzLCBjdXJyZW50VGhlbWUsIHNlbGVjdGVkUGhyYXNlSWQsIGZsb3dlclR5cGUsIHpvb21MZXZlbF0pO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgY2xhc3NOYW1lPXtgcmVsYXRpdmUgdy1mdWxsIGgtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBvdmVyZmxvdy1oaWRkZW4gdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tNzAwIGJnLWJsYWNrICR7XG4gICAgICAgIGlzQ2luZW1hdGljID8gJ3JvdW5kZWQtbm9uZScgOiAncm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci16aW5jLTkwMCdcbiAgICAgIH1gfVxuICAgICAgc3R5bGU9e3tcbiAgICAgICAgYmFja2dyb3VuZDogJyMwMDAwMDAnLFxuICAgICAgICBwZXJzcGVjdGl2ZTogJzEwMDBweCcsXG4gICAgICB9fVxuICAgID5cbiAgICAgIDxjYW52YXNcbiAgICAgICAgcmVmPXtjYW52YXNSZWZ9XG4gICAgICAgIG9uUG9pbnRlck1vdmU9e2hhbmRsZVBvaW50ZXJNb3ZlfVxuICAgICAgICBvblBvaW50ZXJMZWF2ZT17aGFuZGxlUG9pbnRlckxlYXZlfVxuICAgICAgICBvbkNsaWNrPXtoYW5kbGVDbGlja31cbiAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtZnVsbCBjdXJzb3ItcG9pbnRlciB0b3VjaC1ub25lIHNlbGVjdC1ub25lIHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTMwMCBlYXNlLW91dFwiXG4gICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgdHJhbnNmb3JtOiBgcm90YXRlWCgke3RpbHRSZWYuY3VycmVudC5yeH1kZWcpIHJvdGF0ZVkoJHt0aWx0UmVmLmN1cnJlbnQucnl9ZGVnKWAsXG4gICAgICAgIH19XG4gICAgICAvPlxuXG4gICAgICB7LyogUXVpY2sgWm9vbSBIVUQgVG9vbGJhciBvbiBDYW52YXMgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC00IHJpZ2h0LTQgei0yMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGJnLXppbmMtOTUwLzg1IGJvcmRlciBib3JkZXItemluYy04MDAvODAgcm91bmRlZC14bCBwLTEuNSBiYWNrZHJvcC1ibHVyLW1kIHRleHQteHMgdGV4dC16aW5jLTMwMCBzaGFkb3cteGxcIj5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFpvb21MZXZlbCgoeikgPT4gTWF0aC5taW4oMi4wLCBOdW1iZXIoKHogKyAwLjI1KS50b0ZpeGVkKDIpKSkpfVxuICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHJvdW5kZWQtbGcgaG92ZXI6YmctemluYy04MDAgdGV4dC16aW5jLTMwMCBob3Zlcjp0ZXh0LXdoaXRlIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICB0aXRsZT1cIlpvb20gSW4gKEluc3BlY3Qgd29yZHMpXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxab29tSW4gY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1bMTFweF0gcHgtMSB0ZXh0LXBpbmstMzAwIGZvbnQtc2VtaWJvbGQgc2VsZWN0LW5vbmVcIj5cbiAgICAgICAgICB7TWF0aC5yb3VuZCh6b29tTGV2ZWwgKiAxMDApfSVcbiAgICAgICAgPC9zcGFuPlxuXG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRab29tTGV2ZWwoKHopID0+IE1hdGgubWF4KDAuNzUsIE51bWJlcigoeiAtIDAuMjUpLnRvRml4ZWQoMikpKSl9XG4gICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgcm91bmRlZC1sZyBob3ZlcjpiZy16aW5jLTgwMCB0ZXh0LXppbmMtMzAwIGhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgIHRpdGxlPVwiWm9vbSBPdXRcIlxuICAgICAgICA+XG4gICAgICAgICAgPFpvb21PdXQgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICB7em9vbUxldmVsICE9PSAxLjAgJiYgKFxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFpvb21MZXZlbCgxLjApfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgcm91bmRlZC1sZyBob3ZlcjpiZy16aW5jLTgwMCB0ZXh0LXppbmMtNDAwIGhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgdGl0bGU9XCJSZXNldCBab29tXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8Um90YXRlQ2N3IGNsYXNzTmFtZT1cInctMyBoLTNcIiAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuZXhwb3J0IHR5cGUgeyBGbG93ZXJUeXBlIH07XG4iXX0=