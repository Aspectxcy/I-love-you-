<!doctype html>
<html lang="en">
  <head>
    <script type="module" src="/@vite/client"></script>

    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Pink Rose In Every Language</title>
    <meta name="description" content="An interactive creative coding experience rendering blooming flowers entirely from 'I love you' in 60+ world languages with real Python code, romantic audio, and personalization." />
    <meta property="og:title" content="Pink Rose In Every Language" />
    <meta property="og:description" content="An interactive creative coding experience rendering blooming flowers entirely from 'I love you' in 60+ world languages with real Python code, romantic audio, and personalization." />
    <meta property="og:type" content="website" />
    <meta name="twitter:card" content="summary_large_image" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@600;700&family=Great+Vibes&family=JetBrains+Mono:wght@400;500;600&family=Plus+Jakarta+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&family=Cinzel:wght@600;700;800&display=swap" rel="stylesheet">
  <script src="/_aistudio-iframe.js?v=1f94f900"></script></head>
  <body class="bg-black text-rose-50 antialiased selection:bg-rose-500 selection:text-white">
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
