const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport2_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=3ba6436c";
import { Volume2, Sparkles, Heart, X } from "/node_modules/.vite/deps/lucide-react.js?v=3ba6436c";
var _jsxFileName = "/app/applet/src/components/PhraseCard.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=3ba6436c";
export const PhraseCard = ({ phrase, onClose, onDedicate }) => {
	const [isSpeaking, setIsSpeaking] = useState(false);
	const handleSpeak = () => {
		if (!("speechSynthesis" in window)) return;
		window.speechSynthesis.cancel();
		const utterance = new SpeechSynthesisUtterance(phrase.phrase);
		// Attempt to match best language code
		const langMap = {
			fr: "fr-FR",
			es: "es-ES",
			it: "it-IT",
			de: "de-DE",
			ja: "ja-JP",
			zh: "zh-CN",
			ko: "ko-KR",
			ru: "ru-RU",
			tr: "tr-TR",
			ar: "ar-SA",
			hi: "hi-IN",
			pt: "pt-BR",
			el: "el-GR",
			nl: "nl-NL",
			pl: "pl-PL",
			sv: "sv-SE",
			sw: "sw-KE",
			id: "id-ID",
			vi: "vi-VN",
			th: "th-TH",
			hu: "hu-HU",
			ro: "ro-RO",
			cs: "cs-CZ",
			da: "da-DK",
			no: "nb-NO",
			fi: "fi-FI"
		};
		if (langMap[phrase.id]) {
			utterance.lang = langMap[phrase.id];
		}
		utterance.rate = .85;
		utterance.pitch = 1.05;
		utterance.onstart = () => setIsSpeaking(true);
		utterance.onend = () => setIsSpeaking(false);
		utterance.onerror = () => setIsSpeaking(false);
		window.speechSynthesis.speak(utterance);
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "relative group overflow-hidden rounded-2xl bg-zinc-950/85 backdrop-blur-xl border border-rose-500/30 p-5 shadow-2xl shadow-rose-950/50 text-rose-50 transition-all duration-300",
		children: [
			/* @__PURE__ */ _jsxDEV("div", { className: "absolute -top-12 -right-12 w-32 h-32 bg-rose-600/20 rounded-full blur-2xl pointer-events-none" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 66,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center justify-between gap-3 mb-3",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2.5",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "text-2xl select-none",
						role: "img",
						"aria-label": phrase.language,
						children: phrase.flag
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 71,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-1.5",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs uppercase tracking-wider font-semibold text-rose-300",
							children: phrase.language
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 76,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-[10px] px-1.5 py-0.5 rounded-full bg-rose-950/80 border border-rose-500/30 text-rose-400",
							children: phrase.region
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 79,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 75,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-[11px] text-zinc-400 font-medium",
						children: phrase.native
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 83,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 74,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 70,
					columnNumber: 9
				}, this), onClose && /* @__PURE__ */ _jsxDEV("button", {
					onClick: onClose,
					className: "p-1 rounded-full text-zinc-400 hover:text-white hover:bg-zinc-800/80 transition-colors",
					title: "Close",
					children: /* @__PURE__ */ _jsxDEV(X, { className: "w-4 h-4" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 95,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 90,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 69,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "my-3 p-3.5 rounded-xl bg-gradient-to-r from-rose-950/50 to-zinc-900/60 border border-rose-500/20 text-center relative overflow-hidden",
				children: [/* @__PURE__ */ _jsxDEV("h3", {
					className: "text-2xl md:text-3xl font-bold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-rose-200 via-rose-100 to-rose-300 py-1",
					children: [
						"\"",
						phrase.phrase,
						"\""
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 102,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs font-mono text-rose-300/80 mt-1 italic",
					children: ["Pronounced: ", /* @__PURE__ */ _jsxDEV("span", {
						className: "font-semibold text-rose-200",
						children: phrase.pronunciation
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 106,
						columnNumber: 23
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 105,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 101,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mb-4 text-xs text-zinc-300 leading-relaxed bg-zinc-900/40 p-2.5 rounded-lg border border-zinc-800/60",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-1 text-[11px] font-medium text-rose-400 mb-1",
					children: [/* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-3 h-3" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 113,
						columnNumber: 11
					}, this), " Cultural Lore"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 112,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("p", { children: phrase.funFact }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 115,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 111,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-2 pt-1 border-t border-zinc-800/60",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					onClick: handleSpeak,
					disabled: isSpeaking,
					className: "flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-rose-900/30 hover:bg-rose-900/50 border border-rose-500/30 text-xs font-medium text-rose-200 hover:text-white transition-all shadow-sm active:scale-95",
					children: isSpeaking ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Volume2, { className: "w-3.5 h-3.5 animate-pulse text-rose-400" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 127,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Whispering..." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 128,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 126,
						columnNumber: 13
					}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Volume2, { className: "w-3.5 h-3.5 text-rose-400" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 132,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Listen Pronunciation" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 133,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 131,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 120,
					columnNumber: 9
				}, this), onDedicate && /* @__PURE__ */ _jsxDEV("button", {
					onClick: () => onDedicate(phrase),
					className: "flex items-center gap-1.5 py-2 px-3 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-medium transition-all shadow-md shadow-rose-950 active:scale-95",
					title: "Focus this phrase on the rose",
					children: [/* @__PURE__ */ _jsxDEV(Heart, { className: "w-3.5 h-3.5 fill-current" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 144,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Focus" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 145,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 139,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 119,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 64,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUVoQyxTQUFTLFNBQWtCLFVBQVUsT0FBYyxTQUFTOzs7QUFRNUQsT0FBTyxNQUFNLGNBQXlDLEVBQUUsUUFBUSxTQUFTLGlCQUFpQjtDQUN4RixNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxLQUFLO0NBRWxELE1BQU0sb0JBQW9CO0VBQ3hCLElBQUksRUFBRSxxQkFBcUIsU0FBUztFQUVwQyxPQUFPLGdCQUFnQixPQUFPO0VBQzlCLE1BQU0sWUFBWSxJQUFJLHlCQUF5QixPQUFPLE1BQU07O0VBRzVELE1BQU0sVUFBa0M7R0FDdEMsSUFBSTtHQUNKLElBQUk7R0FDSixJQUFJO0dBQ0osSUFBSTtHQUNKLElBQUk7R0FDSixJQUFJO0dBQ0osSUFBSTtHQUNKLElBQUk7R0FDSixJQUFJO0dBQ0osSUFBSTtHQUNKLElBQUk7R0FDSixJQUFJO0dBQ0osSUFBSTtHQUNKLElBQUk7R0FDSixJQUFJO0dBQ0osSUFBSTtHQUNKLElBQUk7R0FDSixJQUFJO0dBQ0osSUFBSTtHQUNKLElBQUk7R0FDSixJQUFJO0dBQ0osSUFBSTtHQUNKLElBQUk7R0FDSixJQUFJO0dBQ0osSUFBSTtHQUNKLElBQUk7RUFDTjtFQUVBLElBQUksUUFBUSxPQUFPLEtBQUs7R0FDdEIsVUFBVSxPQUFPLFFBQVEsT0FBTztFQUNsQztFQUNBLFVBQVUsT0FBTztFQUNqQixVQUFVLFFBQVE7RUFFbEIsVUFBVSxnQkFBZ0IsY0FBYyxJQUFJO0VBQzVDLFVBQVUsY0FBYyxjQUFjLEtBQUs7RUFDM0MsVUFBVSxnQkFBZ0IsY0FBYyxLQUFLO0VBRTdDLE9BQU8sZ0JBQWdCLE1BQU0sU0FBUztDQUN4QztDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUVFLHdCQUFDLE9BQUQsRUFBSyxXQUFVLGdHQUFpRzs7Ozs7R0FHaEgsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxRQUFEO01BQU0sV0FBVTtNQUF1QixNQUFLO01BQU0sY0FBWSxPQUFPO2dCQUNsRSxPQUFPO0tBQ0o7Ozs7ZUFDTix3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFDYixPQUFPO01BQ0o7Ozs7Z0JBQ04sd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQ2IsT0FBTztNQUNKOzs7O2NBQ0g7Ozs7O2VBQ0wsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQ1YsT0FBTztLQUNQOzs7O2FBQ0E7Ozs7YUFDRjs7Ozs7Y0FFSixXQUNDLHdCQUFDLFVBQUQ7S0FDRSxTQUFTO0tBQ1QsV0FBVTtLQUNWLE9BQU07ZUFFTix3QkFBQyxHQUFELEVBQUcsV0FBVSxVQUFXOzs7OztJQUNsQjs7OztZQUVQOzs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBZDtNQUF5SjtNQUNySixPQUFPO01BQU87S0FDZDs7Ozs7Y0FDSix3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFiLENBQThELGdCQUNoRCx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBK0IsT0FBTztLQUFvQjs7OzthQUNyRjs7Ozs7WUFDQTs7Ozs7O0dBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxVQUFXOzs7O2VBQUMsZ0JBQzdCOzs7OztjQUNMLHdCQUFDLEtBQUQsWUFBSSxPQUFPLFFBQVc7Ozs7WUFDbkI7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxVQUFEO0tBQ0UsU0FBUztLQUNULFVBQVU7S0FDVixXQUFVO2VBRVQsYUFDQyxnREFDRSx3QkFBQyxTQUFELEVBQVMsV0FBVSwwQ0FBMkM7Ozs7ZUFDOUQsd0JBQUMsUUFBRCxZQUFNLGdCQUFtQjs7OzthQUN6Qjs7OztnQkFFRixnREFDRSx3QkFBQyxTQUFELEVBQVMsV0FBVSw0QkFBNkI7Ozs7ZUFDaEQsd0JBQUMsUUFBRCxZQUFNLHVCQUEwQjs7OzthQUNoQzs7Ozs7SUFFRTs7OztjQUVQLGNBQ0Msd0JBQUMsVUFBRDtLQUNFLGVBQWUsV0FBVyxNQUFNO0tBQ2hDLFdBQVU7S0FDVixPQUFNO2VBSFIsQ0FLRSx3QkFBQyxPQUFELEVBQU8sV0FBVSwyQkFBNEI7Ozs7ZUFDN0Msd0JBQUMsUUFBRCxZQUFNLFFBQVc7Ozs7YUFDWDs7Ozs7WUFFUDs7Ozs7O0VBQ0Y7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlBocmFzZUNhcmQudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IExvdmVQaHJhc2UgfSBmcm9tICcuLi9kYXRhL2xhbmd1YWdlcyc7XG5pbXBvcnQgeyBWb2x1bWUyLCBWb2x1bWVYLCBTcGFya2xlcywgSGVhcnQsIEdsb2JlLCBYIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcblxuaW50ZXJmYWNlIFBocmFzZUNhcmRQcm9wcyB7XG4gIHBocmFzZTogTG92ZVBocmFzZTtcbiAgb25DbG9zZT86ICgpID0+IHZvaWQ7XG4gIG9uRGVkaWNhdGU/OiAocGhyYXNlOiBMb3ZlUGhyYXNlKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgY29uc3QgUGhyYXNlQ2FyZDogUmVhY3QuRkM8UGhyYXNlQ2FyZFByb3BzPiA9ICh7IHBocmFzZSwgb25DbG9zZSwgb25EZWRpY2F0ZSB9KSA9PiB7XG4gIGNvbnN0IFtpc1NwZWFraW5nLCBzZXRJc1NwZWFraW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICBjb25zdCBoYW5kbGVTcGVhayA9ICgpID0+IHtcbiAgICBpZiAoISgnc3BlZWNoU3ludGhlc2lzJyBpbiB3aW5kb3cpKSByZXR1cm47XG5cbiAgICB3aW5kb3cuc3BlZWNoU3ludGhlc2lzLmNhbmNlbCgpO1xuICAgIGNvbnN0IHV0dGVyYW5jZSA9IG5ldyBTcGVlY2hTeW50aGVzaXNVdHRlcmFuY2UocGhyYXNlLnBocmFzZSk7XG4gICAgXG4gICAgLy8gQXR0ZW1wdCB0byBtYXRjaCBiZXN0IGxhbmd1YWdlIGNvZGVcbiAgICBjb25zdCBsYW5nTWFwOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge1xuICAgICAgZnI6ICdmci1GUicsXG4gICAgICBlczogJ2VzLUVTJyxcbiAgICAgIGl0OiAnaXQtSVQnLFxuICAgICAgZGU6ICdkZS1ERScsXG4gICAgICBqYTogJ2phLUpQJyxcbiAgICAgIHpoOiAnemgtQ04nLFxuICAgICAga286ICdrby1LUicsXG4gICAgICBydTogJ3J1LVJVJyxcbiAgICAgIHRyOiAndHItVFInLFxuICAgICAgYXI6ICdhci1TQScsXG4gICAgICBoaTogJ2hpLUlOJyxcbiAgICAgIHB0OiAncHQtQlInLFxuICAgICAgZWw6ICdlbC1HUicsXG4gICAgICBubDogJ25sLU5MJyxcbiAgICAgIHBsOiAncGwtUEwnLFxuICAgICAgc3Y6ICdzdi1TRScsXG4gICAgICBzdzogJ3N3LUtFJyxcbiAgICAgIGlkOiAnaWQtSUQnLFxuICAgICAgdmk6ICd2aS1WTicsXG4gICAgICB0aDogJ3RoLVRIJyxcbiAgICAgIGh1OiAnaHUtSFUnLFxuICAgICAgcm86ICdyby1STycsXG4gICAgICBjczogJ2NzLUNaJyxcbiAgICAgIGRhOiAnZGEtREsnLFxuICAgICAgbm86ICduYi1OTycsXG4gICAgICBmaTogJ2ZpLUZJJyxcbiAgICB9O1xuXG4gICAgaWYgKGxhbmdNYXBbcGhyYXNlLmlkXSkge1xuICAgICAgdXR0ZXJhbmNlLmxhbmcgPSBsYW5nTWFwW3BocmFzZS5pZF07XG4gICAgfVxuICAgIHV0dGVyYW5jZS5yYXRlID0gMC44NTsgLy8gU2xpZ2h0bHkgc2xvd2VyLCBtb3JlIHJvbWFudGljIGRlbGl2ZXJ5XG4gICAgdXR0ZXJhbmNlLnBpdGNoID0gMS4wNTtcblxuICAgIHV0dGVyYW5jZS5vbnN0YXJ0ID0gKCkgPT4gc2V0SXNTcGVha2luZyh0cnVlKTtcbiAgICB1dHRlcmFuY2Uub25lbmQgPSAoKSA9PiBzZXRJc1NwZWFraW5nKGZhbHNlKTtcbiAgICB1dHRlcmFuY2Uub25lcnJvciA9ICgpID0+IHNldElzU3BlYWtpbmcoZmFsc2UpO1xuXG4gICAgd2luZG93LnNwZWVjaFN5bnRoZXNpcy5zcGVhayh1dHRlcmFuY2UpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBncm91cCBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC0yeGwgYmctemluYy05NTAvODUgYmFja2Ryb3AtYmx1ci14bCBib3JkZXIgYm9yZGVyLXJvc2UtNTAwLzMwIHAtNSBzaGFkb3ctMnhsIHNoYWRvdy1yb3NlLTk1MC81MCB0ZXh0LXJvc2UtNTAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwXCI+XG4gICAgICB7LyogQmFja2dyb3VuZCBhbWJpZW50IGJsdXNoICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSAtdG9wLTEyIC1yaWdodC0xMiB3LTMyIGgtMzIgYmctcm9zZS02MDAvMjAgcm91bmRlZC1mdWxsIGJsdXItMnhsIHBvaW50ZXItZXZlbnRzLW5vbmVcIiAvPlxuXG4gICAgICB7LyogSGVhZGVyIGJhciAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIG1iLTNcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41XCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC0yeGwgc2VsZWN0LW5vbmVcIiByb2xlPVwiaW1nXCIgYXJpYS1sYWJlbD17cGhyYXNlLmxhbmd1YWdlfT5cbiAgICAgICAgICAgIHtwaHJhc2UuZmxhZ31cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBmb250LXNlbWlib2xkIHRleHQtcm9zZS0zMDBcIj5cbiAgICAgICAgICAgICAgICB7cGhyYXNlLmxhbmd1YWdlfVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHB4LTEuNSBweS0wLjUgcm91bmRlZC1mdWxsIGJnLXJvc2UtOTUwLzgwIGJvcmRlciBib3JkZXItcm9zZS01MDAvMzAgdGV4dC1yb3NlLTQwMFwiPlxuICAgICAgICAgICAgICAgIHtwaHJhc2UucmVnaW9ufVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtemluYy00MDAgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAge3BocmFzZS5uYXRpdmV9XG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHtvbkNsb3NlICYmIChcbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xIHJvdW5kZWQtZnVsbCB0ZXh0LXppbmMtNDAwIGhvdmVyOnRleHQtd2hpdGUgaG92ZXI6YmctemluYy04MDAvODAgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgdGl0bGU9XCJDbG9zZVwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIFRoZSBSb21hbnRpYyBQaHJhc2UgRGlzcGxheSAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXktMyBwLTMuNSByb3VuZGVkLXhsIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1yb3NlLTk1MC81MCB0by16aW5jLTkwMC82MCBib3JkZXIgYm9yZGVyLXJvc2UtNTAwLzIwIHRleHQtY2VudGVyIHJlbGF0aXZlIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC0yeGwgbWQ6dGV4dC0zeGwgZm9udC1ib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtdHJhbnNwYXJlbnQgYmctY2xpcC10ZXh0IGJnLWdyYWRpZW50LXRvLXIgZnJvbS1yb3NlLTIwMCB2aWEtcm9zZS0xMDAgdG8tcm9zZS0zMDAgcHktMVwiPlxuICAgICAgICAgIFwie3BocmFzZS5waHJhc2V9XCJcbiAgICAgICAgPC9oMz5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1vbm8gdGV4dC1yb3NlLTMwMC84MCBtdC0xIGl0YWxpY1wiPlxuICAgICAgICAgIFByb25vdW5jZWQ6IDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1yb3NlLTIwMFwiPntwaHJhc2UucHJvbnVuY2lhdGlvbn08L3NwYW4+XG4gICAgICAgIDwvcD5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogUG9ldGljICYgQ3VsdHVyYWwgTG9yZSAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhzIHRleHQtemluYy0zMDAgbGVhZGluZy1yZWxheGVkIGJnLXppbmMtOTAwLzQwIHAtMi41IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci16aW5jLTgwMC82MFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHRleHQtWzExcHhdIGZvbnQtbWVkaXVtIHRleHQtcm9zZS00MDAgbWItMVwiPlxuICAgICAgICAgIDxTcGFya2xlcyBjbGFzc05hbWU9XCJ3LTMgaC0zXCIgLz4gQ3VsdHVyYWwgTG9yZVxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPHA+e3BocmFzZS5mdW5GYWN0fTwvcD5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogQWN0aW9uIEJ1dHRvbnMgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB0LTEgYm9yZGVyLXQgYm9yZGVyLXppbmMtODAwLzYwXCI+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVTcGVha31cbiAgICAgICAgICBkaXNhYmxlZD17aXNTcGVha2luZ31cbiAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgcHktMiBweC0zIHJvdW5kZWQteGwgYmctcm9zZS05MDAvMzAgaG92ZXI6Ymctcm9zZS05MDAvNTAgYm9yZGVyIGJvcmRlci1yb3NlLTUwMC8zMCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtcm9zZS0yMDAgaG92ZXI6dGV4dC13aGl0ZSB0cmFuc2l0aW9uLWFsbCBzaGFkb3ctc20gYWN0aXZlOnNjYWxlLTk1XCJcbiAgICAgICAgPlxuICAgICAgICAgIHtpc1NwZWFraW5nID8gKFxuICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgPFZvbHVtZTIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgYW5pbWF0ZS1wdWxzZSB0ZXh0LXJvc2UtNDAwXCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4+V2hpc3BlcmluZy4uLjwvc3Bhbj5cbiAgICAgICAgICAgIDwvPlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICA8PlxuICAgICAgICAgICAgICA8Vm9sdW1lMiBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXJvc2UtNDAwXCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4+TGlzdGVuIFByb251bmNpYXRpb248L3NwYW4+XG4gICAgICAgICAgICA8Lz5cbiAgICAgICAgICApfVxuICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICB7b25EZWRpY2F0ZSAmJiAoXG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25EZWRpY2F0ZShwaHJhc2UpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweS0yIHB4LTMgcm91bmRlZC14bCBiZy1yb3NlLTYwMCBob3ZlcjpiZy1yb3NlLTUwMCB0ZXh0LXdoaXRlIHRleHQteHMgZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1hbGwgc2hhZG93LW1kIHNoYWRvdy1yb3NlLTk1MCBhY3RpdmU6c2NhbGUtOTVcIlxuICAgICAgICAgICAgdGl0bGU9XCJGb2N1cyB0aGlzIHBocmFzZSBvbiB0aGUgcm9zZVwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPEhlYXJ0IGNsYXNzTmFtZT1cInctMy41IGgtMy41IGZpbGwtY3VycmVudFwiIC8+XG4gICAgICAgICAgICA8c3Bhbj5Gb2N1czwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==