export const LOVE_PHRASES = [
	{
		id: "fr",
		phrase: "Je t'aime",
		language: "French",
		native: "Français",
		pronunciation: "zhuh tem",
		region: "Europe",
		flag: "🇫🇷",
		funFact: "In French, 'Je t'aime' is deeply reserved for true, passionate love. Adding 'bien' actually waters it down to 'I like you'!"
	},
	{
		id: "es",
		phrase: "Te amo",
		language: "Spanish",
		native: "Español",
		pronunciation: "teh AH-moh",
		region: "Americas",
		flag: "🇪🇸",
		funFact: "'Te amo' is the highest poetic declaration of lifelong love in Spanish, while 'Te quiero' expresses everyday affection."
	},
	{
		id: "it",
		phrase: "Ti amo",
		language: "Italian",
		native: "Italiano",
		pronunciation: "tee AH-moh",
		region: "Europe",
		flag: "🇮🇹",
		funFact: "Italian reserves 'Ti amo' strictly for romantic soulmates, while friends and family hear 'Ti voglio bene' (I want the best for you)."
	},
	{
		id: "de",
		phrase: "Ich liebe dich",
		language: "German",
		native: "Deutsch",
		pronunciation: "ikh LEE-buh dikh",
		region: "Europe",
		flag: "🇩🇪",
		funFact: "Germans rarely utter 'Ich liebe dich' casually; when spoken, it carries solemn honesty and profound commitment."
	},
	{
		id: "ja",
		phrase: "愛してる",
		language: "Japanese",
		native: "日本語",
		pronunciation: "aishiteru (ah-ee-shee-teh-roo)",
		region: "Asia",
		flag: "🇯🇵",
		funFact: "In Japanese culture, 'Aishiteru' is so weighty and sacred that novelist Soseki Natsume famously translated it as 'The moon is beautiful, isn't it?'"
	},
	{
		id: "zh",
		phrase: "我爱你",
		language: "Mandarin Chinese",
		native: "中文 (简体)",
		pronunciation: "wǒ ài nǐ (woh eye nee)",
		region: "Asia",
		flag: "🇨🇳",
		funFact: "The Chinese character for love (愛) features a heart (心) nestled gently in the center between accepting arms."
	},
	{
		id: "ko",
		phrase: "사랑해",
		language: "Korean",
		native: "한국어",
		pronunciation: "saranghae (sah-rahng-heh)",
		region: "Asia",
		flag: "🇰🇷",
		funFact: "The pure Korean root 'sarang' (사랑) is etymologically connected to 'thinking deeply of someone' and keeping them in mind."
	},
	{
		id: "ru",
		phrase: "Я тебя люблю",
		language: "Russian",
		native: "Русский",
		pronunciation: "ya tebya lyublyu",
		region: "Europe",
		flag: "🇷🇺",
		funFact: "Because Russian word order is flexible, poets write 'Люблю тебя я' or 'Тебя люблю' to place lyrical emphasis on the beloved."
	},
	{
		id: "tr",
		phrase: "Seni seviyorum",
		language: "Turkish",
		native: "Türkçe",
		pronunciation: "seh-nee seh-vee-yor-oom",
		region: "Middle East",
		flag: "🇹🇷",
		funFact: "Derived from 'sevgi' (pure love). Turkish literature boasts some of the most heartrending mystical love poems (Divan poetry)."
	},
	{
		id: "tl",
		phrase: "Mahal kita",
		language: "Tagalog / Filipino",
		native: "Tagalog",
		pronunciation: "mah-hal kee-tah",
		region: "Asia",
		flag: "🇵🇭",
		funFact: "The word 'Mahal' also means 'precious' and 'priceless'—to love someone in Tagalog means to treasure them as beyond price."
	},
	{
		id: "ar",
		phrase: "أحبك",
		language: "Arabic",
		native: "العربية",
		pronunciation: "uhibbuka (to him) / uhibbuki (to her)",
		region: "Middle East",
		flag: "🇦🇪",
		funFact: "The Arabic language possesses over 11 distinct ascending stages of love, from 'Hawa' (attraction) to 'Ishq' (burning passion) and 'Huyum' (insane adoration)."
	},
	{
		id: "hi",
		phrase: "मैं तुमसे प्यार करता हूँ",
		language: "Hindi",
		native: "हिन्दी",
		pronunciation: "main tumse pyaar karta hoon",
		region: "Asia",
		flag: "🇮🇳",
		funFact: "The word 'Pyaar' traces back to Sanskrit 'Priya', symbolizing dear, cherished, and an eternal divine bond like Radha-Krishna."
	},
	{
		id: "pt",
		phrase: "Eu te amo",
		language: "Portuguese",
		native: "Português",
		pronunciation: "eh-oo chee AH-moo",
		region: "Americas",
		flag: "🇧🇷",
		funFact: "Portuguese is famous for the untranslatable word 'Saudade'—the sweet, aching melancholy longing for the one you love."
	},
	{
		id: "el",
		phrase: "Σ' αγαπώ",
		language: "Greek",
		native: "Ελληνικά",
		pronunciation: "s'agapo (sah-gah-POH)",
		region: "Europe",
		flag: "🇬🇷",
		funFact: "Rooted in 'Agape' (ἀγάπη), considered by ancient Greek philosophers the highest, most selfless form of unconditional universal devotion."
	},
	{
		id: "nl",
		phrase: "Ik hou van jou",
		language: "Dutch",
		native: "Nederlands",
		pronunciation: "ik how fahn yow",
		region: "Europe",
		flag: "🇳🇱",
		funFact: "Literally translates to 'I hold of you'—signifying keeping someone protected, cherished, and embraced safely in one's heart."
	},
	{
		id: "pl",
		phrase: "Kocham Cię",
		language: "Polish",
		native: "Polski",
		pronunciation: "KOH-khahm chyeh",
		region: "Europe",
		flag: "🇵🇱",
		funFact: "The word 'kochać' carries a gentle warmth reminiscent of caressing or cradling something infinitely precious."
	},
	{
		id: "sv",
		phrase: "Jag älskar dig",
		language: "Swedish",
		native: "Svenska",
		pronunciation: "yahg EL-skar dey",
		region: "Europe",
		flag: "🇸🇪",
		funFact: "Derived from Old Norse 'elska', which meant to nurture, protect, and care tenderly through cold Nordic winters."
	},
	{
		id: "sw",
		phrase: "Nakupenda",
		language: "Swahili",
		native: "Kiswahili",
		pronunciation: "nah-koo-PEN-dah",
		region: "Africa",
		flag: "🇰🇪",
		funFact: "Formed as an elegant single verb: 'na-' (present tense), '-ku-' (you), '-penda' (to love warmly)."
	},
	{
		id: "ga",
		phrase: "Táim i ngrá leat",
		language: "Irish Gaelic",
		native: "Gaeilge",
		pronunciation: "taw-im ih ngraw lyat",
		region: "Europe",
		flag: "🇮🇪",
		funFact: "Literally means 'I am in love with you', or poetically 'Mo chuisle' (my pulse / beat of my heart)."
	},
	{
		id: "haw",
		phrase: "Aloha au iā 'oe",
		language: "Hawaiian",
		native: "‘Ōlelo Hawai‘i",
		pronunciation: "ah-LOH-hah ow ee-AH oh-eh",
		region: "Oceania",
		flag: "🌺",
		funFact: "'Aloha' conveys sharing the divine breath of life ('ha') in the presence ('alo') of sacred warmth."
	},
	{
		id: "bn",
		phrase: "আমি তোমাকে ভালোবাসি",
		language: "Bengali",
		native: "বাংলা",
		pronunciation: "ami tomake bhalobashi",
		region: "Asia",
		flag: "🇧🇩",
		funFact: "The language of Nobel poet Rabindranath Tagore, where 'Bhalobasha' literally translates as 'making a home of goodness'."
	},
	{
		id: "id",
		phrase: "Aku cinta kamu",
		language: "Indonesian",
		native: "Bahasa Indonesia",
		pronunciation: "ah-koo chin-tah kah-moo",
		region: "Asia",
		flag: "🇮🇩",
		funFact: "'Cinta' traces back to Sanskrit 'Cintā', signifying constant contemplation and sweet mindful wonder."
	},
	{
		id: "vi",
		phrase: "Anh yêu em",
		language: "Vietnamese",
		native: "Tiếng Việt",
		pronunciation: "ahn eeyew em",
		region: "Asia",
		flag: "🇻🇳",
		funFact: "Pronouns in Vietnamese express tender relation—'Anh' (older/protective brother) loving 'Em' (beloved gentle flower)."
	},
	{
		id: "th",
		phrase: "ฉันรักเธอ",
		language: "Thai",
		native: "ไทย",
		pronunciation: "chan rak thoe (or phom rak khun)",
		region: "Asia",
		flag: "🇹🇭",
		funFact: "The word 'Rak' (รัก) is shared across millennia of Buddhist and courtly poetry to denote devotional warmth."
	},
	{
		id: "hu",
		phrase: "Szeretlek",
		language: "Hungarian",
		native: "Magyar",
		pronunciation: "SEH-ret-lek",
		region: "Europe",
		flag: "🇭🇺",
		funFact: "Hungarian grammar compresses subject and object into a single intimate verb ending: 'I love YOU'."
	},
	{
		id: "ro",
		phrase: "Te iubesc",
		language: "Romanian",
		native: "Română",
		pronunciation: "teh yoo-BESK",
		region: "Europe",
		flag: "🇷🇴",
		funFact: "A Romance language that adopted the Slavic root for love ('ljub'), creating a uniquely sweet lyrical blend."
	},
	{
		id: "uk",
		phrase: "Я тебе кохаю",
		language: "Ukrainian",
		native: "Українська",
		pronunciation: "ya tebe kohayu",
		region: "Europe",
		flag: "🇺🇦",
		funFact: "'Кохати' is reserved exclusively for deep, tender romantic passion, distinct from liking things or friendships."
	},
	{
		id: "cs",
		phrase: "Miluji tě",
		language: "Czech",
		native: "Čeština",
		pronunciation: "MEE-loo-yee tyeh",
		region: "Europe",
		flag: "🇨🇿",
		funFact: "Prague on May 1st (Czech Day of Love) sees thousands of couples kissing under blooming cherry blossom trees!"
	},
	{
		id: "fa",
		phrase: "دوستت دارم",
		language: "Persian (Farsi)",
		native: "فارسی",
		pronunciation: "doostat daram",
		region: "Middle East",
		flag: "🇮🇷",
		funFact: "Persian poetry by Rumi and Hafez is celebrated as the pinnacle of divine and romantic love literature."
	},
	{
		id: "he",
		phrase: "אני אוהב אותך",
		language: "Hebrew",
		native: "עברית",
		pronunciation: "ani ohev otach (m to f)",
		region: "Middle East",
		flag: "🇮🇱",
		funFact: "The root 'Ahav' appears throughout King Solomon's Song of Songs: 'I am my beloved’s, and my beloved is mine'."
	},
	{
		id: "da",
		phrase: "Jeg elsker dig",
		language: "Danish",
		native: "Dansk",
		pronunciation: "yai el-sker dai",
		region: "Europe",
		flag: "🇩🇰",
		funFact: "Deeply connected to the Danish concept of 'hygge'—warm candlelight, closeness, and feeling safe together."
	},
	{
		id: "no",
		phrase: "Jeg elsker deg",
		language: "Norwegian",
		native: "Norsk",
		pronunciation: "yai el-sker dai",
		region: "Europe",
		flag: "🇳🇴",
		funFact: "Shared with the majestic fjords and Northern Lights, representing enduring loyalty under Arctic skies."
	},
	{
		id: "fi",
		phrase: "Minä rakastan sinua",
		language: "Finnish",
		native: "Suomi",
		pronunciation: "mee-na RAH-kas-tahn SEE-noo-ah",
		region: "Europe",
		flag: "🇫🇮",
		funFact: "Finns are famous for quiet sincerity; to hear 'Minä rakastan sinua' is considered an unbreakable lifelong vow."
	},
	{
		id: "ur",
		phrase: "میں آپ سے محبت کرتا ہوں",
		language: "Urdu",
		native: "اردو",
		pronunciation: "main aap se mohabbat karta hoon",
		region: "Asia",
		flag: "🇵🇰",
		funFact: "'Mohabbat' and 'Ishq' in Urdu Ghazals are revered as forms of profound worship and spiritual devotion."
	},
	{
		id: "ta",
		phrase: "நான் உன்னை காதலிக்கிறேன்",
		language: "Tamil",
		native: "தமிழ்",
		pronunciation: "Naan unnai kaadhalikkiren",
		region: "Asia",
		flag: "🇮🇳",
		funFact: "Tamil Sangam literature classified romantic poems into five natural landscapes (Kurinji, Mullai, Marutham, Neythal, Palai)."
	},
	{
		id: "ms",
		phrase: "Saya sayang awak",
		language: "Malay",
		native: "Bahasa Melayu",
		pronunciation: "sah-yah sah-yahng ah-wahk",
		region: "Asia",
		flag: "🇲🇾",
		funFact: "'Sayang' means both love and sweet affectionate care, used also as a tender term of endearment like 'darling'."
	},
	{
		id: "la",
		phrase: "Te amo",
		language: "Latin",
		native: "Latina",
		pronunciation: "tay AH-moh",
		region: "Europe",
		flag: "🏛️",
		funFact: "Immortalized by Catullus: 'Odi et amo' (I hate and I love) and Virgil: 'Amor vincit omnia' (Love conquers all)."
	},
	{
		id: "eo",
		phrase: "Mi amas vin",
		language: "Esperanto",
		native: "Esperanto",
		pronunciation: "mee AH-mahs veen",
		region: "Europe",
		flag: "🌍",
		funFact: "Created as a universal bridge across all nations, 'Mi amas vin' was designed so any two humans on Earth could speak love."
	},
	{
		id: "zu",
		phrase: "Ngiyakuthanda",
		language: "Zulu",
		native: "isiZulu",
		pronunciation: "ng-ee-yah-koo-TAHN-dah",
		region: "Africa",
		flag: "🇿🇦",
		funFact: "Rooted in the philosophy of Ubuntu ('I am because we are')—love is viewed as an interconnected life force."
	},
	{
		id: "am",
		phrase: "እወድሻለሁ",
		language: "Amharic",
		native: "አማርኛ",
		pronunciation: "ewedishalehu (to her)",
		region: "Africa",
		flag: "🇪🇹",
		funFact: "Ancient Semitic Ge'ez script, spoken in Ethiopia, carrying melodies sung across millennium-old highland traditions."
	},
	{
		id: "sq",
		phrase: "Të dua",
		language: "Albanian",
		native: "Shqip",
		pronunciation: "tuh DOO-ah",
		region: "Europe",
		flag: "🇦🇱",
		funFact: "'Të dua' means both 'I love you' and 'I want you', expressing total desire and devotion in two pure syllables."
	},
	{
		id: "hr",
		phrase: "Volim te",
		language: "Croatian / Serbian",
		native: "Hrvatski / Srpski",
		pronunciation: "VOH-leem teh",
		region: "Europe",
		flag: "🇭🇷",
		funFact: "Traces to Proto-Slavic root 'volja' meaning 'will', signifying 'I choose you with all my free will and desire'."
	},
	{
		id: "ka",
		phrase: "მიყვარხარ",
		language: "Georgian",
		native: "ქართული",
		pronunciation: "miqvarkhar",
		region: "Europe",
		flag: "🇬🇪",
		funFact: "Written in the unique rounded Mkhedruli script, spoken in the ancient birthplace of wine and mountain legends."
	},
	{
		id: "is",
		phrase: "Ég elska þig",
		language: "Icelandic",
		native: "Íslenska",
		pronunciation: "yehg EL-skah theeg",
		region: "Europe",
		flag: "🇮🇸",
		funFact: "Preserves virtually unchanged Old Norse grammar from the Viking sagas of the 9th century."
	},
	{
		id: "sk",
		phrase: "Ľúbim ťa",
		language: "Slovak",
		native: "Slovenčina",
		pronunciation: "LYOO-beem tyah",
		region: "Europe",
		flag: "🇸🇰",
		funFact: "Slovaks use 'Ľúbim ťa' for romantic sweetness and 'Milujem ťa' for solemn eternal devotion."
	},
	{
		id: "cy",
		phrase: "Rwy’n dy garu di",
		language: "Welsh",
		native: "Cymraeg",
		pronunciation: "roo-in duh gah-ree dee",
		region: "Europe",
		flag: "🏴󠁧󠁢󠁷󠁬󠁳󠁿",
		funFact: "Wales celebrates St. Dwynwen's Day (the Welsh patron saint of lovers) on January 25 with hand-carved lovespoons!"
	},
	{
		id: "eu",
		phrase: "Maite zaitut",
		language: "Basque",
		native: "Euskara",
		pronunciation: "my-teh zye-toot",
		region: "Europe",
		flag: "🇪🇸",
		funFact: "Basque is a language isolate with zero known living relatives, carrying this love phrase through tens of thousands of years."
	},
	{
		id: "km",
		phrase: "ខ្ញុំស្រលាញ់អ្នក",
		language: "Khmer",
		native: "ភាសាខ្មែរ",
		pronunciation: "knhom sralanh anak",
		region: "Asia",
		flag: "🇰🇭",
		funFact: "Rendered in ornate Angkor Wat-era script, embodying gentle respect and enduring heart fidelity."
	},
	{
		id: "my",
		phrase: "မင်းကိုချစ်တယ်",
		language: "Burmese",
		native: "မြန်မာစာ",
		pronunciation: "min ko chit tal",
		region: "Asia",
		flag: "🇲🇲",
		funFact: "Written with graceful circular letters that originated from carving inscriptions on fragile palm leaves."
	},
	{
		id: "ne",
		phrase: "म तिमीलाई माया गर्छु",
		language: "Nepali",
		native: "नेपाली",
		pronunciation: "ma timīlāī māyā garchu",
		region: "Asia",
		flag: "🇳🇵",
		funFact: "The word 'Māyā' carries both sweet romantic love and the mystical, magical beauty of the cosmos."
	}
];
export const COLOR_THEMES = [
	{
		id: "crimson",
		name: "Eternal Crimson",
		description: "Classic passionate velvet ruby red with emerald stem",
		petalColors: [
			"#ff1744",
			"#f43f5e",
			"#e11d48",
			"#be123c",
			"#fda4af",
			"#fb7185"
		],
		stemColors: [
			"#10b981",
			"#059669",
			"#34d399",
			"#22c55e",
			"#86efac"
		],
		glowColor: "rgba(244, 63, 94, 0.6)",
		sparkleColor: "#fb7185",
		ambientBg: "radial-gradient(ellipse at 50% 30%, rgba(159, 18, 57, 0.22) 0%, rgba(15, 2, 7, 0.98) 75%)"
	},
	{
		id: "midnight",
		name: "Midnight Amethyst",
		description: "Mystical twilight violet and luminous lilac glow",
		petalColors: [
			"#c084fc",
			"#a855f7",
			"#9333ea",
			"#7e22ce",
			"#e9d5ff",
			"#d8b4fe"
		],
		stemColors: [
			"#06b6d4",
			"#0891b2",
			"#22d3ee",
			"#14b8a6"
		],
		glowColor: "rgba(168, 85, 247, 0.65)",
		sparkleColor: "#e9d5ff",
		ambientBg: "radial-gradient(ellipse at 50% 30%, rgba(88, 28, 135, 0.25) 0%, rgba(7, 3, 15, 0.98) 75%)"
	},
	{
		id: "golden",
		name: "Sunset Gold & Amber",
		description: "Warm golden hour radiance with honey & warm copper",
		petalColors: [
			"#fbbf24",
			"#f59e0b",
			"#d97706",
			"#b45309",
			"#fde68a",
			"#fef3c7"
		],
		stemColors: [
			"#65a30d",
			"#4d7c0f",
			"#84cc16",
			"#a3e635"
		],
		glowColor: "rgba(245, 158, 11, 0.65)",
		sparkleColor: "#fef08a",
		ambientBg: "radial-gradient(ellipse at 50% 30%, rgba(180, 83, 9, 0.25) 0%, rgba(18, 10, 3, 0.98) 75%)"
	},
	{
		id: "enchanted_white",
		name: "Enchanted Snow White",
		description: "Pure moonlight ivory with crystalline silver luminescence",
		petalColors: [
			"#f8fafc",
			"#f1f5f9",
			"#e2e8f0",
			"#cbd5e1",
			"#ffffff",
			"#e0e7ff"
		],
		stemColors: [
			"#059669",
			"#10b981",
			"#34d399",
			"#6ee7b7"
		],
		glowColor: "rgba(226, 232, 240, 0.6)",
		sparkleColor: "#ffffff",
		ambientBg: "radial-gradient(ellipse at 50% 30%, rgba(99, 102, 241, 0.18) 0%, rgba(5, 7, 18, 0.98) 75%)"
	},
	{
		id: "cyberpunk",
		name: "Cyber Romance",
		description: "Electric neon pink, laser cyan, and holographic synthwave",
		petalColors: [
			"#ff007f",
			"#ff1493",
			"#00f5ff",
			"#ff3399",
			"#ff69b4",
			"#00e5ff"
		],
		stemColors: [
			"#00ffcc",
			"#00ffaa",
			"#10b981"
		],
		glowColor: "rgba(255, 0, 127, 0.7)",
		sparkleColor: "#00f5ff",
		ambientBg: "radial-gradient(ellipse at 50% 30%, rgba(255, 0, 127, 0.22) 0%, rgba(5, 2, 18, 0.98) 75%)"
	}
];

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBV0EsT0FBTyxNQUFNLGVBQTZCO0NBQ3hDO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLGVBQWU7RUFDZixRQUFRO0VBQ1IsTUFBTTtFQUNOLFNBQVM7Q0FDWDtBQUNGO0FBRUEsT0FBTyxNQUFNLGVBQWU7Q0FDMUI7RUFDRSxJQUFJO0VBQ0osTUFBTTtFQUNOLGFBQWE7RUFDYixhQUFhO0dBQUM7R0FBVztHQUFXO0dBQVc7R0FBVztHQUFXO0VBQVM7RUFDOUUsWUFBWTtHQUFDO0dBQVc7R0FBVztHQUFXO0dBQVc7RUFBUztFQUNsRSxXQUFXO0VBQ1gsY0FBYztFQUNkLFdBQVc7Q0FDYjtDQUNBO0VBQ0UsSUFBSTtFQUNKLE1BQU07RUFDTixhQUFhO0VBQ2IsYUFBYTtHQUFDO0dBQVc7R0FBVztHQUFXO0dBQVc7R0FBVztFQUFTO0VBQzlFLFlBQVk7R0FBQztHQUFXO0dBQVc7R0FBVztFQUFTO0VBQ3ZELFdBQVc7RUFDWCxjQUFjO0VBQ2QsV0FBVztDQUNiO0NBQ0E7RUFDRSxJQUFJO0VBQ0osTUFBTTtFQUNOLGFBQWE7RUFDYixhQUFhO0dBQUM7R0FBVztHQUFXO0dBQVc7R0FBVztHQUFXO0VBQVM7RUFDOUUsWUFBWTtHQUFDO0dBQVc7R0FBVztHQUFXO0VBQVM7RUFDdkQsV0FBVztFQUNYLGNBQWM7RUFDZCxXQUFXO0NBQ2I7Q0FDQTtFQUNFLElBQUk7RUFDSixNQUFNO0VBQ04sYUFBYTtFQUNiLGFBQWE7R0FBQztHQUFXO0dBQVc7R0FBVztHQUFXO0dBQVc7RUFBUztFQUM5RSxZQUFZO0dBQUM7R0FBVztHQUFXO0dBQVc7RUFBUztFQUN2RCxXQUFXO0VBQ1gsY0FBYztFQUNkLFdBQVc7Q0FDYjtDQUNBO0VBQ0UsSUFBSTtFQUNKLE1BQU07RUFDTixhQUFhO0VBQ2IsYUFBYTtHQUFDO0dBQVc7R0FBVztHQUFXO0dBQVc7R0FBVztFQUFTO0VBQzlFLFlBQVk7R0FBQztHQUFXO0dBQVc7RUFBUztFQUM1QyxXQUFXO0VBQ1gsY0FBYztFQUNkLFdBQVc7Q0FDYjtBQUNGIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImxhbmd1YWdlcy50cyJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgaW50ZXJmYWNlIExvdmVQaHJhc2Uge1xuICBpZDogc3RyaW5nO1xuICBwaHJhc2U6IHN0cmluZztcbiAgbGFuZ3VhZ2U6IHN0cmluZztcbiAgbmF0aXZlOiBzdHJpbmc7XG4gIHByb251bmNpYXRpb246IHN0cmluZztcbiAgcmVnaW9uOiAnRXVyb3BlJyB8ICdBc2lhJyB8ICdBbWVyaWNhcycgfCAnQWZyaWNhJyB8ICdNaWRkbGUgRWFzdCcgfCAnT2NlYW5pYSc7XG4gIGZsYWc6IHN0cmluZztcbiAgZnVuRmFjdDogc3RyaW5nO1xufVxuXG5leHBvcnQgY29uc3QgTE9WRV9QSFJBU0VTOiBMb3ZlUGhyYXNlW10gPSBbXG4gIHtcbiAgICBpZDogJ2ZyJyxcbiAgICBwaHJhc2U6IFwiSmUgdCdhaW1lXCIsXG4gICAgbGFuZ3VhZ2U6ICdGcmVuY2gnLFxuICAgIG5hdGl2ZTogJ0ZyYW7Dp2FpcycsXG4gICAgcHJvbnVuY2lhdGlvbjogJ3podWggdGVtJyxcbiAgICByZWdpb246ICdFdXJvcGUnLFxuICAgIGZsYWc6ICfwn4er8J+HtycsXG4gICAgZnVuRmFjdDogXCJJbiBGcmVuY2gsICdKZSB0J2FpbWUnIGlzIGRlZXBseSByZXNlcnZlZCBmb3IgdHJ1ZSwgcGFzc2lvbmF0ZSBsb3ZlLiBBZGRpbmcgJ2JpZW4nIGFjdHVhbGx5IHdhdGVycyBpdCBkb3duIHRvICdJIGxpa2UgeW91JyFcIlxuICB9LFxuICB7XG4gICAgaWQ6ICdlcycsXG4gICAgcGhyYXNlOiAnVGUgYW1vJyxcbiAgICBsYW5ndWFnZTogJ1NwYW5pc2gnLFxuICAgIG5hdGl2ZTogJ0VzcGHDsW9sJyxcbiAgICBwcm9udW5jaWF0aW9uOiAndGVoIEFILW1vaCcsXG4gICAgcmVnaW9uOiAnQW1lcmljYXMnLFxuICAgIGZsYWc6ICfwn4eq8J+HuCcsXG4gICAgZnVuRmFjdDogXCInVGUgYW1vJyBpcyB0aGUgaGlnaGVzdCBwb2V0aWMgZGVjbGFyYXRpb24gb2YgbGlmZWxvbmcgbG92ZSBpbiBTcGFuaXNoLCB3aGlsZSAnVGUgcXVpZXJvJyBleHByZXNzZXMgZXZlcnlkYXkgYWZmZWN0aW9uLlwiXG4gIH0sXG4gIHtcbiAgICBpZDogJ2l0JyxcbiAgICBwaHJhc2U6ICdUaSBhbW8nLFxuICAgIGxhbmd1YWdlOiAnSXRhbGlhbicsXG4gICAgbmF0aXZlOiAnSXRhbGlhbm8nLFxuICAgIHByb251bmNpYXRpb246ICd0ZWUgQUgtbW9oJyxcbiAgICByZWdpb246ICdFdXJvcGUnLFxuICAgIGZsYWc6ICfwn4eu8J+HuScsXG4gICAgZnVuRmFjdDogXCJJdGFsaWFuIHJlc2VydmVzICdUaSBhbW8nIHN0cmljdGx5IGZvciByb21hbnRpYyBzb3VsbWF0ZXMsIHdoaWxlIGZyaWVuZHMgYW5kIGZhbWlseSBoZWFyICdUaSB2b2dsaW8gYmVuZScgKEkgd2FudCB0aGUgYmVzdCBmb3IgeW91KS5cIlxuICB9LFxuICB7XG4gICAgaWQ6ICdkZScsXG4gICAgcGhyYXNlOiAnSWNoIGxpZWJlIGRpY2gnLFxuICAgIGxhbmd1YWdlOiAnR2VybWFuJyxcbiAgICBuYXRpdmU6ICdEZXV0c2NoJyxcbiAgICBwcm9udW5jaWF0aW9uOiAnaWtoIExFRS1idWggZGlraCcsXG4gICAgcmVnaW9uOiAnRXVyb3BlJyxcbiAgICBmbGFnOiAn8J+HqfCfh6onLFxuICAgIGZ1bkZhY3Q6IFwiR2VybWFucyByYXJlbHkgdXR0ZXIgJ0ljaCBsaWViZSBkaWNoJyBjYXN1YWxseTsgd2hlbiBzcG9rZW4sIGl0IGNhcnJpZXMgc29sZW1uIGhvbmVzdHkgYW5kIHByb2ZvdW5kIGNvbW1pdG1lbnQuXCJcbiAgfSxcbiAge1xuICAgIGlkOiAnamEnLFxuICAgIHBocmFzZTogJ+aEm+OBl+OBpuOCiycsXG4gICAgbGFuZ3VhZ2U6ICdKYXBhbmVzZScsXG4gICAgbmF0aXZlOiAn5pel5pys6KqeJyxcbiAgICBwcm9udW5jaWF0aW9uOiAnYWlzaGl0ZXJ1IChhaC1lZS1zaGVlLXRlaC1yb28pJyxcbiAgICByZWdpb246ICdBc2lhJyxcbiAgICBmbGFnOiAn8J+Hr/Cfh7UnLFxuICAgIGZ1bkZhY3Q6IFwiSW4gSmFwYW5lc2UgY3VsdHVyZSwgJ0Fpc2hpdGVydScgaXMgc28gd2VpZ2h0eSBhbmQgc2FjcmVkIHRoYXQgbm92ZWxpc3QgU29zZWtpIE5hdHN1bWUgZmFtb3VzbHkgdHJhbnNsYXRlZCBpdCBhcyAnVGhlIG1vb24gaXMgYmVhdXRpZnVsLCBpc24ndCBpdD8nXCJcbiAgfSxcbiAge1xuICAgIGlkOiAnemgnLFxuICAgIHBocmFzZTogJ+aIkeeIseS9oCcsXG4gICAgbGFuZ3VhZ2U6ICdNYW5kYXJpbiBDaGluZXNlJyxcbiAgICBuYXRpdmU6ICfkuK3mlocgKOeugOS9kyknLFxuICAgIHByb251bmNpYXRpb246ICd3x5Igw6BpIG7HkCAod29oIGV5ZSBuZWUpJyxcbiAgICByZWdpb246ICdBc2lhJyxcbiAgICBmbGFnOiAn8J+HqPCfh7MnLFxuICAgIGZ1bkZhY3Q6IFwiVGhlIENoaW5lc2UgY2hhcmFjdGVyIGZvciBsb3ZlICjmhJspIGZlYXR1cmVzIGEgaGVhcnQgKOW/gykgbmVzdGxlZCBnZW50bHkgaW4gdGhlIGNlbnRlciBiZXR3ZWVuIGFjY2VwdGluZyBhcm1zLlwiXG4gIH0sXG4gIHtcbiAgICBpZDogJ2tvJyxcbiAgICBwaHJhc2U6ICfsgqzrnpHtlbQnLFxuICAgIGxhbmd1YWdlOiAnS29yZWFuJyxcbiAgICBuYXRpdmU6ICftlZzqta3slrQnLFxuICAgIHByb251bmNpYXRpb246ICdzYXJhbmdoYWUgKHNhaC1yYWhuZy1oZWgpJyxcbiAgICByZWdpb246ICdBc2lhJyxcbiAgICBmbGFnOiAn8J+HsPCfh7cnLFxuICAgIGZ1bkZhY3Q6IFwiVGhlIHB1cmUgS29yZWFuIHJvb3QgJ3NhcmFuZycgKOyCrOuekSkgaXMgZXR5bW9sb2dpY2FsbHkgY29ubmVjdGVkIHRvICd0aGlua2luZyBkZWVwbHkgb2Ygc29tZW9uZScgYW5kIGtlZXBpbmcgdGhlbSBpbiBtaW5kLlwiXG4gIH0sXG4gIHtcbiAgICBpZDogJ3J1JyxcbiAgICBwaHJhc2U6ICfQryDRgtC10LHRjyDQu9GO0LHQu9GOJyxcbiAgICBsYW5ndWFnZTogJ1J1c3NpYW4nLFxuICAgIG5hdGl2ZTogJ9Cg0YPRgdGB0LrQuNC5JyxcbiAgICBwcm9udW5jaWF0aW9uOiAneWEgdGVieWEgbHl1Ymx5dScsXG4gICAgcmVnaW9uOiAnRXVyb3BlJyxcbiAgICBmbGFnOiAn8J+Ht/Cfh7onLFxuICAgIGZ1bkZhY3Q6IFwiQmVjYXVzZSBSdXNzaWFuIHdvcmQgb3JkZXIgaXMgZmxleGlibGUsIHBvZXRzIHdyaXRlICfQm9GO0LHQu9GOINGC0LXQsdGPINGPJyBvciAn0KLQtdCx0Y8g0LvRjtCx0LvRjicgdG8gcGxhY2UgbHlyaWNhbCBlbXBoYXNpcyBvbiB0aGUgYmVsb3ZlZC5cIlxuICB9LFxuICB7XG4gICAgaWQ6ICd0cicsXG4gICAgcGhyYXNlOiAnU2VuaSBzZXZpeW9ydW0nLFxuICAgIGxhbmd1YWdlOiAnVHVya2lzaCcsXG4gICAgbmF0aXZlOiAnVMO8cmvDp2UnLFxuICAgIHByb251bmNpYXRpb246ICdzZWgtbmVlIHNlaC12ZWUteW9yLW9vbScsXG4gICAgcmVnaW9uOiAnTWlkZGxlIEVhc3QnLFxuICAgIGZsYWc6ICfwn4e58J+HtycsXG4gICAgZnVuRmFjdDogXCJEZXJpdmVkIGZyb20gJ3NldmdpJyAocHVyZSBsb3ZlKS4gVHVya2lzaCBsaXRlcmF0dXJlIGJvYXN0cyBzb21lIG9mIHRoZSBtb3N0IGhlYXJ0cmVuZGluZyBteXN0aWNhbCBsb3ZlIHBvZW1zIChEaXZhbiBwb2V0cnkpLlwiXG4gIH0sXG4gIHtcbiAgICBpZDogJ3RsJyxcbiAgICBwaHJhc2U6ICdNYWhhbCBraXRhJyxcbiAgICBsYW5ndWFnZTogJ1RhZ2Fsb2cgLyBGaWxpcGlubycsXG4gICAgbmF0aXZlOiAnVGFnYWxvZycsXG4gICAgcHJvbnVuY2lhdGlvbjogJ21haC1oYWwga2VlLXRhaCcsXG4gICAgcmVnaW9uOiAnQXNpYScsXG4gICAgZmxhZzogJ/Cfh7Xwn4etJyxcbiAgICBmdW5GYWN0OiBcIlRoZSB3b3JkICdNYWhhbCcgYWxzbyBtZWFucyAncHJlY2lvdXMnIGFuZCAncHJpY2VsZXNzJ+KAlHRvIGxvdmUgc29tZW9uZSBpbiBUYWdhbG9nIG1lYW5zIHRvIHRyZWFzdXJlIHRoZW0gYXMgYmV5b25kIHByaWNlLlwiXG4gIH0sXG4gIHtcbiAgICBpZDogJ2FyJyxcbiAgICBwaHJhc2U6ICfYo9it2KjZgycsXG4gICAgbGFuZ3VhZ2U6ICdBcmFiaWMnLFxuICAgIG5hdGl2ZTogJ9in2YTYudix2KjZitipJyxcbiAgICBwcm9udW5jaWF0aW9uOiBcInVoaWJidWthICh0byBoaW0pIC8gdWhpYmJ1a2kgKHRvIGhlcilcIixcbiAgICByZWdpb246ICdNaWRkbGUgRWFzdCcsXG4gICAgZmxhZzogJ/Cfh6bwn4eqJyxcbiAgICBmdW5GYWN0OiBcIlRoZSBBcmFiaWMgbGFuZ3VhZ2UgcG9zc2Vzc2VzIG92ZXIgMTEgZGlzdGluY3QgYXNjZW5kaW5nIHN0YWdlcyBvZiBsb3ZlLCBmcm9tICdIYXdhJyAoYXR0cmFjdGlvbikgdG8gJ0lzaHEnIChidXJuaW5nIHBhc3Npb24pIGFuZCAnSHV5dW0nIChpbnNhbmUgYWRvcmF0aW9uKS5cIlxuICB9LFxuICB7XG4gICAgaWQ6ICdoaScsXG4gICAgcGhyYXNlOiAn4KSu4KWI4KSCIOCkpOClgeCkruCkuOClhyDgpKrgpY3gpK/gpL7gpLAg4KSV4KSw4KSk4KS+IOCkueClguCkgScsXG4gICAgbGFuZ3VhZ2U6ICdIaW5kaScsXG4gICAgbmF0aXZlOiAn4KS54KS/4KSo4KWN4KSm4KWAJyxcbiAgICBwcm9udW5jaWF0aW9uOiAnbWFpbiB0dW1zZSBweWFhciBrYXJ0YSBob29uJyxcbiAgICByZWdpb246ICdBc2lhJyxcbiAgICBmbGFnOiAn8J+HrvCfh7MnLFxuICAgIGZ1bkZhY3Q6IFwiVGhlIHdvcmQgJ1B5YWFyJyB0cmFjZXMgYmFjayB0byBTYW5za3JpdCAnUHJpeWEnLCBzeW1ib2xpemluZyBkZWFyLCBjaGVyaXNoZWQsIGFuZCBhbiBldGVybmFsIGRpdmluZSBib25kIGxpa2UgUmFkaGEtS3Jpc2huYS5cIlxuICB9LFxuICB7XG4gICAgaWQ6ICdwdCcsXG4gICAgcGhyYXNlOiAnRXUgdGUgYW1vJyxcbiAgICBsYW5ndWFnZTogJ1BvcnR1Z3Vlc2UnLFxuICAgIG5hdGl2ZTogJ1BvcnR1Z3XDqnMnLFxuICAgIHByb251bmNpYXRpb246ICdlaC1vbyBjaGVlIEFILW1vbycsXG4gICAgcmVnaW9uOiAnQW1lcmljYXMnLFxuICAgIGZsYWc6ICfwn4en8J+HtycsXG4gICAgZnVuRmFjdDogXCJQb3J0dWd1ZXNlIGlzIGZhbW91cyBmb3IgdGhlIHVudHJhbnNsYXRhYmxlIHdvcmQgJ1NhdWRhZGUn4oCUdGhlIHN3ZWV0LCBhY2hpbmcgbWVsYW5jaG9seSBsb25naW5nIGZvciB0aGUgb25lIHlvdSBsb3ZlLlwiXG4gIH0sXG4gIHtcbiAgICBpZDogJ2VsJyxcbiAgICBwaHJhc2U6IFwizqMnIM6xzrPOsc+Az45cIixcbiAgICBsYW5ndWFnZTogJ0dyZWVrJyxcbiAgICBuYXRpdmU6ICfOlc67zrvOt869zrnOus6sJyxcbiAgICBwcm9udW5jaWF0aW9uOiBcInMnYWdhcG8gKHNhaC1nYWgtUE9IKVwiLFxuICAgIHJlZ2lvbjogJ0V1cm9wZScsXG4gICAgZmxhZzogJ/Cfh6zwn4e3JyxcbiAgICBmdW5GYWN0OiBcIlJvb3RlZCBpbiAnQWdhcGUnICjhvIDOs86sz4DOtyksIGNvbnNpZGVyZWQgYnkgYW5jaWVudCBHcmVlayBwaGlsb3NvcGhlcnMgdGhlIGhpZ2hlc3QsIG1vc3Qgc2VsZmxlc3MgZm9ybSBvZiB1bmNvbmRpdGlvbmFsIHVuaXZlcnNhbCBkZXZvdGlvbi5cIlxuICB9LFxuICB7XG4gICAgaWQ6ICdubCcsXG4gICAgcGhyYXNlOiAnSWsgaG91IHZhbiBqb3UnLFxuICAgIGxhbmd1YWdlOiAnRHV0Y2gnLFxuICAgIG5hdGl2ZTogJ05lZGVybGFuZHMnLFxuICAgIHByb251bmNpYXRpb246ICdpayBob3cgZmFobiB5b3cnLFxuICAgIHJlZ2lvbjogJ0V1cm9wZScsXG4gICAgZmxhZzogJ/Cfh7Pwn4exJyxcbiAgICBmdW5GYWN0OiBcIkxpdGVyYWxseSB0cmFuc2xhdGVzIHRvICdJIGhvbGQgb2YgeW91J+KAlHNpZ25pZnlpbmcga2VlcGluZyBzb21lb25lIHByb3RlY3RlZCwgY2hlcmlzaGVkLCBhbmQgZW1icmFjZWQgc2FmZWx5IGluIG9uZSdzIGhlYXJ0LlwiXG4gIH0sXG4gIHtcbiAgICBpZDogJ3BsJyxcbiAgICBwaHJhc2U6ICdLb2NoYW0gQ2nEmScsXG4gICAgbGFuZ3VhZ2U6ICdQb2xpc2gnLFxuICAgIG5hdGl2ZTogJ1BvbHNraScsXG4gICAgcHJvbnVuY2lhdGlvbjogJ0tPSC1raGFobSBjaHllaCcsXG4gICAgcmVnaW9uOiAnRXVyb3BlJyxcbiAgICBmbGFnOiAn8J+HtfCfh7EnLFxuICAgIGZ1bkZhY3Q6IFwiVGhlIHdvcmQgJ2tvY2hhxIcnIGNhcnJpZXMgYSBnZW50bGUgd2FybXRoIHJlbWluaXNjZW50IG9mIGNhcmVzc2luZyBvciBjcmFkbGluZyBzb21ldGhpbmcgaW5maW5pdGVseSBwcmVjaW91cy5cIlxuICB9LFxuICB7XG4gICAgaWQ6ICdzdicsXG4gICAgcGhyYXNlOiAnSmFnIMOkbHNrYXIgZGlnJyxcbiAgICBsYW5ndWFnZTogJ1N3ZWRpc2gnLFxuICAgIG5hdGl2ZTogJ1N2ZW5za2EnLFxuICAgIHByb251bmNpYXRpb246ICd5YWhnIEVMLXNrYXIgZGV5JyxcbiAgICByZWdpb246ICdFdXJvcGUnLFxuICAgIGZsYWc6ICfwn4e48J+HqicsXG4gICAgZnVuRmFjdDogXCJEZXJpdmVkIGZyb20gT2xkIE5vcnNlICdlbHNrYScsIHdoaWNoIG1lYW50IHRvIG51cnR1cmUsIHByb3RlY3QsIGFuZCBjYXJlIHRlbmRlcmx5IHRocm91Z2ggY29sZCBOb3JkaWMgd2ludGVycy5cIlxuICB9LFxuICB7XG4gICAgaWQ6ICdzdycsXG4gICAgcGhyYXNlOiAnTmFrdXBlbmRhJyxcbiAgICBsYW5ndWFnZTogJ1N3YWhpbGknLFxuICAgIG5hdGl2ZTogJ0tpc3dhaGlsaScsXG4gICAgcHJvbnVuY2lhdGlvbjogJ25haC1rb28tUEVOLWRhaCcsXG4gICAgcmVnaW9uOiAnQWZyaWNhJyxcbiAgICBmbGFnOiAn8J+HsPCfh6onLFxuICAgIGZ1bkZhY3Q6IFwiRm9ybWVkIGFzIGFuIGVsZWdhbnQgc2luZ2xlIHZlcmI6ICduYS0nIChwcmVzZW50IHRlbnNlKSwgJy1rdS0nICh5b3UpLCAnLXBlbmRhJyAodG8gbG92ZSB3YXJtbHkpLlwiXG4gIH0sXG4gIHtcbiAgICBpZDogJ2dhJyxcbiAgICBwaHJhc2U6IFwiVMOhaW0gaSBuZ3LDoSBsZWF0XCIsXG4gICAgbGFuZ3VhZ2U6ICdJcmlzaCBHYWVsaWMnLFxuICAgIG5hdGl2ZTogJ0dhZWlsZ2UnLFxuICAgIHByb251bmNpYXRpb246ICd0YXctaW0gaWggbmdyYXcgbHlhdCcsXG4gICAgcmVnaW9uOiAnRXVyb3BlJyxcbiAgICBmbGFnOiAn8J+HrvCfh6onLFxuICAgIGZ1bkZhY3Q6IFwiTGl0ZXJhbGx5IG1lYW5zICdJIGFtIGluIGxvdmUgd2l0aCB5b3UnLCBvciBwb2V0aWNhbGx5ICdNbyBjaHVpc2xlJyAobXkgcHVsc2UgLyBiZWF0IG9mIG15IGhlYXJ0KS5cIlxuICB9LFxuICB7XG4gICAgaWQ6ICdoYXcnLFxuICAgIHBocmFzZTogXCJBbG9oYSBhdSBpxIEgJ29lXCIsXG4gICAgbGFuZ3VhZ2U6ICdIYXdhaWlhbicsXG4gICAgbmF0aXZlOiBcIuKAmMWMbGVsbyBIYXdhaeKAmGlcIixcbiAgICBwcm9udW5jaWF0aW9uOiAnYWgtTE9ILWhhaCBvdyBlZS1BSCBvaC1laCcsXG4gICAgcmVnaW9uOiAnT2NlYW5pYScsXG4gICAgZmxhZzogJ/CfjLonLFxuICAgIGZ1bkZhY3Q6IFwiJ0Fsb2hhJyBjb252ZXlzIHNoYXJpbmcgdGhlIGRpdmluZSBicmVhdGggb2YgbGlmZSAoJ2hhJykgaW4gdGhlIHByZXNlbmNlICgnYWxvJykgb2Ygc2FjcmVkIHdhcm10aC5cIlxuICB9LFxuICB7XG4gICAgaWQ6ICdibicsXG4gICAgcGhyYXNlOiAn4KaG4Kau4Ka/IOCmpOCni+CmruCmvuCmleCnhyDgpq3gpr7gprLgp4vgpqzgpr7gprjgpr8nLFxuICAgIGxhbmd1YWdlOiAnQmVuZ2FsaScsXG4gICAgbmF0aXZlOiAn4Kas4Ka+4KaC4Kay4Ka+JyxcbiAgICBwcm9udW5jaWF0aW9uOiAnYW1pIHRvbWFrZSBiaGFsb2Jhc2hpJyxcbiAgICByZWdpb246ICdBc2lhJyxcbiAgICBmbGFnOiAn8J+Hp/Cfh6knLFxuICAgIGZ1bkZhY3Q6IFwiVGhlIGxhbmd1YWdlIG9mIE5vYmVsIHBvZXQgUmFiaW5kcmFuYXRoIFRhZ29yZSwgd2hlcmUgJ0JoYWxvYmFzaGEnIGxpdGVyYWxseSB0cmFuc2xhdGVzIGFzICdtYWtpbmcgYSBob21lIG9mIGdvb2RuZXNzJy5cIlxuICB9LFxuICB7XG4gICAgaWQ6ICdpZCcsXG4gICAgcGhyYXNlOiAnQWt1IGNpbnRhIGthbXUnLFxuICAgIGxhbmd1YWdlOiAnSW5kb25lc2lhbicsXG4gICAgbmF0aXZlOiAnQmFoYXNhIEluZG9uZXNpYScsXG4gICAgcHJvbnVuY2lhdGlvbjogJ2FoLWtvbyBjaGluLXRhaCBrYWgtbW9vJyxcbiAgICByZWdpb246ICdBc2lhJyxcbiAgICBmbGFnOiAn8J+HrvCfh6knLFxuICAgIGZ1bkZhY3Q6IFwiJ0NpbnRhJyB0cmFjZXMgYmFjayB0byBTYW5za3JpdCAnQ2ludMSBJywgc2lnbmlmeWluZyBjb25zdGFudCBjb250ZW1wbGF0aW9uIGFuZCBzd2VldCBtaW5kZnVsIHdvbmRlci5cIlxuICB9LFxuICB7XG4gICAgaWQ6ICd2aScsXG4gICAgcGhyYXNlOiAnQW5oIHnDqnUgZW0nLFxuICAgIGxhbmd1YWdlOiAnVmlldG5hbWVzZScsXG4gICAgbmF0aXZlOiAnVGnhur9uZyBWaeG7h3QnLFxuICAgIHByb251bmNpYXRpb246ICdhaG4gZWV5ZXcgZW0nLFxuICAgIHJlZ2lvbjogJ0FzaWEnLFxuICAgIGZsYWc6ICfwn4e78J+HsycsXG4gICAgZnVuRmFjdDogXCJQcm9ub3VucyBpbiBWaWV0bmFtZXNlIGV4cHJlc3MgdGVuZGVyIHJlbGF0aW9u4oCUJ0FuaCcgKG9sZGVyL3Byb3RlY3RpdmUgYnJvdGhlcikgbG92aW5nICdFbScgKGJlbG92ZWQgZ2VudGxlIGZsb3dlcikuXCJcbiAgfSxcbiAge1xuICAgIGlkOiAndGgnLFxuICAgIHBocmFzZTogJ+C4ieC4seC4meC4o+C4seC4geC5gOC4mOC4rScsXG4gICAgbGFuZ3VhZ2U6ICdUaGFpJyxcbiAgICBuYXRpdmU6ICfguYTguJfguKInLFxuICAgIHByb251bmNpYXRpb246ICdjaGFuIHJhayB0aG9lIChvciBwaG9tIHJhayBraHVuKScsXG4gICAgcmVnaW9uOiAnQXNpYScsXG4gICAgZmxhZzogJ/Cfh7nwn4etJyxcbiAgICBmdW5GYWN0OiBcIlRoZSB3b3JkICdSYWsnICjguKPguLHguIEpIGlzIHNoYXJlZCBhY3Jvc3MgbWlsbGVubmlhIG9mIEJ1ZGRoaXN0IGFuZCBjb3VydGx5IHBvZXRyeSB0byBkZW5vdGUgZGV2b3Rpb25hbCB3YXJtdGguXCJcbiAgfSxcbiAge1xuICAgIGlkOiAnaHUnLFxuICAgIHBocmFzZTogJ1N6ZXJldGxlaycsXG4gICAgbGFuZ3VhZ2U6ICdIdW5nYXJpYW4nLFxuICAgIG5hdGl2ZTogJ01hZ3lhcicsXG4gICAgcHJvbnVuY2lhdGlvbjogJ1NFSC1yZXQtbGVrJyxcbiAgICByZWdpb246ICdFdXJvcGUnLFxuICAgIGZsYWc6ICfwn4et8J+HuicsXG4gICAgZnVuRmFjdDogXCJIdW5nYXJpYW4gZ3JhbW1hciBjb21wcmVzc2VzIHN1YmplY3QgYW5kIG9iamVjdCBpbnRvIGEgc2luZ2xlIGludGltYXRlIHZlcmIgZW5kaW5nOiAnSSBsb3ZlIFlPVScuXCJcbiAgfSxcbiAge1xuICAgIGlkOiAncm8nLFxuICAgIHBocmFzZTogJ1RlIGl1YmVzYycsXG4gICAgbGFuZ3VhZ2U6ICdSb21hbmlhbicsXG4gICAgbmF0aXZlOiAnUm9tw6JuxIMnLFxuICAgIHByb251bmNpYXRpb246ICd0ZWggeW9vLUJFU0snLFxuICAgIHJlZ2lvbjogJ0V1cm9wZScsXG4gICAgZmxhZzogJ/Cfh7fwn4e0JyxcbiAgICBmdW5GYWN0OiBcIkEgUm9tYW5jZSBsYW5ndWFnZSB0aGF0IGFkb3B0ZWQgdGhlIFNsYXZpYyByb290IGZvciBsb3ZlICgnbGp1YicpLCBjcmVhdGluZyBhIHVuaXF1ZWx5IHN3ZWV0IGx5cmljYWwgYmxlbmQuXCJcbiAgfSxcbiAge1xuICAgIGlkOiAndWsnLFxuICAgIHBocmFzZTogJ9CvINGC0LXQsdC1INC60L7RhdCw0Y4nLFxuICAgIGxhbmd1YWdlOiAnVWtyYWluaWFuJyxcbiAgICBuYXRpdmU6ICfQo9C60YDQsNGX0L3RgdGM0LrQsCcsXG4gICAgcHJvbnVuY2lhdGlvbjogJ3lhIHRlYmUga29oYXl1JyxcbiAgICByZWdpb246ICdFdXJvcGUnLFxuICAgIGZsYWc6ICfwn4e68J+HpicsXG4gICAgZnVuRmFjdDogXCIn0JrQvtGF0LDRgtC4JyBpcyByZXNlcnZlZCBleGNsdXNpdmVseSBmb3IgZGVlcCwgdGVuZGVyIHJvbWFudGljIHBhc3Npb24sIGRpc3RpbmN0IGZyb20gbGlraW5nIHRoaW5ncyBvciBmcmllbmRzaGlwcy5cIlxuICB9LFxuICB7XG4gICAgaWQ6ICdjcycsXG4gICAgcGhyYXNlOiAnTWlsdWppIHTEmycsXG4gICAgbGFuZ3VhZ2U6ICdDemVjaCcsXG4gICAgbmF0aXZlOiAnxIxlxaF0aW5hJyxcbiAgICBwcm9udW5jaWF0aW9uOiAnTUVFLWxvby15ZWUgdHllaCcsXG4gICAgcmVnaW9uOiAnRXVyb3BlJyxcbiAgICBmbGFnOiAn8J+HqPCfh78nLFxuICAgIGZ1bkZhY3Q6IFwiUHJhZ3VlIG9uIE1heSAxc3QgKEN6ZWNoIERheSBvZiBMb3ZlKSBzZWVzIHRob3VzYW5kcyBvZiBjb3VwbGVzIGtpc3NpbmcgdW5kZXIgYmxvb21pbmcgY2hlcnJ5IGJsb3Nzb20gdHJlZXMhXCJcbiAgfSxcbiAge1xuICAgIGlkOiAnZmEnLFxuICAgIHBocmFzZTogJ9iv2YjYs9iq2Kog2K/Yp9ix2YUnLFxuICAgIGxhbmd1YWdlOiAnUGVyc2lhbiAoRmFyc2kpJyxcbiAgICBuYXRpdmU6ICfZgdin2LHYs9uMJyxcbiAgICBwcm9udW5jaWF0aW9uOiAnZG9vc3RhdCBkYXJhbScsXG4gICAgcmVnaW9uOiAnTWlkZGxlIEVhc3QnLFxuICAgIGZsYWc6ICfwn4eu8J+HtycsXG4gICAgZnVuRmFjdDogXCJQZXJzaWFuIHBvZXRyeSBieSBSdW1pIGFuZCBIYWZleiBpcyBjZWxlYnJhdGVkIGFzIHRoZSBwaW5uYWNsZSBvZiBkaXZpbmUgYW5kIHJvbWFudGljIGxvdmUgbGl0ZXJhdHVyZS5cIlxuICB9LFxuICB7XG4gICAgaWQ6ICdoZScsXG4gICAgcGhyYXNlOiAn15DXoNeZINeQ15XXlNeRINeQ15XXqteaJyxcbiAgICBsYW5ndWFnZTogJ0hlYnJldycsXG4gICAgbmF0aXZlOiAn16LXkdeo15nXqicsXG4gICAgcHJvbnVuY2lhdGlvbjogJ2FuaSBvaGV2IG90YWNoIChtIHRvIGYpJyxcbiAgICByZWdpb246ICdNaWRkbGUgRWFzdCcsXG4gICAgZmxhZzogJ/Cfh67wn4exJyxcbiAgICBmdW5GYWN0OiBcIlRoZSByb290ICdBaGF2JyBhcHBlYXJzIHRocm91Z2hvdXQgS2luZyBTb2xvbW9uJ3MgU29uZyBvZiBTb25nczogJ0kgYW0gbXkgYmVsb3ZlZOKAmXMsIGFuZCBteSBiZWxvdmVkIGlzIG1pbmUnLlwiXG4gIH0sXG4gIHtcbiAgICBpZDogJ2RhJyxcbiAgICBwaHJhc2U6ICdKZWcgZWxza2VyIGRpZycsXG4gICAgbGFuZ3VhZ2U6ICdEYW5pc2gnLFxuICAgIG5hdGl2ZTogJ0RhbnNrJyxcbiAgICBwcm9udW5jaWF0aW9uOiAneWFpIGVsLXNrZXIgZGFpJyxcbiAgICByZWdpb246ICdFdXJvcGUnLFxuICAgIGZsYWc6ICfwn4ep8J+HsCcsXG4gICAgZnVuRmFjdDogXCJEZWVwbHkgY29ubmVjdGVkIHRvIHRoZSBEYW5pc2ggY29uY2VwdCBvZiAnaHlnZ2Un4oCUd2FybSBjYW5kbGVsaWdodCwgY2xvc2VuZXNzLCBhbmQgZmVlbGluZyBzYWZlIHRvZ2V0aGVyLlwiXG4gIH0sXG4gIHtcbiAgICBpZDogJ25vJyxcbiAgICBwaHJhc2U6ICdKZWcgZWxza2VyIGRlZycsXG4gICAgbGFuZ3VhZ2U6ICdOb3J3ZWdpYW4nLFxuICAgIG5hdGl2ZTogJ05vcnNrJyxcbiAgICBwcm9udW5jaWF0aW9uOiAneWFpIGVsLXNrZXIgZGFpJyxcbiAgICByZWdpb246ICdFdXJvcGUnLFxuICAgIGZsYWc6ICfwn4ez8J+HtCcsXG4gICAgZnVuRmFjdDogXCJTaGFyZWQgd2l0aCB0aGUgbWFqZXN0aWMgZmpvcmRzIGFuZCBOb3J0aGVybiBMaWdodHMsIHJlcHJlc2VudGluZyBlbmR1cmluZyBsb3lhbHR5IHVuZGVyIEFyY3RpYyBza2llcy5cIlxuICB9LFxuICB7XG4gICAgaWQ6ICdmaScsXG4gICAgcGhyYXNlOiAnTWluw6QgcmFrYXN0YW4gc2ludWEnLFxuICAgIGxhbmd1YWdlOiAnRmlubmlzaCcsXG4gICAgbmF0aXZlOiAnU3VvbWknLFxuICAgIHByb251bmNpYXRpb246ICdtZWUtbmEgUkFILWthcy10YWhuIFNFRS1ub28tYWgnLFxuICAgIHJlZ2lvbjogJ0V1cm9wZScsXG4gICAgZmxhZzogJ/Cfh6vwn4euJyxcbiAgICBmdW5GYWN0OiBcIkZpbm5zIGFyZSBmYW1vdXMgZm9yIHF1aWV0IHNpbmNlcml0eTsgdG8gaGVhciAnTWluw6QgcmFrYXN0YW4gc2ludWEnIGlzIGNvbnNpZGVyZWQgYW4gdW5icmVha2FibGUgbGlmZWxvbmcgdm93LlwiXG4gIH0sXG4gIHtcbiAgICBpZDogJ3VyJyxcbiAgICBwaHJhc2U6ICfZhduM2rog2KLZviDYs9uSINmF2K3YqNiqINqp2LHYqtinINuB2YjauicsXG4gICAgbGFuZ3VhZ2U6ICdVcmR1JyxcbiAgICBuYXRpdmU6ICfYp9ix2K/ZiCcsXG4gICAgcHJvbnVuY2lhdGlvbjogJ21haW4gYWFwIHNlIG1vaGFiYmF0IGthcnRhIGhvb24nLFxuICAgIHJlZ2lvbjogJ0FzaWEnLFxuICAgIGZsYWc6ICfwn4e18J+HsCcsXG4gICAgZnVuRmFjdDogXCInTW9oYWJiYXQnIGFuZCAnSXNocScgaW4gVXJkdSBHaGF6YWxzIGFyZSByZXZlcmVkIGFzIGZvcm1zIG9mIHByb2ZvdW5kIHdvcnNoaXAgYW5kIHNwaXJpdHVhbCBkZXZvdGlvbi5cIlxuICB9LFxuICB7XG4gICAgaWQ6ICd0YScsXG4gICAgcGhyYXNlOiAn4K6o4K6+4K6p4K+NIOCuieCuqeCvjeCuqeCviCDgrpXgrr7grqTgrrLgrr/grpXgr43grpXgrr/grrHgr4fgrqngr40nLFxuICAgIGxhbmd1YWdlOiAnVGFtaWwnLFxuICAgIG5hdGl2ZTogJ+CupOCuruCuv+CutOCvjScsXG4gICAgcHJvbnVuY2lhdGlvbjogJ05hYW4gdW5uYWkga2FhZGhhbGlra2lyZW4nLFxuICAgIHJlZ2lvbjogJ0FzaWEnLFxuICAgIGZsYWc6ICfwn4eu8J+HsycsXG4gICAgZnVuRmFjdDogXCJUYW1pbCBTYW5nYW0gbGl0ZXJhdHVyZSBjbGFzc2lmaWVkIHJvbWFudGljIHBvZW1zIGludG8gZml2ZSBuYXR1cmFsIGxhbmRzY2FwZXMgKEt1cmluamksIE11bGxhaSwgTWFydXRoYW0sIE5leXRoYWwsIFBhbGFpKS5cIlxuICB9LFxuICB7XG4gICAgaWQ6ICdtcycsXG4gICAgcGhyYXNlOiAnU2F5YSBzYXlhbmcgYXdhaycsXG4gICAgbGFuZ3VhZ2U6ICdNYWxheScsXG4gICAgbmF0aXZlOiAnQmFoYXNhIE1lbGF5dScsXG4gICAgcHJvbnVuY2lhdGlvbjogJ3NhaC15YWggc2FoLXlhaG5nIGFoLXdhaGsnLFxuICAgIHJlZ2lvbjogJ0FzaWEnLFxuICAgIGZsYWc6ICfwn4ey8J+HvicsXG4gICAgZnVuRmFjdDogXCInU2F5YW5nJyBtZWFucyBib3RoIGxvdmUgYW5kIHN3ZWV0IGFmZmVjdGlvbmF0ZSBjYXJlLCB1c2VkIGFsc28gYXMgYSB0ZW5kZXIgdGVybSBvZiBlbmRlYXJtZW50IGxpa2UgJ2RhcmxpbmcnLlwiXG4gIH0sXG4gIHtcbiAgICBpZDogJ2xhJyxcbiAgICBwaHJhc2U6ICdUZSBhbW8nLFxuICAgIGxhbmd1YWdlOiAnTGF0aW4nLFxuICAgIG5hdGl2ZTogJ0xhdGluYScsXG4gICAgcHJvbnVuY2lhdGlvbjogJ3RheSBBSC1tb2gnLFxuICAgIHJlZ2lvbjogJ0V1cm9wZScsXG4gICAgZmxhZzogJ/Cfj5vvuI8nLFxuICAgIGZ1bkZhY3Q6IFwiSW1tb3J0YWxpemVkIGJ5IENhdHVsbHVzOiAnT2RpIGV0IGFtbycgKEkgaGF0ZSBhbmQgSSBsb3ZlKSBhbmQgVmlyZ2lsOiAnQW1vciB2aW5jaXQgb21uaWEnIChMb3ZlIGNvbnF1ZXJzIGFsbCkuXCJcbiAgfSxcbiAge1xuICAgIGlkOiAnZW8nLFxuICAgIHBocmFzZTogJ01pIGFtYXMgdmluJyxcbiAgICBsYW5ndWFnZTogJ0VzcGVyYW50bycsXG4gICAgbmF0aXZlOiAnRXNwZXJhbnRvJyxcbiAgICBwcm9udW5jaWF0aW9uOiAnbWVlIEFILW1haHMgdmVlbicsXG4gICAgcmVnaW9uOiAnRXVyb3BlJyxcbiAgICBmbGFnOiAn8J+MjScsXG4gICAgZnVuRmFjdDogXCJDcmVhdGVkIGFzIGEgdW5pdmVyc2FsIGJyaWRnZSBhY3Jvc3MgYWxsIG5hdGlvbnMsICdNaSBhbWFzIHZpbicgd2FzIGRlc2lnbmVkIHNvIGFueSB0d28gaHVtYW5zIG9uIEVhcnRoIGNvdWxkIHNwZWFrIGxvdmUuXCJcbiAgfSxcbiAge1xuICAgIGlkOiAnenUnLFxuICAgIHBocmFzZTogJ05naXlha3V0aGFuZGEnLFxuICAgIGxhbmd1YWdlOiAnWnVsdScsXG4gICAgbmF0aXZlOiAnaXNpWnVsdScsXG4gICAgcHJvbnVuY2lhdGlvbjogJ25nLWVlLXlhaC1rb28tVEFITi1kYWgnLFxuICAgIHJlZ2lvbjogJ0FmcmljYScsXG4gICAgZmxhZzogJ/Cfh7/wn4emJyxcbiAgICBmdW5GYWN0OiBcIlJvb3RlZCBpbiB0aGUgcGhpbG9zb3BoeSBvZiBVYnVudHUgKCdJIGFtIGJlY2F1c2Ugd2UgYXJlJynigJRsb3ZlIGlzIHZpZXdlZCBhcyBhbiBpbnRlcmNvbm5lY3RlZCBsaWZlIGZvcmNlLlwiXG4gIH0sXG4gIHtcbiAgICBpZDogJ2FtJyxcbiAgICBwaHJhc2U6ICfhiqXhi4jhi7XhiLvhiIjhiIEnLFxuICAgIGxhbmd1YWdlOiAnQW1oYXJpYycsXG4gICAgbmF0aXZlOiAn4Yqg4Yib4Yit4YqbJyxcbiAgICBwcm9udW5jaWF0aW9uOiAnZXdlZGlzaGFsZWh1ICh0byBoZXIpJyxcbiAgICByZWdpb246ICdBZnJpY2EnLFxuICAgIGZsYWc6ICfwn4eq8J+HuScsXG4gICAgZnVuRmFjdDogXCJBbmNpZW50IFNlbWl0aWMgR2UnZXogc2NyaXB0LCBzcG9rZW4gaW4gRXRoaW9waWEsIGNhcnJ5aW5nIG1lbG9kaWVzIHN1bmcgYWNyb3NzIG1pbGxlbm5pdW0tb2xkIGhpZ2hsYW5kIHRyYWRpdGlvbnMuXCJcbiAgfSxcbiAge1xuICAgIGlkOiAnc3EnLFxuICAgIHBocmFzZTogJ1TDqyBkdWEnLFxuICAgIGxhbmd1YWdlOiAnQWxiYW5pYW4nLFxuICAgIG5hdGl2ZTogJ1NocWlwJyxcbiAgICBwcm9udW5jaWF0aW9uOiAndHVoIERPTy1haCcsXG4gICAgcmVnaW9uOiAnRXVyb3BlJyxcbiAgICBmbGFnOiAn8J+HpvCfh7EnLFxuICAgIGZ1bkZhY3Q6IFwiJ1TDqyBkdWEnIG1lYW5zIGJvdGggJ0kgbG92ZSB5b3UnIGFuZCAnSSB3YW50IHlvdScsIGV4cHJlc3NpbmcgdG90YWwgZGVzaXJlIGFuZCBkZXZvdGlvbiBpbiB0d28gcHVyZSBzeWxsYWJsZXMuXCJcbiAgfSxcbiAge1xuICAgIGlkOiAnaHInLFxuICAgIHBocmFzZTogJ1ZvbGltIHRlJyxcbiAgICBsYW5ndWFnZTogJ0Nyb2F0aWFuIC8gU2VyYmlhbicsXG4gICAgbmF0aXZlOiAnSHJ2YXRza2kgLyBTcnBza2knLFxuICAgIHByb251bmNpYXRpb246ICdWT0gtbGVlbSB0ZWgnLFxuICAgIHJlZ2lvbjogJ0V1cm9wZScsXG4gICAgZmxhZzogJ/Cfh63wn4e3JyxcbiAgICBmdW5GYWN0OiBcIlRyYWNlcyB0byBQcm90by1TbGF2aWMgcm9vdCAndm9samEnIG1lYW5pbmcgJ3dpbGwnLCBzaWduaWZ5aW5nICdJIGNob29zZSB5b3Ugd2l0aCBhbGwgbXkgZnJlZSB3aWxsIGFuZCBkZXNpcmUnLlwiXG4gIH0sXG4gIHtcbiAgICBpZDogJ2thJyxcbiAgICBwaHJhc2U6ICfhg5vhg5jhg6fhg5Xhg5Dhg6Dhg67hg5Dhg6AnLFxuICAgIGxhbmd1YWdlOiAnR2VvcmdpYW4nLFxuICAgIG5hdGl2ZTogJ+GDpeGDkOGDoOGDl+GDo+GDmuGDmCcsXG4gICAgcHJvbnVuY2lhdGlvbjogJ21pcXZhcmtoYXInLFxuICAgIHJlZ2lvbjogJ0V1cm9wZScsXG4gICAgZmxhZzogJ/Cfh6zwn4eqJyxcbiAgICBmdW5GYWN0OiBcIldyaXR0ZW4gaW4gdGhlIHVuaXF1ZSByb3VuZGVkIE1raGVkcnVsaSBzY3JpcHQsIHNwb2tlbiBpbiB0aGUgYW5jaWVudCBiaXJ0aHBsYWNlIG9mIHdpbmUgYW5kIG1vdW50YWluIGxlZ2VuZHMuXCJcbiAgfSxcbiAge1xuICAgIGlkOiAnaXMnLFxuICAgIHBocmFzZTogJ8OJZyBlbHNrYSDDvmlnJyxcbiAgICBsYW5ndWFnZTogJ0ljZWxhbmRpYycsXG4gICAgbmF0aXZlOiAnw41zbGVuc2thJyxcbiAgICBwcm9udW5jaWF0aW9uOiAneWVoZyBFTC1za2FoIHRoZWVnJyxcbiAgICByZWdpb246ICdFdXJvcGUnLFxuICAgIGZsYWc6ICfwn4eu8J+HuCcsXG4gICAgZnVuRmFjdDogXCJQcmVzZXJ2ZXMgdmlydHVhbGx5IHVuY2hhbmdlZCBPbGQgTm9yc2UgZ3JhbW1hciBmcm9tIHRoZSBWaWtpbmcgc2FnYXMgb2YgdGhlIDl0aCBjZW50dXJ5LlwiXG4gIH0sXG4gIHtcbiAgICBpZDogJ3NrJyxcbiAgICBwaHJhc2U6ICfEvcO6YmltIMWlYScsXG4gICAgbGFuZ3VhZ2U6ICdTbG92YWsnLFxuICAgIG5hdGl2ZTogJ1Nsb3ZlbsSNaW5hJyxcbiAgICBwcm9udW5jaWF0aW9uOiAnTFlPTy1iZWVtIHR5YWgnLFxuICAgIHJlZ2lvbjogJ0V1cm9wZScsXG4gICAgZmxhZzogJ/Cfh7jwn4ewJyxcbiAgICBmdW5GYWN0OiBcIlNsb3Zha3MgdXNlICfEvcO6YmltIMWlYScgZm9yIHJvbWFudGljIHN3ZWV0bmVzcyBhbmQgJ01pbHVqZW0gxaVhJyBmb3Igc29sZW1uIGV0ZXJuYWwgZGV2b3Rpb24uXCJcbiAgfSxcbiAge1xuICAgIGlkOiAnY3knLFxuICAgIHBocmFzZTogJ1J3eeKAmW4gZHkgZ2FydSBkaScsXG4gICAgbGFuZ3VhZ2U6ICdXZWxzaCcsXG4gICAgbmF0aXZlOiAnQ3ltcmFlZycsXG4gICAgcHJvbnVuY2lhdGlvbjogJ3Jvby1pbiBkdWggZ2FoLXJlZSBkZWUnLFxuICAgIHJlZ2lvbjogJ0V1cm9wZScsXG4gICAgZmxhZzogJ/Cfj7TzoIGn86CBovOggbfzoIGs86CBs/Oggb8nLFxuICAgIGZ1bkZhY3Q6IFwiV2FsZXMgY2VsZWJyYXRlcyBTdC4gRHd5bndlbidzIERheSAodGhlIFdlbHNoIHBhdHJvbiBzYWludCBvZiBsb3ZlcnMpIG9uIEphbnVhcnkgMjUgd2l0aCBoYW5kLWNhcnZlZCBsb3Zlc3Bvb25zIVwiXG4gIH0sXG4gIHtcbiAgICBpZDogJ2V1JyxcbiAgICBwaHJhc2U6ICdNYWl0ZSB6YWl0dXQnLFxuICAgIGxhbmd1YWdlOiAnQmFzcXVlJyxcbiAgICBuYXRpdmU6ICdFdXNrYXJhJyxcbiAgICBwcm9udW5jaWF0aW9uOiAnbXktdGVoIHp5ZS10b290JyxcbiAgICByZWdpb246ICdFdXJvcGUnLFxuICAgIGZsYWc6ICfwn4eq8J+HuCcsXG4gICAgZnVuRmFjdDogXCJCYXNxdWUgaXMgYSBsYW5ndWFnZSBpc29sYXRlIHdpdGggemVybyBrbm93biBsaXZpbmcgcmVsYXRpdmVzLCBjYXJyeWluZyB0aGlzIGxvdmUgcGhyYXNlIHRocm91Z2ggdGVucyBvZiB0aG91c2FuZHMgb2YgeWVhcnMuXCJcbiAgfSxcbiAge1xuICAgIGlkOiAna20nLFxuICAgIHBocmFzZTogJ+GegeGfkuGeieGeu+GfhuGen+GfkuGemuGem+GetuGeieGfi+GeouGfkuGek+GegCcsXG4gICAgbGFuZ3VhZ2U6ICdLaG1lcicsXG4gICAgbmF0aXZlOiAn4Z6X4Z624Z6f4Z624Z6B4Z+S4Z6Y4Z+C4Z6aJyxcbiAgICBwcm9udW5jaWF0aW9uOiAna25ob20gc3JhbGFuaCBhbmFrJyxcbiAgICByZWdpb246ICdBc2lhJyxcbiAgICBmbGFnOiAn8J+HsPCfh60nLFxuICAgIGZ1bkZhY3Q6IFwiUmVuZGVyZWQgaW4gb3JuYXRlIEFuZ2tvciBXYXQtZXJhIHNjcmlwdCwgZW1ib2R5aW5nIGdlbnRsZSByZXNwZWN0IGFuZCBlbmR1cmluZyBoZWFydCBmaWRlbGl0eS5cIlxuICB9LFxuICB7XG4gICAgaWQ6ICdteScsXG4gICAgcGhyYXNlOiAn4YCZ4YCE4YC64YC44YCA4YCt4YCv4YCB4YC74YCF4YC64YCQ4YCa4YC6JyxcbiAgICBsYW5ndWFnZTogJ0J1cm1lc2UnLFxuICAgIG5hdGl2ZTogJ+GAmeGAvOGAlOGAuuGAmeGArOGAheGArCcsXG4gICAgcHJvbnVuY2lhdGlvbjogJ21pbiBrbyBjaGl0IHRhbCcsXG4gICAgcmVnaW9uOiAnQXNpYScsXG4gICAgZmxhZzogJ/Cfh7Lwn4eyJyxcbiAgICBmdW5GYWN0OiBcIldyaXR0ZW4gd2l0aCBncmFjZWZ1bCBjaXJjdWxhciBsZXR0ZXJzIHRoYXQgb3JpZ2luYXRlZCBmcm9tIGNhcnZpbmcgaW5zY3JpcHRpb25zIG9uIGZyYWdpbGUgcGFsbSBsZWF2ZXMuXCJcbiAgfSxcbiAge1xuICAgIGlkOiAnbmUnLFxuICAgIHBocmFzZTogJ+CkriDgpKTgpL/gpK7gpYDgpLLgpL7gpIgg4KSu4KS+4KSv4KS+IOCkl+CksOCljeCkm+ClgScsXG4gICAgbGFuZ3VhZ2U6ICdOZXBhbGknLFxuICAgIG5hdGl2ZTogJ+CkqOClh+CkquCkvuCksuClgCcsXG4gICAgcHJvbnVuY2lhdGlvbjogJ21hIHRpbcSrbMSBxKsgbcSBecSBIGdhcmNodScsXG4gICAgcmVnaW9uOiAnQXNpYScsXG4gICAgZmxhZzogJ/Cfh7Pwn4e1JyxcbiAgICBmdW5GYWN0OiBcIlRoZSB3b3JkICdNxIF5xIEnIGNhcnJpZXMgYm90aCBzd2VldCByb21hbnRpYyBsb3ZlIGFuZCB0aGUgbXlzdGljYWwsIG1hZ2ljYWwgYmVhdXR5IG9mIHRoZSBjb3Ntb3MuXCJcbiAgfVxuXTtcblxuZXhwb3J0IGNvbnN0IENPTE9SX1RIRU1FUyA9IFtcbiAge1xuICAgIGlkOiAnY3JpbXNvbicsXG4gICAgbmFtZTogJ0V0ZXJuYWwgQ3JpbXNvbicsXG4gICAgZGVzY3JpcHRpb246ICdDbGFzc2ljIHBhc3Npb25hdGUgdmVsdmV0IHJ1YnkgcmVkIHdpdGggZW1lcmFsZCBzdGVtJyxcbiAgICBwZXRhbENvbG9yczogWycjZmYxNzQ0JywgJyNmNDNmNWUnLCAnI2UxMWQ0OCcsICcjYmUxMjNjJywgJyNmZGE0YWYnLCAnI2ZiNzE4NSddLFxuICAgIHN0ZW1Db2xvcnM6IFsnIzEwYjk4MScsICcjMDU5NjY5JywgJyMzNGQzOTknLCAnIzIyYzU1ZScsICcjODZlZmFjJ10sXG4gICAgZ2xvd0NvbG9yOiAncmdiYSgyNDQsIDYzLCA5NCwgMC42KScsXG4gICAgc3BhcmtsZUNvbG9yOiAnI2ZiNzE4NScsXG4gICAgYW1iaWVudEJnOiAncmFkaWFsLWdyYWRpZW50KGVsbGlwc2UgYXQgNTAlIDMwJSwgcmdiYSgxNTksIDE4LCA1NywgMC4yMikgMCUsIHJnYmEoMTUsIDIsIDcsIDAuOTgpIDc1JSknXG4gIH0sXG4gIHtcbiAgICBpZDogJ21pZG5pZ2h0JyxcbiAgICBuYW1lOiAnTWlkbmlnaHQgQW1ldGh5c3QnLFxuICAgIGRlc2NyaXB0aW9uOiAnTXlzdGljYWwgdHdpbGlnaHQgdmlvbGV0IGFuZCBsdW1pbm91cyBsaWxhYyBnbG93JyxcbiAgICBwZXRhbENvbG9yczogWycjYzA4NGZjJywgJyNhODU1ZjcnLCAnIzkzMzNlYScsICcjN2UyMmNlJywgJyNlOWQ1ZmYnLCAnI2Q4YjRmZSddLFxuICAgIHN0ZW1Db2xvcnM6IFsnIzA2YjZkNCcsICcjMDg5MWIyJywgJyMyMmQzZWUnLCAnIzE0YjhhNiddLFxuICAgIGdsb3dDb2xvcjogJ3JnYmEoMTY4LCA4NSwgMjQ3LCAwLjY1KScsXG4gICAgc3BhcmtsZUNvbG9yOiAnI2U5ZDVmZicsXG4gICAgYW1iaWVudEJnOiAncmFkaWFsLWdyYWRpZW50KGVsbGlwc2UgYXQgNTAlIDMwJSwgcmdiYSg4OCwgMjgsIDEzNSwgMC4yNSkgMCUsIHJnYmEoNywgMywgMTUsIDAuOTgpIDc1JSknXG4gIH0sXG4gIHtcbiAgICBpZDogJ2dvbGRlbicsXG4gICAgbmFtZTogJ1N1bnNldCBHb2xkICYgQW1iZXInLFxuICAgIGRlc2NyaXB0aW9uOiAnV2FybSBnb2xkZW4gaG91ciByYWRpYW5jZSB3aXRoIGhvbmV5ICYgd2FybSBjb3BwZXInLFxuICAgIHBldGFsQ29sb3JzOiBbJyNmYmJmMjQnLCAnI2Y1OWUwYicsICcjZDk3NzA2JywgJyNiNDUzMDknLCAnI2ZkZTY4YScsICcjZmVmM2M3J10sXG4gICAgc3RlbUNvbG9yczogWycjNjVhMzBkJywgJyM0ZDdjMGYnLCAnIzg0Y2MxNicsICcjYTNlNjM1J10sXG4gICAgZ2xvd0NvbG9yOiAncmdiYSgyNDUsIDE1OCwgMTEsIDAuNjUpJyxcbiAgICBzcGFya2xlQ29sb3I6ICcjZmVmMDhhJyxcbiAgICBhbWJpZW50Qmc6ICdyYWRpYWwtZ3JhZGllbnQoZWxsaXBzZSBhdCA1MCUgMzAlLCByZ2JhKDE4MCwgODMsIDksIDAuMjUpIDAlLCByZ2JhKDE4LCAxMCwgMywgMC45OCkgNzUlKSdcbiAgfSxcbiAge1xuICAgIGlkOiAnZW5jaGFudGVkX3doaXRlJyxcbiAgICBuYW1lOiAnRW5jaGFudGVkIFNub3cgV2hpdGUnLFxuICAgIGRlc2NyaXB0aW9uOiAnUHVyZSBtb29ubGlnaHQgaXZvcnkgd2l0aCBjcnlzdGFsbGluZSBzaWx2ZXIgbHVtaW5lc2NlbmNlJyxcbiAgICBwZXRhbENvbG9yczogWycjZjhmYWZjJywgJyNmMWY1ZjknLCAnI2UyZThmMCcsICcjY2JkNWUxJywgJyNmZmZmZmYnLCAnI2UwZTdmZiddLFxuICAgIHN0ZW1Db2xvcnM6IFsnIzA1OTY2OScsICcjMTBiOTgxJywgJyMzNGQzOTknLCAnIzZlZTdiNyddLFxuICAgIGdsb3dDb2xvcjogJ3JnYmEoMjI2LCAyMzIsIDI0MCwgMC42KScsXG4gICAgc3BhcmtsZUNvbG9yOiAnI2ZmZmZmZicsXG4gICAgYW1iaWVudEJnOiAncmFkaWFsLWdyYWRpZW50KGVsbGlwc2UgYXQgNTAlIDMwJSwgcmdiYSg5OSwgMTAyLCAyNDEsIDAuMTgpIDAlLCByZ2JhKDUsIDcsIDE4LCAwLjk4KSA3NSUpJ1xuICB9LFxuICB7XG4gICAgaWQ6ICdjeWJlcnB1bmsnLFxuICAgIG5hbWU6ICdDeWJlciBSb21hbmNlJyxcbiAgICBkZXNjcmlwdGlvbjogJ0VsZWN0cmljIG5lb24gcGluaywgbGFzZXIgY3lhbiwgYW5kIGhvbG9ncmFwaGljIHN5bnRod2F2ZScsXG4gICAgcGV0YWxDb2xvcnM6IFsnI2ZmMDA3ZicsICcjZmYxNDkzJywgJyMwMGY1ZmYnLCAnI2ZmMzM5OScsICcjZmY2OWI0JywgJyMwMGU1ZmYnXSxcbiAgICBzdGVtQ29sb3JzOiBbJyMwMGZmY2MnLCAnIzAwZmZhYScsICcjMTBiOTgxJ10sXG4gICAgZ2xvd0NvbG9yOiAncmdiYSgyNTUsIDAsIDEyNywgMC43KScsXG4gICAgc3BhcmtsZUNvbG9yOiAnIzAwZjVmZicsXG4gICAgYW1iaWVudEJnOiAncmFkaWFsLWdyYWRpZW50KGVsbGlwc2UgYXQgNTAlIDMwJSwgcmdiYSgyNTUsIDAsIDEyNywgMC4yMikgMCUsIHJnYmEoNSwgMiwgMTgsIDAuOTgpIDc1JSknXG4gIH1cbl07XG4iXX0=