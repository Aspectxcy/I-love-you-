"""
Pink Rose In Every Language 🌹
Creative Coding Art / Python Tkinter Edition
Run with: python pink_rose.py
"""

import math as m
import random as r
import tkinter as tk
import time

W, H = 600, 800
DURATION = 10
TICK = 16
SCALE = 1
RECIPIENT = "My Love"

PHRASES = [
    "I love you", "Je t'aime", "Te amo", "Ti amo", "Ich liebe dich",
    "愛してる", "我爱你", "사랑해", "Я тебя люблю", "Seni seviyorum",
    "Mahal kita", "أحبك", "मैं तुमसे प्यार करता हूँ", "Eu te amo"
]

PETAL_COLORS = ["#ff1744", "#f43f5e", "#e11d48", "#be123c", "#fda4af"]
STEM_COLORS = ["#10b981", "#059669", "#34d399", "#22c55e"]
BG_COLOR = "#000000"

# Main Tkinter implementation...
