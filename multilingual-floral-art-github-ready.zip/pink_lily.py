"""
Pink Lily In Every Language 🌸
Creative Coding Art / Python Tkinter Edition
Run with: python pink_lily.py
"""

import math as m
import random as r
import tkinter as tk
import time

# --- Configuration ---
W, H = 600, 800
DURATION = 10  # seconds for full bloom
TICK = 16         # frame tick in ms (~60 FPS)
SCALE = 1       # canvas scale multiplier
RECIPIENT = "My Love"

# Multilingual Love Phrases
PHRASES = [
    "I LOVE YOU", "Je t'aime", "TE AMO", "TI AMO", "Ich liebe dich",
    "愛してる", "我爱你", "사랑해", "Я тебя люблю", "Seni seviyorum",
    "Mahal kita", "أحبك", "मैं तुमसे प्यार करता हूँ", "Eu te amo",
    "Σ' αγαπώ", "Ik hou van jou", "Kocham Cię", "Jag älskar dig",
    "Nakupenda", "Táim i ngrá leat", "Aloha au iā 'oe", "ฉันรักเธอ",
    "Anh yêu em", "Aku cinta kamu", "Szeretlek", "Te iubesc",
    "Miluji tě", "دوستت دارم", "Minä rakastan sinua", "Të dua",
    "Volim te", "AMOR", "LOVE", "Amour"
]

# Pink Lily Color Palette
PINK_PETAL_COLORS = ["#f472b6", "#ec4899", "#db2777", "#fda4af", "#fbcfe8", "#e11d48", "#f43f5e"]
STEM_COLORS = ["#22c55e", "#10b981", "#34d399", "#4ade80", "#15803d", "#16a34a"]
GOLD_ANTHER = "#f59e0b"
BG_COLOR = "#000000"


class PinkLilyApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Pink Lily In Every Language 🌸")
        self.root.geometry(f"{W}x{H}")
        self.root.configure(bg=BG_COLOR)

        self.canvas = tk.Canvas(root, width=W, height=H, bg=BG_COLOR, highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)

        self.elements = self.generate_lily_elements()
        self.elements.sort(key=lambda el: el["order"])

        self.start_time = time.time()
        self.drawn_count = 0

        # Title Header
        self.canvas.create_text(
            W // 2, 40,
            text="Pink Lily In Every Language",
            fill="#fbcfe8",
            font=("Georgia", 16, "italic bold")
        )

        self.animate()

    def generate_lily_elements(self):
        elems = []
        cx = W // 2
        cy = int(H * 0.36)
        scale = min(W, H) / 520 * SCALE
        p_idx = 0

        def next_phrase():
            nonlocal p_idx
            p = PHRASES[p_idx % len(PHRASES)]
            p_idx += 1
            return p

        # 1. Stem (Vertical column of horizontal green words as seen in reference image)
        stem_top_y = cy + int(24 * scale)
        stem_bottom_y = int(H * 0.90)
        stem_step = int(17 * scale)

        for y in range(stem_top_y, stem_bottom_y, max(1, stem_step)):
            t = (y - stem_top_y) / (stem_bottom_y - stem_top_y)
            stem_x = cx + int(m.sin(t * m.pi * 1.2) * (10 * scale))
            words_in_row = 2 if 0.15 < t < 0.65 else 1
            offsets = [-int(14 * scale), int(14 * scale)] if words_in_row == 2 else [0]

            for ox in offsets:
                phrase = next_phrase()
                word = phrase if len(phrase) <= 12 else phrase[:11]
                elems.append({
                    "text": word,
                    "x": stem_x + ox, "y": y,
                    "color": STEM_COLORS[(y // 15) % len(STEM_COLORS)],
                    "size": int(11 * scale) if r.random() > 0.4 else int(9.5 * scale),
                    "order": t * 0.32
                })

        # 2. Leaves (Graceful lanceolate foliage)
        for side, sign in [("left", -1), ("right", 1)]:
            leaf_y = cy + int((130 if sign == -1 else 205) * scale)
            for j in range(10):
                t = j / 9
                lx = cx + sign * int((10 + t * 105) * scale)
                ly = leaf_y + int(t * 50 * scale) - int(m.sin(t * m.pi) * (20 * scale))
                elems.append({
                    "text": next_phrase(),
                    "x": lx, "y": ly,
                    "color": STEM_COLORS[(j + 2) % len(STEM_COLORS)],
                    "size": int(10 * scale),
                    "order": (0.20 if sign == -1 else 0.25) + t * 0.18
                })

        # 3. Pink Lily Petals (6 Star Tepals)
        petal_angles = [
            -m.pi / 2,                  # 0: Top
            -m.pi / 2 + m.pi / 3,       # 1: Top Right
            -m.pi / 2 + 2 * m.pi / 3,   # 2: Bottom Right
            m.pi / 2,                   # 3: Bottom
            -m.pi / 2 + 4 * m.pi / 3,   # 4: Bottom Left
            -m.pi / 2 + 5 * m.pi / 3    # 5: Top Left
        ]
        max_petal_r = 175 * scale
        scan_r = int(185 * scale)
        row_h = int(15 * scale)
        col_w = int(48 * scale)

        for y in range(cy - scan_r, cy + scan_r, max(1, row_h)):
            for x in range(cx - scan_r, cx + scan_r, max(1, col_w)):
                jx = x + ((y // row_h % 2) * col_w // 2) + r.randint(-3, 3)
                jy = y + r.randint(-2, 2)
                dx, dy = jx - cx, jy - cy
                dist = m.sqrt(dx * dx + dy * dy)

                is_inside = False
                dist_ratio = 0.0

                if dist < 26 * scale:
                    is_inside = True
                    dist_ratio = dist / (26 * scale)
                else:
                    for i, p_ang in enumerate(petal_angles):
                        along = dx * m.cos(p_ang) + dy * m.sin(p_ang)
                        perp = abs(-dx * m.sin(p_ang) + dy * m.cos(p_ang))
                        if 12 * scale < along < max_petal_r:
                            t = along / max_petal_r
                            max_w = (42 if i in (0, 3) else 48) * scale
                            w_at_t = max_w * m.sin(t * m.pi) * ((1 - t * 0.45) ** 0.7)
                            if perp <= w_at_t:
                                is_inside = True
                                dist_ratio = t
                                break

                if is_inside:
                    phrase = next_phrase()
                    color = PINK_PETAL_COLORS[r.randint(0, len(PINK_PETAL_COLORS) - 1)]
                    elems.append({
                        "text": phrase,
                        "x": jx, "y": jy,
                        "color": color,
                        "size": int(13 * scale) if r.random() > 0.8 else int(10 * scale),
                        "order": 0.40 + dist_ratio * 0.55
                    })

        # 4. Golden Stamens & Anthers (Pollen tips)
        for idx, ang in enumerate(petal_angles):
            s_len = (48 + (idx % 2) * 12) * scale
            ax = cx + int(m.cos(ang) * s_len)
            ay = cy + int(m.sin(ang) * s_len * 0.88)
            elems.append({
                "text": f"✦ {next_phrase()[:7]} •",
                "x": ax, "y": ay,
                "color": GOLD_ANTHER,
                "size": int(10 * scale),
                "order": 0.92 + (idx / 6) * 0.08
            })

        return elems

    def animate(self):
        elapsed = time.time() - self.start_time
        progress = min(1.0, elapsed / max(1.0, DURATION))

        while self.drawn_count < len(self.elements):
            el = self.elements[self.drawn_count]
            if el["order"] <= progress:
                self.canvas.create_text(
                    el["x"], el["y"],
                    text=el["text"],
                    fill=el["color"],
                    font=("Helvetica", max(7, el["size"]), "bold")
                )
                self.drawn_count += 1
            else:
                break

        if progress < 1.0:
            self.root.after(TICK, self.animate)
        else:
            self.canvas.create_text(
                W // 2, H - 35,
                text="A pink lily that blooms your heart in every language. 🌸",
                fill="#fda4af",
                font=("Georgia", 11, "italic")
            )


if __name__ == "__main__":
    root = tk.Tk()
    app = PinkLilyApp(root)
    root.mainloop()
