# Pink Rose In Every Language 🌹

> *"What if a single rose could say 'I love you' in 60+ world languages?"*

An interactive creative coding art experience inspired by [@halo.ushaa](https://www.instagram.com/p/DejzdrYy0Za/), rendering blooming flowers (Pink Rose, Red Rose, Pink Lily, Sunflower, Royal Tulip) entirely from multilingual declarations of love.

![Preview](https://raw.githubusercontent.com/ayazsobhan/assets/main/rose-preview.png)

## ✨ Features

- **Multilingual Typographic Art**: Flowers composed entirely of horizontal, razor-sharp "I love you" phrases in 60+ languages (French, Japanese, Spanish, Hindi, Tagalog, Arabic, Swahili, Telugu, Russian, etc.).
- **Interactive Audio & Pronunciation**: Click/hover on any word to hear speech synthesis pronunciation, country flags, and romantic cultural lore.
- **Parametric Bloom Animation**: Play, pause, or scrub through the biological bloom timeline from root sprout to full star blossom.
- **Flower Switcher**: Pink Rose, Classic Red Rose, Stargazer Lily, Golden Sunflower, Royal Tulip, and Moonlight White Rose.
- **Python Creative Coding Studio**: Includes standalone runnable Python Tkinter scripts (`pink_rose.py`, `pink_lily.py`).
- **Love Dedication Cards**: Inscribe a loved one's name into the flower heart and export shareable postcards.

## 🚀 Running the Web App Locally

```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/multilingual-floral-art.git
cd multilingual-floral-art

# Install dependencies
npm install

# Start development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

## 🐍 Running Standalone Python Tkinter Scripts

You can also run the Python script directly on your computer (no web browser required):

```bash
python3 pink_rose.py
```

## 📜 License

MIT License. Created with love for creative coders worldwide.
